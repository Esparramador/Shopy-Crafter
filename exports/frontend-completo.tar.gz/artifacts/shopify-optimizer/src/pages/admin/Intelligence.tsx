import { useState, useEffect } from "react";
import { TrendingUp, TrendingDown, Zap, BarChart3, RefreshCw, Download, ShoppingCart } from "lucide-react";
import { useListProjects } from "@workspace/api-client-react";
import GenerationProgress from "@/components/GenerationProgress";
import ReferenceMediaPanel from "@/components/ReferenceMediaPanel";
import SaveToVaultButton from "@/components/SaveToVaultButton";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

function StatCard({ icon, label, value, delta, color = "var(--gold)" }: any) {
  return (
    <div className="glass-card" style={{ padding: "20px 24px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
        <span style={{ fontSize: 22 }}>{icon}</span>
        {delta !== undefined && (
          <span style={{
            fontSize: 12, fontWeight: 600,
            color: delta >= 0 ? "var(--jade)" : "var(--crim)",
            display: "flex", alignItems: "center", gap: 3,
          }}>
            {delta >= 0 ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
            {Math.abs(delta).toFixed(1)}%
          </span>
        )}
      </div>
      <div style={{ fontSize: 26, fontWeight: 700, color, letterSpacing: -1 }}>{value}</div>
      <div style={{ fontSize: 11, color: "var(--t3)", marginTop: 4 }}>{label}</div>
    </div>
  );
}

export default function Intelligence() {
  const { data: projects } = useListProjects();
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [summary, setSummary] = useState<any>(null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [referenceIntelligence, setReferenceIntelligence] = useState<string | null>(null);
  const [syncResult, setSyncResult] = useState<{ ok: boolean; totalRevenue?: number; totalOrders?: number; daysLoaded?: number; error?: string } | null>(null);

  useEffect(() => {
    if (!selectedProject && projects && projects.length > 0) {
      setSelectedProject(String(projects[0].id));
    }
  }, [projects]);

  useEffect(() => {
    if (selectedProject) loadData();
  }, [selectedProject]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [summaryRes, eventsRes] = await Promise.all([
        fetch(`${API_BASE}/api/intelligence/summary?projectId=${selectedProject}`, { credentials: "include" }),
        fetch(`${API_BASE}/api/intelligence/events?projectId=${selectedProject}&limit=20`, { credentials: "include" }),
      ]);
      setSummary(await summaryRes.json());
      setEvents(await eventsRes.json());
    } finally {
      setLoading(false);
    }
  };

  const runAnalysis = async () => {
    setAnalyzing(true);
    try {
      const res = await fetch(`${API_BASE}/api/intelligence/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          projectId: selectedProject,
          referenceContext: referenceIntelligence ?? undefined,
        }),
      });
      const data = await res.json();
      setAnalysis(data.analysis);
    } finally {
      setAnalyzing(false);
    }
  };

  const syncShopifyRevenue = async () => {
    if (!selectedProject) return;
    setSyncing(true);
    setSyncResult(null);
    try {
      const res = await fetch(`${API_BASE}/api/intelligence/sync-revenue`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ projectId: parseInt(selectedProject), days: 90 }),
      });
      const data = await res.json();
      setSyncResult(data);
      if (data.ok) await loadData();
    } catch {
      setSyncResult({ ok: false, error: "Error de conexión" });
    } finally {
      setSyncing(false);
    }
  };

  const exportCSV = () => {
    const BOM = "\uFEFF";
    const rows = [["Fecha", "Tipo", "Producto", "Revenue Delta"]];
    events.forEach(e => rows.push([
      new Date(e.createdAt).toLocaleDateString("es-ES"),
      e.eventType, e.productId || "-",
      e.revenueDelta ? `€${e.revenueDelta}` : "-",
    ]));
    const csv = BOM + rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(";")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Revenue_Intelligence_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: "var(--t)" }}>Revenue Intelligence 360°</h1>
          <p style={{ fontSize: 13, color: "var(--t3)", marginTop: 4 }}>Atribución de revenue por canal y análisis IA</p>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <select
            value={selectedProject}
            onChange={e => setSelectedProject(e.target.value)}
            className="input-field"
            style={{ width: "min(180px, 100%)" }}
          >
            {projects?.map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
          <SaveToVaultButton
            title={`Revenue Intelligence 360° — ${new Date().toLocaleDateString("es-ES")}`}
            content={`<h2>Revenue Intelligence</h2><p>Resumen de inteligencia de ingresos generado el ${new Date().toLocaleDateString("es-ES")}</p>`}
            fileType="financial"
            projectId={selectedProject || undefined}
            generatedBy="revenue_intel"
            variant="small"
            label="Guardar"
          />
          <button className="btn-secondary" onClick={exportCSV} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <Download size={14} /> CSV
          </button>
          <button
            onClick={syncShopifyRevenue}
            disabled={syncing || !selectedProject}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              background: syncing ? "var(--ink3)" : "rgba(45,212,159,0.12)",
              border: "1px solid rgba(45,212,159,0.3)",
              color: "var(--jade)", borderRadius: 8, padding: "8px 14px",
              cursor: syncing ? "not-allowed" : "pointer", fontSize: 13, fontWeight: 600,
              transition: "all 0.2s",
            }}
          >
            <ShoppingCart size={14} />
            {syncing ? "Sincronizando..." : "Sincronizar tienda"}
          </button>
          <button className="btn-primary" onClick={runAnalysis} disabled={analyzing || !selectedProject}
            style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <Zap size={14} />
            {analyzing ? "Analizando..." : "Analizar con IA"}
          </button>
        </div>
      </div>

      {syncResult && (
        <div style={{
          marginBottom: 16, padding: "12px 18px", borderRadius: 10,
          background: syncResult.ok ? "rgba(45,212,159,0.08)" : "rgba(232,69,88,0.08)",
          border: `1px solid ${syncResult.ok ? "rgba(45,212,159,0.25)" : "rgba(232,69,88,0.25)"}`,
          color: syncResult.ok ? "var(--jade)" : "var(--crim)",
          fontSize: 13, display: "flex", alignItems: "center", gap: 10,
        }}>
          {syncResult.ok ? (
            <>
              ✓ Sincronización completada — {syncResult.daysLoaded} días importados · {syncResult.totalOrders?.toLocaleString("es")} órdenes ·
              €{syncResult.totalRevenue?.toLocaleString("es", { minimumFractionDigits: 2 })} revenue real
            </>
          ) : (
            <>✕ Error sincronizando: {syncResult.error}</>
          )}
          <button onClick={() => setSyncResult(null)} style={{ marginLeft: "auto", background: "none", border: "none", cursor: "pointer", color: "inherit", fontSize: 16 }}>×</button>
        </div>
      )}

      <ReferenceMediaPanel
        projectId={selectedProject ? parseInt(selectedProject) : undefined}
        onIntelligenceReady={setReferenceIntelligence}
        context="Análisis de revenue e inteligencia de negocio eCommerce"
        collapsed
      />

      <GenerationProgress
        active={analyzing}
        operation="analysis"
        title="Shopy Crafter analizando tu tienda..."
        subtitle="Procesando revenue, atribución y oportunidades de crecimiento"
      />

      {loading ? (
        <div className="grid-r4" style={{ marginBottom: 24 }}>
          {[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: 110, borderRadius: 12 }} />)}
        </div>
      ) : (
        <div className="grid-r4" style={{ marginBottom: 24 }}>
          <StatCard icon="💰" label="Revenue Atribuido (30d)" value={`€${(summary?.totalAttributedRevenue ?? 0).toFixed(0)}`} delta={summary?.trend} />
          <StatCard icon="⚡" label="Eventos Registrados" value={summary?.totalEvents ?? 0} color="var(--jade)" />
          <StatCard icon="📈" label="Tendencia Semanal" value={summary?.trend ? `${summary.trend.toFixed(1)}%` : "—"} delta={summary?.trend} />
          <StatCard icon="🎯" label="Tienda Activa" value={summary?.storeName ?? "—"} color="var(--t)" />
        </div>
      )}

      <div className="grid-r2">
        <div className="glass-card">
          <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--ink3)" }}>
            <h3 style={{ fontSize: 14, fontWeight: 600, color: "var(--t)" }}>
              <BarChart3 size={14} style={{ marginRight: 6, display: "inline" }} />
              Eventos por Canal
            </h3>
          </div>
          <div style={{ padding: 20 }}>
            {Object.entries(summary?.eventBreakdown ?? {}).length === 0 ? (
              <div style={{ textAlign: "center", color: "var(--t3)", padding: 40 }}>
                <p style={{ fontSize: 13 }}>Sin datos aún. Los eventos se registrarán automáticamente al usar la plataforma.</p>
              </div>
            ) : Object.entries(summary?.eventBreakdown ?? {}).map(([type, count]) => (
              <div key={type} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontSize: 12, color: "var(--t2)", textTransform: "capitalize" }}>{type.replace(/_/g, " ")}</span>
                  <span style={{ fontSize: 12, fontWeight: 600, color: "var(--gold)" }}>{count as number}</span>
                </div>
                <div style={{ height: 4, background: "var(--ink3)", borderRadius: 2 }}>
                  <div style={{ height: "100%", background: "var(--gold)", borderRadius: 2, width: `${Math.min(100, (count as number) * 10)}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card">
          <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--ink3)" }}>
            <h3 style={{ fontSize: 14, fontWeight: 600, color: "var(--t)" }}>
              <RefreshCw size={14} style={{ marginRight: 6, display: "inline" }} />
              Últimos Eventos
            </h3>
          </div>
          <div style={{ padding: "8px 0", maxHeight: 280, overflowY: "auto" }}>
            {events.length === 0 ? (
              <p style={{ padding: "20px", textAlign: "center", fontSize: 13, color: "var(--t3)" }}>Sin eventos registrados</p>
            ) : events.map(e => (
              <div key={e.id} style={{
                padding: "10px 20px",
                borderBottom: "1px solid var(--ink3)",
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}>
                <div>
                  <p style={{ fontSize: 12, color: "var(--t)", textTransform: "capitalize" }}>{e.eventType.replace(/_/g, " ")}</p>
                  <p style={{ fontSize: 11, color: "var(--t3)" }}>{new Date(e.createdAt).toLocaleDateString()}</p>
                </div>
                {e.revenueDelta && (
                  <span style={{ fontSize: 12, fontWeight: 600, color: "var(--jade)" }}>+€{e.revenueDelta}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {analysis && (
        <div className="glass-card" style={{ marginTop: 20 }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--ink3)" }}>
            <h3 style={{ fontSize: 14, fontWeight: 600, color: "var(--gold)" }}>⚡ Análisis IA — Revenue Intelligence</h3>
          </div>
          <div style={{ padding: 20 }}>
            <p style={{ fontSize: 13, color: "var(--t2)", marginBottom: 16, lineHeight: 1.6 }}>{analysis.summary}</p>
            {analysis.topInsights?.length > 0 && (
              <>
                <h4 style={{ fontSize: 12, fontWeight: 600, color: "var(--t3)", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>Top Insights</h4>
                <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
                  {analysis.topInsights.map((insight: string, i: number) => (
                    <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                      <span style={{ color: "var(--gold)", fontSize: 16 }}>◆</span>
                      <p style={{ fontSize: 13, color: "var(--t2)", lineHeight: 1.5 }}>{insight}</p>
                    </div>
                  ))}
                </div>
              </>
            )}
            {analysis.recommendations?.length > 0 && (
              <>
                <h4 style={{ fontSize: 12, fontWeight: 600, color: "var(--t3)", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>Recomendaciones</h4>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {analysis.recommendations.map((rec: any, i: number) => (
                    <div key={i} style={{
                      background: "var(--ink3)", borderRadius: 8, padding: "10px 14px",
                      borderLeft: `3px solid ${rec.priority === "high" ? "var(--crim)" : rec.priority === "medium" ? "var(--gold)" : "var(--jade)"}`,
                    }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                        <span style={{ fontSize: 12, fontWeight: 600, color: "var(--t)" }}>{rec.action}</span>
                        <span style={{
                          fontSize: 10, padding: "2px 6px", borderRadius: 4,
                          background: rec.priority === "high" ? "rgba(220,53,69,0.15)" : "rgba(200,168,75,0.15)",
                          color: rec.priority === "high" ? "var(--crim)" : "var(--gold)",
                          fontWeight: 600,
                        }}>{rec.priority?.toUpperCase()}</span>
                      </div>
                      <p style={{ fontSize: 11, color: "var(--t3)" }}>{rec.impact}</p>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
