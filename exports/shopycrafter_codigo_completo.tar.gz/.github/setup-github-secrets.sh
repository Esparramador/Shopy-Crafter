#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# ShopyBrain — Configura todos los secretos en GitHub Actions de una vez
# Requisito: tener instalado GitHub CLI (gh) y estar autenticado (gh auth login)
#
# Uso:
#   chmod +x .github/setup-github-secrets.sh
#   REPO=tu-usuario/tu-repo ./github/setup-github-secrets.sh
#
# O edita REPO directamente aquí abajo:
# ─────────────────────────────────────────────────────────────────────────────

REPO="${REPO:-TU_USUARIO/TU_REPO}"

echo "Configurando secretos en: $REPO"
echo ""

set_secret() {
  local name="$1"
  local value="$2"
  if [ -z "$value" ]; then
    echo "  ⚠  $name — vacío, saltando"
    return
  fi
  echo "$value" | gh secret set "$name" --repo "$REPO"
  echo "  ✅ $name"
}

# ── Secretos de la app ────────────────────────────────────────────────────────
set_secret "DATABASE_URL"                    "$DATABASE_URL"
set_secret "ANTHROPIC_API_KEY"               "$ANTHROPIC_API_KEY"
set_secret "KLAVIYO_API_KEY"                 "$KLAVIYO_API_KEY"
set_secret "SHOPIFY_CLIENT_ID"               "$SHOPIFY_CLIENT_ID"
set_secret "SHOPIFY_CLIENT_SECRET"           "$SHOPIFY_CLIENT_SECRET"
set_secret "SHOP_DOMAIN"                     "$SHOP_DOMAIN"
set_secret "STOREFRONT_ACCESS_TOKEN"         "$STOREFRONT_ACCESS_TOKEN"
set_secret "ENCRYPTION_KEY"                  "$ENCRYPTION_KEY"
set_secret "DEFAULT_OBJECT_STORAGE_BUCKET_ID" "$DEFAULT_OBJECT_STORAGE_BUCKET_ID"
set_secret "REPLICATE_API_TOKEN"             "$REPLICATE_API_TOKEN"
set_secret "PRIVATE_OBJECT_DIR"              "$PRIVATE_OBJECT_DIR"
set_secret "PUBLIC_OBJECT_SEARCH_PATHS"      "$PUBLIC_OBJECT_SEARCH_PATHS"

# ── URL para el APK (obligatorio para el build Android) ──────────────────────
echo ""
echo "Introduce la URL de tu app desplegada en Replit (ej: https://shopybrain-xxx.replit.app):"
read -r APP_URL_INPUT
set_secret "APP_URL" "$APP_URL_INPUT"

echo ""
echo "Secretos configurados en $REPO"
echo "Ahora ve a: https://github.com/$REPO/actions y lanza el workflow 'Build ShopyBrain APK'"
