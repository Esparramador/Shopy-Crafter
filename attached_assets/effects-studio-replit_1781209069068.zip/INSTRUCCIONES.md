# Effects Studio — Instrucciones de implantación en Replit / Shofy Crafter
# =========================================================================

## Archivos a copiar (3 ficheros nuevos):

1. `backend/_visme_effects_engine.py`
   → Colócalo en la carpeta `backend/` de tu proyecto Shofy Crafter

2. `admin/effects-studio.html`
   → Colócalo en la carpeta `admin/` de tu proyecto

3. `backend/data/prompt_vault/templates/visme_templates.json`
   → Colócalo en `backend/data/prompt_vault/templates/`
   → Si la carpeta no existe, créala.

---

## Edición manual en main.py (busca y añade):

Busca en `main.py` esta línea:
```
# ═══ CLAUDE DESIGNER (claude.ai/design replica) ═══
```

Justo ANTES de esa línea, añade este bloque completo:

```python
# ═══ VISME EFFECTS ENGINE (594 Visme + 30 snippets + Aceternity + Stitch + TypeGPU) ═══
try:
    from _visme_effects_engine import register_visme_engine
    _ve_result = register_visme_engine(app)
    _module_status["loaded"].append("visme_effects_engine")
    print(f"[CRAFTER] [OK] Visme Effects Engine → {_ve_result.get('builtin_snippets',0)} snippets + {_ve_result.get('visme_templates',0)} Visme + {_ve_result.get('effects_prompts',0)} FX prompts")
except Exception as _e:
    _module_status["failed"].append("visme_effects_engine")
    _module_status["errors"]["visme_effects_engine"] = str(_e)
    print(f"[CRAFTER] [FAIL] FAILED: visme_effects_engine - {_e}")
```

---

## Edición manual en admin/app.html (busca y añade):

Busca esta línea en el sidebar:
```html
<a class="nav-item is-gold" data-view="verticals-studio" ...>Verticals Studio</a>
```

Justo DESPUÉS de esa línea, añade:
```html
<a class="nav-item is-gold" data-view="effects-studio" onclick="loadView('effects-studio','/effects-studio')"><span class="ic">✦</span><span class="l-text">Effects Studio</span></a>
```

---

## Variables de entorno necesarias:

El motor usa las mismas keys que ya tienes configuradas:
- `ANTHROPIC_API_KEY` — para generación con IA (endpoints /generate y /compose)
- `ANTHROPIC_MODEL` — opcional, por defecto "claude-sonnet-4-6"

Los 30 snippets pre-built NO necesitan API key (funcionan offline/instantáneos).

---

## URLs disponibles tras la implantación:

- `/effects-studio`           → UI del Effects Studio
- `GET  /api/visme/categories`  → 65 categorías Visme + totales
- `GET  /api/visme/snippets`    → 30 snippets pre-built
- `GET  /api/visme/templates`   → búsqueda unificada (Visme + snippets + Stitch)
- `POST /api/visme/preview-snippet` → preview instantáneo (sin API)
- `POST /api/visme/generate`    → genera HTML real con Claude
- `POST /api/visme/compose`     → compone múltiples efectos en 1 página
- `POST /api/visme/inject`      → inyecta efectos en HTML existente
- `GET  /api/visme/stats`       → totales del catálogo

---

## ¿Qué hace el Effects Studio?

- Navegador de 1000+ efectos visuales (Visme × 594, pre-built × 30, Stitch, etc.)
- DNA form: aplica colores, fuente, nombre de marca a cada efecto
- Modo Explorar: genera un efecto individual como HTML/CSS/JS ejecutable
- Modo Componer: selecciona hasta 8 efectos → Claude los fusiona en 1 landing page
- Preview fullscreen con iframe sandboxed
- Copiar HTML / Guardar en Vault

## Dependencias Python (ya en requirements.txt si usas FastAPI + httpx):
- fastapi
- httpx
- pathlib (stdlib)
- json (stdlib)