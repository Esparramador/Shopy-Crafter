# Auditoría con contexto real del producto

Tras tu explicación, la arquitectura cambia de "62 endpoints huérfanos" a "el producto está mejor diseñado de lo que yo asumía pero hay 8 problemas reales que arreglar".

---

## 1. Plans/créditos — modelo de negocio: lead-gen, NO compra directa

### Tu modelo (verificado en código)

- Cliente entra a `landing` → ve `fp-pricing` (planes Starter/Agency Pro/Enterprise) y `fp-calculator` (calculadora de packs)
- Click en "Solicitar presupuesto" → scroll al formulario `fp-contact` (`Landing.tsx:149`)
- Form envía a `POST /api/contact` con: name, email, phone, storeUrl, niche, revenue, **services[]**, socialMedia, message, productImageUrl
- `routes/contact.ts` recibe el lead, dispara research vía Gemini + Claude, te envía PDF a `craftershopy@gmail.com` y subscribe el lead a Klaviyo
- **Tú** decides manualmente: aceptar el cliente → enviarle invite link → asignar plan vía `PUT /api/projects/:id/plan`

### Conclusión sobre los 6 endpoints `/plan/*`

**NO necesitan UI pública** porque el cliente no compra desde la app — compra desde la landing. Esos endpoints son **herramientas internas tuyas para gestionar planes desde el panel admin**.

#### ✅ Lo que YA funciona bien
- `checkProductionLimit()` se llama en **9 lugares críticos**: redesign, fusion-studio (ambos handlers), images (single + bulk), reference-images (2 handlers), shopybrain. **Antes de cualquier generación de IA, se valida el plan.** Esto está bien diseñado.
- Si el plan se agota, devuelve `{ allowed: false, reason: "..." }` y la UI muestra error.
- `recordUsage()` decrementa créditos y/o cuenta consumo mensual.

#### 🟡 Lo que falta (panel admin, no cliente)
- **El admin (tú) no tiene UI para:**
  1. Ver el plan actual de cada proyecto y consumo del mes (`GET /api/projects/:id/plan`)
  2. Cambiar plan de un proyecto manualmente (`PUT /api/projects/:id/plan`)
  3. Agregar packs comprados (cuando un cliente paga vía Stripe/transferencia, tú asignas pack vía `POST /api/projects/:id/plan/credits`)
  4. Ver qué packs están disponibles (`GET /api/plans/definitions`)
  5. Resetear contador mensual si hace falta (`POST /api/projects/:id/plan/reset-usage`)

**Solución:** Una pestaña/modal nueva dentro de `AdminClients.tsx` cuando abres un cliente — "Plan & Créditos del proyecto X" — accesible solo para ti como admin. NO va en la landing.

### 🔴 Bug grave detectado en push.ts:8

```ts
const subscriptions: Map<string, any> = new Map();
```

**Las suscripciones push se guardan en RAM**, no en BD. Al reiniciar el servidor (deploy, autoscale en Replit, OOM kill) se pierden todas. El usuario tendría que volver a aceptar el permiso del navegador.

**Y no se usa la VAPID privateKey en `/push/send`** — el handler devuelve `{ ok: true }` pero nunca llama a `webpush.sendNotification(sub, payload, { vapidDetails: ... })`. **La notificación nunca sale del servidor.** Es un endpoint stub que finge funcionar.

---

## 2. Shopify OAuth — confirmado: no se usa en tu modelo

Tú accedes como admin con credentials manuales (Custom App de Shopify), creas el proyecto, y mandas invite al cliente. El flujo OAuth `start/callback/check` en `routes/projects.ts` es código heredado.

**Recomendación:** dejar el código, no tocarlo, no añadir UI. Si el día de mañana abres self-service para que clientes conecten su tienda directamente, ya está listo el handler.

---

## 3. ShopyBrain — sí absorbe TODO, brain-sync es cli/admin

### Verificado
- **30 routers diferentes** llaman a `learnFromOperation()` — desde audit, redesign, fusion-studio, generator, emails, klaviyo-ai, products, competitors, voice, consistency, images, absorber, action-buttons, projects, pricing, seo, exports, ab-testing, reference-images, web-lab, contact, shopybrain, intelligence, agency, entity-research, inventory, hasta cms.
- **133 invocaciones totales** de absorción a lo largo del backend.
- Cada operación significativa (audit run, image generation, redesign, email creation, pricing analysis, competitor scan, brand research) **alimenta el brain automáticamente**.

### Lo de brain-sync (11 endpoints) NO es funcionalidad de cliente, es **mantenimiento avanzado tuyo**:
- `brain-export/{knowledge,domains,prompts}` — para hacer backup del cerebro o llevarlo a otro entorno
- `brain-import` y `brain-import/ndjson` — restaurar backup o importar conocimiento externo en bulk
- `brain-sync` — sincronizar con otra instancia (sandbox → prod, p.ej.)
- `brain-stats` — ver qué tiene el cerebro acumulado
- `brain-inject-self-knowledge` — bootstrap inicial

**El dispatcher ShopyBrain ya las invoca desde 3 sitios** (`shopybrain.ts:7319, 7338, 7355`) — son `syncFromExternalBrain`, `getBrainStats`, `getExportData`. Es decir: **están conectadas vía OmniChatbot**, solo te falta UI directa para hacer un backup manual cuando quieras.

**Recomendación:** página simple `/admin/brain-sync` con 3 botones (Export, Import, Sync) + display de stats. ~150 líneas. Solo tú como admin la usarías.

---

## 4. Klaviyo — el flujo SÍ está bien hecho, solo hay redundancia

### Lo que funciona hoy
- `Emails.tsx:296 pushToKlaviyo()` → `POST /api/emails/flows/:id/push` (registrado en `email-templates.ts`)
- `EmailTemplates.tsx:346` → `POST /api/email-templates/:id/push-klaviyo`
- `OmniChatbot.tsx:1720` → `POST /api/klaviyo-ai/generate-workflow`
- `routes/contact.ts` → suscribe leads vía `klaviyo-headers.ts`

### Los 10 endpoints `/api/klaviyo/*` directos
Son **wrappers REST low-level** sobre la API de Klaviyo que **no se usan desde la UI** porque `emails.ts` y `klaviyo-ai.ts` ya hacen las llamadas a Klaviyo internamente.

**Diagnóstico:** son dead code. El UI usa el flujo correcto (high-level vía `email-templates` + `klaviyo-ai`). Los 10 endpoints directos son redundantes y se pueden borrar sin riesgo.

**Recomendación:** **borrar `routes/klaviyo.ts`** (200 líneas). Confirmar primero que `lib/klaviyo-headers.ts` que usan `email-templates.ts` y `contact.ts` no dependa de nada de ahí.

```bash
# Verificar antes de borrar:
grep -rn "from.*klaviyo\.js" routes/ lib/
# Si solo aparece routes/klaviyo.ts importándose en routes/index.ts → safe to delete
```

---

## 5. Push send/subscribe — bugs reales encontrados

### 🔴 BUG 1: Subscriptions en RAM (línea 8 de push.ts)
Ya descrito arriba. Se pierden todas al reiniciar.

**Fix:**
```ts
// Cambiar Map<userId, subscription> por tabla pushSubscriptionsTable en BD
// o al menos por Redis. Lo mínimo: usar la session store PG existente.
```

### 🔴 BUG 2: `/push/send` no envía nada (línea 60)
El handler retorna `{ ok: true, message: "Notification queued" }` pero **no invoca `webpush.sendNotification()`** ni nada. La notificación nunca llega al navegador.

**Faltante:** instalar `web-push` package y enviar de verdad:
```ts
import webpush from "web-push";
webpush.setVapidDetails("mailto:admin@…", publicKey, privateKey);
await webpush.sendNotification(sub, JSON.stringify({ title, body }));
```

### 🟡 No hay UI cliente que se suscriba (Service Worker + permission request)
- `AdminSettings.tsx` solo configura las VAPID keys (admin)
- **No existe** componente que haga `Notification.requestPermission()` + `navigator.serviceWorker.register()` + `pushManager.subscribe()` y luego envíe a `/push/subscribe`
- Sin eso, ningún usuario está suscrito → `/push/send` siempre dará 404 "No subscription found"

**Decisión necesaria:** ¿activar push notifications **ahora** o **borrar** los handlers? Si lo activas: necesito subir un `service-worker.js` al `/public`, añadir hook `usePushSubscription()` en el cliente, conectar el botón "Activar notificaciones" en `client/Settings` o donde quieras.

---

## 6. Audit dispatcher vs dedicated — confirmación que SÍ son duplicados pero diferentes

### Diferencias técnicas verificadas:
- **`routes/audit.ts /audit/run`** (235 líneas) → usa `UniversalAuditConnector` (clase universal multi-plataforma: Shopify, WooCommerce, PrestaShop, custom). Hace `runFullAudit()` con PageSpeed + scraping + Claude analysis. **Funciona para cualquier tienda incluso sin ser Shopify.**
- **`routes/shopybrain.ts case "audit_store"`** (250+ líneas) → usa **solo Shopify GraphQL** directo (`shopifyGraphQL()`). Pagina productos, lee variants, images, SEO. **Solo funciona con Shopify nativo.**

### Lo que invoca `Audit.tsx`
**Cero llamadas a `/audit/run`**. Todas son a `/api/shopybrain/execute-action` (líneas 809, 831, 852).

### Diagnóstico
Son 2 implementaciones distintas para el mismo concepto. La UI usa la versión **Shopify-only** vía dispatcher, ignorando la versión universal.

**Decisión correcta** (la que debes tomar tú):
- **Opción A (mi recomendación):** mantener `audit.ts /audit/run` porque es **multi-plataforma** y mejorar Audit.tsx para que use éste cuando el proyecto NO sea Shopify. Esto cubre los proyectos WooCommerce/PrestaShop/Universal que mencionabas. El dispatcher `audit_store` se queda solo para tiendas Shopify (más ricas en datos vía GraphQL).
- **Opción B:** borrar `routes/audit.ts` completo y solo soportar Shopify para auditoría.

Como tú dices que la app soporta **Shopify/WooCommerce/PrestaShop/Universal**, la **Opción A es la correcta**. Significa modificar `Audit.tsx:809` para que decida según `project.platform`:
```ts
const endpoint = project.platform === "shopify"
  ? `/api/shopybrain/execute-action`  // dispatcher Shopify
  : `/api/projects/${projectId}/audit/run`;  // universal
```

---

## 7. Tabla resumen de los 7 clusters CON CONTEXTO REAL

| Cluster | Estado real | Acción correcta |
|---|---|---|
| **Plans/créditos** | Backend funciona, guards activos, falta UI **interna admin** | Modal en `AdminClients.tsx` para gestionar plan/packs por cliente. ~250 líneas |
| **Shopify OAuth** | Code heredado, no se usa en modelo invite-only | **NO TOCAR**, dejar dormido |
| **Brain absorption** | Funciona perfectamente (30 routers absorbiendo) | **NO TOCAR** |
| **Brain sync admin** | Conectado vía dispatcher, falta UI directa | Página simple `/admin/brain-sync` con 3 botones. ~150 líneas |
| **Klaviyo REST directo** | Redundante con `emails.ts` + `klaviyo-ai.ts` | **BORRAR `routes/klaviyo.ts`** (~200 líneas backend menos) |
| **Push notifications** | **2 BUGS GRAVES**: RAM-only + send stub | Decidir: activar (subir SW + UI cliente + arreglar handler) o borrar |
| **Audit dedup** | NO son duplicados literales — uno universal, uno Shopify-only | Modificar `Audit.tsx` para usar el correcto según plataforma |

---

## 8. Hallazgos NUEVOS de esta pasada (suman a los 33 del informe original)

### 🔴 C6 nuevo crítico: `routes/push.ts:8` `subscriptions: Map<>` en RAM
- Se pierden todas las suscripciones al reiniciar el servidor
- `/push/send` no llama `webpush.sendNotification` — endpoint stub, nada se entrega

### 🟠 A15 nuevo alto: `routes/audit.ts` no se usa, pero **debería usarse para no-Shopify**
- Tu app soporta WooCommerce/PrestaShop/Universal
- El dispatcher Shopify-only no funciona para esas plataformas
- El `audit/run` universal **es la solución correcta para esos casos** y está sin enchufar

### 🟠 A16 nuevo alto: `routes/klaviyo.ts` redundante
- 200 líneas de wrappers REST que duplican lo que `klaviyo-ai.ts` y `emails.ts` ya hacen mejor
- Borrar limpia el backend y no rompe nada

### 🟡 M11 nuevo medio: Brain-sync admin tools sin UI directa
- Funcionalidad core (export/import del cerebro) accesible solo vía OmniChatbot
- Una UI simple permite backup manual cuando lo necesites

---

## 9. Total real

| Score actualizado tras esta pasada |
|---|

- **🔴 Críticos:** **6** (era 5 — añade C6 push roto)
- **🟠 Altos:** **16** (era 14 — añade A15 audit no-Shopify huérfano + A16 klaviyo redundante)
- **🟡 Medios:** **11** (era 10 — añade M11 brain-sync sin UI directa)
- **🟢 Bajos:** 4
- **Total:** **37 findings**

Lo que de verdad necesitas hacer **YA**:
1. Fix C6: arreglar push.ts (pasar subscripciones a BD + invocar webpush real)  o borrarlo si no lo vas a usar
2. Fix A15: modificar `Audit.tsx:809` para usar el endpoint correcto según plataforma
3. Fix A16: borrar `routes/klaviyo.ts` (verificar que `lib/klaviyo-headers.ts` no lo importe)
4. UI nueva 1: modal de plans/créditos en `AdminClients.tsx`
5. UI nueva 2: página `/admin/brain-sync` con export/import/stats
6. Decisión sobre push notifications: implementar o borrar

Los 5 quick wins anteriores (Billing al router, Impersonate, FusionStudio create-product, Revenue PATCH→PUT, AndroidManifest) **siguen vigentes y aplicables** independientemente.
