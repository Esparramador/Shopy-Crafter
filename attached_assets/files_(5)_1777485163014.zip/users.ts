/**
 * FIX BE-2, BE-3, BE-4: schema de users actualizado.
 *
 * Cambios:
 * - clientId ahora INTEGER con FK a projects + onDelete: "set null"
 * - inviteToken y resetToken con índice UNIQUE
 * - Índices en email, clientId, role para queries frecuentes
 *
 * APLICAR EN: lib/db/src/schema/users.ts
 *
 * REQUIERE: antes aplicar migrations/bloque-e-indices-and-types.sql
 * (si no, drizzle intentará convertir tipos y puede fallar con datos existentes).
 *
 * Tras aplicar este archivo:
 *   cd lib/db && pnpm drizzle-kit generate
 */

import { pgTable, text, integer, timestamp, index, uniqueIndex } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";

export const usersTable = pgTable("users", {
  id: text("id").primaryKey(),
  email: text("email").unique().notNull(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().$type<"admin" | "client">(),
  // FIX BE-2: INTEGER + FK en vez de TEXT libre
  clientId: integer("client_id").references(() => projectsTable.id, { onDelete: "set null" }),
  isActive: integer("is_active").default(1).notNull(),
  avatarColor: text("avatar_color").default("#5b4eff"),
  inviteToken: text("invite_token"),
  inviteExpires: timestamp("invite_expires"),
  resetToken: text("reset_token"),
  resetExpires: timestamp("reset_expires"),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  // FIX BE-3: índices en tokens para lookup rápido
  idxInviteToken: uniqueIndex("users_invite_token_idx").on(table.inviteToken),
  idxResetToken: uniqueIndex("users_reset_token_idx").on(table.resetToken),
  idxClientId: index("idx_users_client_id").on(table.clientId),
  idxRole: index("idx_users_role").on(table.role),
}));

// FIX BE-4: projectId como INTEGER en audit_log + índices
export const auditLogTable = pgTable("audit_log", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  projectId: integer("project_id").references(() => projectsTable.id, { onDelete: "set null" }),
  action: text("action").notNull(),
  details: text("details"),
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  idxUserCreated: index("idx_audit_user_created").on(table.userId, table.createdAt),
  idxProjectCreated: index("idx_audit_project_created").on(table.projectId, table.createdAt),
  idxAction: index("idx_audit_action").on(table.action),
}));

// FIX BE-4 + BE-14: projectId como INTEGER + cascade
export const approvalsTable = pgTable("approvals", {
  id: text("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projectsTable.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  beforeValue: text("before_value"),
  afterValue: text("after_value"),
  reasoning: text("reasoning"),
  estimatedImpact: text("estimated_impact"),
  status: text("status").notNull().default("pending").$type<"pending" | "approved" | "rejected">(),
  clientComment: text("client_comment"),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  idxProjectStatus: index("idx_approvals_project_status").on(table.projectId, table.status),
}));

export const rateLimitsTable = pgTable("rate_limits", {
  key: text("key").primaryKey(),
  count: integer("count").notNull().default(0),
  blockedUntil: timestamp("blocked_until"),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  idxBlocked: index("idx_rate_limits_blocked").on(table.blockedUntil),
}));

// FIX BE-4 + BE-20: projectId como INTEGER + cascade + índices
export const messagesTable = pgTable("messages", {
  id: text("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projectsTable.id, { onDelete: "cascade" }),
  fromRole: text("from_role").notNull().$type<"admin" | "client">(),
  fromName: text("from_name").notNull(),
  content: text("content").notNull(),
  isRead: integer("is_read").default(0),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  idxProjectCreated: index("idx_messages_project_created").on(table.projectId, table.createdAt),
  idxUnread: index("idx_messages_unread").on(table.projectId, table.isRead),
}));

// FIX BE-11: tabla nueva para OAuth states (sustituye Map en memoria)
export const oauthStatesTable = pgTable("oauth_states", {
  state: text("state").primaryKey(),
  data: text("data").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  idxExpires: index("idx_oauth_states_expires").on(table.expiresAt),
}));
