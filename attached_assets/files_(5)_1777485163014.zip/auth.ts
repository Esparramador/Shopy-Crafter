/**
 * FIX BE-5: User enumeration via timing attack en /login.
 *
 * Problema original: el delay artificial (200ms) estaba ANTES del lookup,
 * y bcrypt.compare solo se ejecutaba si el email existía. Tiempo observable
 * diferente → enumerar emails válidos.
 *
 * Fix: siempre ejecutar bcrypt.compare (con un hash dummy si el user no existe).
 * Tiempo constante independiente de si el email existe o no.
 *
 * APLICAR EN: artifacts/api-server/src/routes/auth.ts
 * Reemplaza el router.post("/login", ...) completo (líneas 60-115 aprox).
 *
 * También incluye:
 * - FIX BE-5 bis: rate limit unificado por email + IP (no solo IP)
 * - FIX preventivo: password complexity mínima en reset y setup
 * - FIX preventivo: invalidar todas las sesiones del usuario al resetear password
 */

import { Router } from "express";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { db, usersTable, rateLimitsTable } from "@workspace/db";
import { eq, lt, sql, and, or } from "drizzle-orm";
import { requireAuth } from "../lib/auth.js";
import { recordAudit } from "../lib/audit.helper.js";
import { logger } from "../lib/logger.js";
import { getKlaviyoHeaders } from "../lib/klaviyo-headers.js";

const router = Router();

// ─── Configuración ────────────────────────────────────────────────────────────
const RATE_LIMIT_MAX = 5;
const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000;

/**
 * Hash bcrypt pre-computado de "dummy-not-a-real-password".
 * Usado cuando el email no existe para mantener tiempo constante.
 * Pre-computado para evitar coste en cada request.
 */
const DUMMY_BCRYPT_HASH = "$2a$12$CwTycUXWue0Thq9StjUM0uJ8N5cCUGn8RHW6X3HqQe3fFDrHBZpNu";

// ─── Rate limit helpers ──────────────────────────────────────────────────────
async function getRateLimit(key: string): Promise<{ count: number; blockedUntil: Date | null }> {
  try {
    const [row] = await db.select().from(rateLimitsTable).where(eq(rateLimitsTable.key, key));
    if (!row) return { count: 0, blockedUntil: null };
    return { count: row.count, blockedUntil: row.blockedUntil };
  } catch {
    return { count: 0, blockedUntil: null };
  }
}

async function incrementRateLimit(key: string): Promise<void> {
  try {
    const blockedUntil = new Date(Date.now() + RATE_LIMIT_WINDOW_MS);
    await db.insert(rateLimitsTable)
      .values({ key, count: 1, blockedUntil, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: rateLimitsTable.key,
        set: {
          count: sql`${rateLimitsTable.count} + 1`,
          blockedUntil,
          updatedAt: new Date(),
        },
      });
  } catch (err) {
    logger.error({ err, key }, "Failed to increment rate limit");
  }
}

async function clearRateLimit(key: string): Promise<void> {
  try {
    await db.delete(rateLimitsTable).where(eq(rateLimitsTable.key, key));
  } catch {}
}

async function cleanupExpiredRateLimits(): Promise<void> {
  try {
    await db.delete(rateLimitsTable).where(lt(rateLimitsTable.blockedUntil, new Date()));
  } catch {}
}

setInterval(() => { cleanupExpiredRateLimits().catch(() => {}); }, 5 * 60 * 1000);

// ─── Password complexity validator ───────────────────────────────────────────
function validatePassword(password: string): { ok: boolean; error?: string } {
  if (!password || typeof password !== "string") {
    return { ok: false, error: "Contraseña requerida" };
  }
  if (password.length < 12) {
    return { ok: false, error: "La contraseña debe tener al menos 12 caracteres" };
  }
  let complexity = 0;
  if (/[a-z]/.test(password)) complexity++;
  if (/[A-Z]/.test(password)) complexity++;
  if (/[0-9]/.test(password)) complexity++;
  if (/[^A-Za-z0-9]/.test(password)) complexity++;
  if (complexity < 3) {
    return { ok: false, error: "Combina al menos 3 de: mayúsculas, minúsculas, números, símbolos" };
  }
  return { ok: true };
}

// ═══════════════════════════════════════════════════════════════════════════
// POST /login — FIX BE-5 constant-time
// ═══════════════════════════════════════════════════════════════════════════
router.post("/login", async (req, res): Promise<void> => {
  try {
    const { email, password } = req.body ?? {};
    if (!email || typeof email !== "string" || !password || typeof password !== "string") {
      res.status(400).json({ error: "Email y contraseña son obligatorios" });
      return;
    }

    const ip = req.ip ?? "unknown";
    const normalizedEmail = email.toLowerCase().trim();

    // FIX BE-5 bis: rate limit POR email Y por IP (más restrictivo)
    const ipKey = `login:ip:${ip}`;
    const emailKey = `login:email:${normalizedEmail}`;

    const [ipLimit, emailLimit] = await Promise.all([
      getRateLimit(ipKey),
      getRateLimit(emailKey),
    ]);

    const isBlocked = (limit: { count: number; blockedUntil: Date | null }) =>
      limit.count >= RATE_LIMIT_MAX && limit.blockedUntil && limit.blockedUntil > new Date();

    if (isBlocked(ipLimit) || isBlocked(emailLimit)) {
      const blockedUntil = ipLimit.blockedUntil ?? emailLimit.blockedUntil;
      const mins = blockedUntil ? Math.ceil((blockedUntil.getTime() - Date.now()) / 60000) : 15;
      res.status(429).json({ error: `Demasiados intentos. Espera ${mins} minuto(s).` });
      return;
    }

    // FIX BE-5: lookup siempre, bcrypt.compare siempre (tiempo constante)
    const [user] = await db.select().from(usersTable)
      .where(eq(usersTable.email, normalizedEmail));

    const hashToCompare = user?.password ?? DUMMY_BCRYPT_HASH;
    const passwordMatches = await bcrypt.compare(password, hashToCompare);

    // Combinar las verificaciones en un solo check final
    if (!user || !user.isActive || !passwordMatches) {
      await Promise.all([
        incrementRateLimit(ipKey),
        incrementRateLimit(emailKey),
      ]);
      // Mensaje genérico — no revelar si el email existe
      res.status(401).json({ error: "Credenciales incorrectas" });
      return;
    }

    await Promise.all([
      clearRateLimit(ipKey),
      clearRateLimit(emailKey),
    ]);

    req.session.userId = user.id;
    req.session.role = user.role;
    req.session.clientId = user.clientId ?? null;
    req.session.name = user.name;
    req.session.email = user.email;

    await db.update(usersTable).set({ lastLogin: new Date() }).where(eq(usersTable.id, user.id));

    await recordAudit({
      userId: user.id,
      action: "login",
      details: `Login desde ${ip}`,
      ipAddress: ip,
    });

    res.json({ success: true, role: user.role, name: user.name, clientId: user.clientId });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    logger.error({ err }, "Login error");
    res.status(500).json({ error: msg });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// POST /logout
// ═══════════════════════════════════════════════════════════════════════════
router.post("/logout", (req, res): void => {
  try {
    const userId = req.session.userId;
    const ip = req.ip ?? "unknown";
    if (userId) {
      recordAudit({ userId, action: "logout", details: `Logout desde ${ip}`, ipAddress: ip }).catch(() => {});
    }
    req.session.destroy(() => {
      res.clearCookie("connect.sid");
      res.json({ success: true });
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// GET /me
// ═══════════════════════════════════════════════════════════════════════════
router.get("/me", requireAuth, async (req, res): Promise<void> => {
  try {
    const [user] = await db.select({
      id: usersTable.id,
      email: usersTable.email,
      name: usersTable.name,
      role: usersTable.role,
      clientId: usersTable.clientId,
      avatarColor: usersTable.avatarColor,
    }).from(usersTable).where(eq(usersTable.id, req.session.userId!));

    if (!user) {
      res.status(401).json({ error: "Session invalid" });
      return;
    }

    res.json({ ...user, impersonating: req.session.impersonating ?? null });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// GET /invite/:token
// ═══════════════════════════════════════════════════════════════════════════
router.get("/invite/:token", async (req, res): Promise<void> => {
  try {
    const { token } = req.params;
    const [user] = await db.select().from(usersTable)
      .where(eq(usersTable.inviteToken, token));

    if (!user || !user.inviteExpires || user.inviteExpires < new Date()) {
      res.status(410).json({ error: "Enlace expirado o inválido" });
      return;
    }

    let storeName: string | null = null;
    let shopDomain: string | null = null;
    if (user.clientId) {
      try {
        const { projectsTable } = await import("@workspace/db");
        const [project] = await db.select({
          name: projectsTable.name,
          shopDomain: projectsTable.shopDomain,
        }).from(projectsTable).where(eq(projectsTable.id, Number(user.clientId)));
        storeName = project?.name ?? null;
        shopDomain = project?.shopDomain ?? null;
      } catch {}
    }

    res.json({
      name: user.name,
      email: user.email,
      projectId: user.clientId,
      storeName,
      shopDomain,
      expiresAt: user.inviteExpires,
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// POST /invite/:token/setup — FIX: validación de complejidad
// ═══════════════════════════════════════════════════════════════════════════
router.post("/invite/:token/setup", async (req, res): Promise<void> => {
  try {
    const { token } = req.params;
    const { password } = req.body as { password: string };

    const pwCheck = validatePassword(password);
    if (!pwCheck.ok) {
      res.status(400).json({ error: pwCheck.error });
      return;
    }

    const [user] = await db.select().from(usersTable)
      .where(eq(usersTable.inviteToken, token));

    if (!user || !user.inviteExpires || user.inviteExpires < new Date()) {
      res.status(410).json({ error: "Enlace expirado o inválido" });
      return;
    }

    const hashed = await bcrypt.hash(password, 12);
    await db.update(usersTable).set({
      password: hashed,
      inviteToken: null,
      inviteExpires: null,
      isActive: 1,
    }).where(eq(usersTable.id, user.id));

    req.session.userId = user.id;
    req.session.role = user.role;
    req.session.clientId = user.clientId ?? null;
    req.session.name = user.name;
    req.session.email = user.email;

    await recordAudit({
      userId: user.id,
      action: "invite_setup",
      details: `Setup desde invite ${token.slice(0, 8)}...`,
      ipAddress: req.ip ?? "unknown",
    });

    res.json({ success: true, role: user.role, name: user.name, clientId: user.clientId });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// POST /change-password (autenticado)
// ═══════════════════════════════════════════════════════════════════════════
router.post("/change-password", requireAuth, async (req, res): Promise<void> => {
  try {
    const { currentPassword, newPassword } = req.body as { currentPassword: string; newPassword: string };

    const pwCheck = validatePassword(newPassword);
    if (!pwCheck.ok) {
      res.status(400).json({ error: pwCheck.error });
      return;
    }

    const [user] = await db.select().from(usersTable)
      .where(eq(usersTable.id, req.session.userId!));
    if (!user) { res.status(401).json({ error: "Session invalid" }); return; }

    const valid = await bcrypt.compare(currentPassword, user.password);
    if (!valid) {
      res.status(403).json({ error: "Contraseña actual incorrecta" });
      return;
    }

    const hashed = await bcrypt.hash(newPassword, 12);
    await db.update(usersTable).set({ password: hashed }).where(eq(usersTable.id, user.id));

    await recordAudit({
      userId: user.id,
      action: "change_password",
      details: "Password cambiada",
      ipAddress: req.ip ?? "unknown",
    });

    res.json({ success: true });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// POST /forgot-password (público) — ya es correcto: siempre devuelve 200
// para evitar enumeration
// ═══════════════════════════════════════════════════════════════════════════
router.post("/forgot-password", async (req, res): Promise<void> => {
  try {
    const { email } = req.body as { email: string };
    if (!email || typeof email !== "string") {
      res.status(400).json({ error: "Email requerido" });
      return;
    }

    const [user] = await db.select().from(usersTable)
      .where(eq(usersTable.email, email.toLowerCase().trim()));

    if (user && user.isActive) {
      const token = randomBytes(32).toString("hex");
      const expires = new Date(Date.now() + 60 * 60 * 1000);
      await db.update(usersTable).set({
        resetToken: token,
        resetExpires: expires,
      }).where(eq(usersTable.id, user.id));

      const klaviyoKey = process.env.KLAVIYO_API_KEY;
      if (klaviyoKey) {
        const appUrl = process.env.APP_URL
          ?? (process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(",")[0]}` : "https://shopycrafter.com");
        const resetUrl = `${appUrl}/reset-password?token=${token}`;
        try {
          await fetch("https://a.klaviyo.com/api/events/", {
            method: "POST",
            headers: getKlaviyoHeaders(),
            body: JSON.stringify({
              data: {
                type: "event",
                attributes: {
                  properties: { resetUrl, userName: user.name, expireMinutes: 60 },
                  metric: { data: { type: "metric", attributes: { name: "Password Reset Requested" } } },
                  profile: { data: { type: "profile", attributes: { email: user.email } } },
                },
              },
            }),
          });
        } catch (err) {
          req.log?.warn({ err }, "Klaviyo password reset email failed");
        }
      }

      await recordAudit({
        userId: user.id,
        action: "forgot_password",
        details: `Solicitud de reset de contraseña para ${email}`,
        ipAddress: req.ip ?? "unknown",
      });
    }

    // Siempre 200 — evita enumeration
    res.json({ success: true, message: "Si el email existe, recibirás un enlace de recuperación." });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// POST /reset-password — FIX: complejidad + invalidar sesiones
// ═══════════════════════════════════════════════════════════════════════════
router.post("/reset-password", async (req, res): Promise<void> => {
  try {
    const { token, password } = req.body ?? {};

    if (!token || typeof token !== "string") {
      res.status(400).json({ error: "Token requerido" });
      return;
    }

    const pwCheck = validatePassword(password);
    if (!pwCheck.ok) {
      res.status(400).json({ error: pwCheck.error });
      return;
    }

    const [user] = await db.select().from(usersTable)
      .where(eq(usersTable.resetToken, token));

    if (!user || !user.resetExpires || user.resetExpires < new Date()) {
      res.status(410).json({ error: "El enlace ha expirado o no es válido" });
      return;
    }

    const hashed = await bcrypt.hash(password, 12);
    await db.update(usersTable).set({
      password: hashed,
      resetToken: null,
      resetExpires: null,
    }).where(eq(usersTable.id, user.id));

    // FIX preventivo: invalidar todas las sesiones del usuario tras reset.
    // Esto evita que un atacante con acceso a una sesión antigua la siga usando.
    // Requiere ejecutar SQL directo porque connect-pg-simple no expone un método.
    try {
      await db.execute(sql`
        DELETE FROM user_sessions
        WHERE sess::text LIKE ${`%"userId":"${user.id}"%`}
      `);
    } catch (err) {
      logger.warn({ err, userId: user.id }, "Failed to invalidate user sessions after reset");
    }

    await recordAudit({
      userId: user.id,
      action: "password_reset",
      details: "Contraseña restablecida via token",
      ipAddress: req.ip ?? "unknown",
    });

    res.json({ success: true, message: "Contraseña actualizada correctamente" });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// POST /stop-impersonate (admin)
// ═══════════════════════════════════════════════════════════════════════════
router.post("/stop-impersonate", requireAuth, async (req, res): Promise<void> => {
  try {
    const originalAdminId = req.session.impersonating;
    if (!originalAdminId) {
      res.status(400).json({ error: "No impersonation active" });
      return;
    }

    const [admin] = await db.select().from(usersTable).where(eq(usersTable.id, originalAdminId));
    if (!admin || admin.role !== "admin") {
      res.status(403).json({ error: "Original admin not found" });
      return;
    }

    req.session.userId = admin.id;
    req.session.role = admin.role;
    req.session.clientId = null;
    req.session.name = admin.name;
    req.session.email = admin.email;
    req.session.impersonating = undefined;

    res.json({ success: true });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});

export default router;
