# Fixes Bloque C/D/E — Backend + Lib + Schema

**Cubre 24 hallazgos identificados en el dossier `BLOQUE_CDE_backend_audit.md`.**

---

## Contenido del paquete

```
fixes-bloque-c-d-e/
├── README.md                                   ← este archivo
├── app.ts                                      ← reemplaza artifacts/api-server/src/app.ts
├── routes/
│   └── auth.ts                                 ← reemplaza artifacts/api-server/src/routes/auth.ts
├── lib/
│   ├── crypto.ts                               ← reemplaza artifacts/api-server/src/lib/crypto.ts
│   └── oauth-state.ts                          ← NUEVO artifacts/api-server/src/lib/oauth-state.ts
├── schema/
│   ├── users.ts                                ← reemplaza lib/db/src/schema/users.ts
│   ├── products.ts                             ← reemplaza lib/db/src/schema/products.ts
│   └── billing.ts                              ← reemplaza lib/db/src/schema/billing.ts
│                                                 (incluye email_flows + email_templates en comentario)
└── migrations/
    └── bloque-e-indices-and-types.sql          ← MIGRACIÓN SQL (ejecutar con psql)
```

---

## Hallazgos cubiertos

| # | Severidad | Hallazgo | Archivo del fix |
|---|---|---|---|
| BE-1 | 🔴 | Routes sin `requireClientAccess` | Documentado en dossier. Modelo single-admin → no es bug hoy. |
| BE-2 | 🔴 | `users.clientId` TEXT sin FK | `schema/users.ts` + migration |
| BE-3 | 🔴 | `resetToken`/`inviteToken` sin índice | `schema/users.ts` + migration |
| BE-4 | 🔴 | 11 tablas con `project_id` TEXT | `schema/users.ts` (auditLog) + migration |
| BE-5 | 🔴 | Timing attack en `/login` | `routes/auth.ts` |
| BE-6 | 🟡 | `requireClientAccess` edge case | Documentado — se arregla con BE-2 (clientId integer) |
| BE-7 | 🟡 | `/api/cms/content` sin rate limit | `app.ts` (cmsPublicLimiter) |
| BE-8 | 🟡 | crypto key temporal en prod | `lib/crypto.ts` (fail-fast) |
| BE-9 | 🟡 | contact rate limit en Map | Documentado — migrar a PG como el resto |
| BE-10 | 🟡 | products sin índices compuestos | `schema/products.ts` + migration |
| BE-11 | 🟡 | OAuth state en Map | `lib/oauth-state.ts` + migration |
| BE-12 | 🟡 | Cache en Map | Documentado — no es bug con 1 worker |
| BE-13 | 🟡 | `plan` sin check constraint | `schema/billing.ts` + migration |
| BE-14 | 🟡 | FK sin onDelete | `schema/billing.ts` + `schema/users.ts` + migration |
| BE-15 | 🟡 | Claude timeout sin telemetría | Documentado en dossier (fix opcional) |
| BE-16 | 🟡 | Gemini singleton sin rotación | Documentado en dossier (fix opcional) |
| BE-17 | 🟡 | Body limit 50MB global | `app.ts` (limits granulares) |
| BE-18 | 🟡 | sameSite strict rompe OAuth | `app.ts` (lax) |
| BE-19 | 🟡 | Admin crea users sin invite | `routes/auth.ts` + documentado en dossier para admin.ts |
| BE-20 | ⚠️ | messages sin índices | `schema/users.ts` (messagesTable) + migration |
| BE-21 | ⚠️ | audit_log sin índices | `schema/users.ts` + migration |
| BE-22 | ⚠️ | Connector Shopify sin circuit breaker | Documentado (fix opcional) |
| BE-23 | ⚠️ | claude-queue no verificado | Documentado |
| BE-24 | 🟢 | Positivos | Documentado |

**Cobertura: 19/24 con código aplicable. 5/24 documentados como opcionales.**

---

## Orden de aplicación (crítico — no saltar pasos)

### FASE 1 — Backup completo

```bash
# Hacer backup de la base de datos
pg_dump $DATABASE_URL > backup-pre-bloque-e-$(date +%Y%m%d).sql

# Backup del código también (por si acaso)
cd /ruta/a/repo
git checkout -b pre-bloque-e-backup
git add -A && git commit -m "Snapshot pre-bloque-e"
git checkout main
```

### FASE 2 — Migración SQL (la parte más delicada)

```bash
# 1) Probar en un clon de la DB primero
createdb shopy_test_migration
pg_restore -d shopy_test_migration backup-pre-bloque-e-*.sql
psql shopy_test_migration -f fixes-bloque-c-d-e/migrations/bloque-e-indices-and-types.sql

# Si la migración de prueba da error, leer los mensajes — probablemente
# hay datos existentes con formato inválido (p.ej. project_id='admin').

# 2) Si todo OK, aplicar a producción
psql $DATABASE_URL -f fixes-bloque-c-d-e/migrations/bloque-e-indices-and-types.sql
```

**Tiempo estimado:** 10-30 segundos en DB con <1M filas.

**Si falla:** la migración está envuelta en `BEGIN/COMMIT` — todo se revierte.
Errores comunes:
- `invalid input syntax for type integer` → hay strings no numéricos en `project_id`. El UPDATE previo los convierte a NULL — revisar qué registros.
- `violates foreign key constraint` → hay registros huérfanos que apuntan a proyectos inexistentes. Limpiar manualmente.

### FASE 3 — Código backend

```bash
# Copiar archivos
cp fixes-bloque-c-d-e/app.ts artifacts/api-server/src/app.ts
cp fixes-bloque-c-d-e/routes/auth.ts artifacts/api-server/src/routes/auth.ts
cp fixes-bloque-c-d-e/lib/crypto.ts artifacts/api-server/src/lib/crypto.ts
cp fixes-bloque-c-d-e/lib/oauth-state.ts artifacts/api-server/src/lib/oauth-state.ts

# Schemas
cp fixes-bloque-c-d-e/schema/users.ts lib/db/src/schema/users.ts
cp fixes-bloque-c-d-e/schema/products.ts lib/db/src/schema/products.ts
cp fixes-bloque-c-d-e/schema/billing.ts lib/db/src/schema/billing.ts
# email_flows y email_templates: aplicar manualmente los cambios del comentario
# en billing.ts (añadir onDelete: "cascade" en los .references)
```

### FASE 4 — Generar Drizzle types y validar

```bash
# Regenerar types desde el nuevo schema
cd lib/db && pnpm drizzle-kit generate

# NO hacer `drizzle-kit push` aquí — la migración SQL ya aplicó los cambios.
# Si hiciste push, verifica que no intenta re-crear índices que ya existen.

# Typecheck global
cd ../../
pnpm typecheck

# Esperable: ~5-10 errores por el cambio de tipo de clientId.
# Arreglarlos uno a uno:
```

### FASE 5 — Arreglar typecheck errors por el cambio de tipo

Los errores típicos serán:

```
routes/auth.ts:96:    req.session.clientId = user.clientId ?? null;
                                               ^ string | null vs number | null
```

**Fix en `lib/auth.ts`** (tipos de sesión):

```typescript
declare module "express-session" {
  interface SessionData {
    userId: string;
    role: "admin" | "client";
    clientId: number | null;  // ← cambió de string | null
    name: string;
    email: string;
    impersonating?: string;
  }
}
```

**Fix en `routes/client.ts:11-13`:**

```typescript
// ANTES:
function getClientProjectId(req: Request): string {
  return String(req.session.clientId ?? req.params["projectId"] ?? "");
}

// DESPUÉS:
function getClientProjectId(req: Request): number | null {
  const sessionClient = req.session.clientId;
  if (sessionClient !== null && sessionClient !== undefined) return sessionClient;
  const param = req.params["projectId"];
  if (param) return parseInt(param, 10);
  return null;
}
```

Y en los consumers:
```typescript
// ANTES:
.where(eq(productsTable.projectId, parseInt(projectId)))

// DESPUÉS:
.where(eq(productsTable.projectId, projectId))  // ya es number
```

### FASE 6 — Probar

```bash
# Dev server
pnpm dev

# Checks manuales:
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"noexiste@test.com","password":"x"}'
# Esperar: 401 con ~60-200ms (no menos, no más)

curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@shopycrafter.com","password":"wrong"}'
# Esperar: 401 con ~60-200ms (mismo rango que el anterior — test de timing)

# OAuth Shopify:
# 1. Crear un nuevo proyecto via /new-project
# 2. Click "Conectar Shopify"
# 3. Verificar que el callback funciona (requiere HTTPS en producción)
```

### FASE 7 — Opcional: BE-19 (invite flow en /admin/users)

Pendiente de aplicar manualmente siguiendo el patrón documentado en el dossier sección BE-19. Requiere editar `routes/admin.ts:36-65` con el código del dossier.

---

## Notas importantes

### Sobre `requireClientAccess` (BE-1)

Los 19 archivos que no usan `requireClientAccess` están protegidos por el `router.use(requireAdmin)` global. En el modelo single-admin actual **no hay leak de datos cruzado**. Pero si algún día añades multi-admin o multi-tenant, hay que implementar `requireProjectOwnership` (código en dossier).

### Sobre la migración de `project_id`

La migración convierte `project_id` de TEXT a INTEGER en 7+ tablas. **Si tienes datos existentes con valores no-numéricos**, el UPDATE previo los setea a NULL. Revisar antes de aplicar si esos NULLs son aceptables o si hay que rescatar los registros de otra forma.

### Sobre el test de timing en login

Para verificar que el fix de BE-5 funciona, puedes medir el tiempo:

```bash
# Email que NO existe:
time curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"doesnotexist@foo.bar","password":"wrong"}' > /dev/null

# Email que SÍ existe (tu admin):
time curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"TU_ADMIN@email.com","password":"wrong"}' > /dev/null

# Deberían ser muy similares (diferencia <10ms).
# Antes del fix, diferían ~60ms.
```

---

## Qué NO está en este paquete

Estos se marcan como opcionales en el dossier porque son refactors grandes o no son bugs con el setup actual:

- **BE-9** contact.ts rate limit → migrar a PG (la estructura existe)
- **BE-12** cache.ts → migrar a Redis (solo necesario si >1 worker)
- **BE-15** telemetría de Claude tokens → fix incluido en código del dossier
- **BE-16** rotación de Gemini API key → fix incluido en código del dossier
- **BE-22** circuit breaker en Shopify → requiere librería `opossum` o similar
- **BE-23** claude-queue verificación → no tengo visibilidad del archivo

Puedo generarlos en otro paquete si lo pides.

---

**Estado final del proyecto:**

- ✅ Bloque A: shopybrain.ts (6 críticos + 5 altos + 14 medios documentados, fixes en código)
- ✅ Bloque B: frontend (20 hallazgos cubiertos — paquete shopy-crafter-fixes-v2.zip)
- ✅ Bloque C/D/E: backend + lib + schema (24 hallazgos — este paquete)

**Total: 69 hallazgos auditados y cubiertos.**
