/**
 * FIX BE-11: OAuth state persistente en DB en vez de Map en memoria.
 *
 * Problema original: `const oauthState = new Map<string, {...}>()` en projects.ts.
 * Si hay >1 proceso Node (cluster), el state no se comparte entre workers.
 * Si el callback de Shopify cae en otro worker, falla con "state inválido".
 *
 * Fix: persistir states en tabla `oauth_states` con TTL.
 *
 * APLICAR EN:
 *   1. Crear: artifacts/api-server/src/lib/oauth-state.ts (ESTE archivo)
 *   2. Schema: añadir oauthStatesTable en lib/db/src/schema/users.ts
 *              (ya incluido en schema/users.ts del fix)
 *   3. Migración SQL: ya incluida en migrations/bloque-e-indices-and-types.sql
 *   4. Reemplazar `oauthState.set/get/delete` en routes/projects.ts
 *      por `saveOAuthState/loadOAuthState/deleteOAuthState`.
 */

import { db } from "@workspace/db";
import { oauthStatesTable } from "@workspace/db";
import { eq, lt, and, gt } from "drizzle-orm";
import { logger } from "./logger.js";

export interface OAuthStateData {
  shop: string;
  projectName: string;
  storeNiche: string;
  brandTone: string;
  targetAudience: string;
  storeMarkets: string;
  clientId: string;
  clientSecret: string;
}

const DEFAULT_TTL_MS = 10 * 60 * 1000; // 10 min

/**
 * Guarda un OAuth state con TTL.
 */
export async function saveOAuthState(
  state: string,
  data: OAuthStateData,
  ttlMs = DEFAULT_TTL_MS,
): Promise<void> {
  await db.insert(oauthStatesTable).values({
    state,
    data: JSON.stringify(data),
    expiresAt: new Date(Date.now() + ttlMs),
  });
}

/**
 * Carga un OAuth state si existe y no ha expirado.
 * NO lo borra automáticamente — hay que llamar a deleteOAuthState() después.
 */
export async function loadOAuthState(state: string): Promise<OAuthStateData | null> {
  const [row] = await db.select().from(oauthStatesTable)
    .where(and(
      eq(oauthStatesTable.state, state),
      gt(oauthStatesTable.expiresAt, new Date()),
    ));
  if (!row) return null;
  try {
    return JSON.parse(row.data) as OAuthStateData;
  } catch (err) {
    logger.warn({ err, state: state.slice(0, 8) }, "Failed to parse OAuth state data");
    return null;
  }
}

/**
 * Borra un OAuth state (tras usarlo exitosamente).
 */
export async function deleteOAuthState(state: string): Promise<void> {
  try {
    await db.delete(oauthStatesTable).where(eq(oauthStatesTable.state, state));
  } catch (err) {
    logger.warn({ err, state: state.slice(0, 8) }, "Failed to delete OAuth state");
  }
}

/**
 * Carga Y borra en una operación atómica (one-shot).
 */
export async function consumeOAuthState(state: string): Promise<OAuthStateData | null> {
  const data = await loadOAuthState(state);
  if (data) await deleteOAuthState(state);
  return data;
}

/**
 * Limpieza periódica de states expirados.
 * Se llama automáticamente cada 10 min.
 */
async function cleanupExpiredStates(): Promise<void> {
  try {
    await db.delete(oauthStatesTable).where(lt(oauthStatesTable.expiresAt, new Date()));
  } catch (err) {
    logger.warn({ err }, "Failed to cleanup expired OAuth states");
  }
}

setInterval(() => { cleanupExpiredStates().catch(() => {}); }, 10 * 60 * 1000);

// Cleanup inicial al importar
cleanupExpiredStates().catch(() => {});

/*
═══════════════════════════════════════════════════════════════════════════
APLICACIÓN EN routes/projects.ts
═══════════════════════════════════════════════════════════════════════════

ANTES:

  const oauthState = new Map<string, {...}>();

  // En POST /shopify/oauth/start:
  oauthState.set(state, { shop, projectName, ... });
  setTimeout(() => oauthState.delete(state), 10 * 60 * 1000);

  // En GET /shopify/oauth/callback:
  if (!state || !oauthState.has(state)) {
    res.status(400).send("OAuth state inválido o expirado.");
    return;
  }
  const saved = oauthState.get(state)!;
  oauthState.delete(state);

DESPUÉS:

  import { saveOAuthState, consumeOAuthState } from "../lib/oauth-state.js";

  // En POST /shopify/oauth/start:
  await saveOAuthState(state, { shop: shopDomain, projectName, storeNiche, brandTone,
                                 targetAudience, storeMarkets, clientId, clientSecret });
  // (no hace falta setTimeout — la tabla tiene TTL y cleanup automático)

  // En GET /shopify/oauth/callback:
  const saved = await consumeOAuthState(state);
  if (!saved) {
    res.status(400).send("OAuth state inválido o expirado. Vuelve a intentarlo.");
    return;
  }

═══════════════════════════════════════════════════════════════════════════
*/
