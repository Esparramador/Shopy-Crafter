/**
 * FIX BE-13, BE-14: schemas billing + email_flows + email_templates
 * con constraints de check + cascades.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * APLICAR EN:
 *   lib/db/src/schema/billing.ts        (este archivo)
 *   lib/db/src/schema/email_flows.ts    (ver bloque 2)
 *   lib/db/src/schema/email_templates.ts (ver bloque 3)
 * ─────────────────────────────────────────────────────────────────────────
 */

// ═════════════════════════════════════════════════════════════════════════
// lib/db/src/schema/billing.ts
// ═════════════════════════════════════════════════════════════════════════

import { pgTable, text, real, integer, timestamp, index, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { usersTable } from "./users";

export const subscriptionsTable = pgTable("subscriptions", {
  userId: text("user_id").primaryKey().references(() => usersTable.id, { onDelete: "cascade" }),
  stripeCustomerId: text("stripe_customer_id").unique(),
  stripeSubscriptionId: text("stripe_subscription_id"),
  plan: text("plan").default("trial").notNull(),
  status: text("status").default("active").notNull(),
  trialEndsAt: timestamp("trial_ends_at"),
  currentPeriodEnd: timestamp("current_period_end"),
  storesLimit: integer("stores_limit").default(1),
  imagesIncluded: integer("images_included").default(100),
  imagesUsed: integer("images_used").default(0),
  cancelAtPeriodEnd: integer("cancel_at_period_end").default(0),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  // FIX BE-13: check constraints para plan y status
  checkPlan: check("subscriptions_plan_check",
    sql`${table.plan} IN ('trial', 'starter', 'pro', 'agency', 'enterprise')`),
  checkStatus: check("subscriptions_status_check",
    sql`${table.status} IN ('active', 'trialing', 'cancelled', 'past_due', 'incomplete')`),
  idxCurrentPeriod: index("idx_subscriptions_period_end").on(table.currentPeriodEnd),
}));

export const affiliatesTable = pgTable("affiliates", {
  id: text("id").primaryKey(),
  // FIX BE-14: FK con cascade
  userId: text("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  referralCode: text("referral_code").unique().notNull(),
  clicks: integer("clicks").default(0),
  signups: integer("signups").default(0),
  conversions: integer("conversions").default(0),
  pendingPayout: real("pending_payout").default(0),
  totalEarned: real("total_earned").default(0),
  stripeConnectId: text("stripe_connect_id"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  idxUserId: index("idx_affiliates_user_id").on(table.userId),
}));

export const referralTrackingTable = pgTable("referral_tracking", {
  id: text("id").primaryKey(),
  // FIX BE-14: FK con cascade
  affiliateId: text("affiliate_id").notNull().references(() => affiliatesTable.id, { onDelete: "cascade" }),
  referredUserId: text("referred_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  signupDate: timestamp("signup_date"),
  convertedDate: timestamp("converted_date"),
  commissionRate: real("commission_rate").default(0.20),
  commissionEarned: real("commission_earned").default(0),
  status: text("status").default("pending"),
}, (table) => ({
  idxAffiliate: index("idx_referrals_affiliate").on(table.affiliateId),
  // Check constraint opcional
  checkStatus: check("referral_tracking_status_check",
    sql`${table.status} IN ('pending', 'signed_up', 'converted', 'paid', 'rejected')`),
}));

/*
═════════════════════════════════════════════════════════════════════════
lib/db/src/schema/email_flows.ts
═════════════════════════════════════════════════════════════════════════

import { pgTable, text, integer, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";

export const emailFlowsTable = pgTable("email_flows", {
  id: text("id").primaryKey(),
  // FIX BE-14: cascade cuando se borra el proyecto
  projectId: integer("project_id").notNull().references(() => projectsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  trigger: text("trigger"),
  status: text("status").default("draft"),
  emailsJson: jsonb("emails_json"),
  klaviyoFlowId: text("klaviyo_flow_id"),
  expectedRevenueImpact: text("expected_revenue_impact"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  idxProject: index("idx_email_flows_project").on(table.projectId),
  idxTrigger: index("idx_email_flows_trigger").on(table.trigger),
}));

═════════════════════════════════════════════════════════════════════════
lib/db/src/schema/email_templates.ts
═════════════════════════════════════════════════════════════════════════

import { pgTable, text, integer, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";

export const emailTemplatesTable = pgTable("email_templates", {
  id: text("id").primaryKey(),
  // FIX BE-14: cascade
  projectId: integer("project_id").notNull().references(() => projectsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  type: text("type").notNull(),
  subjectA: text("subject_a").notNull(),
  subjectB: text("subject_b"),
  htmlContent: text("html_content").notNull(),
  plainContent: text("plain_content"),
  variables: jsonb("variables"),
  klaviyoTemplateId: text("klaviyo_template_id"),
  status: text("status").default("draft"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  idxProject: index("idx_email_templates_project").on(table.projectId),
  idxType: index("idx_email_templates_type").on(table.type),
}));
*/
