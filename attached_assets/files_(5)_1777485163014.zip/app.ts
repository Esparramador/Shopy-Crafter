/**
 * FIXES aplicados en app.ts:
 * - BE-17: body limits específicos por ruta (1MB default, 25MB solo en image endpoints)
 * - BE-18: sameSite "lax" en producción (OAuth Shopify necesita esto)
 * - BE-7: rate limit específico para /api/cms/content público
 * - BE-8: validación estricta de ENCRYPTION_KEY al arranque (fail fast en prod)
 *
 * Reemplaza el archivo existente: artifacts/api-server/src/app.ts
 */

import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import session from "express-session";
import ConnectPg from "connect-pg-simple";
import pinoHttp from "pino-http";
import compression from "compression";
import path from "path";
import { fileURLToPath } from "url";
import router from "./routes/index.js";
import { logger } from "./lib/logger.js";
import { pool } from "@workspace/db";
import { PgRateLimitStore, startRateLimitCleanup } from "./lib/pg-rate-limit-store.js";
import { validateEncryptionKey } from "./lib/crypto.js";

// ─── FIX BE-8: validar encryption key ANTES de cualquier cosa ────────────────
validateEncryptionKey();

const PgSession = ConnectPg(session);

const app: Express = express();

app.set("trust proxy", 1);

// ── Security headers (Helmet) ─────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));

// ── Gzip compression ──────────────────────────────────────────────────────
app.use(compression());

// ── Request logger ────────────────────────────────────────────────────────
app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) { return { id: req.id, method: req.method, url: req.url?.split("?")[0] }; },
      res(res) { return { statusCode: res.statusCode }; },
    },
  }),
);

// ── CORS ──────────────────────────────────────────────────────────────────
app.use(cors({
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    if (process.env.NODE_ENV !== "production") return callback(null, true);
    const allowed = new Set<string>();
    const appUrl = process.env.APP_URL;
    if (appUrl) allowed.add(appUrl);
    const domain = process.env.REPLIT_DOMAINS?.split(",")[0];
    if (domain) allowed.add(`https://${domain}`);
    if (allowed.has(origin)) return callback(null, true);
    callback(null, false);
  },
  credentials: true,
}));

// ── Rate limiting ─────────────────────────────────────────────────────────
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  store: new PgRateLimitStore("auth"),
  message: { error: "Demasiados intentos. Espera 15 minutos antes de reintentar.", code: "RATE_LIMITED" },
  skip: (_req) => process.env.NODE_ENV === "development" || process.env.NODE_ENV === "test",
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  store: new PgRateLimitStore("api"),
  message: { error: "Límite de peticiones alcanzado. Inténtalo en un momento.", code: "RATE_LIMITED" },
  skip: (_req) => process.env.NODE_ENV === "development" || process.env.NODE_ENV === "test",
});

const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  store: new PgRateLimitStore("ai"),
  message: { error: "Demasiadas solicitudes de IA simultáneas. Espera un momento.", code: "AI_RATE_LIMITED" },
  skip: (_req) => process.env.NODE_ENV === "development" || process.env.NODE_ENV === "test",
});

// FIX BE-7: rate limit específico para CMS público (GET /api/cms/content)
const cmsPublicLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  store: new PgRateLimitStore("cms-public"),
  message: { error: "Demasiadas peticiones al CMS. Espera un momento." },
  skip: (req) => req.method !== "GET" || process.env.NODE_ENV === "development",
});

startRateLimitCleanup();

// ── FIX BE-17: body limits GRANULARES por ruta ────────────────────────────
// Default bajo (1MB) para evitar DoS en endpoints no-file
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

// Overrides específicos para endpoints que reciben imágenes:
const IMAGE_ENDPOINTS_LIMIT = "15mb";
const VIDEO_ENDPOINTS_LIMIT = "50mb";
const LARGE_IMAGE_ANALYSIS_LIMIT = "25mb";

const imageRoutes = [
  "/api/shopybrain/absorb-image",
  "/api/shopybrain/create-product-from-image",
  "/api/fusion-studio/analyze",
  "/api/fusion-studio/create-product",
  "/api/reference/analyze-image",
  "/api/cms/media/upload",
];
for (const route of imageRoutes) {
  app.use(route, express.json({ limit: IMAGE_ENDPOINTS_LIMIT }));
}

// Video/multi-image endpoints
const heavyRoutes = [
  "/api/reference/analyze-video",
  "/api/cms/media/upload-video",
];
for (const route of heavyRoutes) {
  app.use(route, express.json({ limit: VIDEO_ENDPOINTS_LIMIT }));
}

// Analysis endpoints que reciben varias imágenes base64
const analysisRoutes = [
  "/api/reference/analyze-image",
];
for (const route of analysisRoutes) {
  app.use(route, express.json({ limit: LARGE_IMAGE_ANALYSIS_LIMIT }));
}

// ── Global input sanitization (prototype pollution) ─────────────────────
app.use((req: Request, _res: Response, next: NextFunction) => {
  if (req.body && typeof req.body === "object") {
    const sanitize = (obj: unknown): unknown => {
      if (obj === null || typeof obj !== "object") return obj;
      if (Array.isArray(obj)) return obj.map(sanitize);
      const clean: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(obj)) {
        if (key === "__proto__" || key === "constructor" || key === "prototype") continue;
        clean[key] = sanitize(value);
      }
      return clean;
    };
    req.body = sanitize(req.body);
  }
  next();
});

// ── Session — FIX BE-18: sameSite lax para permitir OAuth Shopify ──────
const sessionSecret = process.env.SESSION_SECRET;
if (!sessionSecret) throw new Error("SESSION_SECRET not set");

app.use(
  session({
    store: new PgSession({
      pool,
      tableName: "user_sessions",
    }),
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000,
      // FIX BE-18: "lax" permite que la cookie viaje en GET cross-site
      // (necesario para el callback de Shopify OAuth que viene desde shopify.com).
      // "lax" sigue bloqueando CSRF en POST/PUT/PATCH/DELETE.
      sameSite: "lax",
    },
  }),
);

// ── No-cache para todas las respuestas API ──────────────────────────────
app.use("/api", (_req: Request, res: Response, next: NextFunction) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  next();
});

// ── Static reports (auth-protected) ────────────────────────────────────
const __filename2 = fileURLToPath(import.meta.url);
const __dirname2 = path.dirname(__filename2);
const reportsDir = path.join(__dirname2, "..", "public", "reports");
const reportAuth = (req: Request, res: Response, next: NextFunction): void => {
  if (!(req.session as { userId?: string } | undefined)?.userId) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  next();
};
app.use("/api/reports", reportAuth, express.static(reportsDir));
app.use("/reports", reportAuth, express.static(reportsDir));

// ── Rate-limiters por prefijo ──────────────────────────────────────────
app.use("/api/auth", authLimiter);
app.use("/api/shopybrain/study", aiLimiter);
app.use("/api/intelligence", aiLimiter);
app.use("/api/redesign", aiLimiter);
app.use("/api/seo", aiLimiter);
app.use("/api/emails", aiLimiter);
app.use("/api/reference", aiLimiter);
app.use("/api/agency/analyze", aiLimiter);
app.use("/api/agency/proposal", aiLimiter);

// FIX BE-7: CMS público con su propio rate limit antes del general
app.use("/api/cms/content", cmsPublicLimiter);

app.use("/api", apiLimiter);

// ── Anti-502 middleware ────────────────────────────────────────────────
const AI_ROUTE_PATTERNS = [
  /^\/api\/shopybrain\/(absorb|create-product|supplier|research|audit|search|study|execute|chat)/,
  /^\/api\/fusion-studio\//,
  /^\/api\/agency\/(analyze|quote|budget|proposal)/,
  /^\/api\/research\//,
  /^\/api\/intelligence\//,
  /^\/api\/competitors\/(scan|auto-discover)/,
  /^\/api\/web-lab\//,
  /^\/api\/generator\/run/,
  /^\/api\/email-templates\/generate/,
  /^\/api\/emails\/(generate|flows)/,
  /^\/api\/enrichment\//,
  /^\/api\/klaviyo-ai\//,
  /^\/api\/reference\/analyze/,
  /^\/api\/inventory\/restock-email/,
  /^\/api\/push\/vapid-generate/,
  /^\/api\/voice\/command/,
  /^\/api\/entity-research\//,
];

app.use((req: Request, res: Response, next: NextFunction) => {
  if (AI_ROUTE_PATTERNS.some((p) => p.test(req.path))) {
    req.setTimeout(0);
    res.setTimeout(0);
    req.socket?.setKeepAlive(true, 30_000);
    req.socket?.setNoDelay(true);
  }
  next();
});

// ── Routes ──────────────────────────────────────────────────────────────
app.use(router);

// ── 404 handler ─────────────────────────────────────────────────────────
app.use("/api/*", (_req: Request, res: Response) => {
  res.status(404).json({ error: "Not found" });
});

// ── Error handler ───────────────────────────────────────────────────────
app.use((err: Error & { status?: number }, _req: Request, res: Response, _next: NextFunction) => {
  const status = err.status ?? 500;
  if (status >= 500) {
    logger.error({ err }, "Request error");
  }
  res.status(status).json({
    error: err.message ?? "Internal server error",
  });
});

export default app;
