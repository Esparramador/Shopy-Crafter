/**
 * FIX BE-8: validateEncryptionKey con fail-fast en producción.
 *
 * Original: si no había ENCRYPTION_KEY en producción, generaba una aleatoria
 * con warning. Resultado: los datos cifrados durante esa sesión se pierden al
 * reiniciar (indetectable hasta que el usuario intenta usar datos antiguos).
 *
 * Fix: en producción, throw Error que detiene el arranque.
 * En desarrollo: sigue generando una clave temporal con warning muy visible.
 *
 * APLICAR EN: artifacts/api-server/src/lib/crypto.ts
 */

import { createCipheriv, createDecipheriv, randomBytes } from "crypto";

const ALGO = "aes-256-gcm";

let tempKeyGenerated = false;

export function validateEncryptionKey(): void {
  const keyHex = process.env.ENCRYPTION_KEY;

  if (!keyHex) {
    // FIX BE-8: en producción, NO generar key temporal — fail fast.
    if (process.env.NODE_ENV === "production") {
      console.error("╔══════════════════════════════════════════════════════════════╗");
      console.error("║  ❌ CRITICAL: ENCRYPTION_KEY not set in production          ║");
      console.error("║                                                              ║");
      console.error("║  Generate a secure key:                                      ║");
      console.error("║    openssl rand -hex 32                                      ║");
      console.error("║                                                              ║");
      console.error("║  Set it as the ENCRYPTION_KEY environment variable.          ║");
      console.error("║  This key protects customer data (Shopify tokens, secrets).  ║");
      console.error("║  If lost, all encrypted data becomes unreadable.             ║");
      console.error("║                                                              ║");
      console.error("║  App will NOT start without this key in production.          ║");
      console.error("╚══════════════════════════════════════════════════════════════╝");
      throw new Error("ENCRYPTION_KEY required in production");
    }

    // Dev only: permitir key temporal con warning muy visible
    const generated = randomBytes(32).toString("hex");
    process.env.ENCRYPTION_KEY = generated;
    tempKeyGenerated = true;
    console.warn("╔══════════════════════════════════════════════════════════════╗");
    console.warn("║  ⚠️  DEV WARNING: ENCRYPTION_KEY not set!                    ║");
    console.warn("║  A temporary key has been generated for THIS SESSION ONLY.   ║");
    console.warn("║  Data encrypted now will NOT be decryptable after restart.   ║");
    console.warn("║                                                              ║");
    console.warn("║  To persist data across restarts:                            ║");
    console.warn("║    export ENCRYPTION_KEY=$(openssl rand -hex 32)             ║");
    console.warn("║  Then add it to your .env / Replit secrets.                  ║");
    console.warn("╚══════════════════════════════════════════════════════════════╝");
    return;
  }

  if (keyHex.length !== 64 || !/^[0-9a-fA-F]+$/.test(keyHex)) {
    throw new Error("ENCRYPTION_KEY must be a 64-character hex string (32 bytes)");
  }
}

export function isUsingTemporaryKey(): boolean {
  return tempKeyGenerated;
}

function getKey(): Buffer {
  const keyHex = process.env.ENCRYPTION_KEY;
  if (!keyHex) throw new Error("ENCRYPTION_KEY not set — call validateEncryptionKey() at startup");
  return Buffer.from(keyHex, "hex");
}

export function encrypt(text: string): string {
  const key = getKey();
  const iv = randomBytes(16);
  const cipher = createCipheriv(ALGO, key, iv, { authTagLength: 16 });
  const encrypted = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("hex")}:${tag.toString("hex")}:${encrypted.toString("hex")}`;
}

export function decrypt(data: string): string {
  const key = getKey();
  const [ivHex, tagHex, encHex] = data.split(":");
  if (!ivHex || !tagHex || !encHex) {
    throw new Error("Invalid encrypted data format");
  }
  const iv = Buffer.from(ivHex, "hex");
  const tag = Buffer.from(tagHex, "hex");
  const encrypted = Buffer.from(encHex, "hex");
  const decipher = createDecipheriv(ALGO, key, iv, { authTagLength: 16 });
  decipher.setAuthTag(tag);
  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return decrypted.toString("utf8");
}

/**
 * Decrypt que NO lanza si el input no está cifrado o la clave no encaja.
 * Úsalo para campos legacy que podrían estar en plaintext mientras se migra.
 */
export function safeDecrypt(data: string | null | undefined): string | null {
  if (!data) return null;
  // Si no tiene el formato iv:tag:encrypted, devolverlo tal cual (plaintext legacy)
  if (!/^[0-9a-f]+:[0-9a-f]+:[0-9a-f]+$/i.test(data)) {
    return data;
  }
  try {
    return decrypt(data);
  } catch {
    return null;
  }
}
