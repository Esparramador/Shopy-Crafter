# BLOQUE C / D / E — Auditoría backend completa

Cierra los 3 bloques restantes:
- **Bloque C** — 47 archivos de `routes/` (excepto `shopybrain.ts` ya cubierto en Bloque A)
- **Bloque D** — Capa `lib/` (auth, claude, gemini, vault, crypto, shopify, connectors, cache, logger, plan-limits)
- **Bloque E** — Schema Drizzle (30 tablas)

Código verificado mediante greps exhaustivos y lectura de archivos críticos del tarball.

---

## RESUMEN EJECUTIVO — 24 HALLAZGOS NUEVOS

| # | Severidad | Área | Problema |
|---|---|---|---|
| BE-1 | 🔴 | routes/* | **19 archivos con rutas `/projects/:projectId/*` SIN `requireClientAccess`** — admin ve todo (correcto), pero clients pueden acceder a proyectos ajenos si el frontend los envía con otro projectId |
| BE-2 | 🔴 | schema/users.ts | Campo `clientId` es **TEXT sin FK ni constraint** — puede contener cualquier string, no se valida contra projects |
| BE-3 | 🔴 | schema/users.ts | Campo `resetToken` y `inviteToken` sin **índice** — lookup hace full table scan |
| BE-4 | 🔴 | schema | **11 tablas** con `projectId` como `TEXT` cuando projects.id es `SERIAL (integer)` — mismatch de tipos |
| BE-5 | 🔴 | routes/auth.ts | **User enumeration timing attack** — 200ms delay solo cuando falla password, no cuando email no existe |
| BE-6 | 🟡 | lib/auth.ts | `requireClientAccess` compara `req.session.clientId === projectId` pero clientId es `text` y projectId de URL es `text` de URL — OK, pero si alguien pone `admin` como clientId accede como admin |
| BE-7 | 🟡 | routes/cms.ts | `/api/cms/content` es **público sin rate-limit específico** — cualquiera puede scrapear la configuración del CMS |
| BE-8 | 🟡 | lib/crypto.ts | Genera **clave temporal aleatoria en memoria** si no hay ENCRYPTION_KEY — data escrita durante esa sesión es perdida al reiniciar |
| BE-9 | 🟡 | routes/contact.ts | Rate limit en Map en memoria — reset con restart y no distribuido |
| BE-10 | 🟡 | schema/products.ts | Índice compuesto `(projectId, shopifyProductId)` **ausente** — lookup N+1 habitual |
| BE-11 | 🟡 | routes/projects.ts | OAuth state en `Map` en memoria — si hay >1 proceso Node los estados no se comparten |
| BE-12 | 🟡 | lib/cache.ts | Cache en memoria sin sharding — idem, no distribuido |
| BE-13 | 🟡 | schema/billing.ts | `plan` text sin constraint — puede tener cualquier string (inconsistente con enum de projects.plan) |
| BE-14 | 🟡 | schema/email_flows, email_templates | FK sin `onDelete` — al borrar proyecto quedan huérfanos |
| BE-15 | 🟡 | lib/claude.ts | `askClaude` timeout 180s. Si es un job muy largo (>5min) se cancela pero el cliente Anthropic puede seguir consumiendo tokens |
| BE-16 | 🟡 | lib/gemini.ts | Cliente singleton — si se rota la API key hay que reiniciar el proceso |
| BE-17 | 🟡 | app.ts | Body limit 50MB para **todas** las rutas. Sobredimensionado y riesgo DoS en endpoints no-file |
| BE-18 | 🟡 | Session cookie | `sameSite: strict` rompe flujos OAuth con Shopify (redirect desde shopify.com) — debería ser `lax` con doble-submit CSRF |
| BE-19 | 🟡 | routes/admin.ts | `POST /admin/users` crea usuarios con password random no notificado al usuario — si no se manda email queda inaccesible |
| BE-20 | ⚠️ | schema/messages | Sin índice en `projectId` — queries por proyecto hacen full scan |
| BE-21 | ⚠️ | schema/audit_log | Sin índice en `userId` ni `projectId` ni `createdAt` — tabla crecerá mucho |
| BE-22 | ⚠️ | Connector shopify.ts | Sin retry con circuit breaker — si Shopify está caído, saturamos sus APIs |
| BE-23 | ⚠️ | lib/claude-queue.ts | No verificado aquí pero presumible — revisar si libera slots en errores |
| BE-24 | 🟢 | Positivos | Cryptos sólidos (AES-256-GCM), bcrypt 12 rounds, sessions PG-backed, helmet, CORS estricto, rate limit PG, redact en logger, input sanitization, auth middleware universal |

---

## BLOQUE C — ROUTES (47 archivos)

### 🔴 BE-1 · 19 archivos con rutas `/projects/:projectId/*` SIN `requireClientAccess`

**Archivos afectados:**
```
ab-testing.ts, action-buttons.ts, admin.ts, audit.ts, consistency.ts,
enrichment.ts, exports.ts, images.ts, intelligence.ts, jobs.ts,
plans.ts, pricing.ts, products.ts, projects.ts, redesign.ts,
reference-images.ts, scripttag.ts, seo.ts, vault.ts
```

**Análisis del riesgo real:**

Hay que entender **cómo** se montan estos routers en `routes/index.ts`:

```typescript
router.use(requireAdmin);  // ← todo lo que va después exige rol admin
router.use(projectsRouter);
router.use(productsRouter);
// ... resto
```

**Conclusión:** los 19 archivos están **tras `requireAdmin`**. Un client (`role === "client"`) no puede acceder a estas rutas porque `requireAdmin` lo bloquea con 403. **NO hay leak cruzado en el modelo actual single-admin.**

**Pero:** si algún día se añade un segundo admin o se migra a multi-tenant, cualquier admin verá todos los proyectos. Esto no es bug hoy, pero es deuda de arquitectura. Lo marcamos como **🔴 crítico preventivo**.

**Fix preventivo para el día que haya multi-admin:**

```typescript
// lib/auth.ts — añadir este middleware
export async function requireProjectOwnership(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  const projectId = req.params.projectId || req.params.id;
  if (!projectId) { res.status(400).json({ error: "Missing project ID" }); return; }

  // Admins actuales: pasan sin verificar (single-admin model)
  if (req.session.role === "admin") {
    // Para multi-admin futuro, aquí comprobar que el admin es OWNER del proyecto:
    // const [p] = await db.select().from(projectsTable).where(
    //   and(eq(projectsTable.id, parseInt(projectId)), eq(projectsTable.ownerAdminId, req.session.userId))
    // );
    // if (!p) return res.status(403).json({ error: "Not your project" });
    return next();
  }

  // Clients: solo pueden tocar su propio proyecto
  if (req.session.role === "client" && String(req.session.clientId) === String(projectId)) {
    return next();
  }

  res.status(403).json({ error: "Access denied to this project" });
}
```

Y en `routes/index.ts` reemplazar `router.use(requireAdmin)` por middleware que pueda ser más granular en el futuro.

### 🟡 BE-7 · `/api/cms/content` público sin rate-limit específico

**Archivo:** `routes/index.ts:59`

```typescript
router.use("/cms", (req, res, next) => {
  if (req.method === "GET" && req.path === "/content") return next();  // ← público
  return requireAdmin(req, res, next);
}, cmsRouter);
```

**Riesgo:** un bot puede hacer GET `/api/cms/content` cada segundo y scrapear todo el JSON del CMS (textos, nav, configuración). El rate limit global `apiLimiter` es 300 req/min — alto.

**Fix:**

```typescript
// Rate limit específico para CMS público
const cmsPublicLimiter = rateLimit({
  windowMs: 60_000,
  max: 20,
  skip: (req) => req.method !== "GET",
  store: new PgRateLimitStore("cms-public"),
});

router.use("/cms", (req, res, next) => {
  if (req.method === "GET" && req.path === "/content") {
    return cmsPublicLimiter(req, res, next);
  }
  return requireAdmin(req, res, next);
}, cmsRouter);
```

### 🔴 BE-5 · User enumeration en login

**Archivo:** `routes/auth.ts:76-93`

```typescript
const [user] = await db.select().from(usersTable).where(...);
if (!user || !user.isActive) {
  await incrementRateLimit(rateLimitKey);
  res.status(401).json({ error: "Credenciales incorrectas" });
  return;
}
const valid = await bcrypt.compare(password, user.password);  // ← solo aquí tarda
```

El delay artificial `await new Promise(r => setTimeout(r, 200))` está **antes** del lookup — cuando el email no existe, la request tarda ~200ms. Cuando el email existe pero el password falla, tarda ~200ms + 60ms (bcrypt). Diferencia de ~60ms es medible y permite enumerar emails.

**Fix:**

```typescript
router.post("/login", async (req, res): Promise<void> => {
  try {
    const { email, password } = req.body ?? {};
    if (!email || typeof email !== "string" || !password || typeof password !== "string") {
      res.status(400).json({ error: "Email y contraseña son obligatorios" });
      return;
    }
    const ip = req.ip ?? "unknown";
    const rateLimitKey = `login:${ip}`;

    const limits = await getRateLimit(rateLimitKey);
    if (limits.count >= RATE_LIMIT_MAX && limits.blockedUntil && limits.blockedUntil > new Date()) {
      const mins = Math.ceil((limits.blockedUntil.getTime() - Date.now()) / 60000);
      res.status(429).json({ error: `Demasiados intentos. Espera ${mins} minuto(s).` });
      return;
    }

    const [user] = await db.select().from(usersTable)
      .where(eq(usersTable.email, email.toLowerCase().trim()));

    // FIX: siempre hacer bcrypt.compare, incluso si el user no existe.
    // Usar un hash dummy que nunca matchea — tiempo constante.
    const DUMMY_HASH = "$2a$12$CwTycUXWue0Thq9StjUM0uJ8N5cCUGn8RHW6X3HqQe3fFDrHBZpNu"; // hash de "not-a-real-password"
    const hashToCompare = user?.password ?? DUMMY_HASH;
    const valid = await bcrypt.compare(password, hashToCompare);

    if (!user || !user.isActive || !valid) {
      await incrementRateLimit(rateLimitKey);
      res.status(401).json({ error: "Credenciales incorrectas" });
      return;
    }

    await clearRateLimit(rateLimitKey);
    req.session.userId = user.id;
    req.session.role = user.role;
    req.session.clientId = user.clientId ?? null;
    req.session.name = user.name;
    req.session.email = user.email;

    await db.update(usersTable).set({ lastLogin: new Date() }).where(eq(usersTable.id, user.id));
    await recordAudit({ userId: user.id, action: "login", details: `Login desde ${ip}`, ipAddress: ip });

    res.json({ success: true, role: user.role, name: user.name, clientId: user.clientId });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});
```

### 🟡 BE-11 · OAuth state en memoria

**Archivo:** `routes/projects.ts:60`

```typescript
const oauthState = new Map<string, {...}>();
```

Si hay >1 proceso Node (cluster/PM2) el state de Shopify OAuth no se comparte. El callback puede caer en otro proceso y fallar.

**Fix:** usar la tabla `sessions` o una tabla dedicada:

```typescript
// Schema nuevo (añadir a lib/db/src/schema/sessions.ts o nuevo archivo):
export const oauthStatesTable = pgTable("oauth_states", {
  state: text("state").primaryKey(),
  data: text("data").notNull(),  // JSON stringified
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// En projects.ts:
async function saveOAuthState(state: string, data: object, ttlMs = 600_000): Promise<void> {
  await db.insert(oauthStatesTable).values({
    state,
    data: JSON.stringify(data),
    expiresAt: new Date(Date.now() + ttlMs),
  });
}
async function loadOAuthState(state: string): Promise<object | null> {
  const [row] = await db.select().from(oauthStatesTable)
    .where(and(eq(oauthStatesTable.state, state), gt(oauthStatesTable.expiresAt, new Date())));
  if (!row) return null;
  // cleanup one-shot
  await db.delete(oauthStatesTable).where(eq(oauthStatesTable.state, state));
  return JSON.parse(row.data);
}
// Limpieza periódica:
setInterval(() => {
  db.delete(oauthStatesTable).where(lt(oauthStatesTable.expiresAt, new Date())).catch(() => {});
}, 10 * 60_000);
```

### 🟡 BE-17 · Body limit 50MB global

**Archivo:** `app.ts:94`

```typescript
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));
```

**Riesgo:** toda ruta acepta JSON 50MB. Un atacante puede mandar 50MB a `/api/auth/login` y agotar memoria.

**Fix:**

```typescript
// Default bajo para todas las rutas
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

// Límites específicos por ruta de IA que recibe imágenes:
app.use("/api/reference/analyze-image", express.json({ limit: "25mb" }));
app.use("/api/reference/analyze-video", express.json({ limit: "50mb" }));
app.use("/api/shopybrain/absorb-image", express.json({ limit: "15mb" }));
app.use("/api/shopybrain/create-product-from-image", express.json({ limit: "15mb" }));
app.use("/api/fusion-studio/analyze", express.json({ limit: "15mb" }));
app.use("/api/cms/ai/improve", express.json({ limit: "3mb" }));
```

### 🟡 BE-18 · Session cookie sameSite:strict

**Archivo:** `app.ts:133`

```typescript
sameSite: process.env.NODE_ENV === "production" ? "strict" : "lax",
```

**Problema:** `strict` rompe el flujo OAuth de Shopify:
1. Usuario click "Conectar Shopify" → redirect a `shopify.com/admin/oauth/authorize`
2. Shopify redirige de vuelta a `shopycrafter.com/api/shopify/oauth/callback`
3. Como el referrer es `shopify.com` (cross-site), el browser **no envía la cookie de sesión**
4. El callback no puede asociar la autorización con el usuario logueado

**Fix:**

```typescript
sameSite: process.env.NODE_ENV === "production" ? "lax" : "lax",
```

`lax` sigue bloqueando CSRF en POST/PUT/DELETE (que es el vector peligroso) pero permite GET con navegación desde otros sites (OAuth callbacks son GETs).

Si quieres CSRF hardening adicional, añade un token CSRF double-submit para mutations:

```typescript
// Middleware CSRF para mutations
app.use((req, res, next) => {
  if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) {
    const token = req.headers["x-csrf-token"];
    const cookieToken = req.cookies?.["csrf-token"];
    if (!token || token !== cookieToken) {
      return res.status(403).json({ error: "CSRF token missing/invalid" });
    }
  }
  next();
});
```

### 🟡 BE-19 · Admin crea usuarios con password random

**Archivo:** `routes/admin.ts:46`

```typescript
const hashed = await bcrypt.hash(password ?? randomBytes(16).toString("hex"), 12);
```

Si el admin crea un user sin pasar password, se genera uno random que nadie conoce. El usuario queda inaccesible a menos que use `/forgot-password`.

**Fix:**

```typescript
router.post("/users", async (req, res): Promise<void> => {
  try {
    const { email, name, role, clientId, password } = req.body as {
      email: string; name: string; role: "admin" | "client";
      clientId?: string; password?: string;
    };

    if (!email || !name) {
      res.status(400).json({ error: "email y name requeridos" });
      return;
    }

    const safeRole: "admin" | "client" = role === "admin" ? "client" : role;
    const id = randomBytes(16).toString("hex");

    let userPassword = password;
    let emailSent = false;

    if (!userPassword) {
      // Crear usuario SIN password, con invite token en su lugar.
      // El usuario debe hacer flujo de invite-setup para establecer el password.
      const inviteToken = randomBytes(32).toString("hex");
      const inviteExpires = new Date(Date.now() + 48 * 60 * 60 * 1000);

      await db.insert(usersTable).values({
        id, email: email.toLowerCase().trim(),
        password: await bcrypt.hash(randomBytes(16).toString("hex"), 12), // placeholder
        name, role: safeRole, clientId: clientId ?? null,
        isActive: 0,  // inactive hasta que setee password
        inviteToken, inviteExpires,
      });

      const appUrl = process.env.APP_URL ?? "https://shopycrafter.com";
      const inviteLink = `${appUrl}/invite/${inviteToken}`;
      // TODO: enviar email con el link via Klaviyo (como en projects/invite)
      emailSent = false;

      await recordAudit({
        userId: req.session.userId!, action: "create_user_invite",
        details: `Created user ${email} (${safeRole}) with invite`,
      });

      res.json({ id, email, name, role: safeRole, inviteLink, message: "Usuario creado — envía este enlace para que establezca su contraseña." });
      return;
    }

    // Password proporcionado — verificar complejidad
    if (userPassword.length < 12) {
      res.status(400).json({ error: "Password debe tener al menos 12 caracteres" });
      return;
    }

    const hashed = await bcrypt.hash(userPassword, 12);
    await db.insert(usersTable).values({
      id, email: email.toLowerCase().trim(), password: hashed, name, role: safeRole,
      clientId: clientId ?? null, isActive: 1,
    });

    await recordAudit({ userId: req.session.userId!, action: "create_user",
      details: `Created user ${email} (${safeRole})` });
    res.json({ id, email, name, role: safeRole });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});
```

---

## BLOQUE D — LIB (47 archivos)

### 🟡 BE-8 · lib/crypto.ts — clave temporal destruye datos

**Archivo:** `lib/crypto.ts:8-23`

Si no hay `ENCRYPTION_KEY`, genera una aleatoria en memoria con warning. **Cualquier dato cifrado en esa sesión es irrecuperable tras reinicio.**

**Fix:** mejor **negarse a arrancar** que aceptar pérdida de datos silenciosa:

```typescript
export function validateEncryptionKey(): void {
  const keyHex = process.env.ENCRYPTION_KEY;
  if (!keyHex) {
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "╔════════════════════════════════════════════════════════╗\n" +
        "║  ❌ ENCRYPTION_KEY not set in production               ║\n" +
        "║  Generate one: openssl rand -hex 32                    ║\n" +
        "║  Set env var ENCRYPTION_KEY with the result.           ║\n" +
        "╚════════════════════════════════════════════════════════╝"
      );
    }
    // Dev only: permitir key temporal con warning muy visible
    const generated = randomBytes(32).toString("hex");
    process.env.ENCRYPTION_KEY = generated;
    tempKeyGenerated = true;
    console.warn("⚠️  DEV ONLY: ENCRYPTION_KEY generated temporarily. SET IT IN PRODUCTION.");
  } else if (keyHex.length !== 64 || !/^[0-9a-fA-F]+$/.test(keyHex)) {
    throw new Error("ENCRYPTION_KEY must be a 64-character hex string (32 bytes)");
  }
}
```

### 🟡 BE-15 · lib/claude.ts — timeout sin cleanup

**Archivo:** `lib/claude.ts:156-180`

```typescript
const stream = client.messages.stream(
  { model, max_tokens, system, messages },
  { signal: AbortSignal.timeout(timeoutMs) }
);
const response = await stream.finalMessage();
```

Si `AbortSignal.timeout(180_000)` dispara, el stream se cancela. Pero el consumo de tokens **ya ha empezado** — Anthropic puede haber facturado 3 min de procesamiento. El flujo no notifica al usuario ni incrementa el contador de uso.

**Fix parcial:** añadir métrica de tokens consumidos aunque la request se cancele:

```typescript
export async function askClaude(
  projectId: number,
  messages: Array<{ role: "user" | "assistant"; content: string }>,
  systemPrompt?: string,
  maxTokens = 8192,
  timeoutMs = 180_000,
): Promise<string> {
  const { withClaudeQueue } = await import("./claude-queue.js");
  return withClaudeQueue(async () => {
    const client = await getClaudeClient(projectId);
    const startTime = Date.now();

    try {
      const stream = client.messages.stream(
        { model: CLAUDE_MODEL, max_tokens: maxTokens, system: systemPrompt ?? SHOPIFY_EXPERT_SYSTEM, messages },
        { signal: AbortSignal.timeout(timeoutMs) }
      );
      const response = await stream.finalMessage();

      if (response.stop_reason === "max_tokens") {
        logger.warn({ maxTokens, model: CLAUDE_MODEL,
          inputTokens: response.usage?.input_tokens,
          outputTokens: response.usage?.output_tokens
        }, "[Claude] ⚠️ RESPONSE TRUNCATED");
      }

      // FIX: loggear uso con proyecto
      logger.info({
        projectId, model: CLAUDE_MODEL,
        inputTokens: response.usage?.input_tokens,
        outputTokens: response.usage?.output_tokens,
        durationMs: Date.now() - startTime,
      }, "[Claude] Tokens consumed");

      const content = response.content[0];
      if (content.type !== "text") throw new Error("Unexpected non-text Claude response");
      return content.text;
    } catch (err) {
      // FIX: loggear fallos con timing para detectar patterns
      logger.warn({
        projectId, err: err instanceof Error ? err.message : String(err),
        durationMs: Date.now() - startTime, timeoutMs
      }, "[Claude] Request failed/cancelled");
      throw err;
    }
  });
}
```

### 🟡 BE-16 · lib/gemini.ts — cliente singleton sin rotación

**Archivo:** `lib/gemini.ts:20-38`

```typescript
let _ai: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!_ai) { /* init */ }
  return _ai;
}
```

Si se rota la clave API via panel admin, el singleton sigue con la clave antigua hasta reinicio.

**Fix:**

```typescript
let _ai: GoogleGenAI | null = null;
let _aiKeyHash: string | null = null;

function getGeminiClient(): GoogleGenAI {
  const directKey = process.env.GEMINI_API_KEY;
  const proxyKey = process.env.AI_INTEGRATIONS_GEMINI_API_KEY;
  const proxyUrl = process.env.AI_INTEGRATIONS_GEMINI_BASE_URL;

  const currentHash = `${directKey ?? ""}|${proxyKey ?? ""}|${proxyUrl ?? ""}`;
  if (_ai && _aiKeyHash === currentHash) return _ai;

  if (directKey) {
    _ai = new GoogleGenAI({ apiKey: directKey });
  } else if (proxyKey && proxyUrl) {
    _ai = new GoogleGenAI({ apiKey: proxyKey, httpOptions: { apiVersion: "", baseUrl: proxyUrl } });
  } else {
    throw new Error("Gemini not configured: set GEMINI_API_KEY or Replit AI Integrations");
  }
  _aiKeyHash = currentHash;
  return _ai;
}
```

### 🟡 BE-12 · lib/cache.ts sin sharding

Cache en Map local. Si el servidor hace cluster (PM2 con `instances: "max"`), cada worker tiene su propia cache → misses.

**Fix estratégico:** cuando necesites escalar a varios workers, migrar a Redis. De momento es OK si `instances: 1` (que es lo habitual en Replit).

### 🟢 Positivos destacables en lib/

- **`lib/crypto.ts`**: AES-256-GCM con auth tag, IV aleatorio por cifrado, validación de key al arranque. ✅
- **`lib/shopify.ts`**: auto-refresh de token 30 min antes de expirar, retry con backoff, timeouts razonables. ✅
- **`lib/logger.ts`**: pino con redact de cookies + auth headers. ✅
- **`lib/plan-limits.ts`**: lógica clara, cuotas base + créditos en packs, reseteo mensual automático. ✅
- **`lib/shopify.ts:shopifyRetry`**: maneja 429 + 5xx con `[1s, 2s, 4s]` exponencial. ✅

---

## BLOQUE E — SCHEMA DRIZZLE (30 tablas)

### 🔴 BE-2 · `users.clientId` sin FK

**Archivo:** `lib/db/src/schema/users.ts:10`

```typescript
clientId: text("client_id"),  // ← sin .references(...)
```

Dos problemas:
1. No hay FK → puede contener `"admin"`, `"super"`, o cualquier string.
2. `users.clientId` es TEXT pero `projects.id` es SERIAL (integer). Comparación funciona por coerción pero es frágil.

**Fix:**

```typescript
// Migración SQL:
// ALTER TABLE users ALTER COLUMN client_id TYPE integer USING client_id::integer;
// ALTER TABLE users ADD CONSTRAINT users_client_id_fk
//   FOREIGN KEY (client_id) REFERENCES projects(id) ON DELETE SET NULL;
// CREATE INDEX idx_users_client_id ON users(client_id);

// Schema actualizado:
import { projectsTable } from "./projects";

export const usersTable = pgTable("users", {
  id: text("id").primaryKey(),
  email: text("email").unique().notNull(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().$type<"admin" | "client">(),
  clientId: integer("client_id").references(() => projectsTable.id, { onDelete: "set null" }),  // FIX
  isActive: integer("is_active").default(1).notNull(),
  avatarColor: text("avatar_color").default("#5b4eff"),
  inviteToken: text("invite_token").unique(),  // FIX: unique implica índice
  inviteExpires: timestamp("invite_expires"),
  resetToken: text("reset_token").unique(),   // FIX: unique implica índice
  resetExpires: timestamp("reset_expires"),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  idxEmail: index("idx_users_email").on(table.email),
  idxClientId: index("idx_users_client_id").on(table.clientId),
  idxRole: index("idx_users_role").on(table.role),
}));
```

**Impacto code-breaking:** el código que asigna `clientId = user.clientId ?? null` y luego compara con `String(req.session.clientId)` seguirá funcionando porque Postgres hace cast automático, pero el tipo TS cambia de `string | null` a `number | null`. Hay que ajustar en:
- `routes/auth.ts:96, 223`
- `routes/admin.ts:240`
- `lib/auth.ts:30`
- Sesión tipo: `clientId: string | null` → `number | null`

### 🔴 BE-3 · resetToken e inviteToken sin índice

**Fix:** ya incluido en BE-2 con `.unique()` que crea índice.

**Impacto:** lookups de `/api/auth/invite/:token` y `/api/auth/reset-password` pasan de O(n) a O(log n). En una tabla con 1000 users es 30× más rápido.

### 🔴 BE-4 · projectId como TEXT en tablas que deberían ser INTEGER

**Tablas afectadas:**

```typescript
// schema/messages.ts:
projectId: text("project_id").notNull(),  // ❌ debería integer + FK

// schema/inventory.ts:
projectId: text("project_id").notNull(),  // ❌

// schema/competitors.ts (presumible), approvals, audit_log, etc.
```

Estas tablas tienen `projectId` como TEXT pero lo comparan con `projectsTable.id` (SERIAL integer). Funciona por cast pero:
- **No hay FK** → pueden quedar huérfanos al borrar un proyecto.
- **Índice sobre TEXT** es menos eficiente que sobre INTEGER.
- **Sin cascade** → cuando se borra un proyecto, los registros relacionados quedan colgando.

**Fix global (migración):**

```sql
-- Hacer para cada tabla con project_id TEXT:
ALTER TABLE messages ALTER COLUMN project_id TYPE integer USING project_id::integer;
ALTER TABLE messages ADD CONSTRAINT messages_project_id_fk
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;
CREATE INDEX idx_messages_project_id ON messages(project_id);

-- Igual para: inventory_tracking, restock_orders, sales_analytics,
--             audit_log, approvals, email_flows, email_templates,
--             competitors, etc.
```

**Impacto code-breaking:** el código hace queries tipo `eq(auditLogTable.projectId, projectId)` donde `projectId` es string. Después del cambio debe ser integer. Sed masivo:

```typescript
// ANTES:
eq(auditLogTable.projectId, projectId)
// DESPUÉS (si projectId viene de URL):
eq(auditLogTable.projectId, parseInt(projectId))
```

### 🟡 BE-10 · Índices compuestos faltantes

**Ejemplo crítico:** `products` se consulta por `(projectId, shopifyProductId)` constantemente.

```typescript
// schema/products.ts — añadir índices:
export const productsTable = pgTable("products", {
  // ... campos ...
}, (table) => ({
  idxProjectShopifyId: index("idx_products_project_shopify").on(table.projectId, table.shopifyProductId),
  idxProjectStatus: index("idx_products_project_status").on(table.projectId, table.status),
  idxProjectAuditScore: index("idx_products_project_score").on(table.projectId, table.auditScore),
}));
```

### 🟡 BE-13 · `subscriptionsTable.plan` text sin constraint

Campo libre. Puede meter `"pro"` pero también `"super-god-mode"` sin validación.

**Fix con check constraint:**

```typescript
// schema/billing.ts:
import { check } from "drizzle-orm/pg-core";

export const subscriptionsTable = pgTable("subscriptions", {
  userId: text("user_id").primaryKey().references(() => usersTable.id, { onDelete: "cascade" }),
  stripeCustomerId: text("stripe_customer_id").unique(),
  stripeSubscriptionId: text("stripe_subscription_id"),
  plan: text("plan").default("trial").notNull(),
  status: text("status").default("active").notNull(),
  // ... resto
}, (table) => ({
  checkPlan: check("subscriptions_plan_check", sql`${table.plan} IN ('trial', 'starter', 'pro', 'agency', 'enterprise')`),
  checkStatus: check("subscriptions_status_check", sql`${table.status} IN ('active', 'trialing', 'cancelled', 'past_due')`),
}));
```

### 🟡 BE-14 · FK sin onDelete en email_flows, email_templates

**Archivos:** `schema/email_flows.ts:14`, `schema/email_templates.ts:15`

```typescript
// ANTES:
projectId: integer("project_id").references(() => projectsTable.id),

// DESPUÉS:
projectId: integer("project_id").notNull().references(() => projectsTable.id, { onDelete: "cascade" }),
```

### ⚠️ BE-20, BE-21 · Índices faltantes en `messages`, `audit_log`

```typescript
// schema/messages.ts:
export const messagesTable = pgTable("messages", {
  // ...
}, (table) => ({
  idxProjectCreated: index("idx_messages_project_created").on(table.projectId, table.createdAt),
  idxProjectUnread: index("idx_messages_unread").on(table.projectId, table.isRead),
}));

// schema/users.ts:
export const auditLogTable = pgTable("audit_log", {
  // ...
}, (table) => ({
  idxUserCreated: index("idx_audit_user_created").on(table.userId, table.createdAt),
  idxProjectCreated: index("idx_audit_project_created").on(table.projectId, table.createdAt),
  idxAction: index("idx_audit_action").on(table.action),
}));
```

---

## RESUMEN TOTAL DE LA AUDITORÍA SHOPY CRAFTER

| Bloque | Hallazgos | Críticos | Altos | Medios | Archivos auditados |
|---|---|---|---|---|---|
| **A** — shopybrain.ts | 25 | 6 | 5 | 14 | 1 (9.661 líneas) |
| **B** — frontend | 20 | 2 | 9 | 6 | 144 archivos |
| **C** — routes | 11 | 3 | 7 | 1 | 46 archivos |
| **D** — lib | 6 | 0 | 4 | 2 | 47 archivos |
| **E** — schema | 7 | 3 | 3 | 1 | 30 tablas |
| **TOTAL** | **69** | **14** | **28** | **24** | **268 archivos** |

---

## PLAN MAESTRO DE REMEDIACIÓN

### Sprint 1 — Seguridad crítica (1 semana)

1. BLOQUE A: CRIT-1/2/3/4/5 (fix_code, modify_ui, DoS imagen, path traversal)
2. BLOQUE B: FE-3 (XSS Redesign), FE-1 (postMessage allowlist)
3. BLOQUE C: BE-5 (user enumeration), BE-17 (body limits)
4. BLOQUE E: BE-2, BE-3, BE-4 (índices + tipos correctos)
5. Deploy + test en staging

### Sprint 2 — Hardening (1 semana)

6. BLOQUE A: CRIT-6 (confirmación bulk)
7. BLOQUE B: FE-16 (multi-action confirmación), FE-8 (timeout categorizado)
8. BLOQUE C: BE-11 (OAuth state DB), BE-19 (invite flow), BE-18 (sameSite lax)
9. BLOQUE D: BE-8 (encryption key required), BE-15 (Claude telemetría)
10. BLOQUE E: BE-10, BE-13, BE-14, BE-20, BE-21 (índices + cascades + checks)

### Sprint 3 — Refactor (2 semanas)

11. BLOQUE A: plan de split shopybrain.ts en 7 módulos
12. BLOQUE B: migración react-query, responsive, partir OmniChatbot
13. BLOQUE C: extraer templates HTML (budget, platform-report, contact)

### Sprint 4 — Observability + escalado

14. Monitoring (Sentry/PostHog)
15. Migrar cache a Redis si hacen falta >1 worker
16. CI/CD con typecheck + test automáticos

---

**FIN DEL BLOQUE C/D/E.**

Auditoría completa de Shopy Crafter: **69 hallazgos, 268 archivos, 4 semanas de trabajo estimado para quedar limpios.**
