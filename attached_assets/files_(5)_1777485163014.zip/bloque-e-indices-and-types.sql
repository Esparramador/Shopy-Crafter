-- ════════════════════════════════════════════════════════════════════════════
-- Shopy Crafter — Migración Bloque E (Schema DB)
-- ════════════════════════════════════════════════════════════════════════════
--
-- APLICAR EN: PostgreSQL (via `psql` o Drizzle push)
-- PREREQUISITO: Backup de la DB antes de ejecutar.
--
-- Esta migración cubre los hallazgos BE-2, BE-3, BE-4, BE-10, BE-13, BE-14,
-- BE-20, BE-21, BE-22 del Bloque C/D/E.
--
-- ATOMICIDAD: envuelto en una transacción. Si cualquier paso falla, rollback
-- completo. Tarda ~10-30 segundos en una DB con <1M registros.
--
-- COMANDO DE APLICACIÓN:
--   psql $DATABASE_URL -f migrations/bloque-e-indices-and-types.sql
--
-- O si prefieres uno por uno (más seguro para producción con datos):
--   Aplicar cada BLOQUE (comentario ═) por separado y verificar.
-- ════════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─── VERIFICAR QUE HAY BACKUP ANTES (manual) ─────────────────────────────────
DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '════════════════════════════════════════════════════════════════';
  RAISE NOTICE '  Shopy Crafter — Migración Bloque E';
  RAISE NOTICE '  ¿Has hecho backup? Ctrl+C ahora si no.';
  RAISE NOTICE '════════════════════════════════════════════════════════════════';
  RAISE NOTICE '';
  PERFORM pg_sleep(2);
END $$;

-- ════════════════════════════════════════════════════════════════════════════
-- BLOQUE 1 — Users: clientId como INTEGER + FK + índices (FIX BE-2, BE-3)
-- ════════════════════════════════════════════════════════════════════════════

-- Convertir client_id de TEXT a INTEGER. CUIDADO: si algún user tiene
-- un string no-numérico (p.ej. "admin"), la conversión fallará.
-- Limpiar primero:
UPDATE users SET client_id = NULL
  WHERE client_id IS NOT NULL AND client_id !~ '^[0-9]+$';

-- Convertir tipo
ALTER TABLE users
  ALTER COLUMN client_id TYPE integer USING NULLIF(client_id, '')::integer;

-- FK con SET NULL al borrar proyecto
ALTER TABLE users
  DROP CONSTRAINT IF EXISTS users_client_id_fk,
  ADD CONSTRAINT users_client_id_fk
    FOREIGN KEY (client_id) REFERENCES projects(id) ON DELETE SET NULL;

-- Índices
CREATE INDEX IF NOT EXISTS idx_users_client_id ON users(client_id) WHERE client_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- UNIQUE en invite_token y reset_token (crea índice implícito)
-- Deduplicar nulos primero (Postgres permite múltiples NULLs en UNIQUE,
-- pero mejor ser explícito):
DROP INDEX IF EXISTS users_invite_token_idx;
DROP INDEX IF EXISTS users_reset_token_idx;
CREATE UNIQUE INDEX IF NOT EXISTS users_invite_token_idx
  ON users(invite_token) WHERE invite_token IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS users_reset_token_idx
  ON users(reset_token) WHERE reset_token IS NOT NULL;

-- ════════════════════════════════════════════════════════════════════════════
-- BLOQUE 2 — Tablas con project_id TEXT → INTEGER + FK CASCADE (FIX BE-4)
-- ════════════════════════════════════════════════════════════════════════════

-- messages
UPDATE messages SET project_id = NULL WHERE project_id !~ '^[0-9]+$';
ALTER TABLE messages
  ALTER COLUMN project_id TYPE integer USING NULLIF(project_id, '')::integer;
ALTER TABLE messages
  DROP CONSTRAINT IF EXISTS messages_project_id_fk,
  ADD CONSTRAINT messages_project_id_fk
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS idx_messages_project_created
  ON messages(project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_unread
  ON messages(project_id, is_read) WHERE is_read = 0;

-- audit_log
UPDATE audit_log SET project_id = NULL WHERE project_id IS NOT NULL AND project_id !~ '^[0-9]+$';
ALTER TABLE audit_log
  ALTER COLUMN project_id TYPE integer USING NULLIF(project_id, '')::integer;
ALTER TABLE audit_log
  DROP CONSTRAINT IF EXISTS audit_log_project_id_fk,
  ADD CONSTRAINT audit_log_project_id_fk
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_audit_user_created
  ON audit_log(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_project_created
  ON audit_log(project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action
  ON audit_log(action);

-- approvals
UPDATE approvals SET project_id = NULL WHERE project_id !~ '^[0-9]+$';
ALTER TABLE approvals
  ALTER COLUMN project_id TYPE integer USING NULLIF(project_id, '')::integer;
ALTER TABLE approvals
  DROP CONSTRAINT IF EXISTS approvals_project_id_fk,
  ADD CONSTRAINT approvals_project_id_fk
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS idx_approvals_project_status
  ON approvals(project_id, status);

-- inventory_tracking
UPDATE inventory_tracking SET project_id = NULL WHERE project_id !~ '^[0-9]+$';
ALTER TABLE inventory_tracking
  ALTER COLUMN project_id TYPE integer USING NULLIF(project_id, '')::integer;
ALTER TABLE inventory_tracking
  DROP CONSTRAINT IF EXISTS inventory_tracking_project_id_fk,
  ADD CONSTRAINT inventory_tracking_project_id_fk
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS idx_inventory_project_product
  ON inventory_tracking(project_id, product_id);

-- restock_orders
UPDATE restock_orders SET project_id = NULL WHERE project_id !~ '^[0-9]+$';
ALTER TABLE restock_orders
  ALTER COLUMN project_id TYPE integer USING NULLIF(project_id, '')::integer;
ALTER TABLE restock_orders
  DROP CONSTRAINT IF EXISTS restock_orders_project_id_fk,
  ADD CONSTRAINT restock_orders_project_id_fk
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS idx_restock_project_urgency
  ON restock_orders(project_id, urgency);

-- sales_analytics
UPDATE sales_analytics SET project_id = NULL WHERE project_id !~ '^[0-9]+$';
ALTER TABLE sales_analytics
  ALTER COLUMN project_id TYPE integer USING NULLIF(project_id, '')::integer;
ALTER TABLE sales_analytics
  DROP CONSTRAINT IF EXISTS sales_analytics_project_id_fk,
  ADD CONSTRAINT sales_analytics_project_id_fk
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS idx_sales_project_date
  ON sales_analytics(project_id, order_date DESC);
CREATE INDEX IF NOT EXISTS idx_sales_customer
  ON sales_analytics(customer_id) WHERE customer_id IS NOT NULL;

-- ════════════════════════════════════════════════════════════════════════════
-- BLOQUE 3 — Índices compuestos en products (FIX BE-10)
-- ════════════════════════════════════════════════════════════════════════════

CREATE INDEX IF NOT EXISTS idx_products_project_shopify
  ON products(project_id, shopify_product_id);
CREATE INDEX IF NOT EXISTS idx_products_project_status
  ON products(project_id, status);
CREATE INDEX IF NOT EXISTS idx_products_project_score
  ON products(project_id, audit_score DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_products_last_audited
  ON products(last_audited_at DESC NULLS LAST);

-- ════════════════════════════════════════════════════════════════════════════
-- BLOQUE 4 — Billing: constraints + cascade (FIX BE-13)
-- ════════════════════════════════════════════════════════════════════════════

-- subscriptions.plan con check constraint
ALTER TABLE subscriptions
  DROP CONSTRAINT IF EXISTS subscriptions_plan_check;
ALTER TABLE subscriptions
  ADD CONSTRAINT subscriptions_plan_check
    CHECK (plan IN ('trial', 'starter', 'pro', 'agency', 'enterprise'));

ALTER TABLE subscriptions
  DROP CONSTRAINT IF EXISTS subscriptions_status_check;
ALTER TABLE subscriptions
  ADD CONSTRAINT subscriptions_status_check
    CHECK (status IN ('active', 'trialing', 'cancelled', 'past_due', 'incomplete'));

-- FK con cascade al borrar usuario
ALTER TABLE subscriptions
  DROP CONSTRAINT IF EXISTS subscriptions_user_id_fk,
  ADD CONSTRAINT subscriptions_user_id_fk
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- affiliates: FK + cascade
ALTER TABLE affiliates
  DROP CONSTRAINT IF EXISTS affiliates_user_id_fk,
  ADD CONSTRAINT affiliates_user_id_fk
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- referral_tracking: FK al afiliado
ALTER TABLE referral_tracking
  DROP CONSTRAINT IF EXISTS referral_tracking_affiliate_id_fk,
  ADD CONSTRAINT referral_tracking_affiliate_id_fk
    FOREIGN KEY (affiliate_id) REFERENCES affiliates(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_referrals_affiliate
  ON referral_tracking(affiliate_id);

-- ════════════════════════════════════════════════════════════════════════════
-- BLOQUE 5 — Email flows y templates: cascade (FIX BE-14)
-- ════════════════════════════════════════════════════════════════════════════

ALTER TABLE email_flows
  DROP CONSTRAINT IF EXISTS email_flows_project_id_fk;
ALTER TABLE email_flows
  ADD CONSTRAINT email_flows_project_id_fk
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;

ALTER TABLE email_templates
  DROP CONSTRAINT IF EXISTS email_templates_project_id_fk;
ALTER TABLE email_templates
  ADD CONSTRAINT email_templates_project_id_fk
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_email_flows_project
  ON email_flows(project_id);
CREATE INDEX IF NOT EXISTS idx_email_templates_project
  ON email_templates(project_id);

-- ════════════════════════════════════════════════════════════════════════════
-- BLOQUE 6 — Shopybrain: índices para queries frecuentes
-- ════════════════════════════════════════════════════════════════════════════

CREATE INDEX IF NOT EXISTS idx_omnicore_memories_confidence
  ON omnicore_memories(confidence DESC)
  WHERE confidence >= 0.5;
CREATE INDEX IF NOT EXISTS idx_omnicore_memories_niche
  ON omnicore_memories(niche) WHERE niche IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_omnicore_memories_type
  ON omnicore_memories(memory_type);

CREATE INDEX IF NOT EXISTS idx_omnicore_insights_domain
  ON omnicore_insights(domain, confidence DESC);

-- ════════════════════════════════════════════════════════════════════════════
-- BLOQUE 7 — Tabla oauth_states (FIX BE-11)
-- ════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS oauth_states (
  state text PRIMARY KEY,
  data text NOT NULL,
  expires_at timestamp NOT NULL,
  created_at timestamp DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_oauth_states_expires
  ON oauth_states(expires_at);

-- ════════════════════════════════════════════════════════════════════════════
-- BLOQUE 8 — Verificación final (no-destructiva)
-- ════════════════════════════════════════════════════════════════════════════

DO $$
DECLARE
  missing_fks text[];
BEGIN
  -- Listar tablas esperadas con FK a projects
  SELECT ARRAY_AGG(c.relname::text)
    INTO missing_fks
  FROM pg_class c
  JOIN pg_attribute a ON a.attrelid = c.oid
  WHERE a.attname = 'project_id'
    AND c.relkind = 'r'
    AND NOT EXISTS (
      SELECT 1 FROM pg_constraint con
      WHERE con.conrelid = c.oid
        AND con.contype = 'f'
        AND a.attnum = ANY(con.conkey)
    );

  IF array_length(missing_fks, 1) > 0 THEN
    RAISE NOTICE '';
    RAISE NOTICE '⚠️  Tablas con columna project_id pero SIN FK:';
    RAISE NOTICE '    %', array_to_string(missing_fks, ', ');
    RAISE NOTICE '    Revisa si necesitas añadir FK también a estas.';
  ELSE
    RAISE NOTICE '✅ Todas las tablas con project_id tienen FK.';
  END IF;
END $$;

-- ════════════════════════════════════════════════════════════════════════════
-- COMMIT
-- ════════════════════════════════════════════════════════════════════════════

COMMIT;

-- ════════════════════════════════════════════════════════════════════════════
-- POST-MIGRACIÓN: ajustar también los SCHEMA de Drizzle
-- ════════════════════════════════════════════════════════════════════════════
--
-- Tras aplicar esta SQL, hay que actualizar los archivos .ts en lib/db/src/schema
-- para que el tipo TypeScript refleje el cambio:
--
--   - lib/db/src/schema/users.ts            → client_id: integer
--   - lib/db/src/schema/messages.ts         → project_id: integer
--   - lib/db/src/schema/users.ts:auditLogTable → project_id: integer
--   - lib/db/src/schema/inventory.ts        → project_id: integer (las 3 tablas)
--   - lib/db/src/schema/billing.ts          → FK cascades
--   - lib/db/src/schema/email_flows.ts      → onDelete: cascade
--   - lib/db/src/schema/email_templates.ts  → onDelete: cascade
--
-- Ver schemas actualizados en fixes-bloque-c-d-e/schema/*.ts
--
-- Luego correr:
--   cd lib/db && pnpm drizzle-kit generate
--   cd lib/db && pnpm drizzle-kit push
--
-- Y rebuildar el cliente:
--   pnpm typecheck
--
-- ════════════════════════════════════════════════════════════════════════════
