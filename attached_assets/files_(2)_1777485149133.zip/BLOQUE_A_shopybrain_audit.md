# BLOQUE A — Auditoría profunda `shopybrain.ts`

**Fichero:** `artifacts/api-server/src/routes/shopybrain.ts` · **9.661 líneas** · **148 acciones** en el megaswitch (líneas 1755–9467).

**Ámbito del documento:**
1. Tabla maestra de las 148 acciones (nombre · línea · consume IA · verifica límite · escribe Shopify · requiere confirmación · estado)
2. Bugs **críticos** con parche listo para pegar
3. Bugs **altos** y **medios** con fix sugerido
4. Plan de split del archivo en 5 módulos sin romper nada

Todas las líneas citadas se refieren a `shopybrain.ts`. Todo el análisis se hizo sobre el código real extraído del tarball.

---

## 1. TABLA MAESTRA DE LAS 148 ACCIONES

Leyenda columnas:
- **IA**: consume Claude / Gemini / Replicate / Dual AI (❌ = no, 🧠 = sí)
- **Límite**: ¿verifica `checkProductionLimit` antes de consumir? (✅ sí · ❌ no · n/a si no gasta IA)
- **Shopify W**: ¿escribe en la tienda Shopify? (✅ sí · ❌ no)
- **Confirma**: ¿exige `params.confirmed`? (✅ sí · ❌ no · n/a si no es destructiva)
- **Estado**: ✅ ok · ⚠️ bug medio · 🟡 bug alto · 🔴 bug crítico

### 1.1 Productos — CRUD y operaciones puntuales

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 1 | `store_status` | 1755 | ❌ | n/a | ❌ | n/a | ✅ | Solo lectura (shop.json + counts) |
| 2 | `list_products` | 1798 | ❌ | n/a | ❌ | n/a | ✅ | Lista activos |
| 3 | `create_product` | 1904 | 🧠 | ❌ | ✅ | ❌ | 🟡 | Dual AI + imágenes. No cuenta uso |
| 4 | `edit_product` | 2711 | ❌ | n/a | ✅ | ❌ | ⚠️ | Edita sin confirmación ni diff |
| 5 | `change_price` | 2797 | ❌ | n/a | ✅ | ❌ | ⚠️ | Cambia precio en vivo |
| 6 | `regenerate_token` | 2847 | ❌ | n/a | ❌ | n/a | ✅ | |
| 7 | `get_scopes` | 2867 | ❌ | n/a | ❌ | n/a | ✅ | |
| 8 | `delete_product` | 2900 | ❌ | n/a | ✅ | ✅ | ✅ | **Única que exige confirmación** |
| 9 | `search_product` | 2920 | ❌ | n/a | ❌ | n/a | ✅ | |
| 10 | `publish_product` | 2991 | ❌ | n/a | ✅ | ❌ | ⚠️ | Publica sin confirmación |
| 11 | `get_orders` | 3036 | ❌ | n/a | ❌ | n/a | ✅ | |
| 12 | `set_product_status` | 3670 | ❌ | n/a | ✅ | ❌ | ⚠️ | |
| 13 | `list_all_products` | 3691 | ❌ | n/a | ❌ | n/a | ✅ | |
| 14 | `optimize_product` | 4252 | 🧠 Dual AI | ❌ | ✅ | ❌ | 🟡 | IIFE background sin lock |
| 15 | `optimize_all_products` | 4571 | 🧠 Dual AI ×N | ❌ | ✅ | ❌ | 🟡 | **Race condition** — IIFE sin lock |

### 1.2 Auditoría y scan

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 16 | `audit_store` | 3060 | ❌ | n/a | ❌ | n/a | ✅ | GraphQL + cálculos locales |
| 17 | `fix_unpublished` | 3397 | ❌ | n/a | ✅ bulk | ❌ | 🟡 | **Publica TODO sin confirmar** |
| 18 | `fix_missing_compare_prices` | 3494 | ❌ | n/a | ✅ bulk | ❌ | 🟡 | **Reescribe precios sin confirmar** |
| 19 | `scan_store` | 3587 | ❌ | n/a | ❌ | n/a | ✅ | |
| 20 | `search_suppliers` | 3789 | 🧠 | ❌ | ❌ | n/a | ⚠️ | Delega a endpoint interno |
| 21 | `modify_audit_filter` | 3835 | ❌ | n/a | ❌ | n/a | ✅ | |
| 22 | `diagnose_app` | 3879 | ❌ | **✅** | ❌ | n/a | ✅ | **Único sitio** que usa `checkProductionLimit` |
| 23 | `price_audit` | 5365 | ❌ | n/a | ❌ | n/a | ✅ | Catálogo de precios hardcodeado |
| 24 | `sync_catalog_prices` | 5435 | ❌ | n/a | ✅ bulk | ⚠️ dryRun | ⚠️ | Tiene dryRun pero default reescribe |
| 25 | `copyright_audit` | 7369 | 🧠 | ❌ | ❌ | n/a | 🟡 | JSON de Claude |
| 26 | `audit_app_offerings` | 6506 | 🧠 | ❌ | ❌ | n/a | 🔴 | `projectId || 2` hardcodeado |

### 1.3 Código y UI (peligrosas — escriben en disco)

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 27 | `list_source_files` | 4024 | ❌ | n/a | ❌ | n/a | 🔴 | **Path traversal** en `directory` |
| 28 | `inspect_code` | 4067 | 🧠 | ❌ | ❌ | n/a | 🔴 | `projectId || 2`; fs sin catch |
| 29 | `analyze_component` | 4127 | 🧠 | ❌ | ❌ | n/a | 🔴 | `projectId || 2`; fs sin catch |
| 30 | `fix_code` | 4205 | ❌ | n/a | **disco** | ❌ | 🔴 | **Reescribe ANY workspace file** |
| 31 | `modify_ui` | 6574 | 🧠 | ❌ | **disco** | ❌ | 🔴 | `projectId || 2`; reescribe frontend/backend |

### 1.4 Colecciones y variantes

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 32 | `create_collection` | 4754 | 🧠 | ❌ | ✅ | ❌ | 🟡 | Descripción IA sin tracking |
| 33 | `list_collections` | 4847 | ❌ | n/a | ❌ | n/a | ✅ | |
| 34 | `add_to_collection` | 4882 | ❌ | n/a | ✅ | ❌ | ✅ | |
| 35 | `edit_collection` | 4913 | ❌ | n/a | ✅ | ❌ | ⚠️ | |
| 36 | `delete_collection` | 4952 | ❌ | n/a | ✅ | ❌ | ⚠️ | **Destructiva sin confirmar** |
| 37 | `get_collection_products` | 4970 | ❌ | n/a | ❌ | n/a | ✅ | |
| 38 | `list_variants` | 5008 | ❌ | n/a | ❌ | n/a | ✅ | |
| 39 | `update_stock` | 5044 | ❌ | n/a | ✅ | ❌ | ⚠️ | |
| 40 | `bulk_update_stock` | 5110 | ❌ | n/a | ✅ bulk | ❌ | ⚠️ | |
| 41 | `update_product_price` | 5169 | ❌ | n/a | ✅ | ❌ | ⚠️ | |
| 42 | `bulk_update_prices` | 5219 | ❌ | n/a | ✅ bulk | ❌ | ⚠️ | |
| 43 | `list_products_with_prices` | 5301 | ❌ | n/a | ❌ | n/a | ✅ | |
| 44 | `add_variant` | 5813 | ❌ | n/a | ✅ | ❌ | ✅ | |
| 45 | `edit_variant` | 5864 | ❌ | n/a | ✅ | ❌ | ✅ | |
| 46 | `delete_variant` | 5912 | ❌ | n/a | ✅ | ❌ | ⚠️ | **Destructiva sin confirmar** |
| 47 | `auto_collections` | 5929 | 🧠 | ❌ | ✅ bulk | ❌ | 🟡 | Crea N colecciones con IA |
| 48 | `remove_from_collection` | 9371 | ❌ | n/a | ✅ | ❌ | ✅ | |

### 1.5 Páginas, CMS, themes

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 49 | `create_page` | 6007 | 🧠 Dual AI | ❌ | ✅ | ❌ | 🟡 | |
| 50 | `update_page` | 6088 | ❌ | n/a | ✅ | ❌ | ⚠️ | |
| 51 | `list_pages` | 6124 | ❌ | n/a | ❌ | n/a | ✅ | |
| 52 | `design_all_pages` | 6147 | 🧠 ×5 | ❌ | ✅ bulk | ❌ | 🟡 | 5 llamadas a Claude, 0 tracking |
| 53 | `optimize_images` | 6207 | 🧠 Dual AI | ❌ | ✅ bulk | ❌ | 🟡 | |
| 54 | `read_cms` | 6298 | ❌ | n/a | ❌ | n/a | ✅ | |
| 55 | `update_cms` | 6316 | ❌ | n/a | ❌ | n/a | ✅ | |
| 56 | `update_cms_batch` | 6327 | ❌ | n/a | ❌ | n/a | ✅ | |
| 57 | `reset_cms` | 6337 | ❌ | n/a | ❌ | n/a | ⚠️ | **Reset sin confirmar** |
| 58 | `generate_competitive_pricing` | 6345 | 🧠 Dual AI | ❌ | ✅ opt | ❌ | 🟡 | Crea productos Shopify opcional |
| 59 | `list_themes` | 6718 | ❌ | n/a | ❌ | n/a | ✅ | |
| 60 | `list_theme_files` | 6733 | ❌ | n/a | ❌ | n/a | ✅ | |
| 61 | `read_theme_file` | 6763 | ❌ | n/a | ❌ | n/a | ✅ | |
| 62 | `edit_theme_file` | 6806 | ❌ | n/a | ✅ theme | ❌ | ⚠️ | Escribe en theme Shopify |
| 63 | `create_theme_section` | 6900 | ❌ | n/a | ✅ theme | ❌ | ⚠️ | |
| 64 | `audit_theme` | 6932 | 🧠 Dual AI | ❌ | ❌ | n/a | 🟡 | |
| 65 | `edit_theme_css` | 7039 | ❌ | n/a | ✅ theme | ❌ | ⚠️ | |
| 66 | `edit_theme_settings` | 7098 | ❌ | n/a | ✅ theme | ❌ | ⚠️ | |
| 67 | `sync_store_theme` | 7168 | ❌ | n/a | ✅ theme | ❌ | ⚠️ | |

### 1.6 Brand kit y generadores

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 68 | `generate_brand_css` | 5520 | 🧠 opt | ❌ | ❌ | n/a | ⚠️ | |
| 69 | `generate_brand_kit` | 5557 | ❌ | n/a | ❌ | n/a | ✅ | Solo devuelve URLs |
| 70 | `generate_brand_guide` | 5580 | ❌ | n/a | ❌ | n/a | ✅ | |
| 71 | `run_universal_generator` | 5603 | 🧠 | ❌ | ❌ | n/a | 🟡 | Delega a `./generator.js` |
| 72 | `analyze_web_design` | 5645 | 🧠 | ❌ | ❌ | n/a | 🟡 | Web Lab completo |
| 73 | `fusion_analyze` | 5697 | 🧠 Vision | ❌ | ❌ | n/a | 🔴 | **DoS por imagen gigante** |
| 74 | `fusion_create_product` | 5730 | 🧠 Vision | ❌ | ✅ | ❌ | 🔴 | **DoS por imagen gigante** |
| 75 | `run_leveled_report` | 5777 | 🧠 | ❌ | ❌ | n/a | 🟡 | |

### 1.7 Rediseño y A/B testing

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 76 | `redesign_product` | 7444 | 🧠 | ❌ | ❌ preview | n/a | 🟡 | |
| 77 | `apply_redesign` | 7480 | ❌ | n/a | ✅ | ❌ | ⚠️ | |
| 78 | `bulk_redesign` | 7498 | 🧠 ×N | ❌ | ✅ bulk | ❌ | 🟡 | |
| 79 | `create_ab_test` | 7515 | ❌ | n/a | ❌ | n/a | ✅ | |
| 80 | `list_ab_tests` | 7531 | ❌ | n/a | ❌ | n/a | ✅ | |
| 81 | `declare_winner` | 7546 | ❌ | n/a | ✅ | ❌ | ⚠️ | |

### 1.8 SEO

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 82 | `seo_full_audit` | 7562 | 🧠 | ❌ | ❌ | n/a | 🟡 | Delega a endpoint |
| 83 | `keyword_intelligence` | 7577 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 84 | `blog_strategy` | 7593 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 85 | `generate_blog_post` | 7607 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 86 | `generate_schemas` | 7623 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 87 | `generate_all_metas` | 7638 | 🧠 | ❌ | ✅ opt | ❌ | 🟡 | |
| 88 | `fix_all_alt_texts` | 7653 | 🧠 | ❌ | ✅ bulk | ❌ | 🟡 | |
| 89 | `audit_page_speed` | 7667 | ❌ | n/a | ❌ | n/a | ✅ | |
| 90 | `generate_sitemap` | 7681 | ❌ | n/a | ❌ | n/a | ✅ | |

### 1.9 Competidores

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 91 | `scan_competitor` | 7695 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 92 | `discover_competitors` | 7712 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 93 | `analyze_competitor_product` | 7745 | 🧠 | ❌ | ❌ | n/a | 🟡 | |

### 1.10 Pricing / COGS / finanzas

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 94 | `calculate_optimal_price` | 7760 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 95 | `estimate_cogs` | 7775 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 96 | `auto_estimate_all_cogs` | 7790 | 🧠 ×N | ❌ | ❌ | n/a | 🟡 | |
| 97 | `price_simulator` | 7842 | ❌ | n/a | ❌ | n/a | ✅ | |
| 98 | `financial_forecast` | 7860 | ❌ | n/a | ❌ | n/a | ✅ | |
| 99 | `financial_dashboard` | 7875 | ❌ | n/a | ❌ | n/a | ✅ | |

### 1.11 Imágenes IA (las que SÍ deberían descontar créditos)

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 100 | `generate_product_images` | 7887 | 🧠 Replicate | ❌ | ✅ | ❌ | 🔴 | **Imágenes sin limit check** |
| 101 | `generate_images_from_reference` | 7911 | 🧠 Replicate | ❌ | ✅ | ❌ | 🔴 | |
| 102 | `virtual_tryon` | 7966 | 🧠 Replicate | ❌ | ✅ | ❌ | 🔴 | |
| 103 | `bulk_generate_images` | 8018 | 🧠 Replicate ×N | ❌ | ✅ bulk | ❌ | 🔴 | |

> **Nota crítica:** Los 4 endpoints sub-llamados (`/api/projects/.../images/generate`, `/api/projects/.../images/generate-from-reference`, `/api/projects/.../images/virtual-tryon`, `/api/projects/.../bulk-generate-images`) **sí** llaman a `checkProductionLimit` y `recordUsage` según el grep inicial (líneas 405, 639, 724 de `images.ts`, líneas 299, 349, 566, 621 de `reference-images.ts`, líneas 543, 778 de `fusion-studio.ts`). Por lo tanto estos 4 casos **no son vulnerabilidad económica** — se cobran en el endpoint interno. **Pero el flujo doble (shopybrain → localhost → images.ts) suma latencia y depende de que la cookie pase bien.**

### 1.12 Email / marketing / inventario

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 104 | `generate_email_flow` | 8039 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 105 | `generate_email` | 8058 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 106 | `inventory_sync` | 8077 | ❌ | n/a | ❌ | n/a | ✅ | |
| 107 | `inventory_alerts` | 8092 | ❌ | n/a | ❌ | n/a | ✅ | |
| 108 | `inventory_deep_report` | 8109 | ❌ | n/a | ❌ | n/a | ✅ | |
| 109 | `inventory_sync_orders` | 8138 | ❌ | n/a | ❌ | n/a | ✅ | |
| 110 | `inventory_sales_analytics` | 8154 | ❌ | n/a | ❌ | n/a | ✅ | |
| 111 | `sales_report` | 8183 | ❌ | n/a | ❌ | n/a | ✅ | |
| 112 | `inventory_customer_history` | 8214 | ❌ | n/a | ❌ | n/a | ✅ | |
| 113 | `send_restock_email` | 9332 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 114 | `restock_orders` | 9355 | ❌ | n/a | ❌ | n/a | ✅ | |
| 115 | `list_email_flows` | 9275 | ❌ | n/a | ❌ | n/a | ✅ | |
| 116 | `create_email_flow` | 9291 | ❌ | n/a | ❌ | n/a | ✅ | |
| 117 | `delete_email_flow` | 9318 | ❌ | n/a | ❌ | n/a | ⚠️ | **Sin confirmar** |

### 1.13 Agency, presupuestos, setup

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 118 | `agency_quote` | 8236 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 119 | `generate_budget` | 8251 | ❌ | n/a | ❌ | n/a | 🟡 | **~600 líneas HTML inline** |
| 120 | `generate_platform_report` | 8520 | ❌ | n/a | ❌ | n/a | 🟡 | **~700 líneas HTML inline** |
| 121 | `agency_proposal` | 8799 | 🧠 | ❌ | ❌ | n/a | 🟡 | |
| 122 | `setup_full_store` | 8814 | 🧠 ×N | ❌ | ✅ bulk | ❌ | 🟡 | |

### 1.14 Aprendizaje y knowledge

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 123 | `learn_from_url` | 8823 | 🧠 | ❌ | ❌ | n/a | ⚠️ | |
| 124 | `learn_from_content` | 8843 | ❌ | n/a | ❌ | n/a | ⚠️ | Sin validación de tamaño |
| 125 | `recall_knowledge` | 8863 | ❌ | n/a | ❌ | n/a | ✅ | |
| 126 | `brain_status` | 8896 | ❌ | n/a | ❌ | n/a | ✅ | |
| 127 | `brain_sync` | 7259 | 🧠 | ❌ | ❌ | n/a | ⚠️ | |
| 128 | `brain_stats` | 7285 | ❌ | n/a | ❌ | n/a | ✅ | |
| 129 | `brain_export` | 7318 | ❌ | n/a | ❌ | n/a | ✅ | |
| 130 | `analyze_external_store` | 8926 | 🧠 ×4 Gemini | ❌ | ❌ | n/a | 🟡 | Comparte handler con 131 |
| 131 | `external_pre_report` | 8927 | 🧠 ×4 Gemini | ❌ | ❌ | n/a | 🟡 | |

### 1.15 Usuarios, mensajes, aprobaciones

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 132 | `list_users` | 9054 | ❌ | n/a | ❌ | n/a | ✅ | |
| 133 | `create_user` | 9068 | ❌ | n/a | ❌ | n/a | ⚠️ | Password en params |
| 134 | `invite_client` | 9086 | ❌ | n/a | ❌ | n/a | ✅ | |
| 135 | `deactivate_user` | 9104 | ❌ | n/a | ❌ | ❌ | ⚠️ | |
| 136 | `activate_user` | 9118 | ❌ | n/a | ❌ | n/a | ✅ | |
| 137 | `reset_user_password` | 9132 | ❌ | n/a | ❌ | ❌ | 🟡 | **Password nueva en params sin confirmar** |
| 138 | `list_messages` | 9148 | ❌ | n/a | ❌ | n/a | ✅ | |
| 139 | `send_message` | 9164 | ❌ | n/a | ❌ | n/a | ⚠️ | Sin validar tamaño |
| 140 | `unread_messages` | 9181 | ❌ | n/a | ❌ | n/a | ✅ | |
| 141 | `list_approvals` | 9192 | ❌ | n/a | ❌ | n/a | ✅ | |
| 142 | `create_approval` | 9208 | ❌ | n/a | ❌ | n/a | ✅ | |
| 143 | `audit_log` | 9232 | ❌ | n/a | ❌ | n/a | ✅ | |

### 1.16 Automatizaciones y exports

| # | Acción | Línea | IA | Límite | Shopify W | Confirma | Estado | Notas |
|---|---|---|---|---|---|---|---|---|
| 144 | `list_automations` | 9246 | ❌ | n/a | ❌ | n/a | ✅ | |
| 145 | `run_automation` | 9260 | ❌ | n/a | ❌ | ❌ | ⚠️ | Puede lanzar jobs pesados |
| 146 | `generate_export` | 9398 | ❌ | n/a | ❌ | n/a | ✅ | |
| 147 | `run_full_audit_report` | 9426 | 🧠 indirect | ❌ | ❌ | n/a | 🟡 | |
| 148 | `generate_ai_report` | 9443 | 🧠 | ❌ | ❌ | n/a | 🟡 | |

### 1.17 Resumen numérico

- **148 acciones** totales · **147 handlers únicos** (`analyze_external_store`+`external_pre_report` comparten).
- **Consumen IA directa:** ~55 acciones.
- **Consumen IA indirecta** (vía `fetch localhost`): ~35 acciones.
- **Escriben en Shopify:** 42 acciones.
- **Escriben en disco del servidor:** 2 acciones (`fix_code`, `modify_ui`).
- **Tocan themes Shopify:** 6 acciones.
- **Exigen confirmación:** 1 acción (`delete_product`).
- **Verifican `checkProductionLimit` en shopybrain.ts:** 1 acción (`diagnose_app`, y ahí solo para token/sync).
- **Declaradas pero no implementadas:** ninguna — los 148 case del switch tienen bloque real.

---

## 2. BUGS CRÍTICOS — 🔴 (FIX REQUERIDO)

### 🔴 CRIT-1 · `fix_code` puede reescribir cualquier archivo del workspace

**Archivo:** `shopybrain.ts` · **Líneas 4205–4250**

**Problema:**
`resolveFilePath()` (líneas 85–108) busca el archivo en 5 raíces: `FRONTEND_ROOT`, `BACKEND_ROOT`, `WORKSPACE_ROOT`, y variantes con `src/`. La validación solo comprueba que el path final esté **dentro del workspace** — no que esté dentro de `FRONTEND_ROOT` o `BACKEND_ROOT`. Eso significa que Claude (o un input manipulado) puede pedir `fix_code` sobre `package.json`, `pnpm-workspace.yaml`, `replit.md`, archivos de `lib/db/src/schema/*`, o incluso el propio `shopybrain.ts`. También falta try/catch en `fs.readFileSync` (línea 4222) — si el archivo desaparece entre resolve y read, el server crashea.

**Fix:**

```typescript
case "fix_code": {
  const filePath = params?.filePath;
  const oldCode = params?.oldCode;
  const newCode = params?.newCode;
  const description = params?.description || "Fix aplicado por Shopy Crafter";

  if (!filePath || !oldCode || newCode === undefined) {
    res.status(400).json({ error: "filePath, oldCode y newCode son requeridos" });
    return;
  }
  if (String(filePath).includes("..") || path.isAbsolute(String(filePath))) {
    res.status(400).json({ error: "Path inválido: no se permiten rutas absolutas ni '..'." });
    return;
  }

  const resolvedPath = resolveFilePath(String(filePath));
  if (!resolvedPath) {
    res.status(404).json({ error: `Archivo no encontrado: ${filePath}.` });
    return;
  }

  // FIX: restringir escritura a FRONTEND_ROOT o BACKEND_ROOT
  if (!resolvedPath.startsWith(FRONTEND_ROOT + path.sep) &&
      !resolvedPath.startsWith(BACKEND_ROOT + path.sep)) {
    res.status(403).json({ error: "Solo se permiten cambios en artifacts/shopify-optimizer/ o artifacts/api-server/" });
    return;
  }

  // FIX: bloquear archivos de configuración críticos incluso dentro de esas raíces
  const FORBIDDEN_FILES = new Set(["package.json", "tsconfig.json", "pnpm-workspace.yaml", ".env", ".env.example", "drizzle.config.ts"]);
  const basename = path.basename(resolvedPath);
  if (FORBIDDEN_FILES.has(basename)) {
    res.status(403).json({ error: `Archivo protegido: ${basename} no puede modificarse desde el chatbot.` });
    return;
  }

  // FIX: confirmación obligatoria
  if (!params?.confirmed) {
    res.json({
      success: false,
      requiresConfirmation: true,
      action: "fix_code",
      filePath,
      resolvedPath: resolvedPath.replace(WORKSPACE_ROOT, ""),
      message: `⚠️ Vas a reescribir ${filePath} (${description}). Envía de nuevo con confirmed:true para aplicar.`,
    });
    return;
  }

  // FIX: try/catch en readFileSync
  let fileContent: string;
  try {
    fileContent = fs.readFileSync(resolvedPath, "utf-8");
  } catch (e) {
    res.status(500).json({ error: `No se pudo leer ${filePath}: ${e instanceof Error ? e.message : "error"}` });
    return;
  }

  if (!fileContent.includes(oldCode)) {
    result = { success: false, message: `❌ No se encontró el código a reemplazar en ${filePath}.` };
    break;
  }

  // FIX: backups a una carpeta dedicada con rotación
  const backupDir = path.resolve(WORKSPACE_ROOT, ".shopybrain-backups");
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
  const backupName = `${path.basename(resolvedPath)}.${Date.now()}.bak`;
  const backupPath = path.join(backupDir, backupName);
  fs.writeFileSync(backupPath, fileContent, "utf-8");

  // FIX: rotar backups viejos (mantener últimos 50)
  try {
    const backups = fs.readdirSync(backupDir)
      .filter(f => f.endsWith(".bak"))
      .map(f => ({ name: f, mtime: fs.statSync(path.join(backupDir, f)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime);
    for (const old of backups.slice(50)) {
      try { fs.unlinkSync(path.join(backupDir, old.name)); } catch {}
    }
  } catch {}

  const newContent = fileContent.replace(oldCode, newCode);
  fs.writeFileSync(resolvedPath, newContent, "utf-8");

  result = {
    success: true,
    filePath,
    resolvedPath: resolvedPath.replace(WORKSPACE_ROOT, ""),
    description,
    linesChanged: newCode.split("\n").length,
    backupCreated: path.join(".shopybrain-backups", backupName),
    message: `✅ **Fix aplicado en ${filePath}**\n📝 ${description}\n💾 Backup: .shopybrain-backups/${backupName}\n\n⚠️ Reinicia el servidor para que tengan efecto.`,
  };
  break;
}
```

### 🔴 CRIT-2 · `modify_ui` — mismo problema + projectId hardcodeado a 2

**Archivo:** `shopybrain.ts` · **Líneas 6574–6726**

**Problema:**
- Línea 6644: `parseInt(params?.projectId) || 2` — si no viene projectId, contamina el brain del proyecto 2.
- No exige confirmación aunque reescribe código fuente.
- El check `fullPath.startsWith(FRONTEND_ROOT) || fullPath.startsWith(BACKEND_ROOT)` está bien, pero sin separador puede dar falso positivo si existe un path como `${FRONTEND_ROOT}2/...` (no probable pero mejor ser estricto).
- `fs.readFileSync` sin try/catch.

**Fix (aplicar al bloque del case `modify_ui`):**

```typescript
case "modify_ui": {
  const target = params?.target;
  const change = params?.change;
  if (!target || !change) {
    res.status(400).json({ error: "target y change requeridos" });
    return;
  }
  if (String(target).includes("..") || path.isAbsolute(String(target))) {
    res.status(400).json({ error: "Target inválido" });
    return;
  }

  // FIX 1: projectId obligatorio, no fallback a 2
  const projectIdRaw = params?.projectId;
  if (!projectIdRaw || isNaN(parseInt(projectIdRaw))) {
    res.status(400).json({ error: "projectId requerido (no hay fallback)" });
    return;
  }
  const projectIdNum = parseInt(projectIdRaw);

  // FIX 2: confirmación obligatoria para aplicar cambios (preview primero)
  const preview = params?.preview !== false && !params?.confirmed;

  try {
    // ... [scan de archivos relevantes igual que antes] ...
    // ... [llamada a askClaudeWithBrain igual, pero con projectIdNum en vez de "|| 2"] ...

    const uiText = await askClaudeWithBrain(
      projectIdNum,  // ← sin fallback
      [{ role: "user", content: analyzePrompt }],
      "Eres un experto frontend senior. Responde SOLO JSON válido...",
      "general",
      undefined,
      3000
    );

    let uiJson: any = {};
    try {
      uiJson = JSON.parse(uiText.match(/\{[\s\S]*\}/)?.[0] || "{}");
    } catch {
      uiJson = {};
    }

    // FIX 3: si es preview, devolver el plan sin aplicar
    if (preview) {
      res.json({
        success: false,
        requiresConfirmation: true,
        action: "modify_ui",
        preview: true,
        plan: uiJson,
        message: `⚠️ Preview — se modificarán ${uiJson.files?.length ?? 0} archivos. Envía de nuevo con confirmed:true para aplicar.`,
      });
      return;
    }

    let changesApplied = 0;
    const appliedFiles: string[] = [];
    const failedFiles: string[] = [];
    const failedChanges: string[] = [];

    if (uiJson.files) {
      for (const file of uiJson.files) {
        const rawPath = String(file.filePath).replace(/^src\//, "");
        const fullPath = resolveFilePath(`src/${rawPath}`) || resolveFilePath(rawPath);
        if (!fullPath) {
          failedFiles.push(`${file.filePath} (no encontrado)`);
          continue;
        }

        // FIX 4: check estricto con separador de path
        const inFrontend = fullPath.startsWith(FRONTEND_ROOT + path.sep);
        const inBackend = fullPath.startsWith(BACKEND_ROOT + path.sep);
        if (!inFrontend && !inBackend) {
          failedFiles.push(`${file.filePath} (fuera de frontend/backend)`);
          continue;
        }

        // FIX 5: lista negra de archivos protegidos
        const basename = path.basename(fullPath);
        if (["package.json", "tsconfig.json", ".env", ".env.example", "drizzle.config.ts"].includes(basename)) {
          failedFiles.push(`${file.filePath} (archivo protegido)`);
          continue;
        }

        // FIX 6: try/catch en readFileSync
        let content: string;
        try {
          content = fs.readFileSync(fullPath, "utf-8");
        } catch (e) {
          failedFiles.push(`${file.filePath} (read error: ${e instanceof Error ? e.message : "error"})`);
          continue;
        }

        let fileChanged = false;
        for (const ch of file.changes || []) {
          if (content.includes(ch.oldCode)) {
            content = content.replace(ch.oldCode, ch.newCode);
            changesApplied++;
            fileChanged = true;
          } else {
            failedChanges.push(`${file.filePath}: ${ch.description || "bloque no encontrado"}`);
          }
        }

        if (fileChanged) {
          try {
            fs.writeFileSync(fullPath, content, "utf-8");
            appliedFiles.push(file.filePath);
          } catch (e) {
            failedFiles.push(`${file.filePath} (write error)`);
          }
        }
      }
    }

    // ... [resto del message building igual] ...
  } catch (err) {
    result = { error: true, message: `Error modificando UI: ${err instanceof Error ? err.message : String(err)}` };
  }
  break;
}
```

### 🔴 CRIT-3 · `inspect_code` / `analyze_component` / `audit_app_offerings` — `projectId || 2`

**Líneas afectadas:** 4086 (`inspect_code`), 4152 (`analyze_component`), 6545 (`audit_app_offerings`), 6644 (`modify_ui` — ya arriba).

**Fix universal** — crear un helper al principio del archivo:

```typescript
// En la parte de utilidades iniciales de shopybrain.ts (~línea 110):
function requireProjectId(params: Record<string, unknown> | undefined, res: import("express").Response): number | null {
  const raw = params?.projectId;
  if (!raw) {
    res.status(400).json({ error: "projectId es requerido" });
    return null;
  }
  const n = parseInt(String(raw));
  if (isNaN(n) || n <= 0) {
    res.status(400).json({ error: "projectId inválido" });
    return null;
  }
  return n;
}
```

Luego en los 4 sitios reemplazar:

```typescript
// ANTES (mal):
parseInt(params?.projectId) || 2,

// DESPUÉS (bien):
// Al principio del case:
const projectIdNum = requireProjectId(params, res);
if (projectIdNum === null) return;

// Y luego:
projectIdNum,
```

### 🔴 CRIT-4 · `fusion_analyze` / `fusion_create_product` — DoS por imagen gigante

**Líneas 5697, 5730**

**Problema:** `fetch(imageUrl)` → `await imgResp.arrayBuffer()` sin límite. Una URL pública con 500MB tumba el server por OOM.

**Fix** — helper común + aplicación en los dos casos:

```typescript
// Helper arriba del archivo (antes del router):
const MAX_IMAGE_BYTES = 15 * 1024 * 1024; // 15 MB

async function fetchImageSafely(urlStr: string, timeoutMs = 15_000): Promise<{ buffer: Buffer; mimeType: string }> {
  if (!isPublicUrl(urlStr)) throw new Error("URL no pública");

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(urlStr, { signal: controller.signal });
    if (!resp.ok) throw new Error(`HTTP ${resp.status} descargando imagen`);

    // Chequear content-length si el servidor lo envía
    const contentLength = parseInt(resp.headers.get("content-length") ?? "0");
    if (contentLength > MAX_IMAGE_BYTES) {
      throw new Error(`Imagen demasiado grande: ${Math.round(contentLength / 1024 / 1024)}MB (máx 15MB)`);
    }

    const mimeType = resp.headers.get("content-type") ?? "image/jpeg";
    if (!mimeType.startsWith("image/")) {
      throw new Error(`Tipo MIME no permitido: ${mimeType}`);
    }

    // Leer con límite real por si content-length mintió
    const reader = resp.body?.getReader();
    if (!reader) {
      const buf = Buffer.from(await resp.arrayBuffer());
      if (buf.length > MAX_IMAGE_BYTES) throw new Error("Imagen excede 15MB");
      return { buffer: buf, mimeType };
    }

    const chunks: Uint8Array[] = [];
    let total = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.length;
      if (total > MAX_IMAGE_BYTES) {
        reader.cancel();
        throw new Error(`Imagen excede 15MB`);
      }
      chunks.push(value);
    }
    return { buffer: Buffer.concat(chunks), mimeType };
  } finally {
    clearTimeout(timer);
  }
}
```

Aplicación en `fusion_analyze`:

```typescript
case "fusion_analyze": {
  const imageUrl = params?.imageUrl;
  if (!imageUrl) { result = { error: true, message: "❌ Falta imageUrl" }; break; }
  try {
    const { buffer, mimeType } = await fetchImageSafely(String(imageUrl));
    const analysis = await analyzeImageForFusion(buffer.toString("base64"), mimeType);
    // ... resto igual ...
  } catch (err) {
    result = { error: true, message: `❌ Error en Fusion Studio: ${err instanceof Error ? err.message : String(err)}` };
  }
  break;
}
```

Idéntico para `fusion_create_product`.

### 🔴 CRIT-5 · `list_source_files` — path traversal en enumeración

**Líneas 4024–4065**

**Problema:** `params?.directory` se concatena sin validar. `path.join(FRONTEND_ROOT, "src/../../../../etc")` normaliza a `/etc` y lista el directorio del host.

**Fix:**

```typescript
case "list_source_files": {
  const directoryRaw = params?.directory || "";
  const pattern = params?.pattern || "";

  // FIX: validar directory antes de cualquier join
  if (String(directoryRaw).includes("..") || path.isAbsolute(String(directoryRaw))) {
    res.status(400).json({ error: "directory inválido: no se permiten rutas absolutas ni '..'." });
    return;
  }
  // FIX: solo caracteres seguros
  if (!/^[a-zA-Z0-9_\-\/]*$/.test(String(directoryRaw))) {
    res.status(400).json({ error: "directory contiene caracteres no permitidos" });
    return;
  }
  const directory = String(directoryRaw);

  const listDir = (root: string, dir: string, prefix: string): string[] => {
    const results: string[] = [];
    const fullPath = path.resolve(root, dir);

    // FIX: verificar que fullPath sigue dentro de root
    if (!fullPath.startsWith(root + path.sep) && fullPath !== root) {
      return results;
    }
    if (!fs.existsSync(fullPath)) return results;

    try {
      const entries = fs.readdirSync(fullPath, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.name.startsWith(".") || entry.name === "node_modules" || entry.name === "dist") continue;
        const relPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          results.push(`📁 ${prefix}${relPath}/`);
          if (relPath.split("/").length < 4) {
            results.push(...listDir(root, relPath, prefix));
          }
        } else if (!pattern || entry.name.endsWith(pattern)) {
          const stat = fs.statSync(path.join(root, relPath));
          const sizeKb = Math.round(stat.size / 1024);
          results.push(`📄 ${prefix}${relPath} (${sizeKb}KB)`);
        }
      }
    } catch { /* ignore */ }
    return results;
  };

  const frontendDir = directory ? (directory.startsWith("src") ? directory : `src/${directory}`.replace(/\/+/g, "/").replace(/\/$/, "")) : "src";
  const frontendFiles = listDir(FRONTEND_ROOT, frontendDir, "[frontend] ");
  const backendDir = directory ? (directory.startsWith("src") ? directory : `src/${directory}`.replace(/\/+/g, "/").replace(/\/$/, "")) : "src";
  const backendFiles = listDir(BACKEND_ROOT, backendDir, "[backend] ");

  result = {
    frontend: frontendFiles.slice(0, 60),
    backend: backendFiles.slice(0, 60),
    totalFrontend: frontendFiles.length,
    totalBackend: backendFiles.length,
    message: `📂 Estructura del código:\n\n**Frontend (${frontendFiles.length} items):**\n${frontendFiles.slice(0, 30).join("\n")}\n\n**Backend (${backendFiles.length} items):**\n${backendFiles.slice(0, 30).join("\n")}`,
  };
  break;
}
```

### 🔴 CRIT-6 · Bulk writes en Shopify sin confirmación

**Acciones afectadas:** `fix_unpublished`, `fix_missing_compare_prices`, `sync_catalog_prices`, `optimize_all_products`, `auto_collections`, `design_all_pages`, `bulk_redesign`, `bulk_update_prices`, `bulk_update_stock`, `setup_full_store`.

**Patrón de fix** — lo aplicamos uniforme. Helper al principio del archivo:

```typescript
// Helper genérico de confirmación para acciones destructivas/bulk
function requireBulkConfirmation(
  params: Record<string, unknown> | undefined,
  res: import("express").Response,
  action: string,
  summary: string,
): boolean {
  if (params?.confirmed === true || params?.confirmed === "true") return true;
  res.json({
    success: false,
    requiresConfirmation: true,
    action,
    message: `⚠️ ${summary}\n\nEsta acción modifica en masa. Envía de nuevo con confirmed:true para ejecutar.`,
  });
  return false;
}
```

**Aplicación en `fix_unpublished` (línea 3397):**

```typescript
case "fix_unpublished": {
  const projectId = params?.projectId;
  if (!projectId) { res.status(400).json({ error: "projectId requerido" }); return; }
  const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, parseInt(projectId)));
  if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

  // Primero: contar cuántos se verían afectados (sin mutar nada)
  // ... [código GraphQL para contar unpublished] ...

  if (!requireBulkConfirmation(params, res, "fix_unpublished",
    `Vas a publicar ${unpublishedProducts.length} productos en ${project.shopDomain}.`)) {
    return;
  }

  // ... [resto del código como está] ...
}
```

Repetir el patrón en los 9 casos restantes.

---

## 3. BUGS ALTOS — 🟡

### 🟡 ALT-1 · `success: true` aunque `result.error` sea true

**Línea 9510:** `res.json({ success: true, action, ...result });`

**Problema:** Si el case pone `result = { error: true, message: "..." }`, la respuesta exterior sigue diciendo `success: true`. Confunde al frontend.

**Fix:**

```typescript
// Línea ~9510
const outSuccess = !(result as Record<string, unknown>).error;
res.json({ success: outSuccess, action, ...result });
```

### 🟡 ALT-2 · IIFE background sin lock (optimize_all_products, bulk_*)

**Línea 4626 aprox (IIFE dentro de optimize_all_products) y similares**

**Problema:** Dos peticiones simultáneas optimizan los mismos productos dos veces.

**Fix mínimo** — un lock en memoria por projectId+action:

```typescript
// Arriba del archivo:
const bulkLocks = new Map<string, { startedAt: number; action: string }>();

function tryAcquireBulkLock(projectId: number, action: string, ttlMs = 30 * 60 * 1000): boolean {
  const key = `${projectId}:${action}`;
  const existing = bulkLocks.get(key);
  if (existing && Date.now() - existing.startedAt < ttlMs) return false;
  bulkLocks.set(key, { startedAt: Date.now(), action });
  return true;
}
function releaseBulkLock(projectId: number, action: string): void {
  bulkLocks.delete(`${projectId}:${action}`);
}
```

Aplicación en el IIFE de `optimize_all_products`:

```typescript
// Dentro del case, justo antes de lanzar la IIFE:
if (!tryAcquireBulkLock(parseInt(projectId), "optimize_all_products")) {
  result = {
    error: true,
    message: "⚠️ Ya hay una optimización masiva corriendo para este proyecto. Espera a que termine (o reinicia el servidor si ha quedado colgada).",
  };
  break;
}

// Luego la IIFE:
(async () => {
  try {
    // ... trabajo ...
  } finally {
    releaseBulkLock(parseInt(projectId), "optimize_all_products");
  }
})();
```

Nota: el lock es en memoria — si el server se reinicia durante un bulk, el lock se libera automáticamente. Para lock distribuido haría falta Postgres con `FOR UPDATE SKIP LOCKED`, pero no es necesario en un single-admin tool.

### 🟡 ALT-3 · Streams SSE consumidos con `resp.text()`

**Líneas 7923 (`virtual_tryon`), 7981 (`generate_images_from_reference`)**

**Problema:** El endpoint interno de imágenes emite SSE (Server-Sent Events), pero shopybrain lo consume con `resp.text()` y parsea el texto completo al final. Pierde la naturaleza progresiva del streaming.

**Fix:** cambiar a lectura incremental con `ReadableStream`:

```typescript
// Helper al principio:
async function consumeSSEStream<T>(
  resp: Response,
  onEvent: (data: T) => void,
): Promise<void> {
  const reader = resp.body?.getReader();
  if (!reader) throw new Error("No hay body en la respuesta SSE");
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      try {
        onEvent(JSON.parse(line.slice(6)) as T);
      } catch { /* skip parse errors */ }
    }
  }
}
```

Uso en `virtual_tryon`:

```typescript
let summary = { total: 0, success: 0, failed: 0 };
const sceneResults: string[] = [];

await consumeSSEStream<Record<string, unknown>>(resp, (data) => {
  if (data.type === "done") summary = data.summary as typeof summary;
  if (data.type === "completed" && data.success) sceneResults.push(`✅ ${data.label}`);
  if (data.type === "error") sceneResults.push(`❌ ${data.label}: ${data.error}`);
});
```

### 🟡 ALT-4 · 76 llamadas a `localhost` internas

**Patrón:** `const baseUrl = \`http://localhost:${process.env.PORT || 8080}\`; await fetch(\`${baseUrl}/api/...\`, { cookie: req.headers.cookie })`.

**Problema:** cada llamada reabre conexión HTTP, depende de que la cookie de sesión se reenvíe correctamente, y se pierde el stack si el endpoint interno falla. En un refactor serio, estas deberían ser imports directos.

**Fix estratégico (parte del plan de split — sección 4):** extraer la lógica de los endpoints internos a módulos de lib/ que shopybrain pueda importar directamente. Los propios endpoints se mantienen como wrappers thin.

**Fix táctico corto** — mientras no se haga el refactor, crear un helper que al menos centralice:

```typescript
async function callInternal<T>(
  req: import("express").Request,
  pathAndQuery: string,
  init?: { method?: string; body?: unknown; timeoutMs?: number },
): Promise<{ ok: boolean; status: number; data: T }> {
  const baseUrl = `http://localhost:${process.env.PORT || 8080}`;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), init?.timeoutMs ?? 60_000);
  try {
    const resp = await fetch(`${baseUrl}${pathAndQuery}`, {
      method: init?.method ?? "GET",
      headers: { "Content-Type": "application/json", cookie: req.headers.cookie ?? "" },
      body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
      signal: ctrl.signal,
    });
    const data = await resp.json().catch(() => ({}));
    return { ok: resp.ok, status: resp.status, data: data as T };
  } finally {
    clearTimeout(t);
  }
}
```

Reemplazar las 76 llamadas por `callInternal(req, "/api/...", { method, body })`. Reduce ~4 líneas a 1 por sitio y centraliza timeout + error handling.

### 🟡 ALT-5 · `reset_user_password` sin confirmación y sin log específico

**Línea 9132.** Acepta `userId` y `password` nuevos sin pedir confirmación. Solo queda en el `audit_log` genérico (si el endpoint interno lo registra).

**Fix:**

```typescript
case "reset_user_password": {
  const userId = params?.userId;
  const password = params?.password;
  if (!userId || !password) {
    result = { error: true, message: "❌ Falta userId o password" };
    break;
  }

  // FIX 1: confirmación obligatoria
  if (!params?.confirmed) {
    res.json({
      success: false,
      requiresConfirmation: true,
      action: "reset_user_password",
      userId,
      message: `⚠️ Vas a resetear la contraseña del usuario ${userId}. Envía de nuevo con confirmed:true.`,
    });
    return;
  }

  // FIX 2: validar complejidad mínima de la nueva password
  if (String(password).length < 12) {
    result = { error: true, message: "❌ Contraseña demasiado corta (mín 12 caracteres)" };
    break;
  }

  try {
    const { data, ok } = await callInternal<Record<string, unknown>>(req, `/api/admin/users/${userId}/reset-password`, {
      method: "POST",
      body: { password },
    });
    if (!ok) { result = { error: true, message: "❌ Error reseteando contraseña" }; break; }
    result = { message: `🔑 **Contraseña reseteada** para usuario ${userId}` };
  } catch (err) {
    result = { error: true, message: `❌ Error: ${err instanceof Error ? err.message : String(err)}` };
  }
  break;
}
```

---

## 4. BUGS MEDIOS — ⚠️ (resumen con fix breve)

| # | Acción / ubicación | Problema | Fix |
|---|---|---|---|
| MED-1 | `generate_budget` (8251) y `generate_platform_report` (8520) | ~1300 líneas de HTML inline dentro del switch | Extraer a `lib/templates/budget.ts` y `lib/templates/platform-report.ts`. El switch solo llama al builder. |
| MED-2 | `send_message` (9164) | Sin límite de tamaño en `content` | `if (String(content).length > 10_000) return error` |
| MED-3 | `learn_from_content` (8843) | Sin límite en `content` | Límite 100k chars |
| MED-4 | `create_user` (9068) | Password pasada en params, loggeable si cambia `SENSITIVE_KEYS` | Añadir validación de complejidad (>=12 chars, mezcla) + asegurar `SENSITIVE_KEYS` siga cubriendo `password` |
| MED-5 | `delete_collection`, `delete_variant`, `delete_email_flow`, `deactivate_user`, `reset_cms`, `restock_orders` | Destructivas sin confirmar | Aplicar `requireBulkConfirmation` de CRIT-6 |
| MED-6 | `external_pre_report` (8927) | `saveToVault(...).catch(() => {})` silencia errores | `logger.warn({ err })` en el catch |
| MED-7 | `saveToVault` por defecto en TODA acción exitosa (9490–9508) | Escritura masiva e innecesaria en vault | Invertir el flag: solo guardar si `params.saveResult === true` O si está en una whitelist `SAVEABLE = ["generate_budget", "run_leveled_report", ...]` |
| MED-8 | Catálogo de precios hardcodeado (5399, 5450) | 26 productos con precio en 2 diccionarios duplicados | Mover a `lib/catalog-prices.ts` con una única fuente |
| MED-9 | `audit_store` (3060) → `for (const pa of productAudits) { ... await db ... }` (~3210) | N+1 sobre `seoDataTable` | Batch insert/update con `sql.placeholder` o `ON CONFLICT DO UPDATE` |
| MED-10 | Sin timeout en `callInternal` actual (76 sitios) | Un endpoint colgado bloquea shopybrain hasta timeout por defecto (60s) | Helper con AbortController (ver ALT-4) |
| MED-11 | `modify_ui` escanea frontend/backend en cada llamada (6584) | I/O pesado repetido | Cachear estructura por 5 min en `Map<string, {ts, files}>` |
| MED-12 | `generate_ai_report`, `run_full_audit_report`, `generate_export` hacen `resp.text()` sobre HTML sin límite | 50MB HTML tumba memoria | Añadir chequeo de `content-length` y fallback a "ver en link" si >5MB |
| MED-13 | `SHOPIFY_ACTIONS_THAT_DELETE` no tienen un log específico de auditoría | No trazabilidad de quién borró qué | Envolver las acciones destructivas con un wrapper que escriba en `audit_logs` tabla antes del DELETE |

---

## 5. SEGURIDAD — HALLAZGOS POSITIVOS Y PENDIENTES

### Lo que ya está bien
- `requireAdmin` en todas las rutas del router.
- `isPublicUrl` bloquea SSRF a localhost, RFC1918, link-local, ULA.
- `isInsideWorkspace` + `realpathSync` protege symlinks.
- `SENSITIVE_KEYS` redacta password / token / secret / accessToken / clientSecret / inviteToken / apiKey en logs y metadatos de vault.
- Multer con whitelist de extensiones y 20MB.
- `NON_LEARNABLE` y `NON_SAVEABLE` sets excluyen acciones sensibles del brain / vault.

### Ownership del `projectId`
No hay verificación de que `projectId` pertenezca al admin autenticado. **En el modelo single-admin actual no es un bug** (el admin puede ver todos los proyectos por diseño). Pero si en el futuro se añaden múltiples admins (agencias), cada uno debería poder ver solo sus proyectos. Preparar ahora:

```typescript
// Helper para el día que haya multi-admin:
async function assertProjectBelongsToAdmin(projectId: number, adminUserId: string): Promise<void> {
  const [p] = await db.select({ id: projectsTable.id, ownerAdminId: projectsTable.ownerAdminId })
    .from(projectsTable).where(eq(projectsTable.id, projectId)).limit(1);
  if (!p) throw new Error("Proyecto no encontrado");
  if (p.ownerAdminId && p.ownerAdminId !== adminUserId) {
    throw new Error("Este proyecto no te pertenece");
  }
}
```

Requiere añadir columna `owner_admin_id` a `projects`. No urgente.

### Ejecución de código arbitrario
- `fix_code` y `modify_ui` escriben código fuente. Mitigado con CRIT-1 y CRIT-2.
- **No hay `exec()`, `spawn()`, `eval()`, `Function()` constructor, ni `new Function()`.** Solo un falso positivo: `actionRegex.exec(answer)` (línea 1141, regex match).
- **No hay uso de `require()` dinámico con input del usuario.** Los `await import(...)` son con strings literales.

### Exposición de datos de otros clientes
Por el modelo single-admin, el admin ve todos los proyectos por diseño. No hay leak cruzado entre clientes (el `client` role solo ve su propio `clientId` vía `requireClientAccess`). **Limpio en este punto.**

---

## 6. PLAN DE SPLIT — `shopybrain.ts` (9.661) → 5 módulos

### Estructura propuesta

```
artifacts/api-server/src/routes/shopybrain/
  index.ts                      ~80 líneas   — re-export del router compuesto
  _shared.ts                    ~300 líneas  — utilidades, helpers, SENSITIVE_KEYS, locks, callInternal
  chat-and-learn.ts             ~1500 líneas — memories, study, sessions, niche-profiles, prompt-library, runs, knowledge-graph, upload, search
  actions-shopify.ts            ~3500 líneas — cases de productos, colecciones, variantes, pedidos, páginas, themes, stock
  actions-ai-content.ts         ~2000 líneas — cases que generan contenido IA: brand, fusion, redesign, seo, email, images, pricing, reports, web-lab
  actions-admin.ts              ~1500 líneas — cases de users, messages, approvals, automations, audit-log, email-flows, inspect/fix code, modify_ui, external analysis, learning manual
  templates/
    budget.ts                   ~600 líneas  — extraído de generate_budget
    platform-report.ts          ~700 líneas  — extraído de generate_platform_report
```

Total: ~9.700 líneas en 7 archivos, ningún archivo >3500.

### Paso a paso (sin romper nada)

**Fase 1 — crear `_shared.ts`** (20 minutos de trabajo de Replit):

```typescript
// artifacts/api-server/src/routes/shopybrain/_shared.ts
import * as fs from "fs";
import * as path from "path";
import type { Request, Response } from "express";
import multer from "multer";

// Mover aquí todos los helpers de las líneas 25–108 del shopybrain.ts original:
// - parseTemplate / VALID_TEMPLATES / ReportTemplate
// - findWorkspaceRoot / WORKSPACE_ROOT / FRONTEND_ROOT / BACKEND_ROOT / FRONTEND_SRC / UPLOADS_DIR
// - upload (multer config)
// - isPublicUrl
// - isInsideWorkspace
// - resolveFilePath
// - SENSITIVE_KEYS

// Añadir los helpers nuevos de los fixes:
export function requireProjectId(params: Record<string, unknown> | undefined, res: Response): number | null { /* ... */ }
export function requireBulkConfirmation(params: Record<string, unknown> | undefined, res: Response, action: string, summary: string): boolean { /* ... */ }
export async function fetchImageSafely(urlStr: string, timeoutMs?: number): Promise<{ buffer: Buffer; mimeType: string }> { /* ... */ }
export async function callInternal<T>(req: Request, pathAndQuery: string, init?: { method?: string; body?: unknown; timeoutMs?: number }): Promise<{ ok: boolean; status: number; data: T }> { /* ... */ }
export async function consumeSSEStream<T>(resp: Response, onEvent: (data: T) => void): Promise<void> { /* ... */ }

// Locks de bulk:
const bulkLocks = new Map<string, { startedAt: number }>();
export function tryAcquireBulkLock(projectId: number, action: string, ttlMs?: number): boolean { /* ... */ }
export function releaseBulkLock(projectId: number, action: string): void { /* ... */ }
```

**Fase 2 — extraer `chat-and-learn.ts`**:

Mover íntegras estas rutas (líneas 253–1534 y 9551–9658):
- `GET  /shopybrain/status`
- `GET  /shopybrain/memories`
- `POST /shopybrain/memories`
- `DELETE /shopybrain/memories/:id`
- `POST /shopybrain/learn`
- `POST /shopybrain/search`
- `GET  /shopybrain/insights`
- `POST /shopybrain/study`
- `GET  /shopybrain/sessions`
- `GET  /shopybrain/niche-profiles`
- `POST /shopybrain/niche-profiles`
- `GET  /shopybrain/prompt-library`
- `POST /shopybrain/prompt-library`
- `POST /shopybrain/run/{micro-learning,consolidation,cross-synthesis,daily-study,mega-synthesis,retroanalysis,self-evaluation}`
- `GET  /shopybrain/schedule`
- `GET  /shopybrain/knowledge-graph`
- `POST /shopybrain/upload`
- Funciones auxiliares: `getShopyBrainContext`, `ensureAllKnowledgeDomains`, `ensureDomains`, `learnFromConversation`, `buildEnrichedLearningContent`, `researchRealPricing`.

**Fase 3 — partir el megaswitch en 3 archivos**:

El switch actual (1755–9467) se divide según categoría de acción en 3 handlers exportados. Cada handler devuelve `{ handled: true, result }` o `{ handled: false }`.

```typescript
// actions-shopify.ts
export async function handleShopifyAction(
  action: string,
  params: Record<string, unknown> | undefined,
  req: Request,
): Promise<{ handled: true; result: Record<string, unknown> } | { handled: false }> {
  switch (action) {
    case "store_status":       return { handled: true, result: await caseStoreStatus(params, req) };
    case "list_products":      return { handled: true, result: await caseListProducts(params, req) };
    case "create_product":     return { handled: true, result: await caseCreateProduct(params, req) };
    // ... etc para los ~70 cases de Shopify core ...
    default:                   return { handled: false };
  }
}
```

Lo mismo para `actions-ai-content.ts` (~30 cases) y `actions-admin.ts` (~40 cases + modify_ui + fix_code + external).

**Fase 4 — orquestador en `index.ts`**:

```typescript
// artifacts/api-server/src/routes/shopybrain/index.ts
import { Router } from "express";
import { requireAdmin } from "../../lib/auth.js";
import { enableLongRunning } from "../../lib/long-running.js";
import chatAndLearn from "./chat-and-learn.js";
import { handleShopifyAction } from "./actions-shopify.js";
import { handleAiContentAction } from "./actions-ai-content.js";
import { handleAdminAction } from "./actions-admin.js";
import { SENSITIVE_KEYS } from "./_shared.js";
import { saveToVault } from "../../lib/vault.js";
import { learnFromOperation } from "../../lib/claude.js";
import { buildEnrichedLearningContent } from "./chat-and-learn.js";
import { logger } from "../../lib/logger.js";

const router = Router();
router.use(chatAndLearn);

router.post("/shopybrain/execute-action", requireAdmin, async (req, res): Promise<void> => {
  const action = req.body?.action as string | undefined;
  const params = req.body?.params as Record<string, unknown> | undefined;

  if (!action) {
    res.status(400).json({ error: "action requerido" });
    return;
  }

  try {
    // Intentar cada handler en orden
    let handler = await handleShopifyAction(action, params, req);
    if (!handler.handled) handler = await handleAiContentAction(action, params, req);
    if (!handler.handled) handler = await handleAdminAction(action, params, req);

    if (!handler.handled) {
      res.status(400).json({ error: `Acción desconocida: ${action}` });
      return;
    }

    const result = handler.result;
    const outSuccess = !(result as Record<string, unknown>).error;

    // Learning + Vault post-processing (idéntico al actual)
    const NON_LEARNABLE = new Set([/* ... */]);
    const NON_SAVEABLE = new Set([/* ... */]);
    // ... mismo flujo ...

    res.json({ success: outSuccess, action, ...result });
  } catch (e: unknown) {
    const errMsg = e instanceof Error ? e.message : String(e);
    logger.error({ action, error: errMsg }, "Chatbot action failed");

    let friendlyError = `Error en ${action}: ${errMsg.slice(0, 200)}`;
    if (/credit balance is too low|insufficient_quota|billing/i.test(errMsg)) {
      friendlyError = `⚠️ Créditos de IA agotados. Recarga en console.anthropic.com.`;
    } else if (/rate_limit|Too many requests/i.test(errMsg)) {
      friendlyError = `⏳ Rate limit. Espera unos segundos.`;
    } else if (/overloaded|529/.test(errMsg)) {
      friendlyError = `🔄 IA sobrecargada, reintenta en 1-2 min.`;
    }
    res.status(500).json({ error: friendlyError });
  }
});

export default router;
```

**Fase 5 — actualizar import del archivo original `shopybrain.ts`**:

```typescript
// Lo que antes era artifacts/api-server/src/routes/shopybrain.ts:
// reemplazar por UN solo re-export
export { default } from "./shopybrain/index.js";
```

Así el resto del proyecto (donde sea que se importe `shopybrainRouter`) no cambia.

### Orden recomendado de trabajo

1. **Antes del split** (porque son fáciles y de alto impacto):
   - Aplicar CRIT-1, CRIT-2, CRIT-3, CRIT-4, CRIT-5 (bugs de seguridad en `fix_code` / `modify_ui` / `fusion_*` / `list_source_files` / `inspect_code` / `analyze_component` / `audit_app_offerings`).
   - Aplicar ALT-1 (`success: true` spurio).
   - Aplicar ALT-5 (`reset_user_password` con confirmación).
   - Merge y deploy a dev.

2. **Sesión siguiente** (más invasivo):
   - CRIT-6 (confirmación bulk) + MED-5 (confirmación destructivas). Requiere que el frontend OmniChatbot entienda `requiresConfirmation` para TODAS las acciones bulk — probar el flujo en cliente.
   - ALT-2 (locks bulk) + ALT-3 (SSE streaming).

3. **Después del deploy a producción** (sin bloqueo funcional):
   - Fase 1–5 del split.
   - MED-1 (extraer templates de `generate_budget` / `generate_platform_report`).
   - MED-7 (vault opt-in).
   - Refactor de las 76 llamadas a `callInternal`.

### Criterio de "no romper nada"

- El export `export default router` debe seguir funcionando sin tocar `routes/index.ts`.
- Todas las rutas mantienen exactamente el mismo path (`/shopybrain/*`).
- Los nombres de acciones del switch no cambian (el frontend no se entera).
- El comportamiento de learning + vault post-procesamiento es idéntico.
- Tests a correr tras cada fase: simplemente reiniciar el server y ejecutar una acción de cada bloque (`store_status`, `list_products`, `modify_ui` en preview, `list_users`, `audit_store`).

---

## 7. APÉNDICE — COMANDOS DE VERIFICACIÓN PARA REPLIT

Para que Replit (o cualquiera) pueda validar estos hallazgos rápidamente, los greps exactos que demuestran cada bug:

```bash
# CRIT-1 / CRIT-2: fs.writeFileSync en el switch
grep -n 'fs\.writeFileSync' artifacts/api-server/src/routes/shopybrain.ts

# CRIT-3: projectId hardcodeado a 2
grep -nE 'parseInt\(params\?\.projectId\) \|\| 2' artifacts/api-server/src/routes/shopybrain.ts

# CRIT-6: única confirmación existente (comparar vs 148 cases)
grep -n 'params?\.confirmed' artifacts/api-server/src/routes/shopybrain.ts

# Créditos: checkProductionLimit en shopybrain.ts
grep -n 'checkProductionLimit' artifacts/api-server/src/routes/shopybrain.ts

# ALT-1: success:true spurio
grep -n 'res\.json({ success: true, action' artifacts/api-server/src/routes/shopybrain.ts

# CRIT-4: fetch de imágenes sin límite
grep -nB2 'await imgResp\.arrayBuffer()' artifacts/api-server/src/routes/shopybrain.ts

# Bulk actions sin lock
grep -nA2 '(async () => {' artifacts/api-server/src/routes/shopybrain.ts | grep -B1 'batchErrors\|batchResults' | head
```

---

**FIN DEL DOCUMENTO**

Generado por auditoría del código real en `artifacts/api-server/src/routes/shopybrain.ts` (9.661 líneas). Todas las referencias a línea y nombre de acción provienen directamente del grep sobre el archivo del tarball `shopycrafter_codigo_completo__1__.tar.gz`.
