# BLOQUE B — ADDENDUM (verificaciones completadas + flujo de chat)

Cierra los pendientes que dejé marcados en `BLOQUE_B_frontend_audit.md` y añade el flujo de chat real, descubierto al verificar el endpoint final.

---

## 1. EL FLUJO DE CHAT REAL — descubrimiento clave

En el dossier original dije: *"el OmniChatbot delega a Claude para que decida la acción"*. Ahora tengo el detalle exacto.

### 1.1 Endpoint usado

**`POST /api/shopybrain/search`** con body:
```json
{
  "query": "<texto del usuario>",
  "returnRaw": true,
  "systemPrompt": "<SYSTEM_PROMPT (línea 882 OmniChatbot, ~150 líneas)>",
  "conversationHistory": "<últimos 8 turnos>",
  "currentRoute": "<wouter location>",
  "activeProjectId": "<extraído de la URL si /projects/:id>"
}
```

El frontend lo llama desde `OmniChatbot.tsx` líneas **1695, 1765, 1780** (3 sitios distintos: follow-up tras absorb, follow-up tras entity-research, chat principal).

### 1.2 Cómo el backend detecta la acción a ejecutar

En `shopybrain.ts:373` (`/shopybrain/search` con `returnRaw:true`), el backend:
1. Carga conocimiento previo de entidades mencionadas (regex en línea 388 detecta `@handle`, dominios, "investigar X").
2. Carga 5 memorias relevantes de `omnicoreMemoriesTable`.
3. Construye un `actionDetectionBlock` que instruye a Claude:
   ```
   Cuando el usuario pida EJECUTAR una acción (...), debes responder con un bloque JSON
   de acción AL FINAL de tu respuesta, después de tu texto explicativo.
   Formato: :::ACTION:::{"action":"nombre_accion","params":{...}}:::END_ACTION:::
   ```
4. Le pasa a Claude la lista de las 148 acciones disponibles.
5. Claude responde con texto + bloque ACTION.
6. El backend parsea el bloque y devuelve `{ answer: "<texto sin el bloque>", detectedActions: [{action, params}, ...] }`.

### 1.3 Cómo el frontend ejecuta la(s) acción(es)

En `OmniChatbot.tsx:1834-1846`:
```typescript
const allActions = d.detectedActions ?? (d.detectedAction ? [d.detectedAction] : []);
if (allActions.length > 0) {
  const results = [];
  for (const act of allActions) {
    const actionResult = await executeShopifyAction(act.action, act.params);  // SECUENCIAL
    if (actionResult) {
      const formatted = formatActionResult(act.action, actionResult);  // 93 cases
      results.push(formatted);
      action = { type: actionType, label: ..., data: actionResult, actionName: act.action, ... };
    }
  }
  if (results.length > 0) {
    assistantContent += "\n\n" + results.join("\n\n---\n\n");
  }
}
```

### 1.4 Hallazgos sobre este flujo

**🟡 Nuevo hallazgo FE-16: ejecución secuencial de N acciones sin límite ni confirmación.**

Si Claude devuelve `detectedActions: [a, b, c, d, e, ...]`, el frontend las ejecuta **todas en serie sin preguntar al usuario**. En la práctica significa que:
- Un mensaje del usuario puede disparar 5+ acciones encadenadas.
- Si una de ellas es `delete_product` + Claude ya pone `confirmed: true` en params, se borra sin que el usuario tenga oportunidad de pararlo.
- Si la primera acción tarda 2 minutos y la segunda 3 minutos, el usuario espera 5 minutos sin feedback intermedio (solo se pinta el resultado al final).

**Fix propuesto:**

```typescript
// 1. Límite duro de acciones por turno
const MAX_ACTIONS_PER_TURN = 3;
const actionsToRun = allActions.slice(0, MAX_ACTIONS_PER_TURN);
if (allActions.length > MAX_ACTIONS_PER_TURN) {
  results.push(`⚠️ Claude propuso ${allActions.length} acciones, ejecutando solo las primeras ${MAX_ACTIONS_PER_TURN}. El resto requiere otra solicitud.`);
}

// 2. Para acciones destructivas, NO ejecutar automáticamente — pedir confirmación al usuario
const DESTRUCTIVE_ACTIONS = new Set([
  "delete_product", "delete_collection", "delete_variant", "delete_email_flow",
  "deactivate_user", "reset_user_password", "reset_cms",
  "fix_unpublished", "fix_missing_compare_prices", "sync_catalog_prices",
  "optimize_all_products", "bulk_redesign", "bulk_update_prices", "bulk_update_stock",
  "auto_collections", "design_all_pages", "setup_full_store", "fix_code", "modify_ui",
]);

for (const act of actionsToRun) {
  if (DESTRUCTIVE_ACTIONS.has(act.action) && !act.params?.confirmed) {
    // En vez de ejecutar, pintar un botón de confirmación
    results.push(`⚠️ **Acción pendiente de confirmación:** \`${act.action}\`\n` +
      `Params: \`${JSON.stringify(act.params)}\`\n` +
      `Pulsa "Confirmar" para ejecutar.`);
    // Renderizar acción como pending — el componente debe ofrecer botón "Confirmar"
    action = { type: "pending-confirmation", label: "Confirmar", data: act, actionName: act.action };
    break;  // no seguir ejecutando si hay una pendiente
  }

  // Streaming de progreso intermedio
  setMessages(m => [...m, { id: uuid(), role: "assistant",
    content: `▶️ Ejecutando ${act.action}...`, timestamp: new Date() }]);

  const actionResult = await executeShopifyAction(act.action, act.params);
  if (actionResult) {
    results.push(formatActionResult(act.action, actionResult));
  }
}
```

---

## 2. PENDIENTES VERIFICADOS

### 2.1 InviteSetup.tsx — ✅ CORRECTO

**498 líneas, comprobado:**
- Valida `password.length >= 8` (línea 38) ✅
- Valida `password === confirm` (línea 37) ✅
- Maneja token expirado (línea 423: *"Este enlace de invitación ha expirado (validez 48h) o ya fue utilizado"*) ✅
- Token reuse: el backend lo gestiona — el FE confía en que `/api/auth/invite/:token` falle si ya se usó.
- `autoComplete="new-password"` (línea 104, 131) ✅ buena práctica para password managers.

**Mejora opcional:** subir el mínimo a 12 caracteres y exigir mezcla:
```typescript
function isStrongEnough(pw: string): { ok: boolean; reason?: string } {
  if (pw.length < 12) return { ok: false, reason: "Mínimo 12 caracteres" };
  let score = 0;
  if (/[A-Z]/.test(pw)) score++;
  if (/[a-z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  if (score < 3) return { ok: false, reason: "Combina mayúsculas, minúsculas, números y símbolos (al menos 3 tipos)" };
  return { ok: true };
}
```

### 2.2 ResetPassword.tsx — ✅ CORRECTO (mejor que InviteSetup)

**217 líneas, comprobado:**
- Tiene **password strength score 0-5** (líneas 23-29):
  - +1 si length >=8
  - +1 si length >=12
  - +1 si tiene mayúscula
  - +1 si tiene número
  - +1 si tiene símbolo
- Valida `password.length >= 8` mínimo (línea 45) ✅
- Valida `password === confirmPassword` (línea 49) ✅
- Token validado server-side via `/api/auth/reset-password` ✅

**Recomendación:** unificar la lógica de strength score con `InviteSetup.tsx` para no duplicar.

### 2.3 NewProject.tsx — ✅ NO USA useDraftPersistence

**620 líneas, comprobado:**
- Maneja `clientSecret` de Shopify (32 caracteres, validado en línea 186, 360-365 muestra contador `XX/32 caracteres`).
- **NO usa `useDraftPersistence`** (verificado: el hook solo se usa en `CMSEditor.tsx:1157` y `EmailTemplates.tsx:119`).
- **No hay riesgo de credenciales en localStorage.** ✅

**Posible mejora menor:** si el usuario rellena medio formulario y refresca, pierde todo. Si quieres añadir draft persistence, hay que excluir `clientSecret`/`clientId`/`accessToken` con el parámetro `omitFields` que propuse en FE-12.

### 2.4 useDraftPersistence — ✅ USOS SEGUROS

**Solo 2 usos:**
- `CMSEditor.tsx:1157` — guarda contenido CMS (textos públicos) — sin credenciales.
- `EmailTemplates.tsx:119` — guarda templates de email — sin credenciales.

**Conclusión:** el riesgo FE-12 que describí no se materializa hoy. Pero el fix con `omitFields` sigue siendo válido como protección defensiva si en el futuro alguien añade el hook a NewProject u otro form sensible.

### 2.5 ErrorBoundary coverage — ✅ EXCELENTE

**Verificado en App.tsx:**
- Existe `<PageErrorBoundary>` (línea 184) que envuelve `<ErrorBoundary fallbackRoute="/home">`.
- Se usa dentro de `AdminWrapper` (línea 192) que **se aplica 43 veces en App.tsx** (= todas las rutas admin/projects).
- También hay un `<ErrorBoundary>` raíz en App.tsx:443 que cubre toda la app.
- El componente `ErrorBoundary.tsx` es muy bueno: UI 500 elegante, botones Reintentar/Recargar/Volver, muestra stack trace solo en `DEV`.

**Doble cobertura: root + por ruta.** Si una página `/admin/foo` revienta, la app no muere; solo esa ruta muestra el 500.

**Lo único que faltaría:** que los errores se reporten a un servicio (Sentry/PostHog). Hoy solo se loggean a `console.error` en `componentDidCatch` (línea 23). En producción no se ven.

### 2.6 Billing — declarado mock por el propio backend

**Confirmado leyendo `billing.ts` completo:**
- `POST /api/billing/upgrade` simplemente actualiza `subscriptionsTable.plan` y devuelve:
  ```json
  { "subscription": <row>, "message": "Actualizado a Pro (modo demo — Stripe pendiente de configurar)" }
  ```
- **No hay `checkoutUrl`, no hay redirect a Shopify cart, no hay charge.**
- El frontend `Billing.tsx:166` ya muestra al admin: *"Modo demo: los cambios de plan se simulan. Configura las claves de Stripe para activar pagos reales."* ✅

**Re-evaluación:** el bug crítico que describí en FE-3.4 ("`upgradePlan` no redirige a checkoutUrl") **no es bug del frontend** — el backend nunca devuelve checkoutUrl porque está explícitamente en modo demo. La UI ya avisa.

**Si vas a activar pagos reales** (Shopify Billing, no Stripe), necesitarás:
1. Backend: `/api/billing/upgrade` debe llamar a Shopify Admin GraphQL `appSubscriptionCreate` y devolver `confirmationUrl` en la respuesta.
2. Frontend: el fix que propuse (`window.location.href = data.checkoutUrl`) sigue siendo válido, solo cambia el nombre del campo a `confirmationUrl`.

```typescript
// Billing.tsx upgradePlan (versión Shopify Billing real)
const upgrade = await fetch(`${API_BASE}/api/billing/upgrade`, { ... });
const data = await upgrade.json();
if (data.confirmationUrl) {
  window.top!.location.href = data.confirmationUrl;  // Shopify exige top-level navigation
  return;
}
// fallback: solo es demo o sin pago
setSubData(prev => ({ ...prev, subscription: data.subscription }));
```

### 2.7 Mobile responsive — 🔴 PROBLEMA REAL

**Verificado contando breakpoints `sm:|md:|lg:|xl:` en páginas críticas:**

| Página | Breakpoints |
|---|---|
| `Billing.tsx` | **0** ❌ |
| `CMSEditor.tsx` | **0** ❌ |
| `ShopyBrain.tsx` | **0** ❌ |
| `Images.tsx` | 2 ⚠️ |
| `NewProject.tsx` | **0** ❌ |

**Esto es un hallazgo serio**, no me lo esperaba. La app Android es un WebView wrapper de `shopycrafter.com`. Si las páginas admin no tienen layout responsive, la app móvil será **inusable** en estas pantallas.

Probablemente los layouts usan estilos inline (vi `style={{ ... }}` extensivo en ErrorBoundary y otros sitios) en vez de Tailwind, así que el grep de breakpoints subestima — pero aun así, sin breakpoints la página no se adapta.

**Recomendación:** test manual urgente en Chrome DevTools modo móvil (iPhone 12, 390x844) de las 5 páginas anteriores. Apostar a que al menos 3 de las 5 se rompen.

### 2.8 Hooks utilitarios — ✅ TODOS BIEN

**Verificados:**
- `useSafeTimeout` (21 líneas) — limpia timers en unmount, evita memory leaks. ✅
- `usePlatformFeatures` (40 líneas) — devuelve features según `platform_type` (shopify/woo/presta/universal). Maneja ocultación de tabs (ej: PrestaShop oculta `themes`). ✅ Bien diseñado.
- `useRetryFetch` (visto antes) — exponential backoff, skip 4xx. ✅
- `useDraftPersistence` (visto antes) — solo riesgo si se usa con campos sensibles, hoy no se usa así. ✅

---

## 3. NUEVOS HALLAZGOS DE ESTE ADDENDUM

### FE-16 (🟡 Alto) · Multi-action sin límite ni confirmación
Detalles arriba en §1.4. Fix: límite `MAX_ACTIONS_PER_TURN=3` + confirmación obligatoria para acciones destructivas.

### FE-17 (🟡 Alto) · Mobile responsive ausente en 4/5 páginas críticas
Detalles arriba en §2.7. Fix: revisión por página + test manual en mobile.

### FE-18 (⚠️ Medio) · ErrorBoundary no reporta a servicio externo
`componentDidCatch` solo hace `console.error`. En producción los errores se pierden.

**Fix:**
```typescript
componentDidCatch(error: Error, errorInfo: ErrorInfo) {
  console.error("[ErrorBoundary]", error, errorInfo);
  // FIX: reportar a backend (que lo loggee con winston/pino)
  if (!import.meta.env.DEV) {
    fetch("/api/error-report", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: error.message,
        stack: error.stack,
        componentStack: errorInfo.componentStack,
        url: window.location.href,
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString(),
      }),
    }).catch(() => {});  // fire and forget
  }
}
```

Y en backend añadir un endpoint thin:
```typescript
// routes/health.ts (o similar)
router.post("/error-report", express.json({ limit: "100kb" }), async (req, res) => {
  logger.error({ frontend: true, ...req.body }, "Frontend error reported");
  res.json({ ok: true });
});
```

### FE-19 (⚠️ Medio) · `formatActionResult` con 93 cases puede simplificarse a ~20
**Conté exacto: 93 cases en el switch** (líneas 1037–1400 aprox). En el dossier original dije ~80 — la cifra real es 93.

De los 93 cases:
- ~30 hacen formato muy específico (tablas, gradient bars, emojis variables) — **mantener**.
- ~63 simplemente devuelven `result.message` o variantes mínimas — **eliminar y caer al default**.

Default propuesto:
```typescript
default:
  return result.message ?? result.summary ?? `✅ Acción ${action} completada.`;
```

Esto reduciría el componente en ~250-300 líneas.

### FE-20 (🟢 Info) · El flujo de chat es ingenioso pero invisible al usuario
El usuario escribe "lista mis productos". Claude responde con texto + `:::ACTION:::{"action":"list_products","params":{}}:::END_ACTION:::`. El frontend ejecuta `executeShopifyAction("list_products", {})` y muestra el resultado.

**Es funcional pero opaco:**
- No se ve qué acción se está ejecutando (solo "Analizando tu solicitud").
- Si Claude falla al detectar la acción, el usuario ve solo el texto sin la ejecución, sin saber por qué.

**Mejora UX:** mostrar siempre la acción detectada antes de ejecutarla:
```typescript
if (allActions.length > 0) {
  const actionsList = allActions.map(a => `• \`${a.action}\``).join("\n");
  setMessages(m => [...m, { id: uuid(), role: "assistant",
    content: `🎯 Acciones detectadas:\n${actionsList}\n\n_Ejecutando..._`, timestamp: new Date() }]);
}
```

---

## 4. RESUMEN ACTUALIZADO DE HALLAZGOS

Total con addendum: **20 hallazgos** (15 originales + 5 nuevos).

### Críticos 🔴 — 3 (sin cambios desde dossier original)
- FE-1 postMessage wildcard
- FE-2 message handler sin validar origin
- FE-3 dangerouslySetInnerHTML sin sanitizar

### Altos 🟡 — 9 (era 6 + 3 nuevos)
- FE-4 SVG sin sanitizar
- FE-5 BASE_URL como API URL
- FE-6 RequireClient redirect
- FE-7 capacitor sin offline
- FE-8 timeout fijo OmniChatbot
- FE-9 Billing sin loading state
- **FE-16 multi-action sin límite/confirmación** (nuevo)
- **FE-17 mobile responsive ausente** (nuevo)
- ~~FE-3.4 upgradePlan sin checkoutUrl~~ (revertido — backend dice mock)

### Medios ⚠️ — 6 (era 4 + 2 nuevos)
- FE-11 AndroidManifest minimal
- FE-12 use-draft-persistence sin omitFields
- FE-13 react-query inconsistente
- FE-14 OmniChatbot 2142 líneas
- **FE-18 ErrorBoundary no reporta** (nuevo)
- **FE-19 93 cases formatActionResult** (nuevo)

### Verificados como OK ✅
- FE-15 0 endpoints huérfanos
- 2.1 InviteSetup
- 2.2 ResetPassword
- 2.3 NewProject (no usa drafts)
- 2.4 useDraftPersistence (usos seguros)
- 2.5 ErrorBoundary coverage
- 2.6 Billing es demo declarado (no bug)
- 2.8 Hooks utilitarios

---

## 5. PRIORIZACIÓN ACTUALIZADA

**Sprint 1 — Seguridad crítica (4-6 h):**
1. FE-3, FE-4 (DOMPurify)
2. FE-1, FE-2 (postMessage allowlist)
3. **FE-16** (límite acciones + confirmación destructivas) — añadir aquí

**Sprint 2 — UX y robustez (1 día):**
4. **FE-17** mobile responsive: testear las 5 páginas críticas y arreglar las que se rompan
5. FE-8 timeout categorizado
6. **FE-20** mostrar acciones detectadas antes de ejecutar
7. FE-6 redirect admin

**Sprint 3 — Refactor (2-3 días):**
8. FE-5 VITE_API_URL helper
9. FE-13 migrar a react-query (Billing, AdminClients, etc.)
10. FE-14 partir OmniChatbot.tsx
11. **FE-19** simplificar `formatActionResult` a ~30 cases

**Sprint 4 — Mobile/Capacitor (medio día):**
12. FE-7, FE-11, deep links, permisos

**Sprint 5 — Observability:**
13. **FE-18** error reporting a backend
14. (cuando actives Shopify Billing real) FE-9 + checkoutUrl flow

---

**FIN DEL ADDENDUM**

Verificado contra el código real con greps y lecturas puntuales. Los pendientes del dossier original están todos resueltos. El flujo de chat ahora está documentado al 100%.
