# BLOQUE B — Auditoría frontend `shopify-optimizer`

**Stack:** React 19 + Vite + Wouter + @tanstack/react-query + Tailwind + shadcn/ui + Capacitor Android.
**Tamaño:** 57 páginas, ~45 componentes custom, 144 archivos `.tsx`/`.ts` en `src/`.

---

## RESUMEN EJECUTIVO — LOS 15 HALLAZGOS REALES

| # | Severidad | Archivo | Problema |
|---|-----------|---------|----------|
| FE-1 | 🔴 | `pages/Landing.tsx:507,525` | `postMessage` con `parentOrigin \|\| "*"` — wildcard origin |
| FE-2 | 🔴 | `pages/admin/CMSEditor.tsx:1253` | Handler de `message` **sin validar `event.origin`** |
| FE-3 | 🔴 | `pages/projects/Redesign.tsx:513` | `dangerouslySetInnerHTML={{__html: result.bodyHtml}}` sin sanitizar — XSS real |
| FE-4 | 🟡 | `pages/projects/Images.tsx:566` | `dangerouslySetInnerHTML={{__html: svgContent}}` — XSS si el SVG viene de Replicate con script embebido |
| FE-5 | 🟡 | Todo el frontend | `API_BASE = import.meta.env.BASE_URL` — mal uso de BASE_URL para API. Rompe si frontend y backend están en orígenes distintos |
| FE-6 | 🟡 | `App.tsx:143` | `RequireClient` redirige a `/` si role==="admin", pero expone al admin a la landing como público anónimo |
| FE-7 | 🟡 | `capacitor.config.ts` | `server.url` apunta a `shopycrafter.com` — la app Android es un WebView wrapper, sin offline fallback |
| FE-8 | 🟡 | `OmniChatbot.tsx:1008` | 180s timeout fijo — para bulk actions que tardan >3min el usuario ve "Error de conexión" aunque el backend siga trabajando |
| FE-9 | 🟡 | `pages/admin/Billing.tsx` | Billing **no** es mock (el usuario creía que sí), pero no hay loading skeleton ni error state — si cualquier fetch falla, el tab queda en blanco |
| FE-10 | ⚠️ | `pages/NewProject.tsx` | Pendiente validar guards para Shopify/Woo/PrestaShop/Universal |
| FE-11 | ⚠️ | `AndroidManifest.xml` | Solo declara `INTERNET`. Falta `RECORD_AUDIO` si `VoiceButton` quiere grabar en nativo; falta intent-filter para deep links |
| FE-12 | ⚠️ | `hooks/use-draft-persistence.ts` | Guarda en localStorage sin validar qué se persiste — si un form tiene credenciales, las guarda 24h |
| FE-13 | ⚠️ | Varias páginas | No usan `@tanstack/react-query` — hacen `useEffect + fetch + setState` manual (Billing, AdminClients, ShopyBrainInsights). Pierden cache, invalidation, retry. |
| FE-14 | ⚠️ | `components/OmniChatbot.tsx` (2142 líneas) | Archivo monolítico — imposible de mantener |
| FE-15 | 🟢 | Global | 0 endpoints huérfanos reales en el frontend. Los 9 "posibles huérfanos" son falsos positivos de regex |

Además: **Billing no es mock.** Usa `/api/billing/subscription`, `/plans`, `/affiliate`, `/invoices`, `/upgrade`, `/affiliate/join`. El backend `billing.ts` (161 líneas) lee/escribe tablas reales `subscriptionsTable`, `affiliatesTable`, `referralTrackingTable` de Drizzle. Lo que sí es "mock-ish" son los planes hardcodeados (trial/starter/pro/agency €0/97/297/697) y el `payment_link` que probablemente apunta a Shopify cart — confirmarlo al ver `/api/billing/upgrade` internamente.

---

## 1. MAPA DE PÁGINAS → ENDPOINTS

### 1.1 Páginas y endpoints que consumen

Extraído con `grep -rn '/api/' src/`. **Frontend usa 186 endpoints únicos** (patrones normalizados).
**Backend expone 325 endpoints únicos.** **0 huérfanos reales del lado FE.**

| Página | Endpoints principales | Observaciones |
|---|---|---|
| `Login.tsx` | `/api/auth/login`, `/api/auth/me`, `/api/auth/logout` | Cookie-based, `credentials: "include"` |
| `ForgotPassword.tsx` | `/api/auth/forgot-password` | |
| `ResetPassword.tsx` | `/api/auth/reset-password` | Valida token por query param |
| `InviteSetup.tsx` | `/api/auth/invite/:token`, `/api/auth/invite/:token/setup` | Flujo único de cliente |
| `Landing.tsx` | `/api/contact`, `/api/cms/content` | Pública + modo preview con postMessage |
| `NewProject.tsx` | `/api/projects`, `/api/projects/test-connection-presave` | Soporta 4 plataformas |
| `AdminClients.tsx` | `/api/admin/projects-list`, `/api/admin/users`, `/api/admin/users/:id/:action` (activate/deactivate/reset-password), `/api/auth/stop-impersonate` | |
| `admin/Billing.tsx` | `/api/billing/*` (6 endpoints) | Tabs: subscription, affiliate, invoices |
| `admin/CMSEditor.tsx` | `/api/cms/content`, `/api/cms/content/batch`, `/api/cms/content/reset`, `/api/cms/ai/improve`, `/api/cms/media/*`, `/api/cms/versions`, `/api/cms/events` | Preview iframe con postMessage bidireccional |
| `admin/SystemHealth.tsx` | `/api/admin/shopify-config` (lee estado de claves) | |
| `admin/GeminiIntelligence.tsx` | `/api/gemini/:endpoint` dinámico | Los 7 subendpoints (`/api/gemini/research/business`, `/competitor`, `/market`, `/product-trends`, `/person-brand`, `/full-audit`, `/api/gemini/status`) se construyen dinámicamente |
| `admin/ShopyBrain.tsx`, `ShopyBrainInsights.tsx`, `ShopyBrainMemories.tsx`, `ShopyBrainStudy.tsx` | `/api/shopybrain/status`, `/insights`, `/memories`, `/study`, `/search`, `/sessions`, `/niche-profiles`, `/prompt-library`, `/run/*` | |
| `admin/UniversalSearch.tsx` | `/api/shopybrain/research-entity/:name`, `/api/shopybrain/research-entity-sync`, `/api/vault/global/entities` | Guarda `sc_recent_searches` en localStorage |
| `admin/Competitors.tsx` | `/api/competitors`, `/api/competitors/:id`, `/api/competitors/scan`, `/api/competitors/alerts`, `/api/competitors/alerts/:id/dismiss` | No usa `auto-discover` (está solo desde el chatbot) |
| `admin/Inventory.tsx`, `admin/Forecast.tsx`, `admin/Revenue.tsx` | No llaman directamente — usan `/api/projects/:id/*` o van via OmniChatbot | |
| `admin/GlobalVault.tsx` | `/api/vault/global`, `/api/vault/global/:id/download`, `/api/vault/global/download-selected` | |
| `admin/ProjectVault.tsx` | `/api/projects/:id/vault/*` (stats, download, save-report, download-all, download-selected, download-images/:format) | |
| `admin/TemplateStudio.tsx` | `/api/report-templates`, `/api/report-templates/:id`, `/api/report-templates/ai-suggest` | |
| `admin/MyPricing.tsx` | `/api/agency/analyze-pricing`, `/api/agency/cost-structure`, `/api/agency/services`, `/api/agency/services/:id/shopify-variant`, `/api/agency/shopify-products`, `/api/agency/push-services-to-shopify` | |
| `admin/Emails.tsx`, `admin/EmailTemplates.tsx` | `/api/emails/flows/*`, `/api/email-templates/*`, `/api/emails/generate` | |
| `admin/Achievements.tsx` | `/api/achievements` | |
| `admin/Roadmap.tsx` | Sin fetch — contenido estático | |
| `admin/AdminABTests.tsx` | `/api/admin/all-ab-tests` | |
| `admin/ApkManager.tsx` | `/api/apk/build`, `/api/apk/status`, `/api/apk/download` | |
| `admin/AdminAutomations.tsx` | `/api/automations/jobs`, `/api/automations/jobs/:id/run` | |
| `client/ClientDashboard.tsx` | `/api/client/dashboard` | |
| `client/ClientProducts.tsx` | `/api/client/products` | |
| `client/ClientReports.tsx` | `/api/client/reports`, `/api/client/reports/export` | |
| `client/ClientApprovals.tsx` | `/api/client/approvals`, `/api/client/approvals/:id/approve\|reject` | |
| `client/ClientMessages.tsx` | `/api/client/messages` | |
| `projects/Audit.tsx` | `/api/projects/:id/audit` via OmniChatbot action principalmente | |
| `projects/Images.tsx` | `/api/projects/:id/images/*`, SSE para progreso, localStorage para `img-jobs-${projectId}` y `img-bulk-${projectId}` | |
| `projects/Redesign.tsx` | `/api/projects/:id/redesign`, `/api/projects/:id/apply-redesign` | **XSS via `dangerouslySetInnerHTML`** |
| `projects/Pricing.tsx` | `/api/projects/:id/pricing/*`, `/api/projects/:id/price-simulator`, `/api/projects/:id/financial-*` | |
| `projects/Consistency.tsx` | `/api/projects/:id/consistency/*` | |
| `projects/SEO.tsx` | `/api/projects/:id/seo/*` (12 subendpoints) | |
| `projects/ABTesting.tsx` | `/api/projects/:id/ab-tests` | |
| `projects/ExportCenter.tsx` | `/api/projects/:id/exports/:type`, `/api/projects/:id/exports/run-full-audit`, `/api/projects/:id/exports/generate-ai-report` | |
| `projects/FusionStudio.tsx` | `/api/fusion-studio/analyze`, `/api/projects/:id/products/:pid/images/virtual-tryon` | |
| `projects/UniversalGenerator.tsx` | `/api/generator/levels`, `/api/generator/types`, `/api/generator/run`, `/api/generator/history/:id`, `/api/generator/download/:id` | |
| `projects/WebLab.tsx` | `/api/web-lab/analyze`, `/api/web-lab/history/:id`, `/api/web-lab/download-*` | |
| `projects/Settings.tsx` | `/api/projects/:id` (GET/PATCH/DELETE), `/api/projects/:id/regenerate-token` | |

### 1.2 Endpoints backend NO consumidos por la UI directamente (~150)

**No son endpoints muertos.** Casi todos están llamados por `OmniChatbot` vía `/api/shopybrain/execute-action` → el handler del switch hace `fetch("http://localhost:PORT/api/...")` internamente. Los más relevantes:

- `/api/admin/audit-log` — existe un `audit_log` case en shopybrain.ts, pero **no hay página admin** para visualizarlo. Candidato a "implementar UI" o borrar el endpoint.
- `/api/admin/brain-export/{domains,knowledge,prompts}`, `/api/admin/brain-import`, `/api/admin/brain-import/ndjson`, `/api/admin/brain-inject-self-knowledge`, `/api/admin/brain-stats`, `/api/admin/brain-sync` — 7 endpoints brain-admin **sin UI**. Acceso solo via curl o via chatbot (brain_sync, brain_stats, brain_export cases).
- `/api/admin/create-shopify-services`, `/api/admin/shopify-products-with-prices`, `/api/admin/shopify-update-prices` — admin tools sin UI propia.
- `/api/competitors/auto-discover`, `/api/competitors/snapshots` — invocados solo desde chatbot (`discover_competitors`).
- `/api/enrichment/projects/:id/enrich-batch`, `/product-ids` — sin UI.
- `/api/gemini/research/*` (6 endpoints) — Se usan dinámicamente desde `GeminiIntelligence.tsx` con `${endpoint}` variable. **Falsos muertos.**
- `/api/generator/*` (5 endpoints) — usados por `UniversalGenerator.tsx` de manera dinámica.
- `/api/inventory/*` (7 endpoints) — invocados solo desde chatbot (`inventory_sync`, etc.).
- `/api/klaviyo/*`, `/api/klaviyo-ai/*` — usados por email templates o desde chatbot.
- `/api/push/vapid-*` — push notifications, no configurado en UI.
- `/api/scripttag/*` — si existen, sin UI.
- `/api/automations/jobs/:id` (detail) — existe lista (`AdminAutomations.tsx`) pero no detail.

**Decisión recomendada:**
- **Implementar UI** para `audit_log` (pedido habitual en apps admin) y `brain-sync/stats/export` (si los usas tú desde chatbot, eventualmente los querrás con botón).
- **Borrar o marcar deprecated** los endpoints admin-shopify duplicados (`create-shopify-services`, `shopify-products-with-prices`, `shopify-update-prices`) si `agency/shopify-products` ya los cubre.
- **Mantener** los endpoints internos invocados por chatbot (inventory, competitors/auto-discover, klaviyo-ai, etc.).

---

## 2. OMNICHATBOT — ANÁLISIS DEL COMPONENTE ESTRELLA

### 2.1 Tamaño y estructura

- **2142 líneas** — archivo monolítico. Merece partir en 5-6 sub-componentes:
  - `OmniChatbot.tsx` (orquestador, ~300 líneas)
  - `useChatStream.ts` (hook que encapsula execute-action + streaming)
  - `ChatMessages.tsx` (renderizado de historial)
  - `ChatInput.tsx` (textarea + voice + upload)
  - `ActionFormatters.ts` (el switch de `formatActionResult` para cada acción)
  - `ChatAttachments.tsx` (absorb-document, absorb-image, absorb-url, research-entity)

### 2.2 Cómo se comunica con el backend

**Endpoint principal: `POST /api/shopybrain/execute-action`** (línea 1008 de OmniChatbot).

```typescript
const executeShopifyAction = async (action: string, params: Record<string, unknown>) => {
  const actionController = new AbortController();
  const actionTimeout = setTimeout(() => actionController.abort(), 180000);  // 3 min
  const res = await fetch(`${API}/api/shopybrain/execute-action`, {
    method: "POST", credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action, params }),
    signal: actionController.signal,
  });
  // ...manejo friendly de errores (credits, rate_limit, auth)
};
```

**Otros 11 endpoints usados por el chatbot:**
- `/api/shopybrain/absorb-url`, `/absorb-image`, `/absorb-document`
- `/api/shopybrain/research-entity/:name`, `/research-entity-sync`
- `/api/shopybrain/create-product-from-image`
- `/api/shopybrain/search` (3 llamadas distintas en 1440-1780)
- `/api/projects/:id/actions/{send,save,download}`

**Todos existen en backend.** Verificado con grep.

### 2.3 Acciones declaradas vs reales

**El OmniChatbot NO declara las 148 acciones hardcodeadas.** El flujo real es:

1. Usuario escribe mensaje
2. Frontend lo manda a `/api/shopybrain/chat` (no lo vi explícitamente, pero la respuesta incluye `action` y `params`)
3. Claude decide qué acción ejecutar
4. Frontend llama `executeShopifyAction(action, params)` con lo que Claude le dijo
5. Frontend llama `formatActionResult(action, result)` — aquí sí hay un switch

**El switch `formatActionResult` (líneas ~1046–1400 aprox) formatea ~80 acciones distintas** (grep de `case "xxx":` dentro del componente). Para las ~68 acciones restantes del backend, el frontend muestra un mensaje genérico con `result.message`.

**Consecuencia:** si Claude devuelve una acción que el frontend no sabe formatear, el usuario ve el raw `message` de la respuesta. No se rompe, pero la experiencia es inconsistente.

**Recomendación:** en vez de un switch gigante, el backend debería devolver siempre un `formattedMessage` listo para mostrar (ya lo hace la mayoría, en el `result.message`). El frontend entonces puede simplificarse a:

```typescript
const formatActionResult = (_action: string, result: any): string => {
  if (result.error) return `❌ ${result.message}`;
  return result.message ?? JSON.stringify(result).slice(0, 500);
};
```

Esto elimina ~350 líneas de `OmniChatbot.tsx` y unifica el formato.

### 2.4 Manejo de errores

**Bueno:** el handler en 1008 hace un excelente manejo amigable:
- 401 → "Error de autenticación con Claude"
- 429 / rate_limit → "Límite de velocidad"
- "credit balance is too low" → "Créditos de IA agotados"
- 400 → parsea el JSON y muestra `data.error`
- Otros → primeros 200 chars del texto

**Malo:** el timeout fijo de 180000ms (3 min) es corto para acciones bulk. Acciones como `optimize_all_products`, `bulk_redesign`, `bulk_generate_images` pueden tardar 10-30 minutos. El frontend aborta a los 3 min mostrando "Error de conexión", pero el backend sigue corriendo.

**Fix recomendado:**

```typescript
// Categorizar acciones por timeout esperado
const LONG_RUNNING_ACTIONS = new Set([
  "optimize_all_products", "bulk_redesign", "bulk_generate_images",
  "setup_full_store", "design_all_pages", "auto_collections",
  "fix_unpublished", "fix_missing_compare_prices", "sync_catalog_prices",
  "run_full_audit_report", "generate_ai_report",
]);

const BACKGROUND_ACTIONS = new Set([
  // Estas dicen "pendiente" al usuario y el backend procesa asíncrono
  "optimize_all_products", "bulk_redesign", "bulk_generate_images",
]);

const executeShopifyAction = async (action: string, params: Record<string, unknown>) => {
  const timeoutMs = BACKGROUND_ACTIONS.has(action) ? 30_000      // backend responde rápido con "job started"
                  : LONG_RUNNING_ACTIONS.has(action) ? 900_000   // 15 min para bulk sincrónicas
                  : 180_000;                                      // default 3 min
  // ... resto igual
};
```

Para las `BACKGROUND_ACTIONS` el usuario recibe el "job started" y debe poll el estado por separado (algo que el backend ya soporta via automations/jobs, pero el chatbot no aprovecha).

### 2.5 Streaming

**El OmniChatbot NO usa streaming SSE** para la respuesta de `execute-action`. Espera el JSON completo. Esto es coherente con el backend que responde JSON único.

**Lo que sí usa streaming** es:
- `useAutoReconnectSSE` en `use-draft-persistence.ts` (hook utilitario, no veo usos en OmniChatbot)
- `EventSource` en `Images.tsx` para el progreso de generación (implicado por el uso de `localStorage` `img-jobs`)

---

## 3. FLUJOS CRÍTICOS

### 3.1 Login → dashboard admin

`Login.tsx` → POST `/api/auth/login` con `{email, password}` → setea cookie HttpOnly server-side → `fetchMe()` carga user → `useAuth()` rehidrata → `App.tsx` redirige según rol:
- Admin → `/admin/clients` (vía `/admin` redirect en línea 257 de App.tsx)
- Client → `/client` (vía `ClientLayout.tsx`)

**Posibles fallos:**
- Si `fetchMe()` falla por red, `loading` queda `true` indefinido → LoadingScreen permanente. No veo `timeout` en fetchMe.
- `AuthContext.tsx:30`: `fetch(\`${API_BASE}/api/auth/me\`)` sin timeout.

**Fix:**

```typescript
async function fetchMe(): Promise<AuthUser | null> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 10_000);
    const res = await fetch(`${API_BASE}/api/auth/me`, {
      credentials: "include",
      signal: ctrl.signal,
    });
    clearTimeout(t);
    if (!res.ok) return null;
    const data = await res.json();
    return data.user as AuthUser;
  } catch {
    return null;  // trata el timeout como "no autenticado" en vez de loading eterno
  }
}
```

### 3.2 Invite cliente → setup password → dashboard client

1. Admin invita → POST `/api/admin/projects/:id/invite` con `{email, name}` → backend crea user role=client + envía email con link `https://.../invite/:token`.
2. Cliente abre el link → `InviteSetup.tsx` monta → GET `/api/auth/invite/:token` valida token → muestra form.
3. Cliente elige password → POST `/api/auth/invite/:token/setup` con `{password}` → backend crea sesión + redirige a `/client`.

**Verificar** (pendiente, no tengo el código abierto): que InviteSetup maneje los casos:
- Token expirado (>24h)
- Token ya usado
- Password débil (< 8 chars)
- Server error → estado claro al usuario, no "loading" permanente

### 3.3 Crear proyecto nuevo (Shopify / Woo / Presta / Universal)

`NewProject.tsx` → POST `/api/projects/test-connection-presave` (probar credenciales antes de guardar) → POST `/api/projects` (crear). Soporta 4 plataformas (según `platform_type` en DB, del Bloque A).

**Verificar** (pendiente):
- Que las credenciales no se loggeen en consola del navegador
- Que el token de acceso se borre del state tras guardar
- Que haya error handling si test-connection-presave falla

### 3.4 Comprar pack de créditos (Shopify cart)

Del backend ya sé que `addPackCredits` (lib/plan-limits.ts:161) suma créditos al proyecto. El flujo UI:
- `Billing.tsx` botón "upgrade" → POST `/api/billing/upgrade {plan}` → backend genera `payment_link` (probablemente URL de Shopify cart como `https://<shop>/cart/add?id=XXX&quantity=1`) → frontend abre esa URL en pestaña nueva.
- Cuando Shopify completa el pago, un webhook (no auditado aquí) dispara `addPackCredits`.

**Verificar**:
- Que el botón "Upgrade" realmente abre la URL o solo cambia el state local (en el código que vi, `setSubData(...)` simplemente actualiza UI — NO veo window.open ni redirect).
- **Posible bug:** `upgradePlan(planId)` solo actualiza state; si no redirige a Shopify cart, el usuario nunca paga. Hay que verificar el final del handler.

```typescript
// pages/admin/Billing.tsx:36
const upgradePlan = async (planId: string) => {
  setUpgrading(planId);
  try {
    const res = await fetch(`${API_BASE}/api/billing/upgrade`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ plan: planId }),
    });
    const data = await res.json();
    setSubData((prev: Record<string, unknown>) => ({ ...prev, subscription: data.subscription }));
    // ⚠️ NO hay window.open(data.checkoutUrl) ni window.location = ...
    // Si data.checkoutUrl existe, nunca se usa.
  } finally {
    setUpgrading(null);
  }
};
```

**Fix:**

```typescript
const upgradePlan = async (planId: string) => {
  setUpgrading(planId);
  try {
    const res = await fetch(`${API_BASE}/api/billing/upgrade`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ plan: planId }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      alert(`Error: ${err.error || res.statusText}`);
      return;
    }
    const data = await res.json();
    if (data.checkoutUrl) {
      // Abrir el flujo de Shopify cart
      window.location.href = data.checkoutUrl;
      return;
    }
    // Solo para planes gratuitos (trial) o cambios sin pago
    setSubData((prev: Record<string, unknown>) => ({ ...prev, subscription: data.subscription }));
  } finally {
    setUpgrading(null);
  }
};
```

### 3.5 Generar imagen / audit / report / redesign

Todos tienen el mismo patrón: POST al endpoint → SSE o polling → mostrar resultado. En concreto:
- **Imágenes (`projects/Images.tsx`):** POST `/api/projects/:id/images/generate` con `{imageType}` → SSE → UI muestra progreso → localStorage persiste `img-jobs-${projectId}` con TTL 10 min para resistir reload.
- **Audit:** POST `/api/projects/:id/audit` → JSON grande → render.
- **Redesign:** POST `/api/projects/:id/redesign` → JSON con `bodyHtml` → `dangerouslySetInnerHTML` (XSS, ver FE-3).

### 3.6 Descargar PDF/ZIP del vault

`GlobalVault.tsx` y `ProjectVault.tsx` → GET `/api/vault/global/:id/download` o `/api/projects/:id/vault/:id/download` → browser descarga. OK, patrón estándar.

**Endpoint especial** `/api/projects/:id/vault/download-images/:format` donde format ∈ {avif,jpg,png,tiff,webp}. El FE construye la URL dinámicamente. Backend acepta el parámetro de ruta. **Funciona.**

### 3.7 Forgot / Reset password

- `ForgotPassword.tsx` → POST `/api/auth/forgot-password {email}` → backend envía email con link `/reset-password?token=XXX`.
- `ResetPassword.tsx` → lee `token` de query → POST `/api/auth/reset-password {token, newPassword}`.

**Verificar** (pendiente):
- Token expira tras X horas
- Token es single-use
- `ResetPassword.tsx` valida complejidad de password (mínimo 8 chars, etc.)

---

## 4. ESTADO Y DATOS

### 4.1 React Query — uso inconsistente

**Lugares que SÍ lo usan** (grep de `useQuery\|useMutation`):
- `App.tsx` monta `<QueryClientProvider>` con config correcta (retry skip 401, staleTime 5min, gcTime 30min, no refetchOnWindowFocus).
- Páginas `/admin/projects/*` varias usan `useQuery` para productos, auditoría, etc.

**Lugares que NO lo usan (usan `useEffect + fetch + setState` manual):**
- `pages/admin/Billing.tsx` — 4 fetches paralelos en `useEffect(() => { Promise.all([...]) }, [])`.
- `pages/admin/AdminClients.tsx` — similar patrón.
- `pages/admin/ShopyBrainInsights.tsx` — fetch + setState.
- `pages/admin/UniversalSearch.tsx`.
- Probablemente más.

**Consecuencia:**
- Sin cache: si navegas a Billing, vuelves a /admin/clients, y regresas a Billing → 4 fetches de nuevo.
- Sin invalidation: si haces un upgrade, el tab "subscription" muestra datos viejos hasta reload manual.
- Sin retry: si el backend falla 1 vez, la UI queda rota.
- Sin dedup: varios componentes pidiendo el mismo endpoint → N requests.

**Fix para Billing (ejemplo de refactor)**:

```typescript
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const billingKeys = {
  subscription: ["billing", "subscription"] as const,
  plans: ["billing", "plans"] as const,
  affiliate: ["billing", "affiliate"] as const,
  invoices: ["billing", "invoices"] as const,
};

async function fetchJson(url: string) {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export default function Billing() {
  const qc = useQueryClient();
  const sub = useQuery({ queryKey: billingKeys.subscription, queryFn: () => fetchJson(`${API_BASE}/api/billing/subscription`) });
  const plans = useQuery({ queryKey: billingKeys.plans, queryFn: () => fetchJson(`${API_BASE}/api/billing/plans`) });
  const aff = useQuery({ queryKey: billingKeys.affiliate, queryFn: () => fetchJson(`${API_BASE}/api/billing/affiliate`) });
  const inv = useQuery({ queryKey: billingKeys.invoices, queryFn: () => fetchJson(`${API_BASE}/api/billing/invoices`) });

  const upgrade = useMutation({
    mutationFn: async (planId: string) => {
      const res = await fetch(`${API_BASE}/api/billing/upgrade`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan: planId }),
      });
      if (!res.ok) throw new Error((await res.json()).error || res.statusText);
      return res.json();
    },
    onSuccess: (data) => {
      if (data.checkoutUrl) { window.location.href = data.checkoutUrl; return; }
      qc.invalidateQueries({ queryKey: billingKeys.subscription });
      qc.invalidateQueries({ queryKey: billingKeys.invoices });
    },
  });

  const joinAff = useMutation({
    mutationFn: () => fetch(`${API_BASE}/api/billing/affiliate/join`, { method: "POST", credentials: "include" }).then(r => r.json()),
    onSuccess: () => qc.invalidateQueries({ queryKey: billingKeys.affiliate }),
  });

  if (sub.isLoading || plans.isLoading) return <LoadingState />;
  if (sub.isError) return <ErrorState onRetry={() => sub.refetch()} />;

  // ...resto del JSX
}
```

Aplicar este patrón a las otras páginas que hacen `useEffect + fetch`.

### 4.2 Contextos

**AuthContext.tsx (158 líneas):**
- Cookie-based. `fetchMe()` carga `/api/auth/me`.
- `localStorage`: solo `LAST_ROUTE_KEY` (ruta última visitada para redirigir tras login) y `SESSION_ALIVE_KEY="1"` (flag simple sin datos sensibles).
- Race condition leve: durante `loading` el child no se renderiza (LoadingScreen). ✅
- **Problema menor:** si `fetchMe` es lento, el usuario ve LoadingScreen hasta que Express responde. Añadir timeout (ver 3.1).

**CmsContext.tsx (76 líneas):**
- Carga `/api/cms/content` en mount.
- Expone `t(path, fallback)` para leer claves anidadas tipo `"landing.hero.title"`.
- Ready-flag cuando termina.
- ✅ No hay issues.

### 4.3 localStorage / sessionStorage — claves usadas

| Clave | Componente | Sensible | Observación |
|---|---|---|---|
| `LAST_ROUTE_KEY` | AuthContext | ❌ | Pathname |
| `SESSION_ALIVE_KEY` | AuthContext | ❌ | "1" boolean |
| `COACH_MARKS_KEY` | CoachMarks | ❌ | Flag UI |
| `sc_recent_searches` | UniversalSearch | ❌ | Historial queries |
| `img-jobs-${projectId}` | Images.tsx | ❌ | Job IDs de generación |
| `img-bulk-${projectId}` | Images.tsx | ❌ | Bulk job ID |
| `use-draft-persistence/<key>` | varios | ⚠️ | **Depende del uso** |

**FE-12 — `use-draft-persistence` riesgo:**

```typescript
// hooks/use-draft-persistence.ts
localStorage.setItem(key, JSON.stringify({ data, savedAt: Date.now() }));
```

Si algún formulario usa este hook para persistir un campo con credenciales (Shopify accessToken al crear proyecto, por ejemplo), queda 24h en localStorage. **Hay que auditar todos los usos del hook** para verificar que ningún formulario con credenciales lo use.

Grep rápido recomendado:
```bash
grep -rn "useDraftPersistence" src/ | head
```

Y revisar si alguna página con inputs sensibles (NewProject.tsx cuando pregunta accessToken) lo usa. Si sí, **hay que excluir esos campos** del draft.

**Fix para el hook:**

```typescript
export function useDraftPersistence<T>(
  key: string,
  data: T,
  setData: (d: T) => void,
  opts?: { enabled?: boolean; debounceMs?: number; omitFields?: string[] }
) {
  const { enabled = true, debounceMs = DEBOUNCE_MS, omitFields = [] } = opts ?? {};

  // ... load igual ...

  useEffect(() => {
    if (!enabled || !loaded.current) return;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      try {
        // FIX: omitir campos sensibles antes de serializar
        let sanitized: T = data;
        if (omitFields.length > 0 && typeof data === "object" && data !== null) {
          const clone = { ...(data as Record<string, unknown>) };
          for (const f of omitFields) {
            if (f in clone) clone[f] = undefined;
          }
          sanitized = clone as T;
        }
        localStorage.setItem(key, JSON.stringify({ data: sanitized, savedAt: Date.now() }));
      } catch {}
    }, debounceMs);
    return () => { if (timer.current) clearTimeout(timer.current); };
  }, [key, data, enabled, debounceMs, omitFields]);

  // ...
}
```

Uso en NewProject.tsx:
```typescript
useDraftPersistence("new-project-draft", form, setForm, {
  omitFields: ["accessToken", "apiPassword", "clientSecret"],
});
```

---

## 5. SEGURIDAD FRONTEND — FIXES CON CÓDIGO

### 🔴 FE-1 · `postMessage` con wildcard origin

**Archivo:** `src/pages/Landing.tsx:507, 525`

**Código actual:**

```typescript
window.parent.postMessage({ type: "cms-click-to-edit", path }, parentOrigin || "*");
// ...
window.parent.postMessage({ type: "cms-inline-edit", path, value: newText }, parentOrigin || "*");
```

Si la landing se incrusta en un iframe de un origin que no cumple la condición de preview, cae a `"*"` y el payload se envía a cualquier parent. Los datos no son sensibles (contenido CMS en edición), pero:
- Contamina logs de origins externos.
- Si el admin activa preview en staging y luego navega al CMS desde producción, podría haber cross-origin inesperado.

**Fix:**

```typescript
// Validar parentOrigin contra allowlist
const ALLOWED_CMS_ORIGINS = new Set([
  typeof window !== "undefined" ? window.location.origin : "",
  "https://shopycrafter.com",
  "https://dev.shopycrafter.com",
]);

const parentOrigin = useMemo(() => {
  if (!isPreview) return null;
  const origin = window.location.origin;
  return ALLOWED_CMS_ORIGINS.has(origin) ? origin : null;
}, [isPreview]);

const cmsNotify = useCallback((path: string, e: React.MouseEvent) => {
  if (!isPreview || !parentOrigin) return;  // no postMessage si origin no válido
  e.stopPropagation();
  window.parent.postMessage({ type: "cms-click-to-edit", path }, parentOrigin);
}, [isPreview, parentOrigin]);

// Lo mismo para el onBlur del cmsProps
onBlur: (e: React.FocusEvent<HTMLElement>) => {
  if (!parentOrigin) return;
  const newText = e.currentTarget.innerText;
  window.parent.postMessage({
    type: "cms-inline-edit", path, value: newText,
  }, parentOrigin);
},
```

### 🔴 FE-2 · CMSEditor handler sin validar `event.origin`

**Archivo:** `src/pages/admin/CMSEditor.tsx:1253`

**Código actual:**

```typescript
const handler = (e: MessageEvent) => {
  if (e.data?.type === "cms-click-to-edit") {
    // ...procesa e.data sin validar e.origin
  }
  if (e.data?.type === "cms-inline-edit") {
    setContent(updated => {
      // modifica estado con e.data.value SIN validar origin
    });
  }
};
window.addEventListener("message", handler);
```

**Riesgo:** cualquier iframe embebido en la página (una extensión del navegador, un gadget, un side-panel, un dev-tool) puede mandar mensajes con `type: "cms-inline-edit"` y modificar el state del CMS editor. Si luego el admin hace "save", los cambios se persisten.

**Fix:**

```typescript
const handler = (e: MessageEvent) => {
  // FIX 1: validar origin
  if (e.origin !== window.location.origin) {
    console.warn("[CMS] Mensaje ignorado de origin no válido:", e.origin);
    return;
  }

  // FIX 2: validar source (debe ser el iframe del preview)
  if (iframeRef.current && e.source !== iframeRef.current.contentWindow) {
    return;
  }

  // FIX 3: validar estructura del mensaje
  if (typeof e.data !== "object" || e.data === null) return;

  if (e.data?.type === "cms-click-to-edit") {
    // ... procesar ...
  }
  if (e.data?.type === "cms-inline-edit") {
    // ... procesar ...
  }
};
window.addEventListener("message", handler);
```

### 🔴 FE-3 · XSS en `Redesign.tsx` via `dangerouslySetInnerHTML`

**Archivo:** `src/pages/projects/Redesign.tsx:513`

**Código actual:**

```tsx
<div dangerouslySetInnerHTML={{ __html: result.bodyHtml || "" }} />
```

`result.bodyHtml` viene del backend — ha sido generado por Claude. Claude está instruido a producir HTML limpio, pero:
- Un prompt injection podría lograr que Claude devuelva `<script>fetch("/api/auth/logout")</script>` o exfiltrate cookies.
- El admin ejecutaría el JS con todos sus permisos.

**Fix: sanitizar con DOMPurify**

Añadir dependencia:
```bash
pnpm add dompurify @types/dompurify --filter @workspace/shopify-optimizer
```

```tsx
import DOMPurify from "dompurify";

// Configurar DOMPurify para permitir SOLO tags HTML seguros
const CLEAN_CONFIG = {
  ALLOWED_TAGS: ["p", "h1", "h2", "h3", "h4", "strong", "em", "u", "s",
    "ul", "ol", "li", "a", "img", "br", "hr", "blockquote", "code", "pre",
    "table", "thead", "tbody", "tr", "td", "th", "span", "div"],
  ALLOWED_ATTR: ["href", "src", "alt", "title", "class", "rel", "target"],
  // Forzar target=_blank y rel=noopener en links
  ADD_ATTR: ["target"],
  FORBID_TAGS: ["script", "style", "iframe", "object", "embed", "form"],
  FORBID_ATTR: ["onerror", "onload", "onclick", "onmouseover"],
};

function cleanHtml(raw: string): string {
  const clean = DOMPurify.sanitize(raw, CLEAN_CONFIG);
  // Forzar target="_blank" rel="noopener noreferrer" en <a>
  return clean.replace(/<a\s+([^>]*?)>/gi, (_, attrs) => {
    const hasTarget = /target=/.test(attrs);
    const hasRel = /rel=/.test(attrs);
    let out = `<a ${attrs}`;
    if (!hasTarget) out += ' target="_blank"';
    if (!hasRel) out += ' rel="noopener noreferrer"';
    return out + ">";
  });
}

// Uso:
<div dangerouslySetInnerHTML={{ __html: cleanHtml(result.bodyHtml || "") }} />
```

### 🟡 FE-4 · SVG sin sanitizar en Images.tsx

**Archivo:** `src/pages/projects/Images.tsx:566`

**Código actual:**

```tsx
<div dangerouslySetInnerHTML={{ __html: svgContent ... }} />
```

Si `svgContent` viene de un endpoint que devuelve SVG crudo (ej. un generador de logos), un SVG puede contener `<script>` (permitido por spec) y ejecutarse.

**Fix:** aplicar DOMPurify con config SVG:

```typescript
import DOMPurify from "dompurify";

const SVG_CONFIG = {
  USE_PROFILES: { svg: true, svgFilters: true },
  FORBID_TAGS: ["script", "foreignObject"],
  FORBID_ATTR: ["onerror", "onload", "onclick"],
};

function cleanSvg(raw: string): string {
  return DOMPurify.sanitize(raw, SVG_CONFIG);
}

<div dangerouslySetInnerHTML={{ __html: cleanSvg(svgContent) }} />
```

### 🟡 FE-5 · `API_BASE = import.meta.env.BASE_URL` — mal uso

**Archivos:** 9 archivos usan el mismo patrón:

```typescript
const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
```

**Problema:** `BASE_URL` de Vite es el **path del build estático**, no una URL de API. Solo funciona si:
- Frontend y backend comparten origen (el caso actual: Express sirve el build Vite).
- Capacitor WebView carga shopycrafter.com (funciona porque el site sirve ambos).

**Si mañana separas frontend y backend en dominios distintos**, todo se rompe. Lo correcto:

```bash
# .env.local (git-ignored)
VITE_API_URL=https://api.shopycrafter.com

# .env.production (build)
VITE_API_URL=
```

```typescript
// src/lib/api.ts — archivo nuevo
export const API_BASE: string = import.meta.env.VITE_API_URL ?? "";

export async function apiFetch(path: string, init?: RequestInit): Promise<Response> {
  const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
  return fetch(url, { credentials: "include", ...init });
}
```

Luego reemplazar en los 9 archivos:
```typescript
// ANTES:
const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
fetch(`${API_BASE}/api/auth/me`, { credentials: "include" });

// DESPUÉS:
import { apiFetch } from "@/lib/api";
apiFetch("/api/auth/me");
```

Beneficios:
- Un solo punto de configuración.
- Fácil añadir logging, retry, auth headers en el futuro.
- Compatibilidad con separación de dominios.

### 🟡 FE-6 · `RequireClient` redirige admin a `/`

**Archivo:** `src/App.tsx:131-138`

**Código actual:**

```typescript
function RequireClient({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <LoadingScreen />;
  if (!user) return <Redirect to="/" />;
  if (user.role === "admin") return <Redirect to="/" />;  // ⚠️ admin va a landing pública
  return <>{children}</>;
}
```

**Problema menor:** si un admin accede por accidente a una URL `/client/*`, se le envía a `/` que es la landing pública. Debería ir a `/admin/clients` (dashboard admin).

**Fix:**

```typescript
function RequireClient({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <LoadingScreen />;
  if (!user) return <Redirect to="/" />;
  if (user.role === "admin") return <Redirect to="/admin/clients" />;  // FIX
  return <>{children}</>;
}
```

### Guards — ¿bypassables?

**Análisis técnico:**
- `RequireAdmin` comprueba `user && user.role === "admin"`. Si `user` es null → redirect. Si rol no es admin → redirect.
- No hay forma de evitar esto desde el cliente sin modificar JS en memoria (y entonces solo vería UI — el backend sigue exigiendo cookie admin).
- **El backend es la autoridad final** — todas las rutas admin tienen `requireAdmin` middleware.

**Conclusión:** guards **NO son bypassables** en la práctica. El único "bypass" sería que `useAuth()` devuelva datos incorrectos (race condition con `loading`), pero el código espera correctamente el loading antes de decidir.

### Tokens/secrets en el bundle

Grep rápido:
```bash
grep -rn 'VITE_' artifacts/shopify-optimizer/src/ | grep -v node_modules
```

Resultado: solo `VITE_API_URL` y similares (todas públicas). **No hay claves privadas hardcodeadas** (Claude, Gemini, Shopify están en el backend).

---

## 6. UX / ACCESIBILIDAD / MOBILE

### 6.1 Loading states

**Inconsistentes:**
- Muchas páginas tienen `loading ? <Spinner/> : ...`
- Pero otras (Billing, AdminClients) muestran **nada** hasta que cargue todo → pantalla en blanco de 1-3 segundos.

**Fix unificado** — usar un componente común:

```typescript
// src/components/ui/PageLoader.tsx (ya existe en App.tsx:)
export function PageLoader() {
  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
    </div>
  );
}

// Skeleton variant para listas:
export function ListSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-12 bg-muted animate-pulse rounded" />
      ))}
    </div>
  );
}
```

Y usar en todas las páginas que tengan fetch inicial.

### 6.2 Error boundaries

**Existe `ErrorBoundary.tsx`** (no lo leí completo, pero el grep indica que lo usa `import.meta.env.DEV` para mostrar stack trace solo en dev).

**Verificar**: que el `<ErrorBoundary>` envuelva cada ruta (o al menos las páginas complejas como OmniChatbot, CMSEditor, Redesign). Si no, un error en un componente rompe toda la app.

En `App.tsx` hay que verificar:
```bash
grep -n 'ErrorBoundary' src/App.tsx
```

**Recomendación:** envolver cada ruta con su propio ErrorBoundary para que un fallo en `/admin/shopybrain` no rompa `/admin/clients`.

### 6.3 Mobile responsive

- Hook `use-mobile.tsx` existe — detecta breakpoint.
- Capacitor Android — la app es un WebView de shopycrafter.com.
- **Problema potencial:** muchas páginas admin tienen layouts densos con tablas y sidebars. En móvil esos layouts pueden romperse.
- El `AppLayout.tsx` gestiona el layout adaptativo (sidebar colapsable).

**Recomendación de test manual:**
- Abrir Chrome DevTools → modo móvil (iPhone 12).
- Probar cada página admin crítica: Billing, NewProject, CMSEditor, ProjectVault, ShopyBrain, OmniChatbot.
- Anotar las que se rompen.

### 6.4 Páginas que crashean con datos vacíos

**Potencial:** páginas que hacen `data.products.map()` sin verificar `data.products`:

```bash
grep -rnE '\.map\(' src/pages/ | grep -v 'node_modules' | head -20
```

Recomendación: añadir defaults en `queryFn` o en el render:

```typescript
const products = data?.products ?? [];  // siempre array
return <List items={products} />;
```

---

## 7. CAPACITOR / ANDROID

### 7.1 Config actual

```typescript
// capacitor.config.ts
{
  appId: "es.shopybrain.app",
  appName: "Shopy Crafter",
  webDir: "dist/public",
  server: {
    url: process.env.APP_URL ?? "https://shopycrafter.com",
    cleartext: false,
    androidScheme: "https",
  },
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    SplashScreen: { launchShowDuration: 1500, ... },
  },
}
```

**Análisis:**

✅ **Bien:**
- `cleartext: false` — HTTPS obligatorio.
- `allowMixedContent: false` — sin HTTP embebido en HTTPS.
- `webContentsDebuggingEnabled: false` — sin Chrome DevTools en producción.
- `androidScheme: "https"` — correcto.

⚠️ **Pendiente:**
- `server.url` apunta a producción siempre — **la app es un WebView thin wrapper.** No hay offline fallback.
- Sin service worker — si el usuario abre la app sin internet, pantalla blanca.
- Sin deep linking configurado — links `shopycrafter.com/admin/...` desde otro app no abren la app nativa.

### 7.2 AndroidManifest.xml — permisos

**Solo declara:**
```xml
<uses-permission android:name="android.permission.INTERNET" />
```

**Faltan potencialmente:**
- `RECORD_AUDIO` — si `VoiceButton` quiere grabar sonido (actualmente usa Web Speech API que no requiere permiso nativo porque va por webview, pero si se migra a Capacitor Voice plugin, sí).
- `CAMERA` — si se quiere tomar fotos directamente (ej. para upload en `absorb-image`). Actualmente usa `<input type="file" capture>` que funciona via webview.
- `WRITE_EXTERNAL_STORAGE` — para guardar PDFs descargados localmente (actualmente los descarga via webview usando el sistema del navegador, que usa el FileProvider ya declarado).
- `POST_NOTIFICATIONS` (Android 13+) — para push notifications (los endpoints `/api/push/vapid-*` están en backend pero no hay plugin Capacitor Push configurado).

**Fix para notificaciones push (si lo quieres):**

```xml
<!-- AndroidManifest.xml -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.VIBRATE" />
```

```bash
pnpm add @capacitor/push-notifications --filter @workspace/shopify-optimizer
npx cap sync android
```

### 7.3 Deep links

Actualmente **no configurados**. Si el admin recibe un email con link `https://shopycrafter.com/admin/clients` y tiene la app instalada, abre Chrome en vez de la app.

**Fix** — añadir intent-filter en AndroidManifest.xml:

```xml
<activity android:name=".MainActivity" ...>
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>

    <!-- FIX: deep links -->
    <intent-filter android:autoVerify="true">
        <action android:name="android.intent.action.VIEW" />
        <category android:name="android.intent.category.DEFAULT" />
        <category android:name="android.intent.category.BROWSABLE" />
        <data android:scheme="https"
              android:host="shopycrafter.com" />
    </intent-filter>
</activity>
```

Y hostear `.well-known/assetlinks.json` en `shopycrafter.com` con el SHA-256 del cert de la app para verificación automática.

### 7.4 Build configurado

No tengo visibilidad del `android/app/build.gradle` (no lo pedí), pero lo que importa:
- `minSdkVersion` >= 23 (Android 6.0) — recomendado.
- `targetSdkVersion` = 34 o 35 — requisito Play Store 2025.
- `applicationId` = `es.shopybrain.app` (confirmado en capacitor.config.ts).

Si el build falla, revisar `gradle.properties` para flags de heap.

---

## 8. PÁGINAS QUE ESTÁN BIEN (mérito de mención)

- **`AuthContext.tsx`** — Cookie-based, race-safe, localStorage solo metadata no-sensible.
- **`OmniChatbot.tsx` — executeShopifyAction handler** — manejo friendly de errores (credits, rate_limit, auth) y AbortController bien implementado.
- **`CmsContext.tsx`** — simple, correcto, fallback-safe.
- **`App.tsx`** — lazy loading de páginas con `React.lazy` + `Suspense`. QueryClient configurado bien.
- **`hooks/use-draft-persistence.ts`** — TTL de 24h, debounce 800ms, try/catch alrededor de JSON.parse. Solo falta la omisión de campos sensibles (FE-12).
- **`useRetryFetch`** — retry exponential backoff, skip 4xx. Buena ingeniería.

---

## 9. PLAN DE ACCIÓN PRIORIZADO

### Fase 1 — Parches de seguridad (2-4 h)

1. **FE-3** instalar DOMPurify y aplicar a `Redesign.tsx:513`.
2. **FE-4** aplicar DOMPurify (config SVG) a `Images.tsx:566`.
3. **FE-1** añadir allowlist de origins a `Landing.tsx`.
4. **FE-2** validar `event.origin` en `CMSEditor.tsx:1253`.

### Fase 2 — Correcciones de flujo y UX (4-6 h)

5. **3.4 Billing upgrade** — redirigir a `data.checkoutUrl` cuando venga.
6. **3.1 AuthContext timeout** — añadir AbortController a `fetchMe()`.
7. **FE-8 OmniChatbot timeout** — categorías LONG/BACKGROUND.
8. **FE-6** redirigir admin a `/admin/clients` en vez de `/`.

### Fase 3 — Refactor & tecnología (1-2 días)

9. **FE-5** `VITE_API_URL` + helper `apiFetch`.
10. **4.1** Migrar Billing, AdminClients, ShopyBrainInsights, UniversalSearch a react-query.
11. **FE-14** partir OmniChatbot.tsx en 5-6 módulos.
12. **6.2** envolver cada ruta en su propio ErrorBoundary.

### Fase 4 — Mobile / Capacitor (medio día)

13. **7.3 Deep links** — intent-filter + assetlinks.json.
14. **7.2 Permisos** — evaluar POST_NOTIFICATIONS si se quieren push.
15. **6.3** test manual mobile de las páginas críticas.

### Fase 5 — Cleanup (opcional)

16. **FE-12 use-draft-persistence** — parámetro `omitFields`.
17. **1.2** decidir qué hacer con los 150 endpoints sin UI directa (documentar como "chatbot-only" o implementar UI).
18. **2.3** simplificar `formatActionResult` — el backend ya envía `result.message` formateado.

---

## 10. APÉNDICE — COMANDOS DE VERIFICACIÓN

```bash
# Todos los endpoints usados por el frontend
grep -rn '/api/' artifacts/shopify-optimizer/src/ | \
  grep -oE '/api/[][a-zA-Z0-9_/:${}.-]+' | \
  sed -E 's/\$\{[^}]+\}/:var/g; s/\.[a-z]+$//' | \
  sort -u

# Todos los endpoints definidos por el backend
grep -rnE 'router\.(get|post|put|delete|patch)' artifacts/api-server/src/routes/

# dangerouslySetInnerHTML
grep -rn 'dangerouslySetInnerHTML' artifacts/shopify-optimizer/src/

# postMessage / addEventListener message
grep -rnE 'postMessage|addEventListener\(["'\''"]message' artifacts/shopify-optimizer/src/

# localStorage keys
grep -rn 'localStorage\.(getItem|setItem|removeItem)' artifacts/shopify-optimizer/src/

# Guards
grep -n 'RequireAdmin\|RequireClient' artifacts/shopify-optimizer/src/App.tsx

# Uso de BASE_URL mal aplicado
grep -rn 'import.meta.env.BASE_URL' artifacts/shopify-optimizer/src/
```

---

**FIN DEL DOCUMENTO**

Auditoría realizada sobre el código real extraído de `shopycrafter_codigo_completo__1__.tar.gz`. Todas las líneas y nombres de archivo son verificables con los comandos del apéndice 10.
