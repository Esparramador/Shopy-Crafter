/**
 * Helper centralizado para llamadas a la API del backend.
 *
 * Reemplaza el patrón repetido:
 *   const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
 *   fetch(`${API_BASE}/api/foo`, { credentials: "include" });
 *
 * Ventajas:
 * - Un solo punto de configuración (VITE_API_URL).
 * - Compatibilidad con separación de dominios (api.shopycrafter.com).
 * - `credentials: "include"` automático.
 * - Timeout por defecto con AbortController.
 * - Errores de red tipados.
 *
 * Uso:
 *   import { apiFetch, apiJson } from "@/lib/api";
 *
 *   // Raw fetch (para streams, FormData, etc.)
 *   const res = await apiFetch("/api/auth/me");
 *
 *   // JSON directo con error tipado
 *   const user = await apiJson<User>("/api/auth/me");
 *
 *   // POST con body
 *   await apiJson("/api/billing/upgrade", { method: "POST", json: { plan: "pro" } });
 */

// ─── Configuración ────────────────────────────────────────────────────────────
// En producción VITE_API_URL = "" (mismo origen que el frontend).
// En desarrollo separado VITE_API_URL = "http://localhost:8080".
// En Capacitor Android VITE_API_URL = "https://shopycrafter.com".
export const API_BASE: string = (import.meta.env.VITE_API_URL as string | undefined) ?? "";

// Timeout por defecto de 30s (los endpoints de IA tienen su propio timeout más alto).
const DEFAULT_TIMEOUT_MS = 30_000;

// ─── Tipos ────────────────────────────────────────────────────────────────────
export interface ApiRequestInit extends Omit<RequestInit, "body"> {
  /** Cuerpo JSON — se serializa y se setea Content-Type automáticamente. */
  json?: unknown;
  /** Cuerpo raw (FormData, string, etc.). Mutuamente excluyente con `json`. */
  body?: BodyInit | null;
  /** Timeout en milisegundos. Default: 30_000. Usa 0 para desactivar. */
  timeoutMs?: number;
}

export class ApiError extends Error {
  readonly status: number;
  readonly body: unknown;
  constructor(status: number, message: string, body: unknown) {
    super(message);
    this.status = status;
    this.body = body;
    this.name = "ApiError";
  }
}

// ─── Implementación ───────────────────────────────────────────────────────────
function buildUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) return path;
  if (!path.startsWith("/")) path = "/" + path;
  return `${API_BASE}${path}`;
}

export async function apiFetch(path: string, init?: ApiRequestInit): Promise<Response> {
  const { json, body, timeoutMs, headers, ...rest } = init ?? {};
  const finalHeaders = new Headers(headers);
  let finalBody: BodyInit | null | undefined = body;
  if (json !== undefined) {
    if (body !== undefined) throw new Error("apiFetch: no uses `json` y `body` a la vez");
    finalBody = JSON.stringify(json);
    if (!finalHeaders.has("Content-Type")) finalHeaders.set("Content-Type", "application/json");
  }

  const url = buildUrl(path);
  const ctrl = new AbortController();
  const effectiveTimeout = timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const timer = effectiveTimeout > 0 ? setTimeout(() => ctrl.abort(), effectiveTimeout) : null;

  try {
    // Si el caller pasa su propio signal, respetarlo (no lo reemplazamos).
    const signal = rest.signal ?? ctrl.signal;
    return await fetch(url, {
      credentials: "include",
      ...rest,
      headers: finalHeaders,
      body: finalBody,
      signal,
    });
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function apiJson<T = unknown>(path: string, init?: ApiRequestInit): Promise<T> {
  const res = await apiFetch(path, init);
  let parsed: unknown = null;
  try {
    parsed = await res.json();
  } catch {
    // respuesta no-JSON
  }
  if (!res.ok) {
    const msg = (parsed && typeof parsed === "object" && parsed !== null && "error" in parsed)
      ? String((parsed as { error: unknown }).error)
      : res.statusText || `HTTP ${res.status}`;
    throw new ApiError(res.status, msg, parsed);
  }
  return parsed as T;
}

// ─── Friendly error messages ──────────────────────────────────────────────────
// Convierte errores de IA en mensajes humanos (Claude, Gemini, rate limits).
export function friendlyErrorMessage(err: unknown, action?: string): string {
  if (err instanceof ApiError) {
    if (err.status === 401) return "🔑 Sesión expirada. Inicia sesión de nuevo.";
    if (err.status === 403) return "🚫 No tienes permisos para esta acción.";
    if (err.status === 429) return "⏳ Demasiadas peticiones. Espera unos segundos.";
    if (err.status >= 500) return `⚠️ Error del servidor (${err.status}). ${err.message}`;
    return err.message;
  }
  const msg = err instanceof Error ? err.message : String(err);
  if (msg.includes("credit balance is too low") || msg.includes("insufficient_quota")) {
    return `⚠️ Créditos de IA agotados. Recarga en console.anthropic.com.`;
  }
  if (msg.includes("rate_limit") || msg.includes("429")) {
    return `⏳ Límite de velocidad. Espera unos segundos.`;
  }
  if (msg.includes("aborted") || msg === "timeout") {
    return `⏳ ${action ?? "La solicitud"} tardó demasiado. Intenta de nuevo.`;
  }
  return `❌ ${msg.slice(0, 200)}`;
}
