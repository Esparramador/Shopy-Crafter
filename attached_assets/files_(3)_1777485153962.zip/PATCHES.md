═══════════════════════════════════════════════════════════════════════════════
PATCHES UNIFICADOS — aplicar con `cd artifacts/shopify-optimizer && patch -p1 < XX.patch`
o manualmente abriendo el archivo en Replit y sustituyendo los bloques.
═══════════════════════════════════════════════════════════════════════════════

Orden de aplicación recomendado: ver REPLIT_GUIDE.md

═══════════════════════════════════════════════════════════════════════════════
PATCH #1 — FE-1 · Landing.tsx postMessage SEND con allowlist
═══════════════════════════════════════════════════════════════════════════════

Archivo: src/pages/Landing.tsx
Zona: líneas ~502-530 (2 llamadas a window.parent.postMessage)

─── ANTES (líneas 502-510) ───
  const parentOrigin = isPreview ? window.location.origin : "";

  const cmsNotify = useCallback((path: string, e: React.MouseEvent) => {
    if (!isPreview) return;
    e.stopPropagation();
    window.parent.postMessage({ type: "cms-click-to-edit", path }, parentOrigin || "*");
  }, [isPreview, parentOrigin]);

─── DESPUÉS ───
  // FIX FE-1: validar que el parent es un origen permitido antes de postMessage.
  // Si no lo es, no enviamos el mensaje (evita wildcard "*").
  const ALLOWED_PARENT_ORIGINS = new Set([
    typeof window !== "undefined" ? window.location.origin : "",
    "https://shopycrafter.com",
    "https://www.shopycrafter.com",
  ]);
  const parentOrigin = isPreview && ALLOWED_PARENT_ORIGINS.has(window.location.origin)
    ? window.location.origin
    : null;

  const cmsNotify = useCallback((path: string, e: React.MouseEvent) => {
    if (!isPreview || !parentOrigin) return;
    e.stopPropagation();
    // parentOrigin ya es un origen concreto (nunca "*")
    window.parent.postMessage({ type: "cms-click-to-edit", path }, parentOrigin);
  }, [isPreview, parentOrigin]);


─── ANTES (líneas ~522-530, dentro de cmsProps onBlur) ───
      onBlur: (e: React.FocusEvent<HTMLElement>) => {
        const newText = e.currentTarget.innerText;
        window.parent.postMessage({
          type: "cms-inline-edit",
          path,
          value: newText,
        }, parentOrigin || "*");
      },

─── DESPUÉS ───
      onBlur: (e: React.FocusEvent<HTMLElement>) => {
        if (!parentOrigin) return;  // FIX FE-1
        const newText = e.currentTarget.innerText;
        window.parent.postMessage({
          type: "cms-inline-edit",
          path,
          value: newText,
        }, parentOrigin);
      },


═══════════════════════════════════════════════════════════════════════════════
PATCH #2 — FE-3 · Redesign.tsx XSS con DOMPurify
═══════════════════════════════════════════════════════════════════════════════

Archivo: src/pages/projects/Redesign.tsx
Línea: ~513

─── IMPORTS (añadir arriba del archivo) ───
import { cleanHtml } from "@/lib/sanitize";

─── ANTES (línea 513) ───
                              <div
                                className="prose prose-invert prose-sm max-w-none bg-black/20 rounded-xl p-4 border border-white/5 text-muted-foreground text-xs mb-3 max-h-60 overflow-y-auto"
                                dangerouslySetInnerHTML={{ __html: result.bodyHtml || "" }}
                              />

─── DESPUÉS ───
                              <div
                                className="prose prose-invert prose-sm max-w-none bg-black/20 rounded-xl p-4 border border-white/5 text-muted-foreground text-xs mb-3 max-h-60 overflow-y-auto"
                                dangerouslySetInnerHTML={{ __html: cleanHtml(result.bodyHtml) }}
                              />


═══════════════════════════════════════════════════════════════════════════════
PATCH #3 — FE-4 · Images.tsx SVG con DOMPurify (refuerzo)
═══════════════════════════════════════════════════════════════════════════════

Archivo: src/pages/projects/Images.tsx
Línea: ~564-573

─── IMPORTS (añadir arriba del archivo) ───
import { cleanSvg } from "@/lib/sanitize";

─── ANTES (línea ~564) ───
                    {svgContent && (
                      <div
                        className="w-full aspect-square overflow-hidden bg-black/50"
                        dangerouslySetInnerHTML={{ __html: svgContent
                          .replace(/<script[\s\S]*?<\/script>/gi, "")
                          .replace(/\son\w+\s*=\s*["'][^"']*["']/gi, "")
                          .replace(/javascript:/gi, "")
                        }}
                      />
                    )}

─── DESPUÉS ───
                    {svgContent && (
                      <div
                        className="w-full aspect-square overflow-hidden bg-black/50"
                        dangerouslySetInnerHTML={{ __html: cleanSvg(svgContent) }}
                      />
                    )}


═══════════════════════════════════════════════════════════════════════════════
PATCH #4 — FE-6 · App.tsx RequireClient redirect a /admin/clients
═══════════════════════════════════════════════════════════════════════════════

Archivo: src/App.tsx
Línea: 131-138

─── ANTES ───
function RequireClient({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <LoadingScreen />;
  if (!user) return <Redirect to="/" />;
  if (user.role === "admin") return <Redirect to="/" />;
  return <>{children}</>;
}

─── DESPUÉS ───
function RequireClient({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <LoadingScreen />;
  if (!user) return <Redirect to="/" />;
  // FIX FE-6: el admin no debería ver rutas /client/* — llevarlo a su home
  if (user.role === "admin") return <Redirect to="/admin/clients" />;
  return <>{children}</>;
}


═══════════════════════════════════════════════════════════════════════════════
PATCH #5 — FE-8, FE-16, FE-20 · OmniChatbot.tsx timeout categorizado +
                                 límite multi-action + confirmación destructiva
═══════════════════════════════════════════════════════════════════════════════

Archivo: src/components/OmniChatbot.tsx

─── A) executeShopifyAction con timeout categorizado (reemplazar línea 1003-1035 aprox) ───

─── ANTES ───
  const executeShopifyAction = async (action: string, params: Record<string, unknown>): Promise<Record<string, unknown> | null> => {
    try {
      const actionController = new AbortController();
      const actionTimeout = setTimeout(() => actionController.abort(), 180000);

─── DESPUÉS ───
  // FIX FE-8: timeouts categorizados según la duración real de la acción
  const LONG_RUNNING_ACTIONS = new Set([
    "optimize_all_products", "bulk_redesign", "bulk_generate_images",
    "setup_full_store", "design_all_pages", "auto_collections",
    "fix_unpublished", "fix_missing_compare_prices", "sync_catalog_prices",
    "run_full_audit_report", "generate_ai_report", "audit_store", "scan_store",
    "generate_competitive_pricing", "copyright_audit", "auto_estimate_all_cogs",
    "analyze_external_store", "external_pre_report",
  ]);

  const executeShopifyAction = async (action: string, params: Record<string, unknown>): Promise<Record<string, unknown> | null> => {
    try {
      const actionController = new AbortController();
      // FIX FE-8: 15 min para bulk, 3 min para resto
      const timeoutMs = LONG_RUNNING_ACTIONS.has(action) ? 900_000 : 180_000;
      const actionTimeout = setTimeout(() => actionController.abort(), timeoutMs);


─── B) Loop de multi-action con límite + confirmación (reemplazar línea ~1834-1846) ───

─── ANTES ───
            const results: string[] = [];
            for (const act of allActions) {
              const actionResult = await executeShopifyAction(act.action, act.params);
              if (actionResult) {
                const formatted = formatActionResult(act.action, actionResult);
                results.push(formatted);
                const actionType = act.action === "search_suppliers" ? "supplier-research" : "shopify-action";
                action = { type: actionType as ChatAction["type"], label: actionType === "supplier-research" ? "Descargar informe" : "Ver resultado", data: actionResult, actionName: act.action, formattedContent: formatted };
              }
            }
            if (results.length > 0) {
              assistantContent += "\n\n" + results.join("\n\n---\n\n");
            }

─── DESPUÉS ───
            // FIX FE-16: límite duro de acciones por turno
            const MAX_ACTIONS_PER_TURN = 3;

            // FIX FE-16: acciones destructivas requieren confirmación explícita del usuario
            const DESTRUCTIVE_ACTIONS = new Set([
              "delete_product", "delete_collection", "delete_variant", "delete_email_flow",
              "deactivate_user", "reset_user_password", "reset_cms",
              "fix_unpublished", "fix_missing_compare_prices", "sync_catalog_prices",
              "optimize_all_products", "bulk_redesign", "bulk_update_prices", "bulk_update_stock",
              "auto_collections", "design_all_pages", "setup_full_store",
              "fix_code", "modify_ui", "edit_theme_file", "edit_theme_css", "edit_theme_settings",
              "create_theme_section", "sync_store_theme",
            ]);

            const actionsToRun = allActions.slice(0, MAX_ACTIONS_PER_TURN);
            const truncatedCount = allActions.length - actionsToRun.length;

            // FIX FE-20: anunciar al usuario qué acciones van a ejecutarse
            if (actionsToRun.length > 0) {
              const actionList = actionsToRun.map((a: { action: string }) => `• \`${a.action}\``).join("\n");
              const truncMsg = truncatedCount > 0
                ? `\n\n_(${truncatedCount} acciones adicionales omitidas — límite de ${MAX_ACTIONS_PER_TURN} por turno)_`
                : "";
              setMessages(m => [...m, {
                id: uuid(), role: "assistant" as const, timestamp: new Date(),
                content: `🎯 **Acciones detectadas:**\n${actionList}${truncMsg}`,
              }]);
            }

            const results: string[] = [];
            let stoppedForConfirmation = false;
            for (const act of actionsToRun) {
              // FIX FE-16: bloquear destructivas sin confirmed:true
              if (DESTRUCTIVE_ACTIONS.has(act.action) && !(act.params as Record<string, unknown>)?.confirmed) {
                results.push(
                  `⚠️ **Confirmación requerida para \`${act.action}\`**\n` +
                  `Esta acción modifica tu tienda/código. Re-envía tu petición añadiendo "confirma" al mensaje,\n` +
                  `o ejecútala manualmente desde la página correspondiente.`
                );
                action = { type: "shopify-action" as const, label: "Acción bloqueada", data: act, actionName: act.action, formattedContent: "Confirmación requerida" };
                stoppedForConfirmation = true;
                break;
              }

              const actionResult = await executeShopifyAction(act.action, act.params);
              if (actionResult) {
                const formatted = formatActionResult(act.action, actionResult);
                results.push(formatted);
                const actionType = act.action === "search_suppliers" ? "supplier-research" : "shopify-action";
                action = { type: actionType as ChatAction["type"], label: actionType === "supplier-research" ? "Descargar informe" : "Ver resultado", data: actionResult, actionName: act.action, formattedContent: formatted };
              }
            }

            if (results.length > 0) {
              assistantContent += "\n\n" + results.join("\n\n---\n\n");
            }
            if (stoppedForConfirmation && truncatedCount > 0) {
              // nada más que hacer, ya lo avisamos
            }


═══════════════════════════════════════════════════════════════════════════════
PATCH #6 — FE-5 · Reemplazar BASE_URL por API_BASE del helper apiFetch
═══════════════════════════════════════════════════════════════════════════════

Archivo: varios (9 archivos)

Comando bash para aplicarlo de forma automática (ejecutar desde la raíz del frontend):

  cd artifacts/shopify-optimizer

  # Añadir .env.production y .env.development
  echo "VITE_API_URL=" > .env.production
  echo "VITE_API_URL=" > .env.development

  # Reemplazar en los 9 archivos conocidos:
  for f in \
    src/contexts/AuthContext.tsx \
    src/contexts/CmsContext.tsx \
    src/components/OmniChatbot.tsx \
    src/components/ReferenceMediaPanel.tsx \
    src/components/layout/AppLayout.tsx \
    src/components/KnowledgeGraph.tsx \
    src/components/BrainExtractor.tsx \
    src/components/VoiceButton.tsx \
    src/components/SaveToVaultButton.tsx \
    src/components/OnboardingWidget.tsx \
  ; do
    sed -i.bak -E \
      -e 's|const (API_BASE|API|BASE_URL|API_BASE) = import\.meta\.env\.BASE_URL\?\?\s*\.replace\(/\\/\$/, ""\);|import { API_BASE } from "@/lib/api";|g' \
      -e 's|const (API_BASE|API|BASE_URL|API_BASE) = import\.meta\.env\.BASE_URL\.replace\(/\\/\$/, ""\);|import { API_BASE } from "@/lib/api";|g' \
      "$f"
  done

NOTA: los imports duplicados si ya existe uno hay que limpiarlos a mano.
Alternativamente editar cada archivo manualmente (son 9).

MIGRACIÓN RECOMENDADA DE LARGO PLAZO:
En vez de `fetch(\`${API_BASE}/api/foo\`, { credentials: "include" })`, usar
`apiFetch("/api/foo")` — que ya añade credentials automáticamente.


═══════════════════════════════════════════════════════════════════════════════
PATCH #7 — FE-1 (AuthContext) · timeout en fetchMe para evitar loading eterno
═══════════════════════════════════════════════════════════════════════════════

Archivo: src/contexts/AuthContext.tsx
Línea: ~28-34

─── ANTES ───
async function fetchMe(): Promise<AuthUser | null> {
  try {
    const res = await fetch(`${API_BASE}/api/auth/me`, { credentials: "include" });
    if (!res.ok) return null;
    const data = await res.json();
    return data.user as AuthUser;
  } catch {
    return null;
  }
}

─── DESPUÉS ───
async function fetchMe(): Promise<AuthUser | null> {
  try {
    // FIX: timeout de 10s — si el backend tarda más, tratamos como "no autenticado"
    // en vez de loading eterno en la UI.
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 10_000);
    const res = await fetch(`${API_BASE}/api/auth/me`, {
      credentials: "include",
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    if (!res.ok) return null;
    const data = await res.json();
    return data.user as AuthUser;
  } catch {
    return null;
  }
}
