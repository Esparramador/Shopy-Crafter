# Guía de aplicación de fixes — Shopy Crafter

Este paquete contiene los fixes del **Bloque B** listos para aplicar en Replit. Está diseñado para aplicarse en orden — cada fase no depende de las siguientes, así puedes parar en cualquier punto.

**Tiempo total estimado:** 4-6 horas sin prisa. Cada fase es atómica (un commit por fase).

---

## Estructura del paquete

```
fixes/
├── lib/
│   ├── api.ts                 ← archivo NUEVO (FE-5)
│   └── sanitize.ts            ← archivo NUEVO (FE-3, FE-4)
├── hooks/
│   └── use-draft-persistence.ts  ← reemplaza el existente (FE-12)
├── components/
│   └── ErrorBoundary.tsx      ← reemplaza el existente (FE-18)
├── pages/
│   └── Billing.tsx            ← reemplaza pages/admin/Billing.tsx (FE-9, FE-13, FE-17)
├── android/
│   ├── capacitor.config.ts    ← reemplaza el existente (FE-7, FE-11)
│   └── AndroidManifest.xml    ← reemplaza el existente (FE-11)
├── api-server/
│   └── error-report.ts        ← archivo NUEVO en routes/ (FE-18)
└── patches/
    └── PATCHES.md             ← diffs manuales para ~6 archivos (FE-1, FE-3, FE-4, FE-6, FE-8, FE-16, FE-20)
```

Cada fix corresponde a un ID (FE-1 a FE-20) documentado en `BLOQUE_B_frontend_audit.md` y `BLOQUE_B_addendum.md`.

---

## Correcciones a la auditoría original

Tras re-verificar el código real descubrí que algunos hallazgos del dossier original eran falsos positivos. Los corrijo aquí:

| Hallazgo | Estado real |
|---|---|
| **FE-2** CMSEditor handler sin validar origin | ✅ **YA ARREGLADO** — líneas 1211-1212 validan `e.origin !== window.location.origin` y `e.source !== iframeRef.current.contentWindow`. No requiere fix. |
| **FE-4** SVG sin sanitizar en Images.tsx | ⚠️ Tiene mitigación parcial (regex de `<script>`, `on*`, `javascript:`). DOMPurify es refuerzo, no crítico. |
| **FE-9** Billing upgradePlan sin checkoutUrl | ℹ️ No es bug del FE — el backend está en modo demo declarado. El fix sigue siendo válido como preparación para activar Shopify Billing real. |

---

## Fase 1 — Seguridad crítica (30 min)

### 1.1 Instalar DOMPurify
```bash
pnpm add dompurify --filter @workspace/shopify-optimizer
pnpm add -D @types/dompurify --filter @workspace/shopify-optimizer
```

### 1.2 Crear helpers nuevos
Copiar:
- `fixes/lib/sanitize.ts` → `artifacts/shopify-optimizer/src/lib/sanitize.ts`

### 1.3 Aplicar PATCH #1 (FE-1), PATCH #2 (FE-3), PATCH #3 (FE-4)
Ver `patches/PATCHES.md`. Son sustituciones puntuales en:
- `src/pages/Landing.tsx` (líneas 502-530)
- `src/pages/projects/Redesign.tsx` (línea 513)
- `src/pages/projects/Images.tsx` (líneas 564-573)

### 1.4 Verificar
```bash
cd artifacts/shopify-optimizer
pnpm typecheck
# Debería pasar sin errores
```

---

## Fase 2 — Refactor del networking (1 h)

### 2.1 Crear helper apiFetch
Copiar:
- `fixes/lib/api.ts` → `artifacts/shopify-optimizer/src/lib/api.ts`

### 2.2 Crear variables de entorno
```bash
cd artifacts/shopify-optimizer
echo "VITE_API_URL=" > .env.production
echo "VITE_API_URL=" > .env.development
echo ".env.local" >> .gitignore   # por si ya no está
```

### 2.3 (Opcional) Migrar los 9 archivos que usan `BASE_URL`
Ver PATCH #6. Esto es opcional — el código actual sigue funcionando porque VITE_API_URL es "". Puedes dejarlo para una fase posterior.

### 2.4 PATCH #7 (FE-1) — timeout en fetchMe
Editar `src/contexts/AuthContext.tsx` línea 28.

---

## Fase 3 — ErrorBoundary con reporting (30 min)

### 3.1 Reemplazar el componente
Copiar:
- `fixes/components/ErrorBoundary.tsx` → `artifacts/shopify-optimizer/src/components/ErrorBoundary.tsx`

### 3.2 Añadir endpoint backend
Copiar:
- `fixes/api-server/error-report.ts` → `artifacts/api-server/src/routes/error-report.ts`

Y registrar en `artifacts/api-server/src/routes/index.ts`:
```typescript
import errorReportRouter from "./error-report.js";
// ...
router.use(errorReportRouter);  // ANTES de router.use(requireAdmin)
```

### 3.3 (Opcional) Añadir prop `context` en App.tsx
En cada PageErrorBoundary:
```tsx
<PageErrorBoundary context="admin-billing"><Billing /></PageErrorBoundary>
```

---

## Fase 4 — Billing refactor (30 min)

### 4.1 Reemplazar el archivo
```bash
cp fixes/pages/Billing.tsx artifacts/shopify-optimizer/src/pages/admin/Billing.tsx
```

Este archivo ya viene con:
- FE-9 loading skeleton + error states
- FE-13 react-query con invalidation
- FE-17 responsive mobile-first
- FE-5 usa apiJson
- Preparado para Shopify Billing real (confirmationUrl/checkoutUrl)

### 4.2 Verificar
```bash
pnpm typecheck
pnpm dev
# Abrir /admin/billing — debe verse igual pero con skeletons en carga
```

---

## Fase 5 — Drafts seguros (15 min)

### 5.1 Reemplazar el hook
```bash
cp fixes/hooks/use-draft-persistence.ts artifacts/shopify-optimizer/src/hooks/use-draft-persistence.ts
```

Esto es compatible hacia atrás — el nuevo `omitFields` es opcional.

### 5.2 (Opcional) Si añades drafts a NewProject.tsx
```typescript
import { useDraftPersistence } from "@/hooks/use-draft-persistence";
// ...
useDraftPersistence("new-project-draft", formData, setFormData, {
  omitFields: ["accessToken", "apiPassword", "clientSecret", "clientId"],
});
```

---

## Fase 6 — OmniChatbot multi-action (45 min)

Aplicar PATCH #5 del archivo `patches/PATCHES.md`:
- **FE-8** timeout categorizado (LONG_RUNNING_ACTIONS)
- **FE-16** límite MAX_ACTIONS_PER_TURN + confirmación destructiva
- **FE-20** anunciar acciones detectadas

Son 2 bloques dentro de `src/components/OmniChatbot.tsx`.

Tras aplicar, testear manualmente:
- Preguntar al chatbot "borra el producto XYZ" → debe decir "Confirmación requerida"
- Preguntar "lista mis productos" → debe ejecutar sin fricción
- Preguntar "optimiza todos los productos de la tienda" → debe dar 15 min de timeout

---

## Fase 7 — Guards admin (5 min)

Aplicar PATCH #4 del archivo `patches/PATCHES.md`:
- Cambiar `src/App.tsx:135` de `Redirect to="/"` a `Redirect to="/admin/clients"`.

---

## Fase 8 — Capacitor / Android (1 h)

### 8.1 Reemplazar config
```bash
cp fixes/android/capacitor.config.ts artifacts/shopify-optimizer/capacitor.config.ts
cp fixes/android/AndroidManifest.xml artifacts/shopify-optimizer/android/app/src/main/AndroidManifest.xml
```

### 8.2 Crear los archivos de recursos que referencia el manifest
```bash
# Crear res/xml/network_security_config.xml y res/xml/data_extraction_rules.xml
# Contenido en el comentario final de AndroidManifest.xml
```

### 8.3 Instalar plugins Capacitor opcionales
```bash
# Solo si vas a usar push notifications:
pnpm add @capacitor/push-notifications --filter @workspace/shopify-optimizer

# Solo si quieres barras laterales ajustadas:
pnpm add @capacitor/status-bar @capacitor/keyboard --filter @workspace/shopify-optimizer
```

### 8.4 Sync y build
```bash
cd artifacts/shopify-optimizer
pnpm build
npx cap sync android
cd android
./gradlew assembleDebug
```

### 8.5 Para deep links: hostear assetlinks.json
Generar SHA-256 del keystore y subir a `https://shopycrafter.com/.well-known/assetlinks.json`. Ver instrucciones en `fixes/android/AndroidManifest.xml` (comentario final).

---

## Fase 9 — Mobile responsive (2-3 h) — POR HACER A MANO

**Es trabajo manual de revisión visual.** El patch automático no cubre esto porque son decisiones de diseño.

Abrir en Chrome DevTools modo iPhone 12 (390x844) cada una:

- `src/pages/admin/Billing.tsx` → **ya arreglado** por el reemplazo del Fase 4
- `src/pages/admin/CMSEditor.tsx` → revisar que el iframe + sidebar no se solapen
- `src/pages/admin/ShopyBrain.tsx` → revisar que las cards quepan
- `src/pages/NewProject.tsx` → revisar que el form wizard sea usable
- `src/pages/admin/AdminClients.tsx` → revisar tabla con scroll horizontal

Patrón Tailwind a aplicar donde falten breakpoints:
```jsx
// ANTES (nada responsive)
<div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)" }}>

// DESPUÉS (mobile-first con breakpoints)
<div style={{
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(min(240px, 100%), 1fr))",
  gap: 16,
}}>
```

---

## Checklist final — antes de merge a main

- [ ] `pnpm typecheck` pasa sin errores
- [ ] `pnpm build` genera un bundle sin warnings nuevos
- [ ] Login/logout funciona
- [ ] /admin/billing se ve con skeletons y se cargan los datos
- [ ] OmniChatbot responde a "lista mis productos"
- [ ] OmniChatbot bloquea "borra el producto X"
- [ ] Las 3 páginas del redesign con HTML muestran el contenido (no quedan vacías por un parsing excesivamente restrictivo de DOMPurify)
- [ ] Si forzaste un error en DEV, ErrorBoundary muestra el stack
- [ ] Si forzaste un error en producción, llega al log del backend (ver `logs` de Replit)

---

## Hallazgos NO cubiertos por este paquete

Estos requieren trabajo de más alcance y los dejo para un Bloque C posterior:

| # | Por qué no se incluye |
|---|---|
| FE-14 OmniChatbot 2142 líneas | Refactor grande (partir en 6 módulos). Genero archivos en siguiente iteración si lo pides. |
| FE-19 93 cases formatActionResult | Depende de que el backend devuelva `result.message` consistente para todas las acciones — tocar allí primero. |
| FE-13 migrar AdminClients, ShopyBrainInsights, UniversalSearch a react-query | Misma plantilla que Billing. Puedes replicar tú o generarla yo en otra iteración. |
| Mobile responsive de las 4 páginas restantes | Trabajo manual de diseño — ver Fase 9. |

---

## Si algo falla

**ErrorBoundary nuevo no compila:** revisa que `import { API_BASE } from "@/lib/api";` está presente.

**DOMPurify rompe el render:** abre la consola — probablemente el CSS-in-JS de `prose prose-invert` depende de `style` inline que DOMPurify quita. Puedes permitir `style` en `HTML_CONFIG.ALLOWED_ATTR` en `sanitize.ts`, pero con moderación.

**react-query no invalida:** verifica que `<QueryClientProvider>` envuelve el tree en `App.tsx` — ya lo hace, pero verifica el path.

**typecheck falla con "Cannot find module '@/lib/sanitize'":** revisar `tsconfig.json` que el alias `@/` apunta a `src/`.

---

**Fin de la guía.** Si sigues el orden 1→8, en 4-6 h tienes 14 hallazgos cerrados (todos los críticos + altos + la mayoría de medios).
