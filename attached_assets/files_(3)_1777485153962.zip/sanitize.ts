/**
 * Sanitización HTML/SVG centralizada con DOMPurify.
 *
 * Uso:
 *   import { cleanHtml, cleanSvg } from "@/lib/sanitize";
 *
 *   <div dangerouslySetInnerHTML={{ __html: cleanHtml(untrustedHtml) }} />
 *   <div dangerouslySetInnerHTML={{ __html: cleanSvg(untrustedSvg) }} />
 *
 * INSTALACIÓN:
 *   pnpm add dompurify --filter @workspace/shopify-optimizer
 *   pnpm add -D @types/dompurify --filter @workspace/shopify-optimizer
 *
 * Por qué NO basta con un regex:
 *   - HTML puede ocultar JS en SVG embebido, CSS `expression()`, `<style>@import url(...)`,
 *     `<meta http-equiv="refresh">`, data: URLs en iframe, etc.
 *   - Regex son frágiles. DOMPurify usa el parser real del navegador.
 */

import DOMPurify from "dompurify";

// ─── HTML — contenido rich-text de blogs, product descriptions, emails ───────
const HTML_CONFIG: DOMPurify.Config = {
  ALLOWED_TAGS: [
    // Bloques
    "p", "div", "span", "br", "hr",
    "h1", "h2", "h3", "h4", "h5", "h6",
    "blockquote", "pre", "code",
    // Listas
    "ul", "ol", "li",
    // Inline
    "strong", "em", "u", "s", "b", "i", "mark", "small", "sub", "sup",
    // Tablas
    "table", "thead", "tbody", "tfoot", "tr", "td", "th", "caption",
    // Media (src se valida abajo)
    "a", "img",
    // Semánticos
    "article", "section", "aside", "header", "footer", "nav", "figure", "figcaption",
  ],
  ALLOWED_ATTR: [
    "href", "src", "alt", "title", "class", "id",
    "rel", "target",
    "width", "height",
    "colspan", "rowspan",
    "data-*",  // permitido para data-cms-path y similares
  ],
  FORBID_TAGS: ["script", "style", "iframe", "object", "embed", "form",
    "input", "textarea", "button", "select", "meta", "link"],
  FORBID_ATTR: ["onerror", "onload", "onclick", "onmouseover", "onfocus",
    "onblur", "onchange", "onsubmit", "onkeydown", "onkeypress", "onkeyup",
    "style"],  // style inline bloqueado — evita CSS-based XSS
  ALLOW_DATA_ATTR: true,
  // No permitir data: URLs (evita data:text/html,<script>)
  ALLOWED_URI_REGEXP: /^(?:(?:https?|mailto|tel):|\/|#|\?)/i,
};

export function cleanHtml(raw: string | null | undefined): string {
  if (!raw) return "";
  const clean = DOMPurify.sanitize(String(raw), HTML_CONFIG);
  // Forzar target="_blank" rel="noopener noreferrer" en <a>
  return clean.replace(/<a\s+([^>]*)>/gi, (match, attrs) => {
    let out = attrs as string;
    if (!/\btarget\s*=/i.test(out)) out = `${out.trim()} target="_blank"`;
    if (!/\brel\s*=/i.test(out)) out = `${out.trim()} rel="noopener noreferrer"`;
    else if (!/noopener/i.test(out)) out = out.replace(/\brel\s*=\s*["']([^"']*)["']/i,
      (_m, r) => `rel="${r} noopener noreferrer"`);
    return `<a ${out}>`;
  });
}

// ─── SVG — para logos, iconos generados por IA, brand assets ─────────────────
const SVG_CONFIG: DOMPurify.Config = {
  USE_PROFILES: { svg: true, svgFilters: true },
  FORBID_TAGS: ["script", "foreignObject"],
  FORBID_ATTR: ["onerror", "onload", "onclick", "onmouseover", "onfocus", "onblur"],
};

export function cleanSvg(raw: string | null | undefined): string {
  if (!raw) return "";
  return DOMPurify.sanitize(String(raw), SVG_CONFIG);
}

// ─── Texto plano — para mostrar markdown-like sin HTML ───────────────────────
/**
 * Convierte *bold* y **bold** y `code` a HTML seguro. Para chat messages simples.
 * El resultado pasa por cleanHtml — imposible inyectar HTML.
 */
export function cleanMarkdownLite(raw: string | null | undefined): string {
  if (!raw) return "";
  const text = String(raw)
    // escape HTML primero
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    // luego aplicar formatting
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\n/g, "<br/>");
  return cleanHtml(text);
}
