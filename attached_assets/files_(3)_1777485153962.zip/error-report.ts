/**
 * FIX FE-18: endpoint thin para recibir reportes de error del frontend.
 *
 * UBICACIÓN: artifacts/api-server/src/routes/health.ts
 * (añadir al final del archivo, antes del export)
 *
 * Alternativamente crear un archivo dedicado routes/error-report.ts.
 *
 * LIMIT: rate limit aplicado (reutiliza apiLimiter ya definido en app.ts).
 * LOG: usa el logger existente (pino/winston). Añade flag `frontend:true`.
 */

import { Router } from "express";
import { logger } from "../lib/logger.js";  // ajustar si logger está en otra ruta

const router: Router = Router();

// Payload esperado — del ErrorBoundary del frontend.
interface ErrorReportBody {
  reportId?: string;
  context?: string;
  name?: string;
  message?: string;
  stack?: string;
  componentStack?: string;
  url?: string;
  userAgent?: string;
  timestamp?: string;
}

// Rate-limit simple en memoria: max 30 reports/minuto por IP (dedup secundaria).
const recentReports = new Map<string, number[]>();
const REPORT_WINDOW_MS = 60_000;
const MAX_REPORTS_PER_WINDOW = 30;

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const arr = (recentReports.get(ip) ?? []).filter(t => now - t < REPORT_WINDOW_MS);
  if (arr.length >= MAX_REPORTS_PER_WINDOW) {
    recentReports.set(ip, arr);
    return true;
  }
  arr.push(now);
  recentReports.set(ip, arr);
  return false;
}

/**
 * POST /api/error-report
 *
 * NO requiere auth — el frontend reporta incluso si la sesión expiró.
 * Limitado por IP + tamaño del body.
 */
router.post("/error-report", async (req, res): Promise<void> => {
  try {
    const ip = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim()
            || req.socket?.remoteAddress
            || "unknown";

    if (isRateLimited(ip)) {
      res.status(429).json({ error: "rate_limited" });
      return;
    }

    const body = (req.body ?? {}) as ErrorReportBody;

    // Sanitizar tamaños — evita log spam
    const sanitized = {
      reportId: String(body.reportId ?? "").slice(0, 64),
      context: String(body.context ?? "unknown").slice(0, 64),
      name: String(body.name ?? "Error").slice(0, 64),
      message: String(body.message ?? "").slice(0, 500),
      stack: String(body.stack ?? "").slice(0, 4000),
      componentStack: String(body.componentStack ?? "").slice(0, 2000),
      url: String(body.url ?? "").slice(0, 500),
      userAgent: String(body.userAgent ?? "").slice(0, 200),
      timestamp: String(body.timestamp ?? new Date().toISOString()).slice(0, 32),
      ip,
    };

    // Log estructurado — los errores del frontend quedan en el mismo stream que el backend
    logger.error({ frontend: true, ...sanitized }, "Frontend error reported");

    res.json({ ok: true, reportId: sanitized.reportId });
  } catch (err) {
    logger.error({ err }, "Failed to record frontend error report");
    // NUNCA fallar este endpoint — daría un loop (error frontend → POST → 500 → error frontend)
    res.status(200).json({ ok: false });
  }
});

export default router;

/*
═══════════════════════════════════════════════════════════════════════════════
REGISTRO EN routes/index.ts
═══════════════════════════════════════════════════════════════════════════════

Añadir al inicio de routes/index.ts:

  import errorReportRouter from "./error-report.js";

Añadir ANTES del `router.use(requireAdmin)`:

  router.use(errorReportRouter);

═══════════════════════════════════════════════════════════════════════════════
BODY SIZE LIMIT
═══════════════════════════════════════════════════════════════════════════════

En app.ts asegúrate de tener (si no lo tienes ya):

  app.use(express.json({ limit: "100kb" }));

100kb es más que suficiente para un stack trace — evita payloads abusivos.
═══════════════════════════════════════════════════════════════════════════════
*/
