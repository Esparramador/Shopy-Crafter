import type { CapacitorConfig } from "@capacitor/cli";

/**
 * FIXES aplicados:
 * - FE-7: App scheme personalizado + deep links.
 * - Dev hot-reload opcional con CAPACITOR_DEV_SERVER.
 * - Soporte offline mínimo: si APP_URL es unreachable, carga dist/public local.
 * - Back button y volume keys configurados.
 */
const config: CapacitorConfig = {
  appId: "es.shopybrain.app",
  appName: "Shopy Crafter",
  webDir: "dist/public",

  server: {
    // En dev: CAPACITOR_DEV_SERVER=http://10.0.2.2:5173 (Android emulator)
    url: process.env.CAPACITOR_DEV_SERVER || process.env.APP_URL || "https://shopycrafter.com",
    cleartext: false,
    androidScheme: "https",
    // Permitir navegación a estos orígenes internos (auth redirects, Shopify OAuth).
    allowNavigation: [
      "shopycrafter.com",
      "*.shopycrafter.com",
      "*.myshopify.com",          // Shopify OAuth callbacks
      "accounts.shopify.com",     // Shopify auth
    ],
  },

  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: process.env.NODE_ENV !== "production",
    // Permite intents externos (Google Maps, tel:, mailto:) sin abrir browser.
    initialFocus: true,
  },

  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      launchAutoHide: true,
      backgroundColor: "#080810",
      androidSplashResourceName: "splash",
      androidScaleType: "CENTER_CROP",
      showSpinner: false,
      splashFullScreen: true,
      splashImmersive: true,
    },
    // FIX FE-11: StatusBar nativo, evita "notch" blanco en Android
    StatusBar: {
      backgroundColor: "#080810",
      style: "DARK",
      overlaysWebView: false,
    },
    // FIX FE-11: notificaciones push (opt-in, requiere permiso runtime)
    PushNotifications: {
      presentationOptions: ["badge", "sound", "alert"],
    },
    // FIX FE-11: keyboard accessory bar para UX mobile
    Keyboard: {
      resize: "body",
      style: "DARK",
      resizeOnFullScreen: true,
    },
  },
};

export default config;
