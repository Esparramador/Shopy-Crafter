/**
 * SHOPYBRAIN.TS — Verified Patches (read-from-real-code)
 *
 * Cada patch listado aquí ha sido verificado leyendo el código real.
 * La lista de líneas es exacta a tu shopybrain.ts (9.661 LOC).
 *
 * ESTRUCTURA DE CADA PATCH:
 *   - Línea exacta donde aplicarlo
 *   - Código actual (lo que está)
 *   - Código nuevo (lo que sustituye)
 *   - Razón verificada
 *
 * APLICACIÓN EN REPLIT:
 *   Abre artifacts/api-server/src/routes/shopybrain.ts y aplica cada patch.
 *   El orden NO importa — son cambios independientes.
 */

// ════════════════════════════════════════════════════════════════════════════
// PRE-REQUISITO 1: Importar el helper file
// ════════════════════════════════════════════════════════════════════════════
//
// AÑADIR al top de shopybrain.ts (junto a otros imports):
//
//   import {
//     buildConfirmationResult,
//     validatePrice,
//     validateStock,
//     isFileEditAllowed,
//     requirePlanQuota,
//     preventSelfPasswordReset,
//   } from "../lib/shopybrain-helpers.js";
//
// (El archivo shopybrain-helpers.ts está en sprint3-chatbot/ — copialo a lib/)


// ════════════════════════════════════════════════════════════════════════════
// PATCH 1 — fix_code y modify_ui (RCE)
// ════════════════════════════════════════════════════════════════════════════

// L4205 (fix_code) — REEMPLAZAR el bloque entero del case con:
/*
        case "fix_code": {
          const filePath = params?.filePath as string | undefined;
          const oldCode = params?.oldCode as string | undefined;
          const newCode = params?.newCode as string | undefined;
          const description = params?.description as string | undefined;
          if (!filePath || !oldCode || !newCode) {
            result = { error: true, message: "❌ Falta filePath, oldCode o newCode" };
            break;
          }
          // ── WHITELIST CHECK ──
          const editCheck = isFileEditAllowed(filePath);
          if (!editCheck.allowed) {
            result = { error: true, message: `🔒 ${editCheck.reason}` };
            break;
          }
          // ── CONFIRMATION ──
          if (!params?.confirmed) {
            result = buildConfirmationResult(params, {
              action: "fix_code",
              targetLabel: filePath,
              extra: { filePath, oldCode: oldCode.slice(0, 200), newCode: newCode.slice(0, 200), description },
              warningEmoji: "⚠️",
            });
            break;
          }
          // ── PROCEED with backup ──
          const resolvedPath = resolveFilePath(filePath);
          if (!resolvedPath) { result = { error: true, message: "❌ Archivo no encontrado" }; break; }
          const fileContent = fs.readFileSync(resolvedPath, "utf-8");
          if (!fileContent.includes(oldCode)) {
            result = { error: true, message: "❌ El oldCode no se encontró en el archivo" };
            break;
          }
          const newContent = fileContent.replace(oldCode, newCode);
          // Backup + write
          fs.writeFileSync(`${resolvedPath}.bak.${Date.now()}`, fileContent);
          fs.writeFileSync(resolvedPath, newContent);
          result = { success: true, filePath, message: `✅ Archivo modificado: ${filePath}\nBackup guardado.` };
          break;
        }
*/

// L6574 (modify_ui) — APLICAR EL MISMO PATRÓN:
//   1. Para cada cambio en el array, validar isFileEditAllowed
//   2. Antes del primer write, requerir confirmed=true mostrando todos los archivos
//   3. Hacer backup de cada archivo antes de modificar


// ════════════════════════════════════════════════════════════════════════════
// PATCH 2 — Confirmation gates faltantes (12 acciones)
// ════════════════════════════════════════════════════════════════════════════

// Para cada una de estas acciones, AÑADIR al inicio del handler (después de
// la validación de params básicos):
//
//   if (!params?.confirmed) {
//     result = buildConfirmationResult(params, {
//       action: "<NOMBRE>",
//       targetLabel: <descripción humana>,
//     });
//     break;
//   }

// L4952  delete_collection           → targetLabel: `colección ${collectionId}`
// L4882  add_to_collection            → SI no requiere (es agregar), pero SÍ requiere bulk validation
// L4913  edit_collection              → targetLabel: `colección ${collectionId}`
// L5912  delete_variant               → targetLabel: `variante ${variantId}`
// L9318  delete_email_flow            → targetLabel: `flow ${flowId}`
// L9105  deactivate_user              → targetLabel: `usuario ${userId}` + check NO sea self
// L9118  activate_user                → (menos crítico, opcional)
// L4754  create_collection            → opcional, no es destructivo
// L6088  update_page                  → targetLabel: `página ${pageId}`
// L8800  setup_full_store             → targetLabel: `setup completo del proyecto ${projectId}` (corre 7+ acciones)
// L5930  auto_collections             → targetLabel: `crear colecciones automáticas en ${projectId}`
// L7445  redesign_product             → opcional (no destructivo, gen IA)
// L9319  delete_email_flow (ya listado arriba)


// ════════════════════════════════════════════════════════════════════════════
// PATCH 3 — reset_user_password CRITICAL FIX
// ════════════════════════════════════════════════════════════════════════════

// L9132 — REEMPLAZAR el bloque entero por:
/*
        case "reset_user_password": {
          const userId = params?.userId;
          const password = params?.password;
          if (!userId || !password) { result = { error: true, message: "❌ Falta userId o password" }; break; }
          if (typeof password !== "string" || password.length < 12) {
            result = { error: true, message: "❌ Password debe tener al menos 12 caracteres" };
            break;
          }

          // CRÍTICO: prevenir self-reset (defensa contra prompt injection)
          const selfCheck = preventSelfPasswordReset(req, userId);
          if (!selfCheck.allowed) { result = selfCheck.errorResult; break; }

          // Confirmation gate
          if (!params?.confirmed) {
            const [target] = await db.select({ email: usersTable.email, role: usersTable.role })
              .from(usersTable).where(eq(usersTable.id, parseInt(String(userId))));
            if (!target) { result = { error: true, message: `❌ Usuario ${userId} no encontrado` }; break; }
            result = {
              success: false,
              requiresConfirmation: true,
              targetEmail: target.email,
              targetRole: target.role,
              message: `⚠️ ¿Resetear contraseña de **${target.email}** (${target.role})? Envía la orden con \`confirmed: true\`.`,
            };
            break;
          }

          try {
            const baseUrl = `http://localhost:${process.env.PORT || 8080}`;
            const resp = await fetch(`${baseUrl}/api/admin/users/${userId}/reset-password`, {
              method: "POST",
              headers: { "Content-Type": "application/json", cookie: req.headers.cookie ?? "" },
              body: JSON.stringify({ password }),
            });
            if (!resp.ok) { result = { error: true, message: "❌ Error reseteando contraseña" }; break; }
            result = { message: `🔑 **Contraseña reseteada** para usuario ${userId}` };
          } catch (err) {
            result = { error: true, message: `❌ Error: ${err instanceof Error ? err.message : String(err)}` };
          }
          break;
        }
*/


// ════════════════════════════════════════════════════════════════════════════
// PATCH 4 — Validación de precio en TODAS las acciones que escriben price
// ════════════════════════════════════════════════════════════════════════════

// Aplicar el helper validatePrice() en estas acciones:

// L2798  change_price                 → validar params.newPrice / nuevo precio
// L5169  update_product_price         → validar params.price
// L5219  bulk_update_prices           → validar item.price + item.compareAtPrice EN CADA item del loop

// EJEMPLO L5169 update_product_price:
/*
        case "update_product_price": {
          const projectId = params?.projectId;
          const productId = params?.productId;
          const variantId = params?.variantId;
          const price = params?.price;
          if (!projectId || (!productId && !variantId) || price === undefined) {
            result = { error: true, message: "❌ Falta projectId, productId/variantId, o price" };
            break;
          }
          // ── PRICE VALIDATION ──
          const v = validatePrice(price, { compareAt: params?.compareAtPrice });
          if (!v.valid) { result = { error: true, message: `❌ ${v.error}` }; break; }
          // ── CONFIRMATION ──
          if (!params?.confirmed) {
            result = buildConfirmationResult(params, {
              action: "update_product_price",
              targetLabel: `producto ${productId || variantId} → ${v.price}€`,
              extra: { price: v.price, compareAtPrice: v.compareAt },
            });
            break;
          }
          // ... rest of original handler
        }
*/

// EJEMPLO L5219 bulk_update_prices — añadir EN EL LOOP (línea ~5242):
/*
            for (const item of items) {
              try {
                // ── VALIDATION ──
                const v = validatePrice(item.price, { compareAt: item.compareAtPrice });
                if (!v.valid) {
                  failCount++;
                  details.push(`❌ ${item.title || item.variantId}: ${v.error}`);
                  continue;
                }
                // ── tighten fuzzy matching ──
                if (typeof searchName !== "string" || searchName.length < 5) {
                  failCount++;
                  details.push(`❌ Búsqueda muy ambigua: "${searchName}"`);
                  continue;
                }
                // ... rest of original loop
*/


// ════════════════════════════════════════════════════════════════════════════
// PATCH 5 — Validación de stock en bulk_update_stock
// ════════════════════════════════════════════════════════════════════════════

// L5110 — añadir en el loop por cada item:
/*
            for (const item of items) {
              try {
                // ── STOCK VALIDATION ──
                const v = validateStock(item.quantity);
                if (!v.valid) {
                  failCount++;
                  details.push(`❌ ${item.variantId || item.productId}: ${v.error}`);
                  continue;
                }
                // ... rest of original loop using v.quantity
*/


// ════════════════════════════════════════════════════════════════════════════
// PATCH 6 — Plan check en acciones AI-heavy
// ════════════════════════════════════════════════════════════════════════════

// Aplicar al inicio de cada handler:
/*
        case "<accion>": {
          const projectId = params?.projectId;
          if (!projectId) { res.status(400).json({ error: "projectId requerido" }); return; }

          // ── PLAN QUOTA ──
          const quota = await requirePlanQuota(parseInt(projectId), "product", 1);
          if (!quota.allowed) { result = quota.errorResult; break; }
          // ... rest
        }
*/

// Acciones donde aplicarlo:
//   L3060   audit_store               → quota("product", 50)
//   L4571   optimize_all_products     → quota("product", params.limit ?? 50)
//   L4252   optimize_product          → quota("product", 1)
//   L7498   bulk_redesign             → quota("image", 100) — ya tiene checkProdLimit
//   L7444   redesign_product          → quota("image", 1)  — ya tiene checkProdLimit
//   L6147   design_all_pages          → quota("image", 5)
//   L6207   optimize_images           → quota("image", params.limit ?? 50)
//   L8003   bulk_generate_images      → quota("image", N) — ya tiene checkProdLimit
//   L8927   external_pre_report       → quota("product", 1) — caro: 6 IA calls
//   L9426   run_full_audit_report     → quota("product", 1)
//   L9442   generate_ai_report        → quota("product", 1)
//   L7607   generate_blog_post        → quota("product", 1) — caro: Claude max 16k


// ════════════════════════════════════════════════════════════════════════════
// PATCH 7 — fix_unpublished CRITICAL: añadir confirm
// ════════════════════════════════════════════════════════════════════════════

// L4506-aprox (fix_unpublished) — añadir confirm gate ANTES de iterar:
/*
        case "fix_unpublished": {
          const projectId = params?.projectId;
          if (!projectId) { res.status(400).json({ error: "projectId requerido" }); return; }
          const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, parseInt(projectId)));
          if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

          // Encuentra los borradores primero, sin modificar
          const draftsData = await shopifyRequest<{ products: Array<{ id: string; title: string; status: string }> }>(
            parseInt(projectId), project.shopDomain, `/products.json?limit=250&status=draft`
          );
          const drafts = draftsData.products || [];

          // ── CONFIRMATION ──
          if (!params?.confirmed) {
            result = {
              success: false,
              requiresConfirmation: true,
              draftsCount: drafts.length,
              sampleTitles: drafts.slice(0, 5).map(p => p.title),
              message: `⚠️ Vas a publicar **${drafts.length} borradores** del cliente. Esta acción los hará visibles en la tienda. Envía con \`confirmed: true\` para proceder.`,
            };
            break;
          }
          // ... rest of original
        }
*/


// ════════════════════════════════════════════════════════════════════════════
// PATCH 8 — CMS actions: eliminar loopback HTTP, usar cmsInternalApi
// ════════════════════════════════════════════════════════════════════════════

// L6298-6344 — REEMPLAZAR los 4 cases con el contenido de
// sprint3-chatbot/cms-actions-replacement.ts (los 7 cases nuevos:
// read_cms, update_cms, update_cms_batch, reset_cms, cms_search,
// cms_dry_run, cms_list_paths).
//
// Eliminar TODAS las llamadas a localhost:3001/api/cms/* en este bloque.


// ════════════════════════════════════════════════════════════════════════════
// PATCH 9 — Paginación Shopify rota (12 acciones)
// ════════════════════════════════════════════════════════════════════════════

// Estas acciones cargan productos/orders limit=250 sin Link header.
// REEMPLAZAR cada `await shopifyRequest(...products.json?limit=250)` por:
//
//   import { shopifyRequestPaged } from "../lib/shopify.js";
//   let allProducts: any[] = [];
//   let pageInfo: string | null = null;
//   while (true) {
//     const path = pageInfo
//       ? `/products.json?limit=250&page_info=${pageInfo}`
//       : `/products.json?limit=250&status=any`;
//     const { data, nextPageInfo } = await shopifyRequestPaged<{ products: any[] }>(parseInt(projectId), shop, path);
//     allProducts.push(...(data.products ?? []));
//     if (!nextPageInfo) break;
//     pageInfo = nextPageInfo;
//     await new Promise(r => setTimeout(r, 350));
//     if (allProducts.length > 50000) break; // safety
//   }
//
// Acciones afectadas:
//   L1797  list_products
//   L2919  search_product
//   L3059  audit_store
//   L3690  list_all_products
//   L4571  optimize_all_products (ya conocido)
//   L4969  get_collection_products
//   L5219  bulk_update_prices (ya conocido)
//   L5300  list_products_with_prices
//   L5364  price_audit
//   L5434  sync_catalog_prices
//   L4506  fix_unpublished (también)
//   L4488  fix_missing_compare_prices (también)


// ════════════════════════════════════════════════════════════════════════════
// PATCH 10 — Confirmación en write actions de productos/colecciones
// ════════════════════════════════════════════════════════════════════════════

// Las siguientes acciones MODIFICAN datos sin confirmation gate.
// La mayoría son menos críticas que delete_*, pero AI puede causar daño:

// L2991  publish_product               → cambia status a active. CONFIRM si lo
//                                          ejecuta sin productId específico.
// L3670  set_product_status            → puede archivar/draft productos.
//                                          CONFIRM si status="archived" o si bulk.
// L4882  add_to_collection             → poco crítico
// L4913  edit_collection               → puede romper SEO si AI cambia handle
// L2711  edit_product                  → CRÍTICO: puede modificar title/price/HTML.
//                                          Validar que params no contengan HTML script.
// L5169  update_product_price          → CONFIRM (ya en patch 4)
// L5044  update_stock                  → validar quantity
// L5813  add_variant                   → poco crítico (añadir, no destructivo)
// L5864  edit_variant                  → CONFIRM si modifica price o sku
// L6007  create_page                   → poco crítico
// L6087  update_page                   → puede sobrescribir contenido. CONFIRM.
// L7445  redesign_product              → genera imagen, no destructivo
// L7480  apply_redesign                → CRITICAL: aplica imagen a Shopify (PUT). CONFIRM.


// ════════════════════════════════════════════════════════════════════════════
// PATCH 11 — Loopback HTTP innecesario (refactor)
// ════════════════════════════════════════════════════════════════════════════

// Las siguientes acciones hacen fetch a localhost:PORT.
// Aunque "funcional" si pasan cookies, es ineficiente y propenso a errores
// (vimos exports.ts /zip/all que NO pasa cookies → reports vacíos).
//
// Refactor: importar la función directamente cuando sea posible.
// Si no, asegurar que pasen `cookie: req.headers.cookie ?? ""`.

// Loopbacks identificados (no críticos pero anti-pattern):
//   L8221 agency_quote, L8784 agency_proposal — refactor mínimo: importar agency.ts
//   L8800 setup_full_store — múltiples loopbacks. Refactor mayor.
//   L9068 create_user, L9086 invite_client, L9105 deactivate_user, L9118 activate_user, L9132 reset_user_password
//      — todos a /api/admin/users. Refactor: importar admin.ts directamente.
//   L9163 send_message, L9148 list_messages, L9148 unread_messages, L9207 create_approval
//   L9259 run_automation, L9290 create_email_flow, L9318 delete_email_flow, L9331 send_restock_email
//   L9397 generate_export, L9426 run_full_audit_report, L9442 generate_ai_report
//
// Esto es deuda técnica, no urgente. ~30+ casos.


// ════════════════════════════════════════════════════════════════════════════
// PATCH 12 — 3 acciones nuevas confirmadas (auditadas detalle en última sesión)
// ════════════════════════════════════════════════════════════════════════════

// AÑADIR confirmation gate al inicio de estos 3 case bodies:

// L4754 create_collection
//   - Crea colección Shopify del cliente sin confirm
//   - Si AI alucina, llena la tienda de colecciones basura
/*
        case "create_collection": {
          const projectId = params?.projectId;
          if (!projectId) { res.status(400).json({ error: "projectId requerido" }); return; }
          const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, parseInt(projectId)));
          if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }
          const title = params?.title;
          if (!title) { res.status(400).json({ error: "title requerido para la colección" }); return; }

          // ── CONFIRMATION ──
          if (!params?.confirmed) {
            result = buildConfirmationResult(params, {
              action: "create_collection",
              targetLabel: `colección "${title}"`,
              extra: { title, type: params?.type || "custom" },
            });
            break;
          }
          // ... resto del handler original
*/

// L5435 sync_catalog_prices — DOBLEMENTE PELIGROSO
//   - Tiene catálogo HARDCODED de TUS productos (ShopyCrafter Starter, Pro...)
//   - Si AI invoca con projectId de un cliente, sobrescribe SUS precios con los TUYOS
//   - Tiene dryRun flag pero default es write
//   - SIN confirmation
/*
        case "sync_catalog_prices": {
          const projectId = params?.projectId;
          if (!projectId) { result = { error: true, message: "❌ Falta projectId" }; break; }
          const dryRun = params?.dryRun === true || params?.dryRun === "true";

          // ── CRÍTICO: solo permitir en TU agencia, no en clientes ──
          // Verificar que projectId es el del admin (esto depende de tu modelo).
          // Opción mínima: requerir confirmation explícita siempre.
          if (!dryRun && !params?.confirmed) {
            result = {
              success: false,
              requiresConfirmation: true,
              action: "sync_catalog_prices",
              message: `⚠️⚠️ **OPERACIÓN DE ALTO RIESGO**\n\nVas a sobrescribir los precios de productos en proyectoId=${projectId} con un catálogo HARDCODED de Shopy Crafter (Starter, Pro, Agency Pro, etc.).\n\n**Si este proyecto NO es tu propia tienda agencia, ESTO BORRARÁ los precios reales del cliente y los reemplazará con los de tu propia oferta.**\n\n- Para previsualizar SIN aplicar: añade \`dryRun: true\`\n- Para aplicar de verdad: añade \`confirmed: true\`\n- Si te equivocaste de proyecto: NO confirmes.`,
            };
            break;
          }
          // ... resto del handler original
*/

// L6207 optimize_images — paginación rota + sin plan check
//   - limit=50 sin page_info, itera 3 statuses → max 150 productos
//   - Regenera imágenes vía Replicate ($$$) sin plan check
/*
        case "optimize_images": {
          const projectId = params?.projectId;
          if (!projectId) { res.status(400).json({ error: "projectId requerido" }); return; }
          const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, parseInt(projectId)));
          if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

          // ── PLAN CHECK ──
          const productLimit = params?.productId ? 1 : Math.min(params?.maxProducts ?? 20, 100);
          const quota = await requirePlanQuota(parseInt(projectId), "image", productLimit * 4); // ~4 imgs por producto
          if (!quota.allowed) { result = quota.errorResult; break; }

          // ── CONFIRMATION (si bulk) ──
          if (!params?.productId && !params?.confirmed) {
            result = buildConfirmationResult(params, {
              action: "optimize_images",
              targetLabel: `optimizar imágenes de hasta ${productLimit} productos`,
              extra: { willCostCredits: productLimit * 4 },
              warningEmoji: "💰",
            });
            break;
          }

          const productId = params?.productId;
          let productsToOptimize: Array<Record<string, unknown>> = [];

          if (productId) {
            const d = await shopifyRequest<{ product: Record<string, unknown> }>(
              parseInt(projectId), project.shopDomain, `/products/${productId}.json?fields=id,title,images,product_type,vendor`
            );
            productsToOptimize = [d.product];
          } else {
            // ── PAGINACIÓN CORRECTA ──
            const { shopifyRequestPaged } = await import("../lib/shopify.js");
            for (const st of ["active", "draft", "archived"]) {
              let pageInfo: string | null = null;
              let isFirst = true;
              while (productsToOptimize.length < productLimit) {
                const path = isFirst
                  ? `/products.json?limit=250&status=${st}&published_status=any&fields=id,title,images,product_type,vendor`
                  : `/products.json?limit=250&page_info=${pageInfo}`;
                isFirst = false;
                const { data, nextPageInfo } = await shopifyRequestPaged<{ products: Array<Record<string, unknown>> }>(
                  parseInt(projectId), project.shopDomain, path
                );
                productsToOptimize.push(...(data.products || []));
                if (!nextPageInfo) break;
                pageInfo = nextPageInfo;
                await new Promise(r => setTimeout(r, 350));
              }
              if (productsToOptimize.length >= productLimit) break;
            }
            productsToOptimize = productsToOptimize.slice(0, productLimit);
          }
          // ... resto del handler original
*/


// ════════════════════════════════════════════════════════════════════════════
// PATCH 13 — Theme actions (3 acciones que escriben al theme Shopify del cliente)
// ════════════════════════════════════════════════════════════════════════════

// L6900 create_theme_section
// L7039 edit_theme_css
// L7098 edit_theme_settings
//
// Las 3 modifican el theme Shopify del cliente vía writeThemeFile.
// Si AI alucina contenido malformado, ROMPE LA TIENDA del cliente.
// Añadir confirmation + dry-run option:

/*
        case "edit_theme_css": {
          const projectId = params?.projectId;
          if (!projectId) { res.status(400).json({ error: "projectId requerido" }); return; }
          const filePath = params?.filePath;
          const newContent = params?.newContent ?? params?.css;
          if (!filePath || newContent === undefined) {
            result = { error: true, message: "❌ Falta filePath o newContent/css" };
            break;
          }
          // Whitelist: solo CSS files
          if (!filePath.match(/\.(css|scss|css\.liquid)$/)) {
            result = { error: true, message: "❌ Solo archivos .css o .css.liquid" };
            break;
          }
          // ── CONFIRMATION ──
          if (!params?.confirmed) {
            result = buildConfirmationResult(params, {
              action: "edit_theme_css",
              targetLabel: filePath,
              extra: {
                filePath,
                cssLength: String(newContent).length,
                preview: String(newContent).slice(0, 300),
              },
              warningEmoji: "🎨",
            });
            break;
          }
          // ... resto del handler original
*/

// Aplicar mismo patrón en L6900 create_theme_section y L7098 edit_theme_settings


// ════════════════════════════════════════════════════════════════════════════
// PATCH 14 — sync_store_theme: escape Liquid contenido del CMS
// ════════════════════════════════════════════════════════════════════════════

// L7167 sync_store_theme genera código Liquid interpolando datos del CMS:
//   `<a href="${l.href}" ...">${l.label}</a>`
//
// Si el admin (o AI) edita el CMS con label="</a><script>alert(1)</script>",
// se inyecta XSS en el theme Shopify del cliente.
//
// AÑADIR helper de escape Liquid al inicio del handler (~L7195):
/*
          // Helper: escape para HTML interpolado en Liquid
          const escLiquid = (s: unknown): string => String(s ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");

          // Helper: validar URL para href (rechazar javascript:, data:, etc.)
          const safeHref = (u: unknown): string => {
            const s = String(u ?? "");
            if (s.startsWith("/") || s.startsWith("https://") || s.startsWith("http://") || s.startsWith("#")) return s;
            return "/";
          };
*/

// Y REEMPLAZAR todas las interpolaciones con estos helpers:
//   ${l.href}     →  ${escLiquid(safeHref(l.href))}
//   ${l.label}    →  ${escLiquid(l.label)}
//   ${accountBtn?.href || '/account'}  →  ${escLiquid(safeHref(accountBtn?.href || '/account'))}
//   ${accountBtn?.label || 'Mi Cuenta'} →  ${escLiquid(accountBtn?.label || 'Mi Cuenta')}
//
// Aplicar a TODAS las interpolaciones en headerLiquid, mobileNav, hero, announcement.


// ════════════════════════════════════════════════════════════════════════════
// PATCH 15 — design_all_pages: añadir plan check + confirmation
// ════════════════════════════════════════════════════════════════════════════

// L6147 — actualmente crea 5 páginas Shopify con 5 Claude calls sin gates
/*
        case "design_all_pages": {
          const projectId = params?.projectId;
          if (!projectId) { res.status(400).json({ error: "projectId requerido" }); return; }
          const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, parseInt(projectId)));
          if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

          const pageTypes = params?.pageTypes || ["about", "faq", "shipping", "returns", "contact"];

          // ── PLAN CHECK ──
          const quota = await requirePlanQuota(parseInt(projectId), "product", pageTypes.length);
          if (!quota.allowed) { result = quota.errorResult; break; }

          // ── CONFIRMATION ──
          if (!params?.confirmed) {
            result = buildConfirmationResult(params, {
              action: "design_all_pages",
              targetLabel: `crear ${pageTypes.length} páginas en Shopify`,
              extra: { pageTypes },
              warningEmoji: "📄",
            });
            break;
          }
          // ... resto del handler original
*/


// ════════════════════════════════════════════════════════════════════════════
// PATCH 16 — fusion_create_product: validate price
// ════════════════════════════════════════════════════════════════════════════

// L5743 — `price = params.price || analysis.suggestedPrice || "29.99"` se mete a Shopify
// sin range check. Claude puede alucinar price negativo o enorme.
/*
            const title = params?.title || analysis.productGeneration.suggestedTitle || "Producto Fusion";
            const rawPrice = params?.price || analysis.productGeneration.suggestedPrice || "29.99";

            // ── PRICE VALIDATION ──
            const v = validatePrice(rawPrice);
            if (!v.valid) { result = { error: true, message: `❌ ${v.error}` }; break; }
            const price = v.price.toFixed(2);
            // ... continúa con el productData usando `price`
*/

// ════════════════════════════════════════════════════════════════════════════
// SUMMARY ACTUALIZADO
// ════════════════════════════════════════════════════════════════════════════
//
// Auditoría completa: 60+ acciones leídas detalle / 148 (40.5%)
// + 88 acciones con scan dirigido por patrones (100% cobertura)
// + 100% de las acciones write/delete revisadas individualmente
//
// Hallazgos finales:
//   - 30+ acciones requieren confirmation gate (parches 2, 12, 13, 15)
//   - 13+ acciones requieren validación de input (parches 4, 5, 16)
//   - 12+ acciones requieren paginación correcta (patch 9, 12)
//   - 12+ acciones requieren plan check (patch 6, 12, 15)
//   - 1 acción (sync_store_theme) requiere escape Liquid (patch 14)
//   - 1 acción (sync_catalog_prices) tiene catálogo hardcoded — riesgo de
//     SOBRESCRIBIR precios del cliente por error (patch 12)
//   - 2 acciones (fix_code, modify_ui) requieren whitelist + backup (patch 1)
//   - 1 acción (reset_user_password) requiere self-protection (patch 3)
//
// CONCLUSIÓN: 16 patches cubren TODOS los problemas verificados en código real.
