# 🎯 PATCHES VERIFICADOS — Listos para aplicar en Replit

**Generado**: 28 abril 2026
**Verificación**: cada patch en este documento ha sido **leído del código real** del repo.
**Falsos positivos**: descartados con verificación manual.

---

## 📂 ARCHIVOS DE PATCHES (en orden de aplicación)

```
audit/
├── PATCHES_INDEX.md                                ← ESTE archivo (índice)
├── PLAN_ACCION_FINAL.md                            ← 33 fixes generales (P0/P1/P2)
├── sprint1-cms/
│   ├── cms.ts                                      ← REEMPLAZA routes/cms.ts
│   ├── CmsContext.tsx                              ← REEMPLAZA contexts/CmsContext.tsx
│   └── cms-defaults-MIGRATION.md                   ← Plan modular (manual)
├── sprint2-codemod/
│   ├── migrate-cms.mjs                             ← Script de migración (PROBADO)
│   └── README.md                                   ← Instrucciones de uso
├── sprint3-chatbot/
│   ├── shopybrain-helpers.ts                       ← COPIAR a artifacts/api-server/src/lib/
│   ├── shopybrain-VERIFIED-patches.ts              ← 11 patches específicos verificados
│   ├── exports-VERIFIED-patches.ts                 ← 6 patches verificados
│   └── cms-actions-replacement.ts                  ← Patches CMS para shopybrain (snippets)
└── conn/                                            ← Cruce BE↔FE (no requiere acción)
```

---

## 🚀 ORDEN DE APLICACIÓN EN REPLIT

### Fase 1 — Bugs críticos individuales (1 día — 4-6h)

#### Backend
1. **`projects.ts` HMAC DoS** (PLAN_ACCION_FINAL #2, L158)
   - Añadir check de longitud antes de `crypto.timingSafeEqual`
2. **`pricing.ts apply-price`** (PLAN_ACCION_FINAL #3, L495)
   - Validar precio con rango 0.01-1.000.000
3. **`intelligence.ts` paginación** (PLAN_ACCION_FINAL #1, L454-475)
   - Reemplazar paginación rota por `shopifyRequestPaged`
4. **`ab-testing.ts /track` fuera de requireAdmin** (PLAN_ACCION_FINAL #5)
   - Mover a un router público antes del `router.use(requireAdmin)`
5. **`ab-testing.ts` race condition counters** (PLAN_ACCION_FINAL #6, L470-486)
   - Usar `sql\`+ 1\`` atomic increment
6. **`projects.ts` oauthState a BD** (PLAN_ACCION_FINAL #9, L140)
   - Crear tabla `oauth_state`, migrar Map a SELECT/INSERT
7. **`pdf-generator.ts` Chromium hardcoded** (PLAN_ACCION_FINAL #10)
   - Variable de entorno `PUPPETEER_EXECUTABLE_PATH`

#### Frontend
8. **`Revenue.tsx:72` PATCH→PUT** (PLAN_ACCION_FINAL #33)
   - Cambiar `method: "PATCH"` por `method: "PUT"`

### Fase 2 — Sprint 3 helpers + shopybrain.ts patches (1-2 días — 6-9h)

9. **Copiar el archivo de helpers**:
   ```bash
   cp audit/sprint3-chatbot/shopybrain-helpers.ts \
      artifacts/api-server/src/lib/shopybrain-helpers.ts
   ```

10. **Aplicar los 11 patches verificados** (`audit/sprint3-chatbot/shopybrain-VERIFIED-patches.ts`):
    - PATCH 1: RCE fix_code/modify_ui (whitelist + confirm + backup)
    - PATCH 2: 12 confirmation gates faltantes
    - PATCH 3: reset_user_password fix crítico
    - PATCH 4: validatePrice en 3 acciones (change_price, update_product_price, bulk_update_prices)
    - PATCH 5: validateStock en bulk_update_stock + update_stock
    - PATCH 6: requirePlanQuota en 12 acciones AI-heavy
    - PATCH 7: fix_unpublished — confirm con conteo de borradores
    - PATCH 8: CMS actions sin loopback HTTP (usar cmsInternalApi)
    - PATCH 9: paginación Shopify uniforme (12 acciones afectadas)
    - PATCH 10: confirmation en write actions (publish, update_page, etc.)
    - PATCH 11: refactor loopbacks (deuda técnica, 4-6h)

### Fase 3 — exports.ts patches (1-2h)

11. **Aplicar los 6 patches verificados** (`audit/sprint3-chatbot/exports-VERIFIED-patches.ts`):
    - PATCH 1: Importar/definir `esc()` en financial section
    - PATCH 2: Sanitizar 7 interpolaciones unsafe en financial report (L734-764)
    - PATCH 3: Sanitizar shopybrain insights export (L4322)
    - PATCH 4: /zip/all añadir cookies en loopback (L4480)
    - PATCH 5: Chromium env var (lib/pdf-generator.ts)
    - PATCH 6: report-png — renombrar a report-pdf O implementar PNG real

### Fase 4 — CMS Universal Backend (1 día — 4-6h)

12. **Reemplazar `routes/cms.ts`**:
    ```bash
    cp audit/sprint1-cms/cms.ts artifacts/api-server/src/routes/cms.ts
    ```

13. **Reemplazar `contexts/CmsContext.tsx`**:
    ```bash
    cp audit/sprint1-cms/CmsContext.tsx artifacts/shopify-optimizer/src/contexts/CmsContext.tsx
    ```

14. **Modularizar `cms-defaults.ts`** (opcional — manual, ver MIGRATION.md)

15. **Añadir 7 acciones CMS al chatbot** (snippets en cms-actions-replacement.ts)

### Fase 5 — CMS Universal Frontend (codemod) (1-2 días — 6-10h)

16. **Instalar dependencias del codemod**:
    ```bash
    pnpm add -D @babel/parser @babel/traverse @babel/generator @babel/types
    ```

17. **Correr codemod en modo --dry primero** para revisar:
    ```bash
    node audit/sprint2-codemod/migrate-cms.mjs --dry \
      artifacts/shopify-optimizer/src/pages/admin/*.tsx
    ```
    
    Resultado esperado: aprox **1180 strings detectados** en 40 páginas no-CMS.

18. **Correr `--write` en lotes**:
    ```bash
    # Admin (top prioridad)
    node audit/sprint2-codemod/migrate-cms.mjs --write \
      artifacts/shopify-optimizer/src/pages/admin/*.tsx
    
    # Projects
    node audit/sprint2-codemod/migrate-cms.mjs --write \
      artifacts/shopify-optimizer/src/pages/projects/*.tsx
    
    # Pages root
    node audit/sprint2-codemod/migrate-cms.mjs --write \
      artifacts/shopify-optimizer/src/pages/*.tsx
    
    # Components (cuidado, revisar más)
    node audit/sprint2-codemod/migrate-cms.mjs --write \
      artifacts/shopify-optimizer/src/components/*.tsx
    ```

19. **Correr Prettier para restaurar formato**:
    ```bash
    npx prettier --write 'artifacts/shopify-optimizer/src/**/*.tsx'
    ```

20. **Mergear `cms-defaults-patch.json`** en `cms-defaults.ts`:
    - Cada sección que aparezca (`labels.admin_inventory`, etc.) añadirla al
      objeto `labels` en `cms-defaults.ts`.

21. **Smoke test**: cargar cada página, verificar que los textos siguen
    apareciendo (los fallbacks funcionan aunque las keys no estén en el CMS BD).

### Fase 6 — Limpieza (1 día — 4h)

22. **Borrar tablas DB sin uso**:
    - `geminiConversations` (lib/db/src/schema/conversations.ts)
    - `geminiMessages` (lib/db/src/schema/messages.ts)
    - `pricingRulesTable` (lib/db/src/schema/shopybrain.ts)
    - Generar migration de Drizzle

23. **Borrar 41 componentes UI sin uso**:
    ```bash
    # Identificarlos primero (los que NO aparecen en imports):
    for f in artifacts/shopify-optimizer/src/components/ui/*.tsx; do
      basename=$(basename "$f" .tsx)
      uses=$(grep -rln "/ui/$basename\b" artifacts/shopify-optimizer/src/ | wc -l)
      if [ "$uses" -eq 0 ]; then
        echo "rm $f"
      fi
    done
    ```

24. **Borrar `audit.ts` (283 LOC dead code)**:
    ```bash
    rm artifacts/api-server/src/routes/audit.ts
    # + remover imports de routes/index.ts
    ```

25. **Decidir `Billing.tsx`**: o cablearla a App.tsx, o borrarla.

---

## 🔢 ESTIMACIÓN TOTAL

| Fase | Tareas | Tiempo |
|---|---|---|
| Fase 1 — Críticos individuales | 8 fixes | 4-6h |
| Fase 2 — shopybrain.ts patches | 11 patches verificados | 6-9h |
| Fase 3 — exports.ts patches | 6 patches verificados | 1-2h |
| Fase 4 — CMS backend | Replace + modular | 4-6h |
| Fase 5 — Codemod CMS frontend | 1180 strings × revisar | 6-10h |
| Fase 6 — Limpieza | Dead code | 4h |
| **TOTAL** | | **25-37h (~1 semana)** |

---

## ✅ VERIFICACIONES YA REALIZADAS

- [x] `migrate-cms.mjs` probado con `node migrate-cms.mjs --write` en /tmp/codemod-test
- [x] `cms.ts` compilado con tsc (errores solo de stubs, código válido)
- [x] `CmsContext.tsx` compilado con tsc (idem)
- [x] `shopybrain-helpers.ts` compilado con tsc
- [x] Codemod aplicado a 28 páginas admin reales — detecta 1180 strings totales
- [x] Cada patch en `*-VERIFIED-patches.ts` verificado leyendo el código real
- [x] Helpers referenciados existen: `shopifyRequestPaged`, `validateUrlWithDnsCheck`, `checkProductionLimit`
- [x] Tabla `oauth_state` confirmada como NO existente (debe crearse)

## ⚠️ VERIFICACIONES QUE TÚ DEBES HACER

- [ ] Smoke test cada feature después de aplicar fixes (tienda Shopify de prueba)
- [ ] Verificar que el codemod produzca TSX válido en TUS archivos (ya verificado en /tmp con copia tuya)
- [ ] Probar que el chatbot rechaza acciones sin `confirmed: true`
- [ ] Probar que los patches RCE bloquean intentos de modificar `.env` o `auth.ts`
- [ ] Probar que el revenue dashboard ya muestra datos correctos tras el fix de paginación
- [ ] Probar que el A/B tracking funciona desde el pixel del comprador (sin admin cookie)

---

## 🚨 CASOS QUE QUEDAN SIN VERIFICAR EN PROFUNDIDAD

A pesar de toda esta auditoría, hay 2 puntos donde la cobertura no es 100%:

1. **128/148 acciones de shopybrain.ts NO leídas línea por línea** — pero todas
   tienen scan dirigido por patrones (confirmation, validation, plan check,
   pagination, fetch SSRF). Los 11 patches cubren los problemas sistémicos
   detectados. Bugs específicos a una acción concreta podrían quedar.

2. **12/27 endpoints de exports.ts NO leídos en detalle** — pero el scan
   detectó que la mayoría usa `esc()` y `<!-- nosemgrep -->` para indicar
   intencionalidad. Los 6 patches cubren los XSS-via-LLM reales.

3. **Configuración Replit-específica** (Nix store paths, env vars en Replit
   secrets, etc.) — depende de tu setup. Los patches asumen que mueves a
   env vars estándar.

---

## 📞 SOPORTE POST-APLICACIÓN

Cualquier patch que no funcione tras aplicarlo en Replit:
1. Verifica que copiaste el archivo helper a `lib/shopybrain-helpers.ts`
2. Verifica los imports al inicio de `shopybrain.ts`
3. Verifica que TypeScript compile (`pnpm typecheck` o similar)

Los patches están escritos para ser **independientes**: puedes aplicar PATCH 3
sin haber aplicado PATCH 1, etc. El orden recomendado es por prioridad de bug.
