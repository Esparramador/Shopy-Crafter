-- ============================================================================
-- partition_events.sql — TEMPLATE
-- ----------------------------------------------------------------------------
-- Script completo para particionar `events`. Duplicar y adaptar para
-- `audit_log` (columna created_at) y `sales_analytics` (columna order_date
-- o created_at — elegir en función de qué filtro se use más).
--
-- NO ejecutar directamente. Leer README.md primero, medir, decidir, testear
-- en staging con dump de prod.
-- ============================================================================

-- ─── Fase 1: Crear tabla particionada vacía ──────────────────────────────────
BEGIN;

CREATE TABLE events_partitioned (
  LIKE events INCLUDING ALL
) PARTITION BY RANGE (created_at);

-- Re-crear FKs (INCLUDING ALL no las copia en particionadas)
ALTER TABLE events_partitioned
  ADD CONSTRAINT fk_events_project_partitioned
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;

-- Re-crear índices que queramos globales (se propagan a todas las particiones)
CREATE INDEX idx_events_part_project_created
  ON events_partitioned(project_id, created_at DESC);

COMMIT;

-- ─── Fase 2: Crear particiones por mes ───────────────────────────────────────
DO $$
DECLARE
  start_date date;
  end_date   date := (date_trunc('month', now() + interval '3 months'))::date;
  part_start date;
  part_end   date;
  part_name  text;
BEGIN
  SELECT COALESCE(date_trunc('month', min(created_at))::date, '2025-01-01'::date)
    INTO start_date FROM events;

  part_start := start_date;
  WHILE part_start < end_date LOOP
    part_end  := (part_start + interval '1 month')::date;
    part_name := 'events_y' || to_char(part_start, 'YYYY') ||
                 'm' || to_char(part_start, 'MM');
    EXECUTE format($f$
      CREATE TABLE IF NOT EXISTS %I PARTITION OF events_partitioned
        FOR VALUES FROM (%L) TO (%L)
    $f$, part_name, part_start, part_end);
    RAISE NOTICE 'Created partition: %', part_name;
    part_start := part_end;
  END LOOP;
END $$;

CREATE TABLE IF NOT EXISTS events_default PARTITION OF events_partitioned DEFAULT;

-- ─── Fase 3: Copia por lotes (ejecutar iterativamente) ───────────────────────
-- IMPORTANTE: durante esta fase pueden llegar nuevas filas a `events` (INSERTs
-- de la app). El loop sigue hasta que la tabla quede completamente vacía,
-- incluyendo las que lleguen durante la copia.

DO $$
DECLARE
  batch_size int := 100000;
  moved      int := 1;
  total      bigint := 0;
  started_at timestamptz := clock_timestamp();
BEGIN
  WHILE moved > 0 LOOP
    WITH batch AS (
      SELECT id FROM events
      ORDER BY created_at
      LIMIT batch_size
      FOR UPDATE SKIP LOCKED
    ),
    inserted AS (
      INSERT INTO events_partitioned
        SELECT e.* FROM events e
        JOIN batch b ON b.id = e.id
      ON CONFLICT (id) DO NOTHING   -- defensivo por si se ejecuta 2 veces
      RETURNING id
    )
    DELETE FROM events WHERE id IN (SELECT id FROM inserted);

    GET DIAGNOSTICS moved = ROW_COUNT;
    total := total + moved;
    RAISE NOTICE 'Batch: % rows, total: %, elapsed: %',
      moved, total, clock_timestamp() - started_at;

    PERFORM pg_sleep(0.5);
  END LOOP;
  RAISE NOTICE 'Copy complete: % rows in %', total, clock_timestamp() - started_at;
END $$;

-- ─── Fase 4: Swap atómico ────────────────────────────────────────────────────
-- Ventana: ~1 segundo de AccessExclusiveLock. Durante este tiempo la app no
-- puede INSERT/SELECT `events`. Planificar en hora baja o pausar el scheduler.

BEGIN;

-- Safety: abortar si quedó algo sin migrar
DO $$
DECLARE remaining int;
BEGIN
  SELECT count(*) INTO remaining FROM events;
  IF remaining > 0 THEN
    RAISE EXCEPTION 'events still has % rows, ABORT', remaining;
  END IF;
END $$;

ALTER TABLE events             RENAME TO events_old;
ALTER TABLE events_partitioned RENAME TO events;

ALTER TABLE events RENAME CONSTRAINT fk_events_project_partitioned TO fk_events_project;
ALTER INDEX idx_events_part_project_created RENAME TO idx_events_project_created;

COMMIT;

-- ─── Fase 5: Verificación post-swap ──────────────────────────────────────────
-- Ejecutar en cuanto termine el swap:

SELECT count(*) AS rows_in_new_events FROM events;

SELECT
  parent.relname AS parent,
  child.relname  AS partition,
  pg_size_pretty(pg_total_relation_size(child.oid)) AS size
FROM pg_inherits
JOIN pg_class parent ON pg_inherits.inhparent = parent.oid
JOIN pg_class child  ON pg_inherits.inhrelid  = child.oid
WHERE parent.relname = 'events'
ORDER BY child.relname;

-- ─── Fase 6: Después de 1-2 días sin regresiones ─────────────────────────────
-- DROP TABLE events_old;

-- ─── Fase 7: Retención via DROP de particiones (reemplaza purge_events) ──────
-- Esta función sustituye a `purge_events()` del 0011_retention_jobs.sql.
-- Es O(1) en vez de O(N). Llamar desde el mismo cron diario.

CREATE OR REPLACE FUNCTION purge_events_partitions(retention_days int DEFAULT 180)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE
  cutoff     date := (now() - (retention_days || ' days')::interval)::date;
  p          record;
  part_start date;
  dropped    text[] := '{}';
BEGIN
  FOR p IN
    SELECT child.relname AS name
    FROM pg_inherits
    JOIN pg_class child ON pg_inherits.inhrelid = child.oid
    WHERE pg_inherits.inhparent = 'events'::regclass
      AND child.relname ~ '^events_y\d{4}m\d{2}$'
  LOOP
    -- Parsear yYYYYmMM del nombre
    part_start := to_date(
      substring(p.name FROM 'y(\d{4})m(\d{2})'),
      'YYYYMM'
    );
    -- Si toda la partición está antes del cutoff, dropearla
    IF part_start + interval '1 month' <= cutoff THEN
      EXECUTE format('DROP TABLE %I', p.name);
      dropped := array_append(dropped, p.name);
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'partitions_dropped', to_jsonb(dropped),
    'cutoff', cutoff
  );
END $$;
