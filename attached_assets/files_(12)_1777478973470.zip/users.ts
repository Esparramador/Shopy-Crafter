// users.ts — solo la tabla users tras el refactor
import { pgTable, pgEnum, text, boolean, timestamp } from "drizzle-orm/pg-core";

export const userRoleEnum = pgEnum("user_role", ["admin", "client"]);

export const usersTable = pgTable("users", {
  id:             text("id").primaryKey(),
  email:          text("email").unique().notNull(),
  password:       text("password").notNull(),
  name:           text("name").notNull(),
  role:           userRoleEnum("role").notNull(),
  clientId:       text("client_id"),
  isActive:       boolean("is_active").notNull().default(true),
  avatarColor:    text("avatar_color").default("#5b4eff"),
  inviteToken:    text("invite_token"),
  inviteExpires:  timestamp("invite_expires", { withTimezone: true }),
  resetToken:     text("reset_token"),
  resetExpires:   timestamp("reset_expires", { withTimezone: true }),
  lastLogin:      timestamp("last_login", { withTimezone: true }),
  createdAt:      timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type User = typeof usersTable.$inferSelect;
