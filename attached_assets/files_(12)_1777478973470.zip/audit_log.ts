// audit_log.ts — tabla de auditoría extraída de users.ts
import { pgTable, text, integer, timestamp, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { projectsTable } from "./projects";

export const auditLogTable = pgTable("audit_log", {
  id:         text("id").primaryKey(),
  userId:     text("user_id")
                .references(() => usersTable.id, { onDelete: "set null" }),
  projectId:  integer("project_id")
                .references(() => projectsTable.id, { onDelete: "set null" }),
  action:     text("action").notNull(),
  details:    text("details"),
  ipAddress:  text("ip_address"),
  createdAt:  timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_audit_log_user_created").on(t.userId, t.createdAt.desc()),
  index("idx_audit_log_project_created").on(t.projectId, t.createdAt.desc()),
]);

export type AuditLog = typeof auditLogTable.$inferSelect;
