-- ============================================================================
-- 0012_unify_plan_enum.sql
-- ----------------------------------------------------------------------------
-- Unifica plan_type (projects) y subscription_plan (subscriptions) en un único
-- enum. La fuente de verdad es plan_type: sus valores cubren todo lo que
-- subscription_plan podía expresar y además añade niveles de la escala de
-- precios (agency_pro, emprendedor) que hoy no se pueden representar en
-- subscription_plan.
--
-- Contexto del análisis:
--   projects.plan valores: admin | emprendedor | starter | agency_pro | enterprise | trial
--   subscriptions.plan:    trial | starter | pro | enterprise
--
-- El valor "pro" en subscription_plan era ambiguo: ¿era agency_pro? ¿enterprise?
-- Tras revisar PLAN_LIMITS en artifacts/api-server/src/lib/plan-limits.ts
-- (que usa PlanType de projects para todas las cuentas de uso), queda claro
-- que el enum de projects es el que está vivo. El de billing.ts nunca llegó
-- a usarse en producción con valores distintos de "trial" y "starter".
--
-- REQUISITO: este archivo va DESPUÉS del 0009_enums.sql del Bloque E.
--
-- Pre-flight obligatorio:
--   SELECT DISTINCT plan FROM subscriptions;
--   -- Confirmar que solo hay: 'trial', 'starter'. Si aparece 'pro' o
--   -- 'enterprise' hay que decidir caso a caso con el dueño de cuenta.
-- ============================================================================

BEGIN;

-- ─── Paso 1: normalizar valores existentes en subscriptions ──────────────────
-- Antes de tocar el tipo, mapear los valores viejos al enum unificado.
-- Los DO UPDATE están en IS DISTINCT FROM para ser idempotentes.

-- "pro" → "agency_pro" (asunción: "pro" del viejo billing = tier intermedio
-- del nuevo). Si en tu negocio real "pro" era enterprise, cambiar el target.
UPDATE subscriptions SET plan = 'agency_pro' WHERE plan = 'pro';

-- El resto (trial, starter, enterprise) ya son valores válidos en plan_type,
-- no hay que hacer nada.

-- Verificación: si queda algún valor fuera del enum destino, abortar.
DO $$
DECLARE bad_count int;
BEGIN
  SELECT count(*) INTO bad_count
  FROM subscriptions
  WHERE plan::text NOT IN (
    'admin', 'emprendedor', 'starter', 'agency_pro', 'enterprise', 'trial'
  );
  IF bad_count > 0 THEN
    RAISE EXCEPTION 'subscriptions tiene % filas con plan no mapeable al enum unificado', bad_count;
  END IF;
END $$;

-- ─── Paso 2: cambiar el tipo de la columna al enum unificado ─────────────────

-- Drop default (Postgres exige quitar defaults antes de cambiar el tipo)
ALTER TABLE subscriptions ALTER COLUMN plan DROP DEFAULT;

-- Cast de subscription_plan -> plan_type pasando por text
ALTER TABLE subscriptions
  ALTER COLUMN plan TYPE plan_type USING plan::text::plan_type;

-- Re-poner el default con el tipo correcto
ALTER TABLE subscriptions
  ALTER COLUMN plan SET DEFAULT 'trial'::plan_type;

-- ─── Paso 3: dropear el enum antiguo ─────────────────────────────────────────
-- Solo se puede si ya no hay columnas que lo usen. Postgres avisa si quedara
-- alguna.

DROP TYPE subscription_plan;

COMMIT;

-- ─── Verificación post-migración ─────────────────────────────────────────────
-- Después de COMMIT:
--   SELECT typname FROM pg_type WHERE typname = 'subscription_plan';
--   -- Debe devolver 0 filas.
--
--   SELECT DISTINCT plan FROM subscriptions;
--   -- Debe devolver solo valores del enum plan_type.
--
--   \d subscriptions
--   -- Debe mostrar plan con tipo plan_type.
