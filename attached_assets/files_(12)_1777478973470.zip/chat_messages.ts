// chat_messages.ts — extraído de users.ts
// OJO: renombrado a chat_messages.ts (archivo) para evitar colisión con
// messages.ts que ya existe para gemini_messages. La tabla en DB sigue
// llamándose "messages" como antes (no hay migración — solo cambia el archivo
// en TS).
//
// El export sigue siendo `messagesTable` (nombre de la constante) para no
// romper imports en rutas.

import { pgTable, text, integer, boolean, timestamp, index } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";
import { userRoleEnum } from "./users";

export const messagesTable = pgTable("messages", {
  id:         text("id").primaryKey(),
  projectId:  integer("project_id").notNull()
                .references(() => projectsTable.id, { onDelete: "cascade" }),
  fromRole:   userRoleEnum("from_role").notNull(),
  fromName:   text("from_name").notNull(),
  content:    text("content").notNull(),
  isRead:     boolean("is_read").notNull().default(false),
  createdAt:  timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_messages_project_created").on(t.projectId, t.createdAt),
  index("idx_messages_project_unread")
    .on(t.projectId, t.createdAt)
    .where(/* sql`${t.isRead} = false` */ undefined as any),
  // NOTA: partial index más útil ("mensajes no leídos por proyecto") requiere
  // importar `sql` de drizzle-orm. Lo dejo comentado; al generar con Drizzle
  // se puede activar con `.where(sql`${t.isRead} = false`)`.
]);

export type Message = typeof messagesTable.$inferSelect;
