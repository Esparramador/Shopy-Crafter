// approvals.ts — extraído de users.ts
import { pgTable, pgEnum, text, integer, timestamp, index } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";

export const approvalStatusEnum = pgEnum("approval_status", [
  "pending", "approved", "rejected",
]);

export const approvalsTable = pgTable("approvals", {
  id:               text("id").primaryKey(),
  projectId:        integer("project_id").notNull()
                      .references(() => projectsTable.id, { onDelete: "cascade" }),
  type:             text("type").notNull(),
  title:            text("title").notNull(),
  description:      text("description").notNull(),
  beforeValue:      text("before_value"),
  afterValue:       text("after_value"),
  reasoning:        text("reasoning"),
  estimatedImpact:  text("estimated_impact"),
  status:           approvalStatusEnum("status").notNull().default("pending"),
  clientComment:    text("client_comment"),
  reviewedAt:       timestamp("reviewed_at", { withTimezone: true }),
  createdAt:        timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_approvals_project").on(t.projectId),
  index("idx_approvals_project_status").on(t.projectId, t.status),
]);

export type Approval = typeof approvalsTable.$inferSelect;
