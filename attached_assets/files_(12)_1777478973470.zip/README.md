# Bloque F — Mejoras post-saneamiento

Tres tareas que quedaron fuera del Bloque E por no ser críticas pero que hay
que cerrar para que el schema quede completamente saneado. Son independientes
entre sí: se pueden aplicar en cualquier orden y tiempos distintos.

## Resumen de las 3 tareas

| # | Qué | Severidad | Cuándo | PR independiente |
|---|---|---|---|---|
| 1 | Refactor de `users.ts` en 5 archivos | Cosmético | Siempre (no requiere ventana) | ✅ Sí |
| 2 | Particionado de `audit_log` / `events` / `sales_analytics` | Performance | Cuando superen 10M filas | ✅ Sí |
| 3 | Unificar `plan_type` y `subscription_plan` en un enum | Correctness (bug silencioso) | ASAP tras aplicar Bloque E | ✅ Sí |

## Estructura

```
bloque_f/
├── refactor_users/           ← Tarea 1
│   ├── README.md
│   ├── users.ts              (reemplaza el actual)
│   ├── audit_log.ts          (nuevo)
│   ├── approvals.ts          (nuevo)
│   ├── chat_messages.ts      (nuevo)
│   ├── rate_limits.ts        (nuevo)
│   └── index.ts              (con los 4 exports nuevos)
│
├── partitioning/             ← Tarea 2 (plantilla, aplicar cuando toque)
│   ├── README.md             (playbook completo)
│   └── partition_events.sql  (template para events; duplicar y adaptar)
│
└── unify_plan_enum/          ← Tarea 3
    ├── README.md
    ├── 0012_unify_plan_enum.sql
    └── billing.ts            (reemplaza el del Bloque E)
```

## Orden recomendado

1. **Tarea 3 (unify plan enum)** — primero, porque arregla un bug silencioso
   (`subscriptions.plan = 'pro'` rompe `PLAN_LIMITS` en runtime). Es la única
   de las 3 que corrige un defecto funcional.

2. **Tarea 1 (refactor users.ts)** — cuando no haya otros PRs tocando
   `users.ts`. Cero riesgo, cero downtime, cero cambio de DB. PR de 5 minutos
   para revisar.

3. **Tarea 2 (particionado)** — cuando las métricas de `pg_stat_user_tables`
   digan que toca. Probablemente dentro de 6-12 meses desde ahora. Hasta
   entonces, dejar el playbook archivado.

## Lo que NO queda después de Bloque F

- Todas las tablas están con FKs coherentes.
- Enums unificados y sin ambigüedades.
- Archivos TS organizados (una responsabilidad por archivo).
- Plan de escalado documentado para cuando las tablas crezcan.
- Guardarraíles (CI drift guard, codemod) en su sitio desde el Bloque E.

Cualquier siguiente iteración sería de funcionalidad nueva, no de
saneamiento del schema existente.
