// billing.ts — POST unificación de enums plan
//
// Cambios respecto a updated_schemas/billing.ts del Bloque E:
//   - subscriptionPlanEnum REMOVIDO — ahora se importa planTypeEnum desde
//     ./projects, que es la fuente única de verdad.
//   - subscriptions.plan usa planTypeEnum con default 'trial'.
//   - subscription_status sigue siendo un enum propio (correcto: el ciclo de
//     vida de Stripe no solapa con plan).
//
// Esto alinea las 2 fuentes de verdad del plan. El código que lea el plan de
// un subscription y lo compare con PLAN_LIMITS ahora funciona sin casts.

import {
  pgTable, pgEnum, text, real, integer, boolean, timestamp,
} from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { planTypeEnum } from "./projects";  // ← fuente única de verdad

export const subscriptionStatusEnum = pgEnum("subscription_status", [
  "active", "past_due", "canceled", "unpaid", "trialing", "incomplete",
]);

export const subscriptionsTable = pgTable("subscriptions", {
  userId:                text("user_id").primaryKey()
                           .references(() => usersTable.id, { onDelete: "cascade" }),
  stripeCustomerId:      text("stripe_customer_id").unique(),
  stripeSubscriptionId:  text("stripe_subscription_id").unique(),
  plan:                  planTypeEnum("plan").notNull().default("trial"),
  status:                subscriptionStatusEnum("status").notNull().default("active"),
  trialEndsAt:           timestamp("trial_ends_at", { withTimezone: true }),
  currentPeriodEnd:      timestamp("current_period_end", { withTimezone: true }),
  storesLimit:           integer("stores_limit").default(1),
  imagesIncluded:        integer("images_included").default(100),
  imagesUsed:            integer("images_used").default(0),
  cancelAtPeriodEnd:     boolean("cancel_at_period_end").notNull().default(false),
  createdAt:             timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const affiliatesTable = pgTable("affiliates", {
  id:                text("id").primaryKey(),
  userId:            text("user_id").notNull()
                       .references(() => usersTable.id, { onDelete: "cascade" }),
  referralCode:      text("referral_code").unique().notNull(),
  clicks:            integer("clicks").default(0),
  signups:           integer("signups").default(0),
  conversions:       integer("conversions").default(0),
  pendingPayout:     real("pending_payout").default(0),
  totalEarned:       real("total_earned").default(0),
  stripeConnectId:   text("stripe_connect_id"),
  createdAt:         timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const referralTrackingTable = pgTable("referral_tracking", {
  id:                text("id").primaryKey(),
  affiliateId:       text("affiliate_id").notNull()
                       .references(() => affiliatesTable.id, { onDelete: "cascade" }),
  referredUserId:    text("referred_user_id")
                       .references(() => usersTable.id, { onDelete: "set null" }),
  signupDate:        timestamp("signup_date", { withTimezone: true }),
  convertedDate:     timestamp("converted_date", { withTimezone: true }),
  commissionRate:    real("commission_rate").default(0.20),
  commissionEarned:  real("commission_earned").default(0),
  status:            text("status").default("pending"),
});

export type Subscription     = typeof subscriptionsTable.$inferSelect;
export type Affiliate        = typeof affiliatesTable.$inferSelect;
export type ReferralTracking = typeof referralTrackingTable.$inferSelect;
