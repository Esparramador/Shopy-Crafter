# Particionado por mes — cuándo y cómo

## Resumen

Tres tablas van a crecer sin techo natural: `audit_log`, `events`,
`sales_analytics`. Hoy (Abril 2026, aplicación joven) son pequeñas. Cuando
cualquiera supere **~10M filas** o **~5 GB en disco**, conviene particionarla
por mes. Este documento es la **receta reproducible** para ese momento.

Regla de decisión: si el `VACUUM` de una de estas tablas empieza a tardar más
de 5 minutos o los queries con filtro por fecha tardan más de 500ms incluso
con índices, **es el momento**. Hasta entonces, no.

## Por qué no ahora

Particionar una tabla pequeña no aporta nada y añade complejidad operacional
(hay que crear particiones nuevas cada mes, el `EXPLAIN` es más ruidoso,
algunos clientes Postgres antiguos se confunden con `pg_inherits`). En Postgres
14+, el coste del particionado es bajo, pero **no es cero** y solo se amortiza
cuando hay suficientes datos como para que el pruning de particiones haga
diferencia real en las queries.

## Cómo medir "es el momento"

```sql
-- Tamaño y filas de las 3 candidatas
SELECT
  relname,
  n_live_tup                                   AS rows,
  pg_size_pretty(pg_total_relation_size(relid)) AS size,
  pg_total_relation_size(relid)                 AS size_bytes
FROM pg_stat_user_tables
WHERE relname IN ('audit_log', 'events', 'sales_analytics')
ORDER BY size_bytes DESC;

-- Tiempo del VACUUM más reciente de cada tabla
SELECT schemaname, relname, last_vacuum, last_autovacuum,
       n_dead_tup, n_live_tup
FROM pg_stat_user_tables
WHERE relname IN ('audit_log', 'events', 'sales_analytics');
```

Umbrales:
- `n_live_tup` > 10.000.000 → candidata clara
- `size_bytes` > 5 * 1024^3 → candidata clara  
- VACUUM > 5 min → candidata urgente (ralentiza todo)

## Playbook de migración (por tabla)

El ejemplo es `events`, pero la receta es idéntica para `audit_log` y
`sales_analytics` cambiando nombres. **Todo se hace online** con swap al final.

### Fase 0 — Pre-requisitos
- Postgres 13+ (soporte completo de `DEFAULT` partition).
- Tener ya aplicado el plan del Bloque E (en particular: FKs, índices).
- `pg_dump` de backup.
- Ventana de mantenimiento opcional: la migración es online pero el swap final
  requiere un lock muy breve (AccessExclusiveLock por ~1 segundo).

### Fase 1 — Crear la tabla particionada vacía

```sql
BEGIN;

-- Tabla particionada con el mismo schema que `events`
CREATE TABLE events_partitioned (
  LIKE events INCLUDING ALL  -- copia columnas, defaults, NOT NULL, checks
) PARTITION BY RANGE (created_at);

-- Comentario: INCLUDING ALL NO copia las FKs ni los índices globales en tablas
-- particionadas. Hay que recrearlos explícitamente:

-- FK (postgres 11+ soporta FKs en tablas particionadas):
ALTER TABLE events_partitioned
  ADD CONSTRAINT fk_events_project_partitioned
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE;

-- Índices (se propagan a todas las particiones):
CREATE INDEX idx_events_part_project_created
  ON events_partitioned(project_id, created_at DESC);

CREATE INDEX idx_events_part_created
  ON events_partitioned(created_at DESC);

COMMIT;
```

### Fase 2 — Crear particiones

```sql
-- Una partición por mes para todo el histórico + próximos 3 meses
-- Ajustar fechas según el primer createdAt real de prod:
--   SELECT min(created_at), max(created_at) FROM events;

DO $$
DECLARE
  start_date date := '2025-01-01';  -- ajustar al mes más antiguo en events
  end_date   date := '2026-07-01';  -- mes actual + 3
  part_start date;
  part_end   date;
  part_name  text;
BEGIN
  part_start := start_date;
  WHILE part_start < end_date LOOP
    part_end  := (part_start + interval '1 month')::date;
    part_name := 'events_y' || to_char(part_start, 'YYYY') ||
                 'm' || to_char(part_start, 'MM');
    EXECUTE format($f$
      CREATE TABLE IF NOT EXISTS %I PARTITION OF events_partitioned
        FOR VALUES FROM (%L) TO (%L)
    $f$, part_name, part_start, part_end);
    part_start := part_end;
  END LOOP;
END $$;

-- Partición DEFAULT para cualquier fecha fuera de rango (seguridad):
CREATE TABLE events_default PARTITION OF events_partitioned DEFAULT;
```

### Fase 3 — Copiar datos por lotes (online)

```sql
-- Copiar en lotes de 100k filas para no inflar WAL ni bloquear autovacuum.
-- Esta query se ejecuta N veces hasta que retorne 0 filas movidas.
-- Se puede scriptear desde la app o desde cron.

-- Opción A: script en psql (simple)
DO $$
DECLARE
  batch_size  int := 100000;
  moved       int := 1;
  total_moved bigint := 0;
BEGIN
  WHILE moved > 0 LOOP
    WITH batch AS (
      SELECT id FROM events
      ORDER BY created_at
      LIMIT batch_size
      FOR UPDATE SKIP LOCKED
    ),
    inserted AS (
      INSERT INTO events_partitioned
        SELECT e.* FROM events e
        JOIN batch b ON b.id = e.id
      RETURNING id
    )
    DELETE FROM events WHERE id IN (SELECT id FROM inserted);

    GET DIAGNOSTICS moved = ROW_COUNT;
    total_moved := total_moved + moved;
    RAISE NOTICE 'Moved batch: %, total: %', moved, total_moved;

    -- Pausa para que autovacuum y replicación alcancen
    PERFORM pg_sleep(0.5);
  END LOOP;
END $$;
```

### Fase 4 — Swap atómico

```sql
BEGIN;

-- Verificar que la tabla origen está vacía
-- (si no lo está, hay INSERTs concurrentes que hay que parar antes)
DO $$
DECLARE remaining int;
BEGIN
  SELECT count(*) INTO remaining FROM events;
  IF remaining > 0 THEN
    RAISE EXCEPTION 'events todavía tiene % filas, abortar', remaining;
  END IF;
END $$;

-- Swap de nombres (lock AccessExclusive, ~1 segundo)
ALTER TABLE events            RENAME TO events_old;
ALTER TABLE events_partitioned RENAME TO events;

-- Renombrar las FKs para que los mensajes de error sean consistentes
ALTER TABLE events
  RENAME CONSTRAINT fk_events_project_partitioned TO fk_events_project;

-- Renombrar índices para que coincidan con nombres esperados
ALTER INDEX idx_events_part_project_created RENAME TO idx_events_project_created;
ALTER INDEX idx_events_part_created          RENAME TO idx_events_created;

COMMIT;

-- Después de un par de días sin regressions:
-- DROP TABLE events_old;
```

### Fase 5 — Automatizar creación de particiones futuras

Cada mes hay que crear la partición del mes siguiente. Si no existe cuando
llegan datos de ese mes, caen en `events_default`, que es correcto pero no
aporta las ventajas del particionado.

Opción A (pg_cron):
```sql
SELECT cron.schedule(
  'create-next-month-partition-events',
  '0 0 25 * *',  -- día 25 de cada mes a las 00:00
  $$ SELECT create_next_partition('events_partitioned', now()) $$
);
```

Función reutilizable:
```sql
CREATE OR REPLACE FUNCTION create_next_partition(
  parent_table text,
  ref_date     timestamptz DEFAULT now()
) RETURNS text LANGUAGE plpgsql AS $$
DECLARE
  next_start date := date_trunc('month', ref_date + interval '1 month')::date;
  next_end   date := (next_start + interval '1 month')::date;
  part_name  text := parent_table || '_y' || to_char(next_start, 'YYYY')
                                   || 'm' || to_char(next_start, 'MM');
BEGIN
  EXECUTE format($f$
    CREATE TABLE IF NOT EXISTS %I PARTITION OF %I
      FOR VALUES FROM (%L) TO (%L)
  $f$, part_name, parent_table, next_start, next_end);
  RETURN part_name;
END $$;
```

Opción B (cron app): llamar desde `scheduler.ts` una vez al mes:
```typescript
await db.execute(sql`SELECT create_next_partition('events', now())`);
await db.execute(sql`SELECT create_next_partition('audit_log', now())`);
await db.execute(sql`SELECT create_next_partition('sales_analytics', now())`);
```

### Fase 6 — Retención con DROP de particiones

La enorme ventaja del particionado: borrar 90 días de `audit_log` es instantáneo
(`DROP TABLE audit_log_y2025m12`) en vez de un `DELETE` de millones de filas.

El `0011_retention_jobs.sql` del Bloque E puede simplificarse tras particionar:

```sql
-- Antes (lento, O(N), genera WAL masivo):
-- DELETE FROM audit_log WHERE created_at < now() - interval '90 days';

-- Después (instantáneo, O(1)):
DO $$
DECLARE
  p record;
  cutoff date := (now() - interval '90 days')::date;
BEGIN
  FOR p IN
    SELECT inhrelid::regclass::text AS name
    FROM pg_inherits
    WHERE inhparent = 'audit_log'::regclass
  LOOP
    -- Solo dropear si toda la partición está antes del cutoff
    -- (parseando el nombre: audit_log_yYYYYmMM)
    IF substring(p.name FROM 'y(\d{4})m(\d{2})')::date < cutoff THEN
      EXECUTE format('DROP TABLE %I', p.name);
      RAISE NOTICE 'Dropped partition %', p.name;
    END IF;
  END LOOP;
END $$;
```

## Lo que cambia para Drizzle

Drizzle-kit no genera tablas particionadas automáticamente; la sintaxis
`PARTITION BY RANGE` no está en el DSL. Hay dos caminos:

**Opción 1 (recomendada)**: mantener la tabla particionada fuera del workflow
normal de Drizzle. Drizzle seguirá viéndola como una tabla normal para SELECT,
INSERT, UPDATE. La única diferencia es que:
- `drizzle-kit generate` no detectará cambios sobre la tabla particionada.
- Las migraciones de columnas/índices se hacen con SQL manual.

En la práctica, tablas como `events` rara vez cambian de schema una vez
particionadas.

**Opción 2**: `drizzle-kit` con `.$inferInsert` sigue funcionando porque la
tabla tiene la misma estructura. En el schema TS no hay que cambiar nada.

## Resumen ejecutivo

| Tabla | Cuándo particionar | Tiempo estimado de migración |
|---|---|---|
| `audit_log` | Cuando supere 10M filas o VACUUM > 5 min | ~2h para 20M filas |
| `events` | Igual | ~2h para 20M filas |
| `sales_analytics` | Igual, pero tarda más en llegar al umbral (1 fila por línea de orden) | ~3h para 20M filas |
| `omnicore_absorbed_content` | Probablemente nunca si la retención (0011) se aplica | — |
| `gemini_messages` | Raro que sea necesario | — |

**Recomendación**: poner un alert en monitorización sobre `pg_stat_user_tables.n_live_tup`
de estas 3 tablas. Cuando alguna supere 5M filas, planificar ventana para los
2 meses siguientes.
