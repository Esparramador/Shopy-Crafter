# Unificar `plan_type` y `subscription_plan` en un único enum

## El problema

En el Bloque E (0009_enums.sql) se crearon dos enums distintos para el mismo
concepto:

```sql
CREATE TYPE plan_type         AS ENUM ('admin','emprendedor','starter','agency_pro','enterprise','trial');
CREATE TYPE subscription_plan AS ENUM ('trial','starter','pro','enterprise');
```

- `plan_type` lo usa `projects.plan` — es la fuente que `PLAN_LIMITS` (en
  `plan-limits.ts`) mapea a límites de uso de productos/imágenes.
- `subscription_plan` lo usa `subscriptions.plan` — heredado de un diseño
  anterior que no llegó a desarrollarse.

La ambigüedad visible:
- `"pro"` existe solo en `subscription_plan`. No hay nada en el código que lo
  mapee a un tier de `PLAN_LIMITS`. Es decir: si un `subscriptions.plan='pro'`
  llega a `plan-limits.ts`, el `Record<PlanType, PlanConfig>[plan]` devuelve
  `undefined` y la app se rompe en silencio.
- `plan_type` tiene `agency_pro`, `emprendedor`, `admin` que no pueden
  almacenarse en `subscriptions.plan`.

En otras palabras: el modelo de suscripciones no puede representar los planes
que la app vende. Bug silencioso.

## La solución

Usar `plan_type` en ambas tablas. Es un superset de `subscription_plan` en los
valores que realmente están vivos.

### Decisión de mapeo de datos existentes

Solo hay 1 valor ambiguo: `"pro"` en `subscriptions.plan`.
- Si en tu negocio real `"pro"` era "Agency Pro €149/mes" → mapear a `agency_pro`.
- Si era "Enterprise" → mapear a `enterprise`.

El script `0012_unify_plan_enum.sql` asume **`pro` → `agency_pro`**. Si en tu
caso es distinto, editar la línea correspondiente antes de ejecutar.

**Validación pre-ejecución (obligatoria)**:
```sql
SELECT plan, count(*) FROM subscriptions GROUP BY plan;
```
- Si solo aparecen `trial` y `starter`, el mapeo es trivial y no hace falta
  decidir nada. El UPDATE de `pro` → `agency_pro` simplemente no afecta a
  ninguna fila.

## Archivos entregados

```
bloque_f/unify_plan_enum/
├── 0012_unify_plan_enum.sql   ← Migración DDL
├── billing.ts                 ← Schema TS actualizado
└── README.md
```

## Orden

Este cambio va **después** del Bloque E completo:
```
... 0011_retention_jobs.sql ...
0012_unify_plan_enum.sql      ← este
```

## Impacto en código TS

Solo 1 archivo cambia: `lib/db/src/schema/billing.ts`. Desaparece el export
`subscriptionPlanEnum`. Si algún consumer lo importa directamente, habrá que
cambiar a `planTypeEnum` de `./projects`. Búsqueda para verificar:

```bash
grep -r "subscriptionPlanEnum" artifacts/ lib/
# → 0 resultados esperados (nadie lo usaba por nombre, solo por tipo inferido)
```

El tipo `PlanType` que exporta `projects.ts` ahora también describe
`subscriptions.plan` sin casts. `PLAN_LIMITS` en `plan-limits.ts` pasa a
cubrir ambas tablas de forma natural.

## Riesgo

**Bajo** si el pre-flight confirma que no hay valores `pro` huérfanos en
`subscriptions`. La migración es idempotente (los UPDATE solo tocan filas que
coincidan) y el `DROP TYPE subscription_plan` falla explícitamente si queda
alguna columna con el tipo.

## Ganancia

- Una sola fuente de verdad para "qué plan tiene X".
- `PLAN_LIMITS[subscription.plan]` compila sin casts, sin `as PlanType`.
- Al añadir un plan nuevo (ej. "agency_enterprise") se añade en un solo sitio.
- Un tipo enum menos en la base de datos.
