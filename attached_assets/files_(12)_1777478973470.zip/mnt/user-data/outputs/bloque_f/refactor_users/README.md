# Refactor `users.ts` — 5 archivos separados

## Objetivo
Partir el archivo `users.ts` (que hoy contiene 5 tablas distintas mezcladas) en
5 archivos individuales. **Cero impacto en la DB**: ninguna tabla se renombra,
ningún índice se toca. Solo se reorganizan imports en TypeScript.

## Archivos nuevos
```
lib/db/src/schema/
├── users.ts          (SOLO usersTable + userRoleEnum)   ← reemplaza el actual
├── audit_log.ts      (nuevo: auditLogTable)
├── approvals.ts      (nuevo: approvalsTable + approvalStatusEnum)
├── chat_messages.ts  (nuevo: messagesTable admin↔cliente)
└── rate_limits.ts    (nuevo: rateLimitsTable)
```

**Importante sobre el naming**: el archivo es `chat_messages.ts` para evitar
colisión con el `messages.ts` ya existente (que tiene `gemini_messages`). La
tabla en DB sigue llamándose `messages` y la constante sigue llamándose
`messagesTable` — solo cambia el archivo donde vive.

## Por qué importa
- **Legibilidad**: `users.ts` hoy tiene 61 líneas y 5 conceptos distintos. Nadie
  busca "gestión de rate limits" en un archivo llamado users.
- **Imports correctos**: quien quiera `auditLogTable` ya no fuerza a que tsc
  cargue `approvalsTable` + 3 más.
- **Blast radius**: al tocar rate_limits no aparece un diff en users.ts que
  confunda en code review.

## Validación

### Pre-merge
```bash
# 1. Los imports externos deben seguir funcionando tal cual
grep -r "from.*schema/users" artifacts/api-server/src lib/
#    → sigue funcionando: users.ts aún existe y exporta usersTable+userRoleEnum

# 2. Nadie importa directamente de "./users" para auditLogTable ni similar
grep -r "usersTable\|auditLogTable\|approvalsTable\|messagesTable\|rateLimitsTable" \
   artifacts/api-server/src lib/
#    → todos estos se siguen importando desde `@shopycrafter/db` o
#      `schema/index.ts`, que no cambia su superficie pública

# 3. Typecheck
pnpm -w tsc --noEmit
```

### Post-merge (en DB) — tiene que ser no-op
```bash
# drizzle-kit generate no debería producir ninguna migración
# (si la produce, hay drift que investigar)
cd lib/db && pnpm drizzle-kit generate
#    → salida esperada: "No schema changes, nothing to migrate"
```

## Orden de aplicación
1. Crear los 4 archivos nuevos (`audit_log.ts`, `approvals.ts`,
   `chat_messages.ts`, `rate_limits.ts`).
2. Reducir `users.ts` a solo `usersTable` + `userRoleEnum`.
3. Actualizar `index.ts` con los 4 exports nuevos.
4. Ejecutar `tsc --noEmit` y `drizzle-kit generate` — ambos deben salir limpios.
5. PR con solo estos cambios. Al ser 100% cosmético se puede mergear sin
   ventana de mantenimiento.

## Cuándo NO hacer este refactor
- Si tienes otros PRs en vuelo que tocan `users.ts` o importan símbolos de ahí.
  Espera a que se mergeen para evitar conflicts de merge cosméticos molestos.
- Si el equipo va a hacer un refactor más grande del schema en 2 semanas (p.ej.
  migrar a multi-tenant). Entonces este es ruido.
