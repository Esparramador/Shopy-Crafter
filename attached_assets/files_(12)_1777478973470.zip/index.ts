// index.ts — POST refactor de users.ts
// Cambio: `./users` ya no exporta las 5 tablas. Se añaden 4 exports nuevos.
// Resultado funcionalmente idéntico: los mismos símbolos (usersTable,
// auditLogTable, approvalsTable, messagesTable, rateLimitsTable) siguen
// disponibles y ningún import externo necesita cambiar.

export * from "./projects";
export * from "./products";
export * from "./redesigns";
export * from "./generation_jobs";
export * from "./ab_tests";
export * from "./cogs";
export * from "./visual_dna";
export * from "./seo_data";
export * from "./bulk_jobs";

// ─── users.ts refactorizado en 5 archivos ────────────────────────────────────
export * from "./users";          // userRoleEnum, usersTable
export * from "./audit_log";      // auditLogTable
export * from "./approvals";      // approvalStatusEnum, approvalsTable
export * from "./chat_messages";  // messagesTable
export * from "./rate_limits";    // rateLimitsTable

export * from "./cms";
export * from "./intelligence";
export * from "./inventory";
export * from "./onboarding";
export * from "./competitors";
export * from "./billing";
export * from "./shopybrain";
export * from "./project_files";
export * from "./conversations";
export * from "./messages";       // gemini_messages (NO confundir con chat_messages)
export * from "./platform_settings";
export * from "./sessions";
export * from "./priceHistory";
export * from "./email_templates";
export * from "./email_flows";
export * from "./audit_results";
export * from "./report_templates";
