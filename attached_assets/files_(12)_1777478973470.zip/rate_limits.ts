// rate_limits.ts — extraído de users.ts
import { pgTable, text, integer, timestamp, index } from "drizzle-orm/pg-core";

export const rateLimitsTable = pgTable("rate_limits", {
  key:          text("key").primaryKey(),
  count:        integer("count").notNull().default(0),
  blockedUntil: timestamp("blocked_until", { withTimezone: true }),
  updatedAt:    timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_rate_limits_blocked_until").on(t.blockedUntil),
]);

export type RateLimit = typeof rateLimitsTable.$inferSelect;
