/**
 * FIX BE-22: Circuit breaker para la API de Shopify.
 *
 * Problema original: si Shopify cae o tiene problemas sostenidos (5xx, timeouts),
 * seguimos machacándolo con requests que fallan. Cada request:
 *   - Consume slots de nuestro worker pool
 *   - Agota timeouts (45s cada una)
 *   - Satura la API de Shopify y nos aumenta la probabilidad de ban
 *   - Hace esperar al usuario que está mirando el loading
 *
 * Fix: circuit breaker con 3 estados:
 *   - CLOSED:    requests pasan normalmente
 *   - OPEN:      se descartan inmediatamente con error "Shopify degraded"
 *                tras N fallos en una ventana
 *   - HALF_OPEN: tras un cooldown, deja pasar 1 request para testear
 *                si Shopify se recuperó
 *
 * Usa `opossum` (librería estándar de la industria, mantenida por Red Hat).
 *
 * APLICAR EN: artifacts/api-server/src/lib/shopify.ts
 * DEPENDENCIA:
 *   pnpm add opossum --filter @workspace/api-server
 *   pnpm add -D @types/opossum --filter @workspace/api-server
 */

import CircuitBreaker from "opossum";
import { logger } from "./logger.js";

// ─── Un breaker POR proyecto (cada tienda tiene su propio estado) ────────────
// Así un breaker abierto para tienda A no afecta a tienda B.
// Limit de 500 proyectos activos a la vez (LRU).

interface BreakerEntry {
  breaker: CircuitBreaker<unknown[], unknown>;
  lastUsed: number;
}

const breakers = new Map<number, BreakerEntry>();
const MAX_BREAKERS_CACHED = 500;

// ─── Opciones del circuit breaker ────────────────────────────────────────────
const BREAKER_OPTIONS: CircuitBreaker.Options = {
  // Si el 50% de las requests fallan en la ventana, abrir el breaker
  errorThresholdPercentage: 50,
  // Ventana de evaluación — si hay <=5 requests en 30s, no abrir por falsos +
  volumeThreshold: 5,
  // Tiempo que el breaker permanece abierto antes de probar HALF_OPEN
  resetTimeout: 30_000,     // 30 segundos
  // Ventana deslizante para calcular el porcentaje de errores
  rollingCountTimeout: 60_000,   // 1 minuto
  rollingCountBuckets: 10,
  // Timeout por llamada individual (además del timeout interno de fetch)
  timeout: 60_000,          // 1 minuto — fetch ya tiene 45s, este es belt-and-suspenders
  // Nombre para métricas
  name: "shopify-api",
};

// ─── Obtener / crear breaker para un proyecto ────────────────────────────────
function getBreakerFor(projectId: number): CircuitBreaker<unknown[], unknown> {
  const existing = breakers.get(projectId);
  if (existing) {
    existing.lastUsed = Date.now();
    return existing.breaker;
  }

  // Eviction LRU si tenemos demasiados
  if (breakers.size >= MAX_BREAKERS_CACHED) {
    let oldestId: number | null = null;
    let oldestTime = Infinity;
    for (const [id, entry] of breakers) {
      if (entry.lastUsed < oldestTime) {
        oldestTime = entry.lastUsed;
        oldestId = id;
      }
    }
    if (oldestId !== null) {
      breakers.get(oldestId)?.breaker.shutdown();
      breakers.delete(oldestId);
    }
  }

  // Crear breaker nuevo
  const breaker = new CircuitBreaker(
    // La función "wrappeable" — solo llama a `fn()` que recibe como argumento.
    // Esto nos permite reutilizar el breaker para diferentes llamadas al API.
    async (fn: () => Promise<unknown>) => fn(),
    { ...BREAKER_OPTIONS, name: `shopify-api-${projectId}` },
  );

  // Eventos para logging y observabilidad
  breaker.on("open", () => {
    logger.warn({ projectId }, "[CircuitBreaker] OPEN — Shopify degraded, fast-failing requests for 30s");
  });
  breaker.on("halfOpen", () => {
    logger.info({ projectId }, "[CircuitBreaker] HALF_OPEN — testing Shopify recovery");
  });
  breaker.on("close", () => {
    logger.info({ projectId }, "[CircuitBreaker] CLOSED — Shopify healthy again");
  });
  breaker.on("reject", () => {
    // Counter-only log, no spam
  });
  breaker.on("timeout", () => {
    logger.warn({ projectId }, "[CircuitBreaker] Shopify call timeout");
  });

  breakers.set(projectId, { breaker, lastUsed: Date.now() });
  return breaker;
}

// ─── Wrapper pública ────────────────────────────────────────────────────────

export class ShopifyCircuitBreakerError extends Error {
  readonly projectId: number;
  readonly reason: "open" | "timeout";
  constructor(projectId: number, reason: "open" | "timeout", underlying?: Error) {
    const suffix = reason === "open"
      ? "Shopify no está respondiendo — reintenta en 30 segundos"
      : "Timeout de Shopify — reintenta en un momento";
    super(`[project:${projectId}] ${suffix}${underlying ? `: ${underlying.message}` : ""}`);
    this.projectId = projectId;
    this.reason = reason;
    this.name = "ShopifyCircuitBreakerError";
  }
}

/**
 * Envuelve una llamada a la API de Shopify en el circuit breaker del proyecto.
 *
 * Uso:
 *   const data = await withShopifyBreaker(projectId, () =>
 *     fetch(url, { headers, signal }).then(r => r.json())
 *   );
 *
 * Si el breaker está OPEN, lanza ShopifyCircuitBreakerError inmediatamente
 * sin llamar a Shopify.
 */
export async function withShopifyBreaker<T>(
  projectId: number,
  fn: () => Promise<T>,
): Promise<T> {
  const breaker = getBreakerFor(projectId);

  try {
    return (await breaker.fire(fn)) as T;
  } catch (err) {
    if (breaker.opened) {
      throw new ShopifyCircuitBreakerError(projectId, "open", err instanceof Error ? err : undefined);
    }
    throw err;
  }
}

// ─── Health endpoint helper ──────────────────────────────────────────────────

/**
 * Devuelve estado de todos los breakers activos para monitoring.
 */
export function getCircuitBreakerSnapshot(): Array<{
  projectId: number;
  state: "closed" | "open" | "halfOpen";
  stats: {
    fires: number;
    successes: number;
    failures: number;
    rejects: number;
    timeouts: number;
  };
  lastUsed: string;
}> {
  const result: Array<{
    projectId: number;
    state: "closed" | "open" | "halfOpen";
    stats: { fires: number; successes: number; failures: number; rejects: number; timeouts: number };
    lastUsed: string;
  }> = [];

  for (const [projectId, entry] of breakers) {
    const b = entry.breaker;
    const state: "closed" | "open" | "halfOpen" =
      b.opened ? "open" : b.halfOpen ? "halfOpen" : "closed";
    result.push({
      projectId,
      state,
      stats: {
        fires: b.stats.fires,
        successes: b.stats.successes,
        failures: b.stats.failures,
        rejects: b.stats.rejects,
        timeouts: b.stats.timeouts,
      },
      lastUsed: new Date(entry.lastUsed).toISOString(),
    });
  }

  return result.sort((a, b) => a.projectId - b.projectId);
}

/*
═══════════════════════════════════════════════════════════════════════════════
INTEGRACIÓN EN shopify.ts EXISTENTE
═══════════════════════════════════════════════════════════════════════════════

El objetivo es envolver TODAS las llamadas REST y GraphQL con el breaker.
Modificar las funciones shopifyRequest, shopifyRequestPaged, shopifyGraphQL.

EJEMPLO — shopifyRequest:

ANTES:
  export async function shopifyRequest<T>(projectId, shopDomain, path, options) {
    const domain = normalizeShopDomain(shopDomain);
    const headers = await getShopifyHeaders(projectId);
    const url = `https://${domain}/admin/api/2025-01${path}`;

    const doFetch = (hdrs) => () =>
      fetch(url, { ...options, headers: {...hdrs, ...options.headers},
                   signal: AbortSignal.timeout(SHOPIFY_FETCH_TIMEOUT) });

    try {
      return await shopifyRetry<T>(doFetch(headers), path, projectId);
    } catch (err) { /* 401 handling */ }
  }

DESPUÉS:
  import { withShopifyBreaker } from "./shopify-circuit-breaker.js";

  export async function shopifyRequest<T>(projectId, shopDomain, path, options) {
    return withShopifyBreaker(projectId, async () => {
      const domain = normalizeShopDomain(shopDomain);
      const headers = await getShopifyHeaders(projectId);
      const url = `https://${domain}/admin/api/2025-01${path}`;

      const doFetch = (hdrs) => () =>
        fetch(url, { ...options, headers: {...hdrs, ...options.headers},
                     signal: AbortSignal.timeout(SHOPIFY_FETCH_TIMEOUT) });

      try {
        return await shopifyRetry<T>(doFetch(headers), path, projectId);
      } catch (err) { /* 401 handling (no cambia) */ }
    });
  }

IMPORTANTE:
- El breaker considera una request "fallo" si lanza cualquier error.
- Los 401 que se auto-resuelven (refresh token + retry) NO son fallos desde
  el punto de vista del breaker porque la función completa no throw-ea.
- Los 429 después de los 3 reintentos SÍ son fallos (correcto — quiere decir
  que Shopify nos está rate-limitando persistentemente).

═══════════════════════════════════════════════════════════════════════════════
HEALTH ENDPOINT (añadir en routes/health.ts)
═══════════════════════════════════════════════════════════════════════════════

import { getCircuitBreakerSnapshot } from "../lib/shopify-circuit-breaker.js";

router.get("/shopify-breakers", requireAdmin, (_req, res) => {
  const snapshot = getCircuitBreakerSnapshot();
  const summary = {
    total: snapshot.length,
    closed: snapshot.filter(s => s.state === "closed").length,
    open: snapshot.filter(s => s.state === "open").length,
    halfOpen: snapshot.filter(s => s.state === "halfOpen").length,
    breakers: snapshot,
  };
  res.json(summary);
});

═══════════════════════════════════════════════════════════════════════════════
MANEJO EN EL FRONTEND
═══════════════════════════════════════════════════════════════════════════════

Cuando el breaker está abierto, el backend responde con 503 + mensaje claro.
El frontend puede detectarlo y mostrar un mensaje amigable:

// En src/lib/api.ts (friendlyErrorMessage):
if (err.message.includes("Shopify no está respondiendo")) {
  return "⚠️ Shopify temporalmente no disponible. Reintenta en 30 segundos.";
}

Y permitir retry manual tras el cooldown.
═══════════════════════════════════════════════════════════════════════════════
*/
