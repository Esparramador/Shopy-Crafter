# Fixes pendientes — BE-9, BE-12, BE-15, BE-16, BE-22

Los últimos 5 hallazgos opcionales del Bloque C/D/E. Con esto se cierra la
auditoría al **100%** (69/69 hallazgos con código aplicable).

---

## Contenido

```
fixes-pendientes/
├── README.md                           ← este archivo
├── BE-9_contact-rate-limit.ts          ← contact.ts rate limit migrado a PG
├── BE-12_cache-redis-adapter.ts        ← cache con adapter Redis opcional
├── BE-15_claude-telemetry.ts           ← telemetría de tokens Claude
├── BE-16_gemini-key-rotation.ts        ← rotación Gemini API key sin reiniciar
└── BE-22_shopify-circuit-breaker.ts    ← circuit breaker para Shopify API
```

Cada archivo está **completo con código funcional** + comentarios extensivos
que explican la integración paso a paso.

---

## Resumen de cada fix

### BE-9 · contact.ts rate limit → PG

**Antes:** `Map<string, ...>` en memoria que se perdía con cada reinicio.

**Ahora:** `PgRateLimitStore` + `express-rate-limit`, persistente y distribuido.

**Aplicación:**
1. Abrir `artifacts/api-server/src/routes/contact.ts`.
2. Eliminar la función `checkContactRateLimit` y el `contactRateMap`.
3. Añadir el import y la constante `contactLimiter` del archivo BE-9.
4. Añadir `contactLimiter` como middleware a las rutas POST.
5. Eliminar los chequeos manuales en los handlers.

**Tiempo:** 5-10 min. Sin dependencias nuevas.

---

### BE-12 · cache.ts → adapter Redis

**Antes:** cache en `Map` local. Solo sirve con 1 worker.

**Ahora:** adapter transparente que usa `Redis` si `REDIS_URL` está definido,
o sigue usando `Map` local si no. **Cero impacto en los callers existentes**.

**Aplicación:**
1. Reemplazar `artifacts/api-server/src/lib/cache.ts` con el archivo BE-12.
2. Si quieres usar Redis: `pnpm add ioredis --filter @workspace/api-server` y
   `pnpm add -D @types/ioredis --filter @workspace/api-server`.
3. Setear `REDIS_URL` en el env.
4. Si no, dejarlo como está — seguirá con Map y funcionará idéntico.

**Importante:** la API pasa de **sync** a **async** (pequeño breaking change).
Verifica que todos los callers hacen `await cached(...)` — en tu código sí lo hacen.

**Tiempo:** 10 min (solo reemplazo) + 1h si quieres configurar Redis.

---

### BE-15 · telemetría Claude tokens

**Antes:** si un `AbortSignal.timeout` cancelaba a Claude, el contador de tokens
se perdía. Facturación opaca.

**Ahora:** wrapper `instrumentedClaudeCall` que registra:
- Tokens consumidos (input/output) en éxito, fallo y timeout.
- Duración, status, estimación de coste en USD.
- Log a pino + tabla `ai_usage_log`.
- Snapshot en memoria para un endpoint `/health/ai-usage`.

**Aplicación:**
1. Crear `artifacts/api-server/src/lib/claude-telemetry.ts` con el archivo BE-15.
2. Crear schema `lib/db/src/schema/ai_usage.ts` (código en el comentario del archivo).
3. Aplicar la migración SQL (en el comentario) — crea tabla `ai_usage_log`.
4. Envolver cada llamada al SDK de Claude en `lib/claude.ts` con `instrumentedClaudeCall`.
5. Añadir endpoint `GET /api/health/ai-usage` con el código del comentario.

**Tiempo:** 1-2 h (integración en 5-6 funciones de `lib/claude.ts`).

---

### BE-16 · rotación Gemini API key

**Antes:** cliente singleton que se crea una vez. Si rotas la key, hay que
reiniciar el proceso.

**Ahora:**
- Factory con hash de config. Detecta cambios en env vars o en `platform_settings`.
- Cache de 60s antes de consultar la DB (no satura en cada llamada).
- Endpoint `POST /api/admin/ai-keys/refresh` para forzar refresh manual.
- Telemetría ligera similar a Claude.

**Aplicación:**
1. Reemplazar la sección de `getGeminiClient` en `artifacts/api-server/src/lib/gemini.ts`
   con el código del archivo BE-16 (o integrar como módulo separado).
2. Envolver las llamadas a `ai.models.generateContent` con `instrumentedGeminiCall`.
3. Añadir endpoint admin para refresh manual.
4. (Opcional) Guardar la key en `platform_settings` cifrada para rotar desde UI.

**Tiempo:** 1 h.

---

### BE-22 · circuit breaker Shopify

**Antes:** si Shopify falla, seguimos intentando request tras request. Saturamos
sus APIs, aumentamos probabilidad de ban y hacemos esperar al usuario.

**Ahora:** circuit breaker con 3 estados (CLOSED/OPEN/HALF_OPEN) usando `opossum`:
- Un breaker **por proyecto** (si tienda A falla, tienda B sigue funcionando).
- Se abre cuando >50% de las requests fallan en 60s (con >=5 requests).
- Cooldown de 30s antes de probar HALF_OPEN.
- Error tipado `ShopifyCircuitBreakerError` para manejar en el frontend.
- LRU de 500 breakers cacheados (evita leak de memoria con muchos proyectos).
- Health endpoint con estado de todos los breakers.

**Aplicación:**
1. `pnpm add opossum --filter @workspace/api-server`.
2. `pnpm add -D @types/opossum --filter @workspace/api-server`.
3. Crear `artifacts/api-server/src/lib/shopify-circuit-breaker.ts` con el código BE-22.
4. En `lib/shopify.ts`, envolver las 3 funciones principales con `withShopifyBreaker`:
   - `shopifyRequest`
   - `shopifyRequestPaged`
   - `shopifyGraphQL`
5. Añadir endpoint `GET /api/health/shopify-breakers` para monitoring.
6. En el frontend (`lib/api.ts` del Bloque B), añadir manejo del error:
   ```typescript
   if (err.message.includes("Shopify no está respondiendo")) {
     return "⚠️ Shopify temporalmente no disponible. Reintenta en 30 segundos.";
   }
   ```

**Tiempo:** 2-3 h (incluyendo test de que los 401 con auto-refresh NO abren el breaker).

---

## Orden de aplicación recomendado

Empezar por los **más baratos** y terminar por los **más impactantes**:

1. **BE-9** (5-10 min) — 1 archivo, sin dependencias. Aplicar ya.
2. **BE-16** (1 h) — útil si vas a rotar Gemini keys por seguridad periódicamente.
3. **BE-15** (1-2 h) — imprescindible para controlar gasto de IA.
4. **BE-22** (2-3 h) — crítico si tienes >5 tiendas — protege contra outages de Shopify.
5. **BE-12** (10 min + 1h config) — solo si vas a escalar a >1 worker. Dejar para el final.

**Total:** 5-7 horas para cerrar el 100% de la auditoría.

---

## Verificación post-aplicación

Para cada fix, verificar con:

### BE-9
```bash
# Intentar enviar el formulario de contacto 6 veces seguidas desde la misma IP
for i in {1..6}; do
  curl -X POST http://localhost:8080/api/contact/submit \
    -H "Content-Type: application/json" \
    -d '{"name":"test","email":"test@test.com","services":["audit"],"submittedAt":"'$(date -Iseconds)'"}'
  echo ""
done
# Esperar: 5 respuestas OK, la 6ª con 429 y el mensaje del rate limit
```

### BE-12
```bash
# Sin REDIS_URL (default):
pnpm dev
# Debería loggear: "Cache: using in-memory Map (single-worker mode)"

# Con REDIS_URL:
REDIS_URL=redis://localhost:6379 pnpm dev
# Debería loggear: "Cache: Redis connected" + "Cache: using Redis backend"
```

### BE-15
```bash
# Tras aplicar el fix, hacer cualquier llamada que use Claude:
curl -X POST http://localhost:8080/api/shopybrain/search \
  -H "Content-Type: application/json" \
  -d '{"query":"test"}' \
  --cookie "connect.sid=tu-session"

# Ver el health:
curl http://localhost:8080/api/health/ai-usage \
  --cookie "connect.sid=tu-admin-session"

# Esperar:
#  { since: "...", totals: { calls: 1, success: 1, ... },
#    tokens: { input: 500, output: 200 }, estimatedCostUsd: "0.00450" }
```

### BE-16
```bash
# Forzar refresh manual:
curl -X POST http://localhost:8080/api/admin/ai-keys/refresh \
  --cookie "connect.sid=tu-admin-session"
# Esperar: { success: true, message: "Gemini client refreshed" }

# Log del servidor debería mostrar:
# [Gemini] Client manually refreshed
# [Gemini] Client re-initialized with new API key (direct)
```

### BE-22
```bash
# Simular que Shopify falla — cambiar shopDomain a algo inválido:
# Hacer 6+ requests rápidas. Tras 5 fallos en 60s, el breaker se abre.

# Health:
curl http://localhost:8080/api/health/shopify-breakers \
  --cookie "connect.sid=tu-admin-session"
# Esperar al menos un breaker con state: "open"

# Esperar 30s y una nueva request debería ir a HALF_OPEN.
```

---

## Estado final de la auditoría Shopy Crafter

| Bloque | Hallazgos | Código aplicable | Documentados |
|---|---|---|---|
| A — shopybrain.ts | 25 | 25/25 | 25/25 |
| B — frontend | 20 | 20/20 | 20/20 |
| C/D/E — backend+lib+schema | 24 | 24/24 | 24/24 |
| **TOTAL** | **69** | **69/69** | **69/69** |

**Todos los hallazgos tienen código aplicable o patrón documentado.**

---

## Próximos pasos recomendados (fuera de la auditoría)

Una vez aplicados estos 5 fixes, lo siguiente naturalmente es:

1. **Monitoring real** — integrar Sentry/Datadog (el endpoint `/api/error-report`
   del Bloque B es solo el hook; falta el provider).
2. **CI/CD** — GitHub Actions con `pnpm typecheck + pnpm test + pnpm build`.
3. **Tests E2E** — Playwright de flujos críticos (login, crear proyecto,
   OmniChatbot, billing, invite flow).
4. **Observability** — dashboards de Grafana o similar con las métricas de
   `ai_usage_log` y los breakers de Shopify.

Si quieres que genere cualquiera de estos, dímelo.
