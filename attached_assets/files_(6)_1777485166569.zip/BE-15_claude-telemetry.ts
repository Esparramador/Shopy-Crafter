/**
 * FIX BE-15: telemetría de tokens de Claude.
 *
 * Problema original: cuando `AbortSignal.timeout()` cancelaba una petición
 * a Claude, se perdía el contador de tokens consumidos. Anthropic puede haber
 * procesado durante 3 minutos antes de cancelar — el coste queda opaco.
 *
 * Fix: wrapper que:
 *  1. Mide tokens consumidos (input + output) en éxito, fallo y cancelación.
 *  2. Guarda métricas en tabla `ai_usage_log` para análisis posterior.
 *  3. Loggea con pino, incluyendo projectId y duración.
 *  4. Actualiza contador in-memory para health checks.
 *
 * APLICAR EN: artifacts/api-server/src/lib/claude.ts
 *
 * SCHEMA NUEVO REQUERIDO:
 *   Añadir en lib/db/src/schema/ai_usage.ts (nuevo archivo) — ver abajo.
 */

import Anthropic from "@anthropic-ai/sdk";
import { db } from "@workspace/db";
// Cuando tengas el schema creado:
// import { aiUsageLogTable } from "@workspace/db";
import { logger } from "./logger.js";
import { randomBytes } from "crypto";

// ─── Métricas in-memory (para /health y agregaciones rápidas) ────────────────
interface UsageSnapshot {
  callsTotal: number;
  callsSuccess: number;
  callsFailed: number;
  callsTimedOut: number;
  inputTokensTotal: number;
  outputTokensTotal: number;
  lastReset: number;
}

const usage: UsageSnapshot = {
  callsTotal: 0,
  callsSuccess: 0,
  callsFailed: 0,
  callsTimedOut: 0,
  inputTokensTotal: 0,
  outputTokensTotal: 0,
  lastReset: Date.now(),
};

export function getClaudeUsageSnapshot(): UsageSnapshot & { hours: number } {
  return {
    ...usage,
    hours: (Date.now() - usage.lastReset) / 3_600_000,
  };
}

export function resetClaudeUsageSnapshot(): void {
  usage.callsTotal = 0;
  usage.callsSuccess = 0;
  usage.callsFailed = 0;
  usage.callsTimedOut = 0;
  usage.inputTokensTotal = 0;
  usage.outputTokensTotal = 0;
  usage.lastReset = Date.now();
}

// ─── Costes aproximados (actualizar según modelo usado) ──────────────────────
// Claude Sonnet 4.5: $3/1M input, $15/1M output (orientativo Q4 2024 — ajustar)
const CLAUDE_COST_PER_MTOK_INPUT = 3.0;
const CLAUDE_COST_PER_MTOK_OUTPUT = 15.0;

function estimateCost(inputTokens: number, outputTokens: number): number {
  return (inputTokens / 1_000_000) * CLAUDE_COST_PER_MTOK_INPUT
       + (outputTokens / 1_000_000) * CLAUDE_COST_PER_MTOK_OUTPUT;
}

// ─── Logger persistente en DB (fire-and-forget) ──────────────────────────────
interface UsageLogParams {
  projectId: number | null;
  useCase: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
  durationMs: number;
  status: "success" | "failed" | "timeout" | "cancelled";
  errorMessage?: string | null;
  maxTokens?: number;
  hitMaxTokens?: boolean;
}

async function logUsageToDb(params: UsageLogParams): Promise<void> {
  try {
    // Cuando tengas el schema creado, descomenta:
    //
    // await db.insert(aiUsageLogTable).values({
    //   id: randomBytes(16).toString("hex"),
    //   projectId: params.projectId,
    //   useCase: params.useCase,
    //   provider: "claude",
    //   model: params.model,
    //   inputTokens: params.inputTokens,
    //   outputTokens: params.outputTokens,
    //   estimatedCostUsd: estimateCost(params.inputTokens, params.outputTokens),
    //   durationMs: params.durationMs,
    //   status: params.status,
    //   errorMessage: params.errorMessage ?? null,
    //   maxTokens: params.maxTokens ?? null,
    //   hitMaxTokens: params.hitMaxTokens ? 1 : 0,
    //   createdAt: new Date(),
    // });
  } catch (err) {
    // Nunca fallar el flujo principal por un problema de logging
    logger.warn({ err }, "Failed to write ai_usage_log");
  }
}

// ─── Wrapper principal: instrumentedClaudeCall ────────────────────────────────

export interface ClaudeCallContext {
  projectId: number | null;
  useCase: string;
  model: string;
  maxTokens: number;
}

/**
 * Ejecuta una llamada a Claude y mide tokens consumidos, duración, estado.
 * Usa la respuesta del SDK (`response.usage`) para contar tokens exactos.
 * En cancelación/timeout no hay `response.usage` → marcamos como aproximado.
 */
export async function instrumentedClaudeCall<T extends { usage?: Anthropic.Messages.Usage; stop_reason?: string | null }>(
  ctx: ClaudeCallContext,
  callFn: () => Promise<T>,
): Promise<T> {
  const start = Date.now();
  usage.callsTotal++;

  try {
    const response = await callFn();
    const durationMs = Date.now() - start;

    const inputTokens = response.usage?.input_tokens ?? 0;
    const outputTokens = response.usage?.output_tokens ?? 0;
    const hitMaxTokens = response.stop_reason === "max_tokens";

    usage.callsSuccess++;
    usage.inputTokensTotal += inputTokens;
    usage.outputTokensTotal += outputTokens;

    if (hitMaxTokens) {
      logger.warn({
        projectId: ctx.projectId, useCase: ctx.useCase, model: ctx.model,
        inputTokens, outputTokens, maxTokens: ctx.maxTokens,
      }, "[Claude] ⚠️ RESPONSE TRUNCATED — hit max_tokens");
    } else {
      logger.info({
        projectId: ctx.projectId, useCase: ctx.useCase, model: ctx.model,
        inputTokens, outputTokens, durationMs,
        estimatedCostUsd: estimateCost(inputTokens, outputTokens).toFixed(5),
      }, "[Claude] Call OK");
    }

    void logUsageToDb({
      projectId: ctx.projectId,
      useCase: ctx.useCase,
      model: ctx.model,
      inputTokens, outputTokens, durationMs,
      status: "success",
      maxTokens: ctx.maxTokens,
      hitMaxTokens,
    });

    return response;
  } catch (err: unknown) {
    const durationMs = Date.now() - start;
    const errMsg = err instanceof Error ? err.message : String(err);
    const isTimeout = errMsg.includes("aborted") || errMsg.includes("timeout");

    if (isTimeout) usage.callsTimedOut++;
    else usage.callsFailed++;

    logger.error({
      projectId: ctx.projectId, useCase: ctx.useCase, model: ctx.model,
      durationMs, maxTokens: ctx.maxTokens, err: errMsg,
      status: isTimeout ? "timeout" : "failed",
    }, "[Claude] Call FAILED");

    void logUsageToDb({
      projectId: ctx.projectId,
      useCase: ctx.useCase,
      model: ctx.model,
      inputTokens: 0,  // desconocido en error
      outputTokens: 0,
      durationMs,
      status: isTimeout ? "timeout" : "failed",
      errorMessage: errMsg.slice(0, 500),
      maxTokens: ctx.maxTokens,
    });

    throw err;
  }
}

/*
═══════════════════════════════════════════════════════════════════════════════
INTEGRACIÓN EN lib/claude.ts EXISTENTE
═══════════════════════════════════════════════════════════════════════════════

En las funciones askClaude, askClaudeJson, askClaudeWithVision, etc., envolver
la llamada al SDK con instrumentedClaudeCall. Ejemplo:

ANTES:
  export async function askClaude(projectId, messages, systemPrompt, maxTokens = 8192, timeoutMs = 180_000) {
    const { withClaudeQueue } = await import("./claude-queue.js");
    return withClaudeQueue(async () => {
      const client = await getClaudeClient(projectId);
      const stream = client.messages.stream({ model, max_tokens, system, messages },
        { signal: AbortSignal.timeout(timeoutMs) });
      const response = await stream.finalMessage();
      // ... check stop_reason ...
      const content = response.content[0];
      if (content.type !== "text") throw new Error(...);
      return content.text;
    });
  }

DESPUÉS:
  export async function askClaude(projectId, messages, systemPrompt, maxTokens = 8192, timeoutMs = 180_000) {
    const { withClaudeQueue } = await import("./claude-queue.js");
    return withClaudeQueue(async () => {
      const client = await getClaudeClient(projectId);
      const response = await instrumentedClaudeCall(
        { projectId, useCase: "generic", model: CLAUDE_MODEL, maxTokens },
        async () => {
          const stream = client.messages.stream(
            { model: CLAUDE_MODEL, max_tokens: maxTokens,
              system: systemPrompt ?? SHOPIFY_EXPERT_SYSTEM, messages },
            { signal: AbortSignal.timeout(timeoutMs) }
          );
          return stream.finalMessage();
        },
      );
      const content = response.content[0];
      if (content.type !== "text") throw new Error("Unexpected non-text Claude response");
      return content.text;
    });
  }

Hacer lo mismo para askClaudeJson, askClaudeWithVision, askClaudeWithBrain, etc.
En cada caso, pasar el useCase correcto: "json", "vision", "brand_analysis", etc.
═══════════════════════════════════════════════════════════════════════════════

SCHEMA DRIZZLE (lib/db/src/schema/ai_usage.ts) — ARCHIVO NUEVO:

import { pgTable, text, integer, real, timestamp, index } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";

export const aiUsageLogTable = pgTable("ai_usage_log", {
  id: text("id").primaryKey(),
  projectId: integer("project_id").references(() => projectsTable.id, { onDelete: "set null" }),
  useCase: text("use_case").notNull(),
  provider: text("provider").notNull(),
  model: text("model").notNull(),
  inputTokens: integer("input_tokens").notNull().default(0),
  outputTokens: integer("output_tokens").notNull().default(0),
  estimatedCostUsd: real("estimated_cost_usd").notNull().default(0),
  durationMs: integer("duration_ms").notNull().default(0),
  status: text("status").notNull(),
  errorMessage: text("error_message"),
  maxTokens: integer("max_tokens"),
  hitMaxTokens: integer("hit_max_tokens").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  idxProjectCreated: index("idx_ai_usage_project_created").on(table.projectId, table.createdAt),
  idxProviderModel: index("idx_ai_usage_provider_model").on(table.provider, table.model),
  idxStatus: index("idx_ai_usage_status").on(table.status),
  idxUseCase: index("idx_ai_usage_use_case").on(table.useCase, table.createdAt),
}));

Y añadirlo a lib/db/src/schema/index.ts:
  export * from "./ai_usage";

SQL directa (aplicar en la próxima migración):

CREATE TABLE IF NOT EXISTS ai_usage_log (
  id text PRIMARY KEY,
  project_id integer REFERENCES projects(id) ON DELETE SET NULL,
  use_case text NOT NULL,
  provider text NOT NULL,
  model text NOT NULL,
  input_tokens integer NOT NULL DEFAULT 0,
  output_tokens integer NOT NULL DEFAULT 0,
  estimated_cost_usd real NOT NULL DEFAULT 0,
  duration_ms integer NOT NULL DEFAULT 0,
  status text NOT NULL,
  error_message text,
  max_tokens integer,
  hit_max_tokens integer NOT NULL DEFAULT 0,
  created_at timestamp NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ai_usage_project_created ON ai_usage_log(project_id, created_at);
CREATE INDEX IF NOT EXISTS idx_ai_usage_provider_model ON ai_usage_log(provider, model);
CREATE INDEX IF NOT EXISTS idx_ai_usage_status ON ai_usage_log(status);
CREATE INDEX IF NOT EXISTS idx_ai_usage_use_case ON ai_usage_log(use_case, created_at);

═══════════════════════════════════════════════════════════════════════════════

HEALTH ENDPOINT (añadir en routes/health.ts):

import { getClaudeUsageSnapshot } from "../lib/claude-telemetry.js";

router.get("/ai-usage", requireAdmin, (_req, res) => {
  const snapshot = getClaudeUsageSnapshot();
  const estimatedCost = estimateCost(snapshot.inputTokensTotal, snapshot.outputTokensTotal);
  res.json({
    since: new Date(snapshot.lastReset).toISOString(),
    hours: snapshot.hours.toFixed(2),
    totals: {
      calls: snapshot.callsTotal,
      success: snapshot.callsSuccess,
      failed: snapshot.callsFailed,
      timedOut: snapshot.callsTimedOut,
      successRate: snapshot.callsTotal === 0 ? 1
                 : (snapshot.callsSuccess / snapshot.callsTotal).toFixed(3),
    },
    tokens: {
      input: snapshot.inputTokensTotal,
      output: snapshot.outputTokensTotal,
    },
    estimatedCostUsd: estimatedCost.toFixed(4),
  });
});

═══════════════════════════════════════════════════════════════════════════════
*/
