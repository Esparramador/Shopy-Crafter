/**
 * FIX BE-9: contact.ts rate limit migrado de Map en memoria a PG.
 *
 * Problema original: `const contactRateMap = new Map<string, ...>()` dentro
 * del archivo. Se perdía con cada reinicio y no era distribuido.
 *
 * Fix: usar `PgRateLimitStore` + `express-rate-limit`, igual que el resto
 * de la app. Compatible con múltiples workers, persistente, con cleanup automático.
 *
 * APLICAR EN: artifacts/api-server/src/routes/contact.ts
 *
 * PARCHE A APLICAR — reemplazar el bloque de rate limit (líneas 20-35) por
 * el siguiente código. El resto del archivo queda igual.
 */

import rateLimit from "express-rate-limit";
import { PgRateLimitStore } from "../lib/pg-rate-limit-store.js";

// ─── FIX BE-9: rate limit de contact migrado a PostgreSQL ──────────────
// 5 submissions/hora por IP, fail-closed si la DB no responde.
// Se aplica directamente a la ruta en vez de chequear en cada handler.
export const contactLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,        // 1 hora
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  store: new PgRateLimitStore("contact"),
  message: {
    error: "Has alcanzado el límite de envíos de este formulario. Inténtalo de nuevo en una hora.",
    code: "CONTACT_RATE_LIMITED",
  },
  // En dev permite iteración rápida sin pegarse con el rate limit
  skip: () => process.env.NODE_ENV === "development" || process.env.NODE_ENV === "test",
});

// ─── ELIMINAR DEL ARCHIVO ORIGINAL ──────────────────────────────────────
//
// Eliminar estas líneas:
//
//   const contactRateMap = new Map<string, { count: number; resetAt: number }>();
//   function checkContactRateLimit(ip: string): boolean {
//     const now = Date.now();
//     const entry = contactRateMap.get(ip);
//     if (!entry || now > entry.resetAt) {
//       contactRateMap.set(ip, { count: 1, resetAt: now + 3600_000 });
//       return true;
//     }
//     if (entry.count >= 5) return false;
//     entry.count++;
//     return true;
//   }
//
// Y eliminar cada llamada `if (!checkContactRateLimit(ip)) { return 429 ... }`
// dentro de los handlers de POST /api/contact/*, porque ahora el middleware
// contactLimiter se encarga ANTES de llegar al handler.

// ─── APLICAR EL MIDDLEWARE A LAS RUTAS ──────────────────────────────────
//
// En el mismo archivo contact.ts, cambiar:
//
//   router.post("/submit", contactUpload.single("productImage"), async (req, res) => { ... });
//
// Por:
//
//   router.post("/submit", contactLimiter, contactUpload.single("productImage"), async (req, res) => { ... });
//
// Y para cualquier otro endpoint público que aún lo use.
//
// ─── REGISTRO EN routes/index.ts ────────────────────────────────────────
//
// NO requiere cambios — contact.ts ya se monta normalmente y el limiter
// está a nivel de handler.
