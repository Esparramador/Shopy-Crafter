/**
 * FIX BE-12: cache.ts con adapter opcional a Redis.
 *
 * Problema original: cache en Map local. Si se escala a >1 worker (PM2 cluster,
 * Docker replicas), cada worker tiene su propia cache y las entradas no se
 * comparten → misses, datos inconsistentes entre requests del mismo usuario.
 *
 * Fix: mantiene la API actual `cached(key, ttl, fn)` pero permite conectar
 * un backend Redis transparentemente. Si no hay REDIS_URL, sigue usando
 * Map local (comportamiento actual — único worker).
 *
 * APLICAR EN: artifacts/api-server/src/lib/cache.ts
 *
 * DEPENDENCIA OPCIONAL:
 *   pnpm add ioredis --filter @workspace/api-server
 *   pnpm add -D @types/ioredis --filter @workspace/api-server
 *   (no hacen falta si no vas a usar Redis)
 *
 * ENV VAR OPCIONAL:
 *   REDIS_URL=redis://default:password@host:6379/0
 *   # Si no existe, usa Map local (identico al comportamiento actual)
 */

import { logger } from "./logger.js";

// ─── Interfaz común ──────────────────────────────────────────────────────────
interface CacheBackend {
  get(key: string): Promise<unknown | null>;
  set(key: string, value: unknown, ttlMs: number): Promise<void>;
  delete(key: string): Promise<void>;
  clear(): Promise<void>;
  invalidatePrefix(prefix: string): Promise<void>;
}

// ─── Backend 1: Map en memoria (default, comportamiento actual) ─────────────
class MemoryCacheBackend implements CacheBackend {
  private store = new Map<string, { data: unknown; expires: number }>();

  constructor() {
    // Limpieza de expirados cada 5 min
    setInterval(() => this.sweep(), 300_000).unref();
  }

  async get(key: string): Promise<unknown | null> {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (entry.expires <= Date.now()) {
      this.store.delete(key);
      return null;
    }
    return entry.data;
  }

  async set(key: string, value: unknown, ttlMs: number): Promise<void> {
    this.store.set(key, { data: value, expires: Date.now() + ttlMs });
  }

  async delete(key: string): Promise<void> {
    this.store.delete(key);
  }

  async clear(): Promise<void> {
    this.store.clear();
  }

  async invalidatePrefix(prefix: string): Promise<void> {
    for (const key of this.store.keys()) {
      if (key.startsWith(prefix)) this.store.delete(key);
    }
  }

  private sweep(): void {
    const now = Date.now();
    for (const [key, entry] of this.store) {
      if (entry.expires < now) this.store.delete(key);
    }
  }
}

// ─── Backend 2: Redis (opcional, si REDIS_URL está configurado) ──────────────
class RedisCacheBackend implements CacheBackend {
  private redis: unknown; // tipo real: ioredis Redis
  private prefix: string;
  private available = true;

  constructor(redisClient: unknown, prefix = "cache:") {
    this.redis = redisClient;
    this.prefix = prefix;
  }

  private key(k: string): string {
    return this.prefix + k;
  }

  async get(key: string): Promise<unknown | null> {
    if (!this.available) return null;
    try {
      const raw = await (this.redis as { get(k: string): Promise<string | null> })
        .get(this.key(key));
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (err) {
      logger.warn({ err, key }, "Redis get failed — fallback null");
      return null;
    }
  }

  async set(key: string, value: unknown, ttlMs: number): Promise<void> {
    if (!this.available) return;
    try {
      const serialized = JSON.stringify(value);
      // PSETEX acepta TTL en ms directamente
      await (this.redis as { psetex(k: string, ttl: number, v: string): Promise<string> })
        .psetex(this.key(key), ttlMs, serialized);
    } catch (err) {
      logger.warn({ err, key }, "Redis set failed — cache miss next time");
    }
  }

  async delete(key: string): Promise<void> {
    if (!this.available) return;
    try {
      await (this.redis as { del(k: string): Promise<number> }).del(this.key(key));
    } catch {}
  }

  async clear(): Promise<void> {
    // No implementamos FLUSHDB porque puede afectar a otras apps.
    // Mejor invalidar por prefix.
    return this.invalidatePrefix("");
  }

  async invalidatePrefix(prefix: string): Promise<void> {
    if (!this.available) return;
    try {
      // SCAN es no-bloqueante; evita KEYS en producción
      const pattern = this.key(prefix) + "*";
      let cursor = "0";
      do {
        const [next, keys] = await (this.redis as {
          scan(c: string, m: string, p: string, cl: string, cnt: string): Promise<[string, string[]]>;
        }).scan(cursor, "MATCH", pattern, "COUNT", "100");
        cursor = next;
        if (keys.length > 0) {
          await (this.redis as { del(...k: string[]): Promise<number> }).del(...keys);
        }
      } while (cursor !== "0");
    } catch (err) {
      logger.warn({ err, prefix }, "Redis invalidatePrefix failed");
    }
  }
}

// ─── Inicialización del backend ──────────────────────────────────────────────
let backend: CacheBackend;

async function initBackend(): Promise<void> {
  const redisUrl = process.env.REDIS_URL;

  if (!redisUrl) {
    backend = new MemoryCacheBackend();
    logger.info("Cache: using in-memory Map (single-worker mode)");
    return;
  }

  try {
    // Import dinámico — solo carga ioredis si está configurado
    const { default: Redis } = await import("ioredis");
    const redis = new Redis(redisUrl, {
      retryStrategy: (times) => {
        if (times > 5) return null; // dar up tras 5 intentos
        return Math.min(times * 500, 5000);
      },
      maxRetriesPerRequest: 3,
      enableOfflineQueue: false, // fail fast si no hay conexión
    });

    redis.on("error", (err) => {
      logger.warn({ err: err.message }, "Redis connection error");
    });
    redis.on("connect", () => {
      logger.info("Cache: Redis connected");
    });

    backend = new RedisCacheBackend(redis);
    logger.info("Cache: using Redis backend");
  } catch (err) {
    logger.warn({ err }, "Cache: Redis init failed — falling back to Map");
    backend = new MemoryCacheBackend();
  }
}

// Init al cargar el módulo
initBackend().catch(() => {
  backend = new MemoryCacheBackend();
});

// Esperar a que backend esté listo antes de usarlo.
// En la práctica nunca bloqueará porque initBackend es síncrono en el caso Map.
async function getBackend(): Promise<CacheBackend> {
  while (!backend) {
    await new Promise((r) => setTimeout(r, 10));
  }
  return backend;
}

// ─── API pública — idéntica a la original ───────────────────────────────────

export async function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const b = await getBackend();
  const hit = await b.get(key);
  if (hit !== null) return hit as T;

  const data = await fn();
  await b.set(key, data, ttlMs);
  return data;
}

export async function invalidateCache(keyPrefix: string): Promise<void> {
  const b = await getBackend();
  await b.invalidatePrefix(keyPrefix);
}

export async function clearAllCache(): Promise<void> {
  const b = await getBackend();
  await b.clear();
}

/**
 * Devuelve estadísticas del backend actual (para endpoint de health).
 */
export async function cacheStats(): Promise<{ backend: string; connected: boolean }> {
  const b = await getBackend();
  return {
    backend: b instanceof MemoryCacheBackend ? "memory" : "redis",
    connected: true, // en Redis, un error haría fallback — si llega aquí está conectado
  };
}

/*
═══════════════════════════════════════════════════════════════════════════════
COMPATIBILIDAD HACIA ATRÁS
═══════════════════════════════════════════════════════════════════════════════

La API pública es la misma que la versión anterior:

  cached(key, ttl, fn)   → antes sync, ahora async. Los callers ya usan await.
  invalidateCache(prefix) → antes sync, ahora async. Revisar si hay sitios
                            que NO hagan await (buscar grep 'invalidateCache(').
  clearAllCache()        → idem.

COMMAND para verificar:
  grep -rn 'invalidateCache\|cached\|clearAllCache' artifacts/api-server/src/ \
    | grep -v '\.ts:[0-9]*:import'

Si algún sitio hace `invalidateCache("x");` sin await, sigue funcionando porque
devuelve Promise, pero no espera al cleanup. Mejor añadir `void` para que
TypeScript no se queje:
  void invalidateCache("x");
═══════════════════════════════════════════════════════════════════════════════
*/
