/**
 * FIX BE-16: rotación de Gemini API key sin reiniciar.
 *
 * Problema original: el cliente Gemini es un singleton que se inicializa una
 * sola vez. Si rotas la API key via panel admin o env vars actualizados,
 * el cliente sigue usando la key antigua hasta que reinicies el proceso.
 *
 * Fix: el factory del cliente chequea si las env vars han cambiado (por hash)
 * y recrea el cliente si es así. Sin reinicio. Sin impacto en performance
 * (el hash es O(1) y el cliente se reutiliza mientras no cambie).
 *
 * Añade también:
 *  - Hot-reload desde tabla `platform_settings` cada 60s (opcional, permite
 *    rotar la key desde la UI sin tocar env vars).
 *  - Telemetría básica de uso (similar a Claude pero más ligera).
 *
 * APLICAR EN: artifacts/api-server/src/lib/gemini.ts
 *
 * Reemplazar la sección "Base generation" y el factory getGeminiClient.
 */

import { GoogleGenAI } from "@google/genai";
import { logger } from "./logger.js";
import { db, platformSettingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { safeDecrypt } from "./crypto.js";

// ─── Estado del cliente + hash de la config actual ──────────────────────────
let _ai: GoogleGenAI | null = null;
let _aiConfigHash: string | null = null;
let _lastDbCheckTime = 0;
const DB_CHECK_INTERVAL_MS = 60_000; // Cada minuto, chequear DB

// Override desde DB (platform_settings) — permite rotar key sin tocar env vars
interface GeminiDbConfig {
  apiKey?: string;
  proxyUrl?: string;
  proxyKey?: string;
}

let _dbOverride: GeminiDbConfig = {};

// ─── Carga override desde DB (non-blocking, cacheada 60s) ────────────────────
async function loadDbOverride(): Promise<void> {
  const now = Date.now();
  if (now - _lastDbCheckTime < DB_CHECK_INTERVAL_MS) return;
  _lastDbCheckTime = now;

  try {
    const rows = await db.select().from(platformSettingsTable);
    const map = new Map(rows.map(r => [r.key, r.value]));

    const apiKey = map.get("gemini_api_key");
    const proxyKey = map.get("gemini_proxy_key");
    const proxyUrl = map.get("gemini_proxy_url");

    // Si los values vienen cifrados, descifrar
    _dbOverride = {
      apiKey: apiKey ? (safeDecrypt(apiKey) || apiKey) : undefined,
      proxyKey: proxyKey ? (safeDecrypt(proxyKey) || proxyKey) : undefined,
      proxyUrl: proxyUrl ?? undefined,
    };
  } catch (err) {
    // Fallo no-fatal — seguimos con env vars
    logger.debug({ err }, "Gemini DB override check failed (using env)");
  }
}

// Lanzar el check inicial
void loadDbOverride();

// ─── Resolver config actual combinando env + DB ──────────────────────────────
interface ResolvedGeminiConfig {
  apiKey?: string;
  proxyKey?: string;
  proxyUrl?: string;
  hash: string;
}

function resolveGeminiConfig(): ResolvedGeminiConfig {
  // Prioridad: DB override > env vars
  const apiKey = _dbOverride.apiKey ?? process.env.GEMINI_API_KEY;
  const proxyKey = _dbOverride.proxyKey ?? process.env.AI_INTEGRATIONS_GEMINI_API_KEY;
  const proxyUrl = _dbOverride.proxyUrl ?? process.env.AI_INTEGRATIONS_GEMINI_BASE_URL;

  const hash = `${apiKey?.slice(-8) ?? ""}|${proxyKey?.slice(-8) ?? ""}|${proxyUrl ?? ""}`;
  return { apiKey, proxyKey, proxyUrl, hash };
}

// ─── Factory con rotación transparente ───────────────────────────────────────
export function getGeminiClient(): GoogleGenAI {
  // Trigger lazy re-check desde DB (non-blocking — si tarda, la próxima request lo usa)
  void loadDbOverride();

  const config = resolveGeminiConfig();

  if (_ai && _aiConfigHash === config.hash) {
    return _ai;
  }

  // Config cambió o cliente nunca creado → recrear
  if (config.apiKey) {
    _ai = new GoogleGenAI({ apiKey: config.apiKey });
    _aiConfigHash = config.hash;
    if (_aiConfigHash !== null && _aiConfigHash !== config.hash) {
      logger.info("[Gemini] Client re-initialized with new API key (direct)");
    } else {
      logger.info("[Gemini] Client initialized (direct API key)");
    }
    return _ai;
  }

  if (config.proxyKey && config.proxyUrl) {
    _ai = new GoogleGenAI({
      apiKey: config.proxyKey,
      httpOptions: { apiVersion: "", baseUrl: config.proxyUrl },
    });
    _aiConfigHash = config.hash;
    logger.info("[Gemini] Client initialized (Replit proxy)");
    return _ai;
  }

  throw new Error("Gemini not configured: set GEMINI_API_KEY, AI_INTEGRATIONS_GEMINI_*, or platform_settings.gemini_api_key");
}

export function isGeminiAvailable(): boolean {
  const config = resolveGeminiConfig();
  return Boolean(config.apiKey || (config.proxyKey && config.proxyUrl));
}

/**
 * Fuerza re-inicialización del cliente. Útil tras UPDATE en platform_settings
 * desde el panel admin si no quieres esperar el DB check de 60s.
 */
export async function refreshGeminiClient(): Promise<void> {
  _lastDbCheckTime = 0; // forzar re-lectura
  _ai = null;
  _aiConfigHash = null;
  await loadDbOverride();
  logger.info("[Gemini] Client manually refreshed");
}

// ─── Telemetría ligera (similar a Claude) ────────────────────────────────────
interface GeminiUsage {
  callsTotal: number;
  callsSuccess: number;
  callsFailed: number;
  inputTokensApprox: number;   // aproximado — Gemini no siempre devuelve usage
  outputTokensApprox: number;
  lastReset: number;
}

const geminiUsage: GeminiUsage = {
  callsTotal: 0,
  callsSuccess: 0,
  callsFailed: 0,
  inputTokensApprox: 0,
  outputTokensApprox: 0,
  lastReset: Date.now(),
};

export function getGeminiUsageSnapshot(): GeminiUsage & { hours: number } {
  return {
    ...geminiUsage,
    hours: (Date.now() - geminiUsage.lastReset) / 3_600_000,
  };
}

/**
 * Wrapper para instrumentar cualquier llamada a generateContent.
 */
export async function instrumentedGeminiCall<T extends { usageMetadata?: { promptTokenCount?: number; candidatesTokenCount?: number } }>(
  label: string,
  callFn: () => Promise<T>,
): Promise<T> {
  const start = Date.now();
  geminiUsage.callsTotal++;

  try {
    const response = await callFn();
    const durationMs = Date.now() - start;

    const inputTokens = (response as { usageMetadata?: { promptTokenCount?: number } })
      .usageMetadata?.promptTokenCount ?? 0;
    const outputTokens = (response as { usageMetadata?: { candidatesTokenCount?: number } })
      .usageMetadata?.candidatesTokenCount ?? 0;

    geminiUsage.callsSuccess++;
    geminiUsage.inputTokensApprox += inputTokens;
    geminiUsage.outputTokensApprox += outputTokens;

    logger.debug({
      label, durationMs, inputTokens, outputTokens,
    }, "[Gemini] Call OK");

    return response;
  } catch (err) {
    const durationMs = Date.now() - start;
    geminiUsage.callsFailed++;
    logger.warn({
      label, durationMs,
      err: err instanceof Error ? err.message : String(err),
    }, "[Gemini] Call FAILED");
    throw err;
  }
}

/*
═══════════════════════════════════════════════════════════════════════════════
INTEGRACIÓN EN LAS FUNCIONES EXISTENTES DE gemini.ts
═══════════════════════════════════════════════════════════════════════════════

En askGemini, askGeminiJson, askGeminiWithSearch, etc., envolver la llamada
al SDK con instrumentedGeminiCall:

ANTES:
  async function askGemini(prompt, systemInstruction?, useProModel = false): Promise<string> {
    const ai = getGeminiClient();
    const model = useProModel ? GEMINI_PRO_MODEL : GEMINI_MODEL;
    const response = await withTimeout(
      ai.models.generateContent({ model, contents: [...], config: {...} }),
      GEMINI_CALL_TIMEOUT_MS,
      `askGemini(${model})`
    );
    // ...
    return response.text ?? "";
  }

DESPUÉS:
  async function askGemini(prompt, systemInstruction?, useProModel = false): Promise<string> {
    const ai = getGeminiClient();
    const model = useProModel ? GEMINI_PRO_MODEL : GEMINI_MODEL;
    const response = await instrumentedGeminiCall(
      `askGemini(${model})`,
      () => withTimeout(
        ai.models.generateContent({ model, contents: [...], config: {...} }),
        GEMINI_CALL_TIMEOUT_MS,
        `askGemini(${model})`
      ),
    );
    // ...
    return response.text ?? "";
  }

═══════════════════════════════════════════════════════════════════════════════

ENDPOINT PARA REFRESCAR MANUALMENTE (añadir en routes/admin.ts):

import { refreshGeminiClient } from "../lib/gemini.js";

router.post("/ai-keys/refresh", requireAdmin, async (_req, res) => {
  await refreshGeminiClient();
  res.json({ success: true, message: "Gemini client refreshed" });
});

═══════════════════════════════════════════════════════════════════════════════

USO DESDE EL PANEL ADMIN — permite rotar sin redeployar:

1. En la tabla platform_settings, UPDATE para poner la nueva key:
     INSERT INTO platform_settings (key, value) VALUES ('gemini_api_key', 'AIza...new...')
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

2. El factory detecta el cambio en el próximo check (max 60s) y recrea el cliente.

3. O fuerza el refresh inmediato:
     POST /api/admin/ai-keys/refresh

═══════════════════════════════════════════════════════════════════════════════
*/
