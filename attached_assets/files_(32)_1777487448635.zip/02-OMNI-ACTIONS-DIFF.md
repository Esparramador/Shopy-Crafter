# OmniChatbot — Acciones BE vs Formatters UI

- **Backend** (`shopybrain.ts:1725 execute-action`): **148 cases**
- **Frontend formatter** (`OmniChatbot.tsx:1037 formatActionResult`): **93 cases**
- Matched: **93**
- **BE-only (sin formatter UI específico)**: **55** — caen al default `✅ Acción completada` o `✅ {result.message}`
- **FE-only (formatter muerto, BE nunca emite)**: **0**

## Acciones BE sin formatter UI (prioridad por impacto)

### 🔴 Alto impacto UX (usuarios finales los pedirán)

- `activate_user`
- `bulk_update_prices`
- `bulk_update_stock`
- `create_approval`
- `create_email_flow`
- `create_user`
- `deactivate_user`
- `delete_email_flow`
- `fusion_analyze`
- `fusion_create_product`
- `generate_ai_report`
- `generate_brand_css`
- `generate_brand_guide`
- `generate_brand_kit`
- `generate_budget`
- `generate_platform_report`
- `invite_client`
- `list_approvals`
- `list_email_flows`
- `list_messages`
- `list_users`
- `reset_user_password`
- `run_full_audit_report`
- `run_leveled_report`
- `send_message`
- `sync_catalog_prices`
- `virtual_tryon`

### 🟡 Medio impacto (operativos)

- `add_to_collection`
- `add_variant`
- `analyze_web_design`
- `audit_log`
- `auto_estimate_all_cogs`
- `brain_export`
- `delete_collection`
- `delete_variant`
- `discover_competitors`
- `edit_collection`
- `edit_variant`
- `get_collection_products`
- `list_products_with_prices`
- `list_variants`
- `price_audit`
- `remove_from_collection`
- `restock_orders`
- `sales_report`
- `send_restock_email`

### 🟢 Bajo (probable uso interno o raro)

- `generate_export`
- `list_automations`
- `run_automation`
- `run_universal_generator`
- `sync_store_theme`
- `unread_messages`
- `update_page`
- `update_product_price`
- `update_stock`

## Acciones matched (UI formatea, BE emite)

<details><summary>Ver las 93 matched</summary>

- `agency_proposal`
- `agency_quote`
- `analyze_competitor_product`
- `analyze_component`
- `analyze_external_store`
- `apply_redesign`
- `audit_app_offerings`
- `audit_page_speed`
- `audit_store`
- `audit_theme`
- `auto_collections`
- `blog_strategy`
- `brain_stats`
- `brain_status`
- `brain_sync`
- `bulk_generate_images`
- `bulk_redesign`
- `calculate_optimal_price`
- `change_price`
- `copyright_audit`
- `create_ab_test`
- `create_collection`
- `create_page`
- `create_product`
- `create_theme_section`
- `declare_winner`
- `delete_product`
- `design_all_pages`
- `diagnose_app`
- `edit_product`
- `edit_theme_css`
- `edit_theme_file`
- `edit_theme_settings`
- `estimate_cogs`
- `external_pre_report`
- `financial_dashboard`
- `financial_forecast`
- `fix_all_alt_texts`
- `fix_code`
- `fix_missing_compare_prices`
- `fix_unpublished`
- `generate_all_metas`
- `generate_blog_post`
- `generate_competitive_pricing`
- `generate_email`
- `generate_email_flow`
- `generate_images_from_reference`
- `generate_product_images`
- `generate_schemas`
- `generate_sitemap`
- `get_orders`
- `get_scopes`
- `inspect_code`
- `inventory_alerts`
- `inventory_customer_history`
- `inventory_deep_report`
- `inventory_sales_analytics`
- `inventory_sync`
- `inventory_sync_orders`
- `keyword_intelligence`
- `learn_from_content`
- `learn_from_url`
- `list_ab_tests`
- `list_all_products`
- `list_collections`
- `list_pages`
- `list_products`
- `list_source_files`
- `list_theme_files`
- `list_themes`
- `modify_audit_filter`
- `modify_ui`
- `optimize_all_products`
- `optimize_images`
- `optimize_product`
- `price_simulator`
- `publish_product`
- `read_cms`
- `read_theme_file`
- `recall_knowledge`
- `redesign_product`
- `regenerate_token`
- `reset_cms`
- `scan_competitor`
- `scan_store`
- `search_product`
- `search_suppliers`
- `seo_full_audit`
- `set_product_status`
- `setup_full_store`
- `store_status`
- `update_cms`
- `update_cms_batch`

</details>

## ✅ No hay formatters UI huérfanos (todo `case` del UI existe en BE)

