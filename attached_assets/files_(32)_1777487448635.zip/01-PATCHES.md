# Shopy Crafter — Parches concretos

Cada sección referencia el finding del informe principal (`00-AUDIT-REPORT.md`). Los diffs están en formato `unified` compacto; los archivos reemplazables completos están en `files-to-replace/`.

---

## § C1 — Revenue.tsx PATCH → PUT + toast de error

**File:** `artifacts/shopify-optimizer/src/pages/admin/Revenue.tsx`

**Antes** (líneas 68-84):
```tsx
async function saveEdit(id: number) {
  setSaving(true);
  try {
    await fetch(`${API}/api/projects/${id}`, {
      method: "PATCH",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(editData),
    });
    setProjects(prev => prev.map(p => p.id === id ? { ...p, ...editData } : p));
    setEditingId(null);
    setEditData({});
  } catch { }
  setSaving(false);
}
```

**Después:**
```tsx
async function saveEdit(id: number) {
  setSaving(true);
  try {
    const res = await fetch(`${API}/api/projects/${id}`, {
      method: "PUT",                                       // ← era "PATCH"
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(editData),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      toast({ title: err.error || `Error ${res.status}`, variant: "destructive" });
      return;
    }
    setProjects(prev => prev.map(p => p.id === id ? { ...p, ...editData } : p));
    setEditingId(null);
    setEditData({});
    toast({ title: "Proyecto actualizado" });
  } catch (e: any) {
    toast({ title: e?.message || "Error de conexión", variant: "destructive" });
  } finally {
    setSaving(false);
  }
}
```

**Y en el top del fichero añadir:**
```tsx
import { useToast } from "@/hooks/use-toast";
// ...dentro del componente:
const { toast } = useToast();
```

Fichero completo corregido: `files-to-replace/Revenue.tsx`.

---

## § C2 — Mover montaje de apkRouter detrás de requireAdmin

**File:** `artifacts/api-server/src/routes/index.ts`

**Antes** (líneas 54-80):
```ts
router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/admin", adminRouter);
router.use("/client", clientRouter);
router.use("/cms", (req, res, next) => {
  if (req.method === "GET" && req.path === "/content") return next();
  return requireAdmin(req, res, next);
}, cmsRouter);
router.use(storeRouter);
router.use(contactRouter);
router.use(apkRouter);                                     // ← público, MAL

router.get("/report-templates/:token", ...);               // público condicional OK

router.use(requireAdmin);                                  // ← a partir de aquí, todo protegido
router.use(projectsRouter);
// ...
```

**Después:**
```ts
router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/admin", adminRouter);
router.use("/client", clientRouter);
router.use("/cms", (req, res, next) => {
  if (req.method === "GET" && req.path === "/content") return next();
  return requireAdmin(req, res, next);
}, cmsRouter);
router.use(storeRouter);
router.use(contactRouter);
//  ❌  router.use(apkRouter);  ← eliminado de aquí

router.get("/report-templates/:token", ...);

router.use(requireAdmin);
router.use(apkRouter);                                     // ← MOVIDO aquí: solo admins
router.use(projectsRouter);
// ...
```

Alternativa si prefieres endurecer también el router en sí (por si algún día lo expones sin querer) — **recomendada como defensa en profundidad**:

**File:** `artifacts/api-server/src/routes/apk.ts` — cabecera:
```ts
import { Router } from "express";
import { requireAdmin } from "../lib/auth.js";

const router = Router();
router.use(requireAdmin);                                  // ← LOCAL guard

// resto igual
```

Fichero completo corregido: `files-to-replace/routes-index.ts`.

---

## § C3 — reveal-token con scope por propiedad

Esto requiere conocer tu modelo de multi-tenancy. Opción mínima (sin ORM schema extras) — loguear y no descifrar:

**File:** `artifacts/api-server/src/routes/projects.ts`, reemplazar handler en línea 657:

```ts
router.get("/projects/:projectId/reveal-token", async (req, res): Promise<void> => {
  try {
    const id = parseInt(Array.isArray(req.params.projectId) ? req.params.projectId[0] : req.params.projectId, 10);
    const userId = (req.session as any).userId;
    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, id));
    if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }
    if (!project.accessToken) { res.status(404).json({ error: "Sin token de acceso" }); return; }

    // OPCIÓN A — si projectsTable tiene ownerId/userId column
    if ((project as any).ownerId && (project as any).ownerId !== userId) {
      // log el intento de cross-tenant
      console.warn(`[reveal-token] user ${userId} tried to access project ${id} owned by ${(project as any).ownerId}`);
      res.status(403).json({ error: "No autorizado" });
      return;
    }

    // Enmascarar SIN descifrar completo — usar el cifrado como "prueba" y enmascarar los bytes enceriptados
    const stored = project.accessToken;
    const masked = stored.length > 16
      ? stored.slice(0, 8) + "••••••••••••" + stored.slice(-4)
      : "••••••••••••••••";

    // Audit log
    console.log(`[audit] reveal-token project=${id} user=${userId} at=${new Date().toISOString()}`);

    res.json({
      accessToken: masked,
      shopDomain: project.shopDomain,
      tokenValid: true,
      note: "Token enmascarado. Para obtener el plano usa GET /projects/:id/admin-token (audit log) o Shopify Partners.",
    });
  } catch (err: any) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    res.status(500).json({ error: msg });
  }
});
```

**Opción B** — si no tienes `ownerId` en `projectsTable` todavía: añadir columna y migración. Fuera del scope de esta auditoría, pero marcar como deuda técnica.

---

## § C4 — Montar la ruta `/admin/billing` en App.tsx

**File:** `artifacts/shopify-optimizer/src/App.tsx`

**Añadir import** (después de línea 55 `const TemplateStudio = ...`):
```tsx
const Billing = lazy(() => import("@/pages/admin/Billing"));
```

**Añadir Route** (sugerencia: junto a los otros admin, después de `/admin/settings` línea 336):
```tsx
<Route path="/admin/billing">
  <RequireAdmin><AdminWrapper><AppLayout><S><Billing /></S></AppLayout></AdminWrapper></RequireAdmin>
</Route>
```

**Y en `AppLayout.tsx` (sidebar)** añadir el link al menú admin. No puedo escribirlo exacto sin ver el sidebar completo, pero el patrón es:
```tsx
<NavLink to="/admin/billing" icon={<CreditCard />}>Facturación</NavLink>
```

---

## § A1 — Wrapper `fetchApi` y migración progresiva

**Crear** `artifacts/shopify-optimizer/src/lib/api.ts`:

```ts
import { customFetch, ApiError } from "@workspace/api-client-react";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

/**
 * Wrapper interno para fetch() directo contra endpoints no tipados.
 * Usa el customFetch de Orval con BASE_URL, credentials="include", manejo 401.
 *
 * Preferir hooks Orval cuando el endpoint esté en el OpenAPI.
 */
export async function fetchApi<T = unknown>(
  path: string,
  options: RequestInit & { responseType?: "json" | "text" | "blob" | "auto" } = {}
): Promise<T> {
  const url = path.startsWith("/api/") ? `${API_BASE}${path}` : path;
  try {
    return await customFetch<T>(url, options);
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) {
      // forzar re-login — sesión expirada
      window.location.href = "/login";
      throw err;
    }
    throw err;
  }
}

// Helpers de conveniencia
export const apiGet = <T>(path: string, init: RequestInit = {}) =>
  fetchApi<T>(path, { ...init, method: "GET" });

export const apiPost = <T>(path: string, body?: unknown, init: RequestInit = {}) =>
  fetchApi<T>(path, {
    ...init,
    method: "POST",
    headers: { "Content-Type": "application/json", ...init.headers },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

export const apiPut = <T>(path: string, body?: unknown, init: RequestInit = {}) =>
  fetchApi<T>(path, {
    ...init,
    method: "PUT",
    headers: { "Content-Type": "application/json", ...init.headers },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

export const apiDelete = <T>(path: string, init: RequestInit = {}) =>
  fetchApi<T>(path, { ...init, method: "DELETE" });

// Re-exportar tipo de error
export { ApiError } from "@workspace/api-client-react";
```

**Migración ejemplo** — convertir `Revenue.tsx:62` (GET projects list):

Antes:
```tsx
const res = await fetch(`${API}/api/projects`, { credentials: "include" });
const data = await res.json();
```

Después:
```tsx
import { apiGet } from "@/lib/api";
// ...
const data = await apiGet<Project[]>("/api/projects");
```

Migración progresiva sugerida: 1 página por día, priorizando admin (más riesgo).

---

## § A2 — Añadir `credentials: "include"` a 3 fetchs

### Pricing.tsx:958

**File:** `artifacts/shopify-optimizer/src/pages/projects/Pricing.tsx`

**Antes:**
```tsx
const res = await fetch(`${API_BASE}/api/projects/${projectId}/products/${product.id}/ai-estimate-cogs`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
});
```

**Después:**
```tsx
const res = await fetch(`${API_BASE}/api/projects/${projectId}/products/${product.id}/ai-estimate-cogs`, {
  method: "POST",
  credentials: "include",                                   // ← AÑADIR
  headers: { "Content-Type": "application/json" },
});
```

### CMSEditor.tsx:883

**Antes:**
```tsx
const res = await fetch(`${BASE_URL}/api/cms/media/upload`, { method: "POST", body: form });
```

**Después:**
```tsx
const res = await fetch(`${BASE_URL}/api/cms/media/upload`, {
  method: "POST",
  credentials: "include",                                   // ← AÑADIR
  body: form,
});
```

### CMSEditor.tsx:901

**Antes:**
```tsx
if (filename) await fetch(`${BASE_URL}/api/cms/media/${filename}`, { method: "DELETE" }).catch(() => {});
```

**Después:**
```tsx
if (filename) {
  await fetch(`${BASE_URL}/api/cms/media/${filename}`, {
    method: "DELETE",
    credentials: "include",                                 // ← AÑADIR
  }).catch(() => {});
}
```

---

## § A3 — Formatters UI para las 55 acciones faltantes del OmniChatbot

**Estrategia recomendada** (más mantenible que 55 cases): contrato común en backend.

**Backend** — en `shopybrain.ts` dispatcher, asegurar que TODAS las ramas retornen al menos `{ok: boolean, summary: string, details?: any}`. El handler `executeAction` ya lo hace para algunas.

**Frontend** — en `OmniChatbot.tsx:1416-1418` reemplazar el default:

Antes:
```tsx
default:
  return result.message ? `✅ ${result.message}` : "✅ Acción completada.";
```

Después:
```tsx
default:
  // Si el backend devolvió un summary estructurado, usarlo
  if (result.summary && typeof result.summary === "string") {
    return `✅ ${result.summary}`;
  }
  // Si hay details iterables, mostrarlos en lista
  if (Array.isArray(result.details) && result.details.length > 0) {
    const items = result.details.slice(0, 10).map((d: any) =>
      typeof d === "string" ? `· ${d}` : `· ${JSON.stringify(d).slice(0, 100)}`
    ).join("\n");
    const more = result.details.length > 10 ? `\n...y ${result.details.length - 10} más` : "";
    return `✅ ${result.message || "Acción completada."}\n\n${items}${more}`;
  }
  return result.message ? `✅ ${result.message}` : "✅ Acción completada.";
```

**Y añadir cases de alto impacto** — sugeridos (los más visibles):

```tsx
case "invite_client":
  return `✅ **Cliente invitado:** ${result.email}\n🔗 Enlace: ${result.inviteLink}\n${result.emailSent ? "📧 Email enviado" : "⚠️ Email no enviado (configurar SMTP)"}`;

case "create_user":
  return `✅ **Usuario creado:**\n· ID: ${result.userId}\n· Email: ${result.email}\n· Rol: ${result.role}`;

case "activate_user":
case "deactivate_user":
  return `✅ Usuario ${result.email} ${action === "activate_user" ? "activado" : "desactivado"}.`;

case "reset_user_password":
  return `✅ **Password reseteada para ${result.email}.**\n🔗 Enlace de reset: ${result.resetLink || "(enviado por email)"}`;

case "generate_budget":
  return `💰 **Presupuesto generado:**\n📄 ${result.title}\n💵 Total: €${result.total}\n🔗 ${result.documentUrl || "(ver detalles)"}`;

case "run_full_audit_report":
case "run_leveled_report":
  return `📋 **Informe generado:** ${result.title}\n📊 ${result.sectionsCount || "?"} secciones · ${result.productsAnalyzed || "?"} productos\n🔗 ${result.url || "(descargar desde el botón)"}`;

case "generate_brand_kit":
case "generate_brand_guide":
case "generate_brand_css":
  return `🎨 **${action.replace(/_/g, " ")}:**\n${result.message || "Generado correctamente."}\n📦 Contiene: ${(result.assets || []).join(", ") || "(ver vault)"}`;

case "bulk_update_prices":
case "bulk_update_stock":
  return `⚡ **${action === "bulk_update_prices" ? "Precios" : "Stocks"} actualizados en masa:**\n✅ ${result.updated || 0} productos OK\n❌ ${result.failed || 0} fallos\n${(result.failedTitles || []).slice(0,5).map((t: string) => `· ${t}`).join("\n")}`;

case "virtual_tryon":
  return `👗 **Virtual try-on generado:**\n🖼️ ${result.imageCount || 1} imagen(es)\n⏱️ ${result.elapsed || "?"}\n💾 Guardado en vault del proyecto.`;
```

El resto puede quedar con el fallback mejorado. Lista completa de 55 acciones en `02-OMNI-ACTIONS-DIFF.md`.

---

## § A4 — Guard re-check en downgrade de rol

**File:** `artifacts/shopify-optimizer/src/App.tsx` líneas 123-137.

```tsx
function RequireAdmin({ children }: { children: React.ReactNode }) {
  const { user, loading, refresh } = useAuth();
  const [recheck, setRecheck] = useState(false);

  useEffect(() => {
    // Si el usuario parece no ser admin, forzar un refresh antes de aceptar
    if (user && user.role !== "admin" && !recheck) {
      setRecheck(true);
      refresh();
    }
  }, [user, recheck, refresh]);

  if (loading) return <LoadingScreen />;
  if (!user) return <Redirect to="/" />;
  if (user.role !== "admin") return <Redirect to="/client" />;
  return <>{children}</>;
}
```

Añade `useState, useEffect` al import si no están.

---

## § A5 — AndroidManifest.xml

**File:** `artifacts/shopify-optimizer/android/app/src/main/AndroidManifest.xml`

Reemplazar el bloque `<application>` attrs y permissions:

**Antes:**
```xml
<application
    android:allowBackup="true"
    android:icon="@mipmap/ic_launcher"
    ...>

<!-- Permissions -->
<uses-permission android:name="android.permission.INTERNET" />
```

**Después:**
```xml
<application
    android:allowBackup="false"
    android:fullBackupContent="false"
    android:dataExtractionRules="@xml/data_extraction_rules"
    android:icon="@mipmap/ic_launcher"
    ...>

<!-- Permissions -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

**Crear también** `android/app/src/main/res/xml/data_extraction_rules.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <exclude domain="sharedpref" />
        <exclude domain="database" />
    </cloud-backup>
    <device-transfer>
        <exclude domain="sharedpref" />
        <exclude domain="database" />
    </device-transfer>
</data-extraction-rules>
```

Fichero completo: `files-to-replace/AndroidManifest.xml`.

---

## § A6 — postMessage sin fallback "*"

**File:** `artifacts/shopify-optimizer/src/pages/Landing.tsx`

**Antes (línea 507):**
```tsx
window.parent.postMessage({ type: "cms-click-to-edit", path }, parentOrigin || "*");
```

**Después:**
```tsx
if (!parentOrigin) {
  console.warn("[Landing] postMessage skipped: no parentOrigin");
  return;
}
window.parent.postMessage({ type: "cms-click-to-edit", path }, parentOrigin);
```

**Misma lógica en línea 525.** Si el CMS editor necesita recibir el mensaje, asegúrate de que pase `parentOrigin` por query string (`?parent=https://shopycrafter.com`) y que la landing lo lea.

---

## § A7 — Sanitizar dangerouslySetInnerHTML

**Paso 1:** instalar
```bash
pnpm add isomorphic-dompurify -F @workspace/shopify-optimizer
```

**Paso 2:** `Redesign.tsx:513`

**Antes:**
```tsx
<div dangerouslySetInnerHTML={{ __html: result.bodyHtml || "" }} />
```

**Después:**
```tsx
import DOMPurify from "isomorphic-dompurify";
// ...
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(result.bodyHtml || "", {
  ALLOWED_TAGS: ["h1","h2","h3","h4","p","ul","ol","li","strong","em","br","a","img","span","div","blockquote","code","pre"],
  ALLOWED_ATTR: ["href","src","alt","title","class","style","target","rel"],
}) }} />
```

**Paso 3:** `Images.tsx:566` — SVG es más delicado (contenido legítimo puede traer `<script>`). Usa sandbox iframe:

**Antes:**
```tsx
<div dangerouslySetInnerHTML={{ __html: svgContent ... }} />
```

**Después:**
```tsx
// Renderizar SVG en iframe sandboxed
<iframe
  sandbox=""
  srcDoc={svgContent}
  style={{ border: 0, width: "100%", height: 300, background: "transparent" }}
  title="svg-preview"
/>
```

O si prefieres DOMPurify (más rápido):
```tsx
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(svgContent, {
  USE_PROFILES: { svg: true, svgFilters: true },
}) }} />
```

---

## § A8 — Invalidations react-query — los 3 puntos críticos

**Tras invitar cliente** — `AdminClients.tsx:75-85`:

```tsx
import { useQueryClient } from "@tanstack/react-query";
import { getListProjectsQueryKey } from "@workspace/api-client-react";
// ...
const queryClient = useQueryClient();

// tras `setInviteResult(...)` en línea 81:
queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });
queryClient.invalidateQueries({ queryKey: ["/api/admin/projects-list"] });
queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
```

**Tras crear producto desde OmniChatbot** — `OmniChatbot.tsx` después de recibir `prodRes.ok` en línea ~1602:

```tsx
import { useQueryClient } from "@tanstack/react-query";
import { getGetProjectProductsQueryKey } from "@workspace/api-client-react";
// ...
const queryClient = useQueryClient();

// tras parse de prodData:
if (projectIdFromUrl) {
  queryClient.invalidateQueries({
    queryKey: getGetProjectProductsQueryKey(parseInt(projectIdFromUrl))
  });
}
```

**Tras editar producto en Audit** — `Audit.tsx:131` ya lo hace (línea 795). Falta añadir el invalidate tras el `products/create` de línea 469:

```tsx
// tras res.ok en línea ~475:
queryClient.invalidateQueries({
  queryKey: getGetProjectProductsQueryKey(projectId)
});
```

---

## § M2 — Feedback de error en ClientApprovals

**File:** `src/pages/client/ClientApprovals.tsx`

**Antes (línea 37-47):**
```tsx
const act = async (id: string, action: "approve" | "reject") => {
  setProcessing(id);
  await fetch(`${API_BASE}/api/client/approvals/${id}/${action}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ comment: comments[id] ?? "" }),
  });
  setProcessing(null);
  load();
};
```

**Después:**
```tsx
import { useToast } from "@/hooks/use-toast";
// ...
const { toast } = useToast();

const act = async (id: string, action: "approve" | "reject") => {
  setProcessing(id);
  try {
    const res = await fetch(`${API_BASE}/api/client/approvals/${id}/${action}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ comment: comments[id] ?? "" }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      toast({ title: err.error || `Error ${res.status}`, variant: "destructive" });
      return;
    }
    toast({ title: action === "approve" ? "Aprobado" : "Rechazado" });
  } catch (e: any) {
    toast({ title: e?.message || "Error de conexión", variant: "destructive" });
  } finally {
    setProcessing(null);
    load();
  }
};
```

---

## § M3 — CoachMarks versionado

**File:** `src/components/CoachMarks.tsx`

**Antes (línea 47):**
```tsx
const COACH_MARKS_KEY = "sc_coach_marks_dismissed";
```

**Después:**
```tsx
const COACH_MARKS_VERSION = "v2";  // bump cuando cambies los marks
const COACH_MARKS_KEY = `sc_coach_marks_${COACH_MARKS_VERSION}_dismissed`;

// Opcional: cleanup de la key vieja
useEffect(() => {
  try {
    localStorage.removeItem("sc_coach_marks_dismissed");
  } catch {}
}, []);
```

---

## § M4 — ErrorBoundary → /api/errors

**Backend** — añadir a `api-server/src/routes/health.ts` (o crear `errors.ts`):
```ts
router.post("/errors", async (req, res): Promise<void> => {
  try {
    const { message, stack, url, userAgent } = req.body as any;
    // Sin PII; solo mensaje + stack truncados
    logger.error("[client-error]", {
      message: String(message).slice(0, 500),
      stack: String(stack || "").slice(0, 2000),
      url: String(url).slice(0, 200),
      userAgent: String(userAgent).slice(0, 200),
      userId: (req.session as any)?.userId,
      at: new Date().toISOString(),
    });
    res.json({ ok: true });
  } catch { res.status(500).json({ ok: false }); }
});
```

**Frontend** — `ErrorBoundary.tsx:23-25`:

```tsx
componentDidCatch(error: Error, errorInfo: ErrorInfo) {
  console.error("[ErrorBoundary]", error, errorInfo);
  if (!import.meta.env.DEV) {
    fetch(`${import.meta.env.BASE_URL.replace(/\/$/, "")}/api/errors`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: error.message,
        stack: error.stack,
        url: window.location.href,
        userAgent: navigator.userAgent,
      }),
    }).catch(() => {});
  }
}
```

---

## Orden sugerido de aplicación

1. **Hoy** (bugs rompiendo features en producción): C1, C2, A2
2. **Esta semana** (seguridad): C3, A5, A7, A6
3. **Sprint siguiente** (UX + estructural): C4, A1 (wrapper), A3, A4, A8, M2, M3, M4
4. **Backlog** (decisiones de negocio): M1 (qué borrar del backend), B1-B4

---

## Comandos para aplicar los ficheros de reemplazo

```bash
# Desde la raíz del repo
cp shopycrafter-audit/files-to-replace/AndroidManifest.xml \
   artifacts/shopify-optimizer/android/app/src/main/AndroidManifest.xml

cp shopycrafter-audit/files-to-replace/Revenue.tsx \
   artifacts/shopify-optimizer/src/pages/admin/Revenue.tsx

cp shopycrafter-audit/files-to-replace/routes-index.ts \
   artifacts/api-server/src/routes/index.ts

# Verificar que compila
pnpm -F @workspace/shopify-optimizer typecheck
pnpm -F @workspace/api-server build
```
