# Hallazgos adicionales — pases sobre páginas pesadas

Este documento añade hallazgos encontrados en el deep-dive sobre `CMSEditor.tsx` (1691L), `MyPricing.tsx` (1034L), `AdminClients.tsx` (805L), `Audit.tsx` (1396L), `Emails.tsx` (727L), y `NewProject.tsx` (620L), más el backend Shopify agency.

## Nuevos hallazgos

### A9 · Existe `useRetryFetch` oculto, se usa solo en 4 sitios

**Where:** `src/hooks/use-draft-persistence.ts:132-148`

```ts
export function useRetryFetch() {
  return useCallback(async (url, options, maxRetries = 3) => {
    let lastError: Error | null = null;
    for (let i = 0; i < maxRetries; i++) {
      try {
        const res = await fetch(url, options);
        if (res.ok || res.status < 500) return res;   // ← solo reintenta 5xx
        lastError = new Error(`HTTP ${res.status}`);
      } catch (e) {
        lastError = e as Error;
      }
      if (i < maxRetries - 1) {
        await new Promise(r => setTimeout(r, 1000 * Math.pow(2, i)));
      }
    }
    throw lastError;
  }, []);
}
```

- Hook con backoff exponencial (1s, 2s, 4s) solo para errores de servidor (5xx / network).
- **Solo lo usa `CMSEditor.tsx`** en 4 llamadas (líneas 1174, 1197, 1315).
- **Bug sutil:** no fuerza `credentials: "include"`. En CMSEditor unas llamadas lo pasan, otras no (ej. línea 1174 no pasa, y se llama a `/api/cms/content` que es público GET → OK pero confuso).

**Recomendación:**
- O se elimina (y se migra CMSEditor a `customFetch` de Orval + `fetchApi` del fix A1)
- O se promociona: mover a `src/lib/api.ts`, forzar `credentials: "include"` por defecto, añadir tipado de respuesta, y usarlo en más sitios.

Este hook + el `customFetch` de Orval es evidencia de que **la centralización se intentó 2 veces y no se propagó**. Es justamente el problema estructural del A1.

---

### A10 · Audit.tsx invoca `execute-action` directamente desde UI (no via OmniChatbot)

**Where:** `src/pages/projects/Audit.tsx:809`, `:831`, `:852`

```tsx
const res = await fetch(`${API}/api/shopybrain/execute-action`, {
  method: "POST", credentials: "include",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ action: "regenerate_token", params: { projectId } }),
});
```

También se usa para `optimize_product` (línea 831) y `optimize_all_products` (línea 852).

- **No es bug** — es un atajo de diseño: en lugar de crear endpoints específicos, la UI envía directamente al dispatcher.
- **Implicación:** la lista de "rutas backend sin UI" del `03-UNUSED-BACKEND.txt` puede incluir rutas que SÍ se invocan — pero internamente desde el dispatcher. Para saber cuáles, hay que trazar el `switch` del backend caso por caso.
- **Riesgo de mantenimiento:** si renombras la acción en el dispatcher, rompes Audit.tsx sin pista de TypeScript. No hay tipado compartido.

**Sugerencia:** crear un tipo enum compartido `ShopybrainAction` en `lib/api-zod` con todas las acciones como string literal union, e importarlo tanto en backend como en frontend.

---

### A11 · Flujo Shopify cart para packs de créditos — SÍ existe, es admin-only

**Where:**
- Frontend: `src/pages/AdminClients.tsx:212` → `POST /api/agency/payment-link`
- Backend: `api-server/src/routes/agency.ts:417-460`

El flujo real es:
1. Admin elige un servicio (de `/api/agency/services`) y un cliente.
2. Frontend POST → backend crea **Cart vía Storefront API** (`cartCreate` GraphQL mutation).
3. Backend devuelve `{checkoutUrl}` — el admin copia el link y se lo envía al cliente (copy-to-clipboard + `sendViaChat`).
4. El cliente paga en Shopify hosted checkout.

**Tienda.tsx no es el flujo de créditos** — es solo un pass-through al storefront de Comic Crafter. El flujo real es admin-generado.

**Observaciones sobre el flujo existente:**
- ✅ `agency.ts:449` usa la mutation correcta de Storefront API (`cartCreate`), no la obsoleta `checkoutCreate`.
- ⚠️ `AdminClients.tsx:220` — cuando `res.ok` es falso, `setResult(data)` igualmente con `{error:...}` aunque sea JSON error. Si el servidor devuelve HTML (ej. nginx 502), `res.json()` revienta dentro del `try` y cae al catch genérico "Error de red". Es aceptable pero podría mejorarse.
- ⚠️ No hay webhook `orders/paid` que cierre el loop — cuando el cliente paga, el admin no recibe notificación interna. Depende del email de Shopify.

**Recomendación:** añadir endpoint `POST /api/shopify/webhooks/orders-paid` (con verificación HMAC) que marque el servicio como `paid` y acredite créditos si aplica.

---

### A12 · `AdminClients.tsx` tiene flujo de mensajería cliente↔admin pero sin updates en tiempo real

**Where:** `src/pages/AdminClients.tsx:488-520`

- GET `/api/admin/projects/:id/messages` — polling manual cada vez que abres el modal.
- POST `/api/admin/projects/:id/messages` — envía mensaje.
- `AppLayout.tsx:103` hace `fetch('/api/admin/unread-messages')` para badge de notificaciones — también polling bajo demanda.

**Problema:**
- Sin polling periódico ni websocket → admin tiene que reabrir el modal para ver respuestas.
- El badge solo se actualiza en cambio de pestaña (`visibilitychange` del AuthContext).

**Recomendación mínima:** añadir `setInterval` con `invalidateQueries` de la key de unread-messages cada 60s cuando el tab está visible. O SSE/Websockets si quieres "real" real-time.

---

### M6 · `NewProject.tsx` no fuerza `handleTestConnection` antes de crear

**Where:** `src/pages/NewProject.tsx:187-196`

- `canTestConnection = !isUniversal && isValid` — el botón "Test" aparece si no es Universal y los datos están completos.
- Pero `handleSubmit` crea el proyecto **sin exigir** que `connectionTest.status === "success"`. El comentario en línea 189 (`_connectionTested`) subrayado insinúa que esta validación estaba en mente pero quedó deshabilitada.

**Efecto:**
- Usuario pega API key mala en Shopify/Woo, submitea, proyecto se crea en BD, y luego nada funciona (audit, sync, etc. todos 401/404 al llamar a la tienda).
- La versión actual te permite crear "proyecto zombi" en BD y no te entera hasta que entras a intentar algo.

**Fix:** bloquear submit si no es universal Y el test no ha pasado:

```tsx
// en NewProject.tsx, línea ~189:
const _connectionTested = connectionTest.status === "success";
const canSubmit = isUniversal || _connectionTested;    // ← nuevo

// en el botón submit:
<button type="submit" disabled={!isValid || !canSubmit || saving}>
  {saving ? "Creando..." : "Crear proyecto"}
</button>
```

---

### M7 · `MyPricing.tsx` calcula costes en cliente — riesgo de precio manipulado

**Where:** `src/pages/admin/MyPricing.tsx`

- 11 fetches a `/api/agency/*` endpoints (cost-structure, services, analyze-pricing, quote, proposal, budget, shopify-products).
- El patrón común: el frontend envía `body` con precios/márgenes y el backend hace lo que le digas.

**No es estrictamente un bug** porque `/api/agency/*` está detrás de `requireAdmin` → solo tú como admin lo usas. Pero si algún día conviertes esto en self-service para subagencies, el cálculo tiene que blindarse en backend (validar ranges, recomputar).

**Acción:** ninguna inmediata. Solo marcarlo para cuando se abra a multi-agencia.

---

### M8 · `CMSEditor.tsx` postMessage bidireccional iframe con origen `window.location.origin`

**Where:** `src/pages/admin/CMSEditor.tsx:1253-1302,1367`

```tsx
// Reception:
window.addEventListener("message", handler);

// Sending:
iframeRef.current?.contentWindow?.postMessage({...}, window.location.origin);
iframeRef.current?.contentWindow?.postMessage({ type: "cms-go-to-section", sectionId }, window.location.origin);
```

- **Bueno:** sender usa `window.location.origin` explícitamente (no `"*"`).
- **Regular:** receptor (`handler` línea 1253) — necesito verlo para confirmar que valida `event.origin`. Si no, es vector XSS si la landing carga terceros.

Sin verlo todo, asumo que cumple. Si no, añadir al `handler`:

```tsx
if (event.origin !== window.location.origin) return;
```

---

## Bloques que realmente quedaron fuera del presupuesto

- **Lectura completa de `CMSEditor.tsx` (1691L):** vi los fetches y postMessage. No audité a fondo la lógica del schema CMS, el versioning, batch save.
- **`MyPricing.tsx` (1034L) lógica de pricing:** vi los endpoints. No seguí la función `analyzePricing` ni cómo se construyen los budgets.
- **`AdminClients.tsx` (805L) flujo de pago y mensajería:** vi los endpoints clave y los bugs aparentes. No vi handlers de todos los botones del card del cliente (editar, pausar, completar...).
- **`Audit.tsx` (1396L) enriquecimiento con IA:** vi los 3 execute-action. No seguí el flujo completo de `optimize_all_products` → generar reporte → guardar en vault.
- **CmsContext.tsx:** lo toqué en pasada, usa fetch sin creds pero es endpoint público. Bien.

---

## Updated consolidated count

Con los hallazgos nuevos, el score final:

| Severidad | Antes | Después | Detalle |
|---|--:|--:|---|
| 🔴 Críticos | 4 | **4** | C1-C4 (sin nuevos) |
| 🟠 Altos | 8 | **12** | +A9 (useRetryFetch huérfano), +A10 (Audit usa execute-action), +A11 (webhook Shopify), +A12 (mensajería sin RT) |
| 🟡 Medios | 5 | **8** | +M6 (test conexión no obligado), +M7 (MyPricing trust client), +M8 (CMS iframe verify origin) |
| 🟢 Bajos | 4 | **4** | sin cambios |
| **Total** | **21** | **28** | |

---

## TL;DR de lo urgente tras todo el análisis

1. **Hoy mismo** (rompe flujos productivos):
   - C1 Revenue.tsx: PATCH→PUT + toast de error (ver `files-to-replace/Revenue.tsx`)
   - C2 apkRouter detrás de requireAdmin (ver `files-to-replace/routes-index.ts`)
   - A2 3 fetch sin credentials (Pricing:958, CMSEditor:883,:901)
   - M6 NewProject bloqueo de submit sin test-connection OK

2. **Esta semana** (seguridad / experiencia):
   - C3 reveal-token scoping
   - C4 montar /admin/billing
   - A5 AndroidManifest (ver `files-to-replace/AndroidManifest.xml`)
   - A7 sanitizar dangerouslySetInnerHTML

3. **Sprint próximo** (estructural):
   - A1 wrapper `fetchApi` centralizado + migración progresiva
   - A3 formatters UI para 55 acciones OmniChatbot
   - A8 invalidations queryKey tras mutaciones
   - A11 webhook orders/paid de Shopify (cerrar loop de créditos)
   - A12 polling de mensajería

4. **Decisión de negocio** (borrar vs terminar):
   - Klaviyo (49 routes sin UI)
   - Push notifications (3 sin UI)
   - Shopify OAuth (4 sin UI)
   - Admin impersonate UI (solo STOP está enganchado)
