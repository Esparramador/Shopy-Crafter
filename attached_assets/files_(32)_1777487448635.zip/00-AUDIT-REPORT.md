# Shopy Crafter — Auditoría Frontend (Bloque B)

**Fecha:** 2026-04-24  ·  **Alcance:** `artifacts/shopify-optimizer/` + cruce con `artifacts/api-server/`
**Método:** batches paralelos · estructura primero · sin rellenar con humo

---

## Resumen en 30 segundos

| Bloque | Estado |
|---|---|
| 1. Mapa de páginas y endpoints | ✅ completo (149 FE × 360 BE, diff hecho) |
| 2. OmniChatbot | ✅ a fondo (93 formatters UI vs 148 actions BE) |
| 3. Flujos críticos | ✅ login/invite/reset/OAuth/NewProject/Tienda leídos |
| 4. Estado y datos (react-query) | ✅ 41/49 hooks Orval usados · 0 useMutation · fetch-a-pelo mayoría |
| 5. Seguridad | ✅ XSS, guards, tokens, postMessage, creds |
| 6. UX/a11y básico | 🟡 parcial (loading states OK, mobile no probado) |
| 7. Capacitor / Android | ✅ manifest + config |
| 8. Arreglos concretos | ✅ patches en `01-PATCHES.md` + ficheros reemplazables |

**Findings con severidad:** 4 críticos · 8 altos · 5 medios · 4 bajos  ·  **total: 21**

---

## Contexto arquitectónico descubierto

**Stack:** React 19 + Vite + Wouter + @tanstack/react-query + Capacitor 8 (Android) + workspace PNPM

**Dos mundos coexisten en el mismo código:**

1. **Mundo tipado** — `@workspace/api-client-react` (Orval-generated desde `lib/api-spec/openapi.yaml`).
   - 49 hooks de react-query (`useListProjects`, `useGetProject`, `useUpdateProject`, `useRunSeoAudit`, etc.)
   - Wrapper `customFetch` excelente (`lib/api-client-react/src/custom-fetch.ts`): ApiError tipada, parsing robusto, `credentials: "include"` por defecto, soporte bearer, manejo de 204/HEAD, etc.
   - Usado en **16 páginas / 14 hooks de lectura** (mayormente `/projects/*`, `/products/*`, `/audit/*`, `/ab-tests/*`, `/seo/*`).

2. **Mundo wild-west** — `fetch()` directo.
   - **180 call sites**, **135 endpoints** sin pasar por `customFetch`.
   - Cada página reimplementa manejo de errores, `credentials`, headers. Inconsistencia garantizada.
   - 0 `useMutation` en todo el código — todas las mutaciones son `async/await fetch` + `setState` manual.

**Consecuencia:** los endpoints del OpenAPI tienen cache, invalidation, tipos. Los demás (chatbot, CMS, admin, billing, emails, vault, klaviyo, shopybrain extendido) no tienen nada.

**Inline queryClient** — `App.tsx:81-99`: `staleTime: 5min`, `gcTime: 30min`, `refetchOnWindowFocus: false`, retry que excluye 401. Correcto.

---

## Cifras del cruce frontend ↔ backend

| Métrica | Valor |
|---|--:|
| Endpoints únicos llamados desde FE (método + ruta normalizada) | **149** |
| Rutas únicas declaradas en BE | **360** |
| Matched (FE llama → BE sirve) | **144** |
| **Mismatches reales** | **1** (PATCH `/api/projects/:id`) |
| Rutas BE sin caller FE | **~190** (Klaviyo completo, buena parte de `/exports/*`, `/plans/*`, `/push/*`, `/inventory/sync*`, `/generator/*`, OAuth Shopify, impersonate, etc.) |
| Falsos positivos del diff (URLs dinámicas `${x}`) | **4 de 5 "orphans"** |

---

## 🔴 CRÍTICOS (rompen cosas o exponen datos)

### C1 · `PATCH /api/projects/:id` inexistente en backend

- **Where:** `src/pages/admin/Revenue.tsx:72`
  ```ts
  await fetch(`${API}/api/projects/${id}`, {
    method: "PATCH", credentials: "include",
    ...
  });
  ```
- **Backend:** `routes/projects.ts:500` solo tiene `router.put("/projects/:projectId", ...)`. No hay PATCH handler.
- **Efecto runtime:** Express devuelve `404` / sin match. Como `Revenue.tsx` envuelve en `try { } catch { }` sin handler, la UI marca el proyecto como editado localmente (optimistic update en línea 78) aunque el servidor **nunca lo guardó**. Cerrar el navegador pierde los cambios.
- **Fix:** cambiar `"PATCH"` → `"PUT"` y añadir check `if (!res.ok)` con toast. Ver `01-PATCHES.md § C1`.

### C2 · `/api/apk/*` públicos y queman tu token de GitHub

- **Where:** `artifacts/api-server/src/routes/index.ts:64`
  ```ts
  router.use(apkRouter);          // línea 64 — PÚBLICO
  router.get("/report-templates/:token", ...)
  router.use(requireAdmin);       // línea 80 — todo lo de aquí en adelante queda protegido
  ```
- `routes/apk.ts:23,57,82` handlers no llaman `requireAdmin` localmente.
- **Efecto:** un anónimo que conozca `/api/apk/build` puede dispararlo sin sesión; el endpoint llama `ghFetch(/repos/Esparramador/Shopy-Crafter/actions/workflows/build-apk.yml/dispatches)` con tu `GITHUB_API_TOKEN`. Consume minutos CI y crea releases sin control.
- **Impacto adicional:** `apk.ts:82 GET /api/apk/download` puede devolver el APK firmado a cualquiera.
- **Fix:** mover `router.use(apkRouter)` debajo de `router.use(requireAdmin)` **o** añadir `requireAdmin` por-handler. Ver `01-PATCHES.md § C2`.

### C3 · `reveal-token` sin scope por proyecto

- **Where:** `artifacts/api-server/src/routes/projects.ts:657`
  ```ts
  router.get("/projects/:projectId/reveal-token", async (req, res) => {
    const id = parseInt(...);
    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, id));
    if (!project) { res.status(404)...; return; }
    // ❌ no valida req.user.id == project.ownerId (o equivalente)
    const plainToken = safeDecrypt(project.accessToken) || project.accessToken;
    const masked = plainToken.slice(0,8) + "••••••••••••" + plainToken.slice(-4);
    res.json({ accessToken: masked, ... });
  });
  ```
- Cualquier admin ve el token (enmascarado) de cualquier proyecto. En SaaS multi-tenant es una fuga entre agencias.
- Separadamente: aunque el return sea enmascarado, la llamada a `safeDecrypt` devuelve **el plano en memoria**. Si se añade un `console.log` por depuración o Sentry, se te escapa el token real.
- **Fix:** añadir validación de propiedad. Si no tienes multi-tenancy todavía, al menos loguea el acceso y no descifres si vas a enmascarar. Ver `01-PATCHES.md § C3`.

### C4 · `pages/admin/Billing.tsx` huérfana de routing

- **Where:** `src/App.tsx` — no importa ni rutea `Billing.tsx`.
- El archivo existe (`pages/admin/Billing.tsx`), el backend tiene `/api/billing/subscription`, `/api/billing/plans`, `/api/billing/invoices`, `/api/billing/upgrade`, `/api/billing/affiliate`, `/api/billing/affiliate/join` (`routes/billing.ts`).
- **Efecto:** el admin no puede ver su plan, invoices, ni gestionar afiliados desde la UI. La función existe, solo falta el `<Route>`.
- **Corrección importante al Bloque A:** "billing.ts está mock" es **falso**. `billing.ts:17-44` hace `db.select().from(subscriptionsTable)` con Drizzle, crea el trial en BD. Lo único pendiente sería Stripe/pasarela (el endpoint `upgrade` probablemente es stub — verificarlo es otro task).
- **Fix:** añadir import + `<Route path="/admin/billing">` en App.tsx. Ver `01-PATCHES.md § C4`.

---

## 🟠 ALTOS

### A1 · 197 `fetch()` directos bypassean el wrapper `customFetch` existente

- El `customFetch` de Orval es de buena calidad (ApiError tipada, BOM strip, `responseType=auto`, credentials, bearer). Está escrito y nadie fuera de los 14 endpoints del OpenAPI lo usa.
- **Efecto:**
  - Errores inconsistentes: unos `try/catch` silenciosos, otros con toast, otros con `setError` local.
  - Respuestas 401 no disparan logout global. El AuthContext detecta offline pero no expiración de sesión.
  - Imposible refresh de sesión centralizado.
- **Fix estructural (recomendado):**
  1. Crear `src/lib/api.ts` que exporte `customFetch` del cliente Orval con `credentials: "include"` forzado y sin base URL (para que use relativas).
  2. Migrar las páginas en orden de severidad: primero las que no pasan `credentials` (bugs reales), luego el resto.
  3. Añadir un `response.status === 401 → logout + redirect` global.
  Ver `01-PATCHES.md § A1`.

### A2 · `fetch()` sin `credentials: "include"` donde se necesita sesión

3 bugs reales de esto (excluyendo endpoints legítimamente públicos):

| Archivo | Línea | Endpoint | Por qué falla |
|---|--:|---|---|
| `src/pages/projects/Pricing.tsx` | 958 | `POST /api/projects/:id/products/:pid/ai-estimate-cogs` | Detrás de `requireAdmin` en backend → 401 silencioso, COGS masivo muestra "success" con 0 actualizados |
| `src/pages/admin/CMSEditor.tsx` | 883 | `POST /api/cms/media/upload` | `/api/cms/*` protegido en backend → no sube |
| `src/pages/admin/CMSEditor.tsx` | 901 | `DELETE /api/cms/media/:filename` | Idem — no borra, el `.catch(()=>{})` oculta el 401 |

Otros `fetch` sin creds que SÍ son correctos (no los marco como bug):
- `Landing.tsx:17,208,210,229` (apk/status, contact, cms/content) — endpoints públicos
- `ResetPassword.tsx:56`, `ForgotPassword.tsx:20`, `CmsContext.tsx:39` — endpoints públicos

Ver `01-PATCHES.md § A2`.

### A3 · OmniChatbot: 55 acciones backend sin formatter UI

- `components/OmniChatbot.tsx:1037-1418` — `formatActionResult()` tiene **93 case labels**.
- Backend `routes/shopybrain.ts:1725 execute-action` dispatch tiene **148 case labels**.
- **55 acciones** devuelven resultado que el UI renderiza con fallback genérico `"✅ Acción completada"` o `"✅ {result.message}"`. Lista completa en `02-OMNI-ACTIONS-DIFF.md`. Ejemplos impactantes:
  - `invite_client`, `create_user`, `activate_user`, `deactivate_user`, `reset_user_password`
  - `generate_budget`, `generate_platform_report`, `run_full_audit_report`, `run_leveled_report`
  - `fusion_analyze`, `fusion_create_product`, `virtual_tryon`
  - `bulk_update_prices`, `bulk_update_stock`, `sync_catalog_prices`
  - `generate_brand_kit`, `generate_brand_guide`, `generate_brand_css`
- **Efecto:** el usuario pide "crea 10 usuarios", la acción se ejecuta, pero la respuesta del chatbot dice solo "✅ Acción completada" sin listar ids/emails. UX pobre en funciones clave.
- **Fix:** añadir case-by-case al switch, o (mejor) que el backend devuelva siempre `{ok, summary, details}` y el UI use `summary` en el fallback. Ver `01-PATCHES.md § A3`.

### A4 · Guard `RequireAdmin`/`RequireClient` no fuerza re-check en mutaciones de rol

- **Where:** `src/App.tsx:123-128`
  ```ts
  function RequireAdmin({ children }) {
    const { user, loading } = useAuth();
    if (loading) return <LoadingScreen />;
    if (!user) return <Redirect to="/" />;
    if (user.role !== "admin") return <Redirect to="/client" />;
    return <>{children}</>;
  }
  ```
- El guard es **solo UI**. El backend ya protege con `router.use(requireAdmin)` en `index.ts:80`, así que la defensa real existe. Peero: si un admin es degradado a client mientras navega, seguirá viendo la UI admin (fetch fallará 403 pero UI no se mueve).
- **AuthContext** refresca en `visibilitychange` (línea 98 `handleVisibility`) — bien, pero con `setTimeout(..., 500)` (línea 104). Agresivo.
- **Fix menor:** en `RequireAdmin`, si `user.role !== "admin"` hacer `refresh()` antes de redirect. Ver `01-PATCHES.md § A4` para opción más defensiva.

### A5 · Android: `allowBackup="true"` + permisos faltantes

- **Where:** `android/app/src/main/AndroidManifest.xml:4,42`
  - `android:allowBackup="true"` permite extraer cookies de sesión (`connect.sid` u similar) y localStorage (`sc_last_route`, `sc_session_alive`) vía `adb backup`.
  - Solo declara `INTERNET`. Falta:
    - `RECORD_AUDIO` → **VoiceButton.tsx** usa `getUserMedia({audio:true})` en runtime (`components/VoiceButton.tsx:88-100`). Sin permiso declarado → app crash o permiso denegado en Android 6+.
    - `READ_MEDIA_IMAGES` + `READ_MEDIA_VIDEO` → Android 13+ lo requiere para el file picker de `ReferenceMediaPanel.tsx` y para el `OmniChatbot` attachment.
    - Opcional: `POST_NOTIFICATIONS` (Android 13+) si se prevé usar `/api/push/*`.
- **Fix:** editar AndroidManifest.xml. Ver `01-PATCHES.md § A5`. Archivo completo ya fixed en `files-to-replace/AndroidManifest.xml`.

### A6 · `postMessage` con origin `"*"` en Landing.tsx

- **Where:** `src/pages/Landing.tsx:507`, `:525`
  ```ts
  window.parent.postMessage({ type: "cms-click-to-edit", path }, parentOrigin || "*");
  ```
- Cuando `parentOrigin` es falsy, se publica a `"*"` — el mensaje llega a cualquier frame padre.
- Riesgo bajo en producción si la landing no se embebe, pero en el CMS editor sí se embebe en iframe (`CMSEditor.tsx:1253-1302`) y se envía mensaje bidireccional.
- **Fix:** si `parentOrigin` es falsy → **no postear**. Ver `01-PATCHES.md § A6`.

### A7 · XSS potencial en Redesign.tsx e Images.tsx

- **Where:**
  - `src/pages/projects/Redesign.tsx:513` — `dangerouslySetInnerHTML={{ __html: result.bodyHtml || "" }}`. `bodyHtml` viene de la respuesta de `POST /api/projects/:id/products/:pid/redesign` — es HTML generado por LLM (Claude/Gemini). Si el modelo emite `<script>`, se ejecuta.
  - `src/pages/projects/Images.tsx:566` — `dangerouslySetInnerHTML={{ __html: svgContent ... }}`. SVG subido/generado puede contener `<script>` dentro.
- **Efecto:** XSS en contexto admin. Un atacante que pueda influir en el resultado del LLM (prompt injection en producto Shopify con descripción maliciosa) ejecuta JS en el navegador del admin, con sus cookies de sesión.
- **Fix:** instalar `isomorphic-dompurify` (o `dompurify`), sanitizar antes de render. Ver `01-PATCHES.md § A7`.

### A8 · react-query: zero `useMutation`, invalidations inconsistentes

- **Problema:** mutaciones (crear proyecto, editar producto, subir imagen, etc.) se hacen con `fetch + setState` en vez de `useMutation`. Efecto: no hay retry automático, no hay optimistic updates, y las invalidations son manuales (solo 10 llamadas a `invalidateQueries` en 6 páginas).
- **Keys mezcladas:**
  - OK: `queryKey: getListProjectsQueryKey()`, `getGetProjectQueryKey(id)`, `getGetProjectProductsQueryKey(id)` — generadas por Orval.
  - Inconsistente: `queryKey: ["job-status", projectId, jobId]` en `Consistency.tsx:22` y `Redesign.tsx:52` como literales. Si el backend añade un nuevo status, invalidar uno no invalida el otro.
- **Efecto concreto:**
  - Crear producto en Omni Chat no refresca la lista del proyecto.
  - Invitar cliente en `AdminClients` no refresca `useListProjects` en la barra lateral → el contador queda stale hasta F5.
- **Fix:** corto plazo, añadir `queryClient.invalidateQueries({queryKey:getListProjectsQueryKey()})` tras los puntos donde se crean/borran proyectos o clientes. Largo plazo, migrar a `useMutation` pasa por pasa. Ver `01-PATCHES.md § A8`.

---

## 🟡 MEDIOS

### M1 · 190 rutas backend sin UI (features fantasma o pendientes)

Áreas completas sin consumidor frontend:

| Área | Rutas sin UI | Backend ref |
|---|--:|---|
| Klaviyo (`/api/klaviyo/*` + `/api/klaviyo-ai/*`) | 15 | `klaviyo.ts`, `klaviyo-ai.ts` |
| Exports extendidos (`/api/projects/:id/exports/*` y `/api/exports/*`) | 26 | `exports.ts` (5115 líneas) |
| Plans/packs UI (`/api/projects/:id/plan/*`, `/api/plans/definitions`) | 7 | `plans.ts` |
| Push notifications (`/api/push/*`) | 3 | `push.ts` |
| Inventory sync & sales (`/api/inventory/sync*`, `alerts`, `sales-*`, `deep-report`) | 7 | `inventory.ts` |
| Universal Generator (`/api/generator/run`, `levels`, `types`, `download`, `history`) | 5 | `generator.ts` |
| Shopify OAuth (`/api/shopify/oauth/{start,callback,check}`) | 4 | `projects.ts:64-213` |
| Admin impersonation (`/api/admin/impersonate/:userId`) | 1 | `admin.ts:234` (solo stop está usado) |
| Brain Sync export/import (`/api/admin/brain-*`) | 11 | `brain-sync.ts` |
| Leads + Lead Reports | 3 | `contact.ts:1025-1076` |
| ShopyBrain research extendido (audit-entity, supplier-*, research-entity POST) | 5 | `entity-research.ts`, `absorber.ts` |
| Misc: `/api/track`, `/api/reference/ingest`, `/api/cms/versions`, `/api/cms/events` | 4 | varios |

**Nota:** "sin UI" no siempre significa "muerto". Algunos los invoca **OmniChatbot** indirectamente vía `execute-action` (el backend llama a lo que necesite internamente). Para identificar cuáles son realmente muertos habría que trazar `execute-action` case-by-case. Fuera del presupuesto de esta auditoría; ver `03-UNUSED-BACKEND.txt` para lista cruda.

**Recomendación:** decidir por área:
- **Klaviyo** → si no es prioridad Q2-Q3, borrar los 49 routes y `klaviyo.ts`/`klaviyo-ai.ts`. Son 600+ líneas mantenidas sin uso.
- **Push** → borrar salvo que la app Android la necesite. Permite quitar `web-push` dependency.
- **Shopify OAuth** → hay rutas completas pero `NewProject.tsx` crea proyectos con `clientId/clientSecret` manuales (custom app). Si el OAuth está planeado, falta el botón "Conectar con Shopify" que haga `GET /api/shopify/oauth/start?shop=...`. Si no, borrar las 4 rutas.
- **Admin impersonate** → `App.tsx:159-162` maneja STOP. Falta UI en `AdminClients.tsx` para START (botón "Ver como cliente"). Bajo riesgo.
- **Exports** → algunos están detrás de OmniChatbot action `generate_export`. Probablemente vivos. Revisar antes de borrar.

### M2 · `ClientApprovals.tsx:37-47` sin feedback de error

```ts
const act = async (id, action) => {
  setProcessing(id);
  await fetch(`${API_BASE}/api/client/approvals/${id}/${action}`, {...});  // no se revisa res.ok
  setProcessing(null);
  load();
};
```
- Si el backend rechaza (403, 500, network), el cliente ve el approval recargado sin cambio, sin feedback de por qué.
- **Fix:** capturar `res`, mostrar toast si `!res.ok`. Ver `01-PATCHES.md § M2`.

### M3 · CoachMarks sin versión → usuarios antiguos nunca ven updates

- **Where:** `src/components/CoachMarks.tsx:47` — `COACH_MARKS_KEY = "sc_coach_marks_dismissed"` sin sufijo de versión.
- Si cambias los tours, los que ya los descartaron nunca los verán.
- **Fix:** sufijar con versión `sc_coach_marks_v2_dismissed` y bumpear cuando hay cambios significativos. Ver `01-PATCHES.md § M3`.

### M4 · ErrorBoundary no reporta a servidor

- **Where:** `src/components/ErrorBoundary.tsx:23-25` — `componentDidCatch` solo hace `console.error`.
- En producción no tienes forma de saber qué errores rompen a usuarios.
- **Fix:** añadir `fetch("/api/errors", {method:"POST", body:...})` silencioso. Backend sería un endpoint nuevo (50 líneas). Ver `01-PATCHES.md § M4`.

### M5 · `initGlobalErrorHandlers()` se llama fuera del componente

- **Where:** `src/App.tsx:452` — `initGlobalErrorHandlers();` al final del fichero antes de `function App()`.
- Se ejecuta en tiempo de import del módulo, no dentro del ciclo de React. Si `global-error-handler.ts` registra listeners en `window.onerror`, los registra una vez al cargar. Funcional pero frágil a doble import (ej. HMR).
- **Fix:** mover a `useEffect` en el `App` component, cleanup en return.

---

## 🟢 BAJOS

- **B1 · `Tienda.tsx` es un pass-through de 26 líneas** que redirige a Shopify. No hay "flujo de compra de créditos" en el React — todo ocurre en `comic-crafter.myshopify.com`. Si quieres tracking de conversión necesitarás un webhook Shopify + UI nueva. *No es bug.*

- **B2 · `InviteSetup.tsx` duplica `StepPassword`** — líneas 17 y 332 con código casi idéntico. Refactor a un solo componente.

- **B3 · Orval hooks nunca usados:** `useAuditProduct`, `useCreateProject`, `useDeleteProject`, `useGetAbTest`, `useGetProduct`, `useHealthCheck`, `useRunAudit`, `useTrackEvent`, `useUploadImageToShopify`. Las páginas equivalentes usan `fetch` directo. Migrar gana tipos y cache automática.

- **B4 · `localStorage` sin namespace consistente** — prefijos mezclados: `sc_last_route`, `sc_session_alive`, `sc_coach_marks_dismissed`, `sc_recent_searches`, `img-jobs-${projectId}`, `img-bulk-${projectId}`. Estandarizar a `sc_*` (añade colisión si alguna lib usa `img-*`).

---

## Flujos críticos auditados (resumen)

### Login → Dashboard admin
- `Login.tsx:18` → `AuthContext.login()` → POST `/api/auth/login` → GET `/api/auth/me` → role check → navigate `/home` o ruta guardada (`getLastRoute`).
- **OK** · con detalle pequeño: `Login.tsx:21-32` llama `navigate(savedRoute)` solo si `role === "admin"` — si un client había guardado última ruta de cliente, la pierde al re-login. Menor.

### Invite cliente → Setup password → Dashboard client
- Admin en `AdminClients.tsx:75` → POST `/api/admin/projects/:id/invite` → recibe `inviteLink` + copia al clipboard.
- Usuario visita `/invite/:token` → `InviteSetup.tsx:376` GET `/api/auth/invite/:token` (valida y devuelve data del cliente).
- `InviteSetup.tsx:42` POST `/api/auth/invite/:token/setup` con password → `refresh()` AuthContext → step 2 → `/client`.
- **OK** estructuralmente. Dos detalles: (a) el token `inviteLink` se copia al clipboard con `writeText` sin comprobar permisos; en mobile puede fallar silencioso. (b) `StepPassword` está **duplicado** (B2).

### Crear proyecto nuevo (Shopify / Woo / Presta / Universal)
- `NewProject.tsx:45` — state `platform: "shopify" | "woocommerce" | "prestashop" | "universal"`.
- `handleTestConnection` (línea 96) → POST `/api/projects/test-connection-presave` con creds platform.
- `handleSubmit` (línea 134) → POST `/api/projects` → `queryClient.invalidateQueries({queryKey:getListProjectsQueryKey()})` → navigate.
- **OK**. Nota: para `platform === "shopify"`, el flujo actual es **credentials manuales** (custom app token). El `/api/shopify/oauth/start` existe en backend pero no se usa. Decidir si se añade botón "Conectar vía OAuth Shopify" o se borra backend.

### Comprar pack de créditos (Shopify cart)
- `Tienda.tsx` redirige a `comic-crafter.myshopify.com/...`. El checkout es externo. Post-compra no hay webhook visible en backend (`store.ts:128 checkout` existe pero sin caller — probablemente se llama desde Shopify webhook app).
- **No auditado a fondo** por falta de visibilidad cross-app. Si quieres cerrar el loop, añade a `store.ts` un webhook handler `orders/paid` que acredite `subscriptionsTable.imagesIncluded`.

### Generar imagen / audit / report / redesign
- Todas usan hooks Orval tipados (`useGenerateImage`, `useRunSeoAudit`, `useRedesignProduct`, `useBuildImagePrompt`, `useApplyRedesign`, etc.).
- Polling de jobs: `Redesign.tsx:52 useGetGenerationJob` y `Images.tsx` con keys literales.
- **OK en grueso**. Tres detalles:
  - `Images.tsx:285-293` carga del localStorage un snapshot de jobs con TTL 10min — si el backend cierra el job, la UI muestra stale hasta que se monta de nuevo.
  - `Redesign.tsx:513` XSS potencial (A7).
  - `Pricing.tsx:958` missing creds (A2).

### Descargar PDF/ZIP del vault
- `ProjectVault.tsx` / `GlobalVault.tsx` → `/api/projects/:id/vault/*` (endpoints existen).
- **No auditado en profundidad** — los heavy files (CMSEditor 1700L, MyPricing 1034L, AdminClients 805L, Audit 1400L) no caben en el presupuesto restante. Marcados en `04-PENDING-DEEP-DIVE.md`.

### Forgot/Reset password
- `ForgotPassword.tsx:20` POST `/api/auth/forgot-password`. **OK** (público por diseño).
- `ResetPassword.tsx:56` POST `/api/auth/reset-password` con token de URL. **OK**.
- `ResetPassword.tsx:43` valida `password.length < 8` — mismo threshold que `InviteSetup.tsx:38`. Consistente.
- Detalle: no hay validación de complejidad (solo longitud). Si quieres ser estricto, añadir regex.

---

## OmniChatbot — detalle

- **API principal:** `POST /api/shopybrain/execute-action` (shopybrain.ts:1725). Body `{action, params}`. Timeout 180s con AbortController (`OmniChatbot.tsx:1007-1035`).
- **Mensajes de error amigables** según response body (`credit balance is too low`, `rate_limit`, `401`) — **bien hecho**.
- **Acciones "acompañantes" (por proyecto):**
  - `POST /api/projects/:id/actions/send` — envía resultado al cliente (action-buttons.ts:297)
  - `POST /api/projects/:id/actions/save` — guarda en vault (action-buttons.ts:338)
  - `POST /api/projects/:id/actions/download` — descarga zip/html (action-buttons.ts:407)
- **Absorb flows:** `/api/shopybrain/absorb-document`, `/api/shopybrain/absorb-image`, `/api/shopybrain/absorb-url`, `/api/shopybrain/create-product-from-image` — usados con FormData, timeout 180s.
- **Voice:** `POST /api/voice/command` (`VoiceButton.tsx:171`) y `POST /api/shopybrain/execute-action` desde voz también.

Lista completa de **55 acciones BE sin formatter UI** en `02-OMNI-ACTIONS-DIFF.md`.

---

## Capacitor / Android

### Bueno
- `capacitor.config.ts` usa `cleartext: false`, `androidScheme: "https"`, `allowMixedContent: false`, `webContentsDebuggingEnabled: false` → todo correcto para producción.
- `captureInput: true` → teclado físico llega a la WebView (bien para PC-like Chromebook).
- `appId: "es.shopybrain.app"` → consistente con marca.
- Server URL remoto vía `APP_URL` env con fallback a `https://shopycrafter.com` → la app funciona como wrapper, no como SPA offline. Estrategia coherente.

### A arreglar
- **A5** (ver arriba): `allowBackup="true"` + faltan `RECORD_AUDIO`, `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`.
- **Sin `intent-filter` para deep links** — si quieres que `shopycrafter.com/projects/123/audit` abra la app desde un click en email, falta un `<intent-filter android:autoVerify="true">` con `<data android:scheme="https" android:host="shopycrafter.com"/>`.
- **Sin `android:theme` para splash screen** — configurado en capacitor.config, pero un `style` en `styles.xml` robusto no está verificable desde los tarballs (falta `res/values/styles.xml`).
- **Version code / name** — no puedo verlos sin `build.gradle`. Asegúrate de bumpearlos por release (olvidarse → Google Play rechaza).

Fichero `AndroidManifest.xml` arreglado: `files-to-replace/AndroidManifest.xml`.

---

## Seguridad (recap)

| Vector | Estado |
|---|---|
| XSS (dangerouslySetInnerHTML) | 🟠 2 sitios sin sanitizar — A7 |
| Tokens en bundle | ✅ solo usa `import.meta.env.BASE_URL` (ruta base del deploy) — no hay secretos |
| Cookies de sesión | ✅ mayoritariamente `credentials: "include"`; 3 bugs aislados — A2 |
| CSRF | 🟠 backend expone `app.use(cors({...}))` (app.ts:49) pero no veo `csurf` middleware; las rutas POST/PUT protegidas solo por sesión cookie. Revisar `cors.origin` y `sameSite` de cookie (no lo tengo en el backend lib visible). Fuera del scope frontend, pero **marcar para Bloque A revisión**. |
| postMessage | 🟠 `"*"` fallback en Landing.tsx — A6 |
| allowBackup Android | 🟠 A5 |
| Guards | 🟡 A4 — solo UI, backend sí protege |
| localStorage sensible | ✅ solo `sc_last_route` y `sc_session_alive` (flag boolean) — no tokens ni PII |
| reveal-token scoping | 🔴 C3 |

---

## Entregables adjuntos

```
shopycrafter-audit/
├── 00-AUDIT-REPORT.md        ← este archivo
├── 01-PATCHES.md             ← fixes copy-pasteables por finding
├── 02-OMNI-ACTIONS-DIFF.md   ← 93 UI vs 148 BE, las 55 faltantes
├── 03-UNUSED-BACKEND.txt     ← 190 rutas BE sin caller FE
├── 04-PENDING-DEEP-DIVE.md   ← lo que quedó fuera del presupuesto
└── files-to-replace/
    ├── AndroidManifest.xml   ← reemplaza android/app/src/main/AndroidManifest.xml
    ├── Revenue.tsx           ← reemplaza src/pages/admin/Revenue.tsx (fix C1)
    └── routes-index.ts       ← reemplaza api-server/src/routes/index.ts (fix C2)
```
