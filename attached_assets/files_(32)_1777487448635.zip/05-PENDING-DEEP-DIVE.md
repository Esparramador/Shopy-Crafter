# Zonas NO auditadas a fondo

Registro honesto de qué no llegué a tocar y por qué, para que el siguiente pase sepa por dónde empezar.

## Páginas admin no auditadas línea a línea

| Archivo | Líneas | Notas |
|---|--:|---|
| `pages/admin/CMSEditor.tsx` | 1691 | Sí audité fetches + postMessage (M8) + creds (A2). No seguí la lógica de schema CMS, versioning, batch save. |
| `pages/admin/MyPricing.tsx` | 1034 | Sí audité endpoints. No seguí `analyzePricing` ni builders de budget. |
| `pages/AdminClients.tsx` | 805 | Sí audité invite, payment-link, users toggle, messages. No vi modales de editar/pausar cliente. |
| `pages/projects/Audit.tsx` | 1396 | Sí audité execute-action (A10). No seguí optimize_all → vault. |
| `pages/admin/Emails.tsx` | 727 | Sí conté fetches. No audité la generación de emails con IA ni el push a Klaviyo. |
| `pages/admin/ShopyBrain*.tsx` | 4 páginas | No auditado. Son de gestión del cerebro (memorias, insights, study, base). Bajo riesgo si el backend está bien. |
| `pages/admin/Intelligence.tsx` + `GeminiIntelligence.tsx` | 2 páginas | No auditado. Research dashboard. |
| `pages/admin/TemplateStudio.tsx` | - | No auditado. Plantillas de informe. |
| `pages/admin/AdminSettings.tsx` | - | No auditado. Config general. |
| `pages/admin/SystemHealth.tsx`, `Roadmap`, `Achievements`, `CommandCenter`, `Forecast`, `Inventory`, `Competitors`, `UniversalSearch`, `ApkManager`, `GlobalVault`, `ProjectVault`, `AdminABTests`, `AdminProducts`, `AdminAutomations`, `EmailTemplates` | - | No auditadas. Prioridad baja a menos que reporten bugs. |

## Páginas de cliente no auditadas en profundidad

Solo `ClientApprovals.tsx` se revisó (y se encontró M2). Falta:

| Archivo | Notas |
|---|---|
| `pages/client/ClientDashboard.tsx` | No auditado |
| `pages/client/ClientMessages.tsx` | Complemento del mensajería A12 |
| `pages/client/ClientProducts.tsx` | No auditado |
| `pages/client/ClientReports.tsx` | No auditado — descarga PDF/ZIP del vault (pendiente "flujo crítico") |
| `pages/client/ClientLayout.tsx` | Layout wrapper, bajo riesgo |

## Páginas /projects/ no auditadas

Auditadas parcialmente o sí: `Audit.tsx`, `Redesign.tsx`, `Images.tsx`, `Pricing.tsx`, `Settings.tsx`, `Consistency.tsx`, `ABTesting.tsx`, `SEO.tsx` (por imports Orval).

No auditadas a fondo:
- `pages/projects/FusionStudio.tsx` — Fusion Studio (creación de producto con IA)
- `pages/projects/UniversalGenerator.tsx`
- `pages/projects/WebLab.tsx` + `WebLabStandalone` — analisis de competidores web
- `pages/projects/ExportCenter.tsx` — punto clave del "flujo crítico" de descargas

## Componentes no auditados

- `components/BrainExtractor.tsx` (77L) — saqué un endpoint call, no profundicé
- `components/KnowledgeGraph.tsx` — d3 viz
- `components/CommandPalette.tsx` — Cmdk
- `components/GenerationProgress.tsx`, `OnboardingWidget.tsx`, `CoachMarks.tsx`, `ReferenceMediaPanel.tsx`, `SaveReportButton.tsx`, `SaveToVaultButton.tsx` — vistos por fetches pero no lógica
- `components/ui/*` (shadcn) — no auditados; son estándar shadcn

## Backend no auditado

- `lib/` de `api-server` (los 51 ficheros de `api-server-lib_tar.gz`):
  - `lib/auth.ts` — no verifiqué `requireAdmin` implementation exactly
  - `lib/crypto.ts` — no verifiqué `safeDecrypt` (relevante para C3)
  - `lib/shopify.ts`, `lib/connectors/*` — no verifiqué ataques de Shopify API
  - `lib/audit.ts`, `lib/pdf-generator.ts`, `lib/vault.ts` — no auditados
  - Sesión: `cookie.secure`, `sameSite`, `httpOnly` — NO vistos. Cero visibilidad del setup de express-session.

## OpenAPI spec

- `lib/api-spec/openapi.yaml` (2417L) — vi los paths. No comparé response schemas con lo que devuelven los handlers reales.

## Bloques nunca tocados del prompt original

| Bloque pedido | Estado |
|---|---|
| **6. UX/a11y básico** | Parcial — loading states sí los vi; mobile responsive NO probado (requiere runtime); crashes con datos vacíos detectados solo en ClientApprovals y Revenue (catch vacíos). |
| Testing con trial/sin datos | No probé ningún flujo con BD vacía. Algunos componentes hacen `Array.isArray(d) ? d : []` (bien), otros no. Una auditoría de "¿qué revienta si el backend devuelve `{}`?" sería un pase propio. |

## Para el siguiente Claude / próxima sesión

**Carga incremental recomendada** (mantén contexto pequeño):

1. Sube solo lo que vas a auditar (ej. `ExportCenter.tsx` + `exports.ts` del backend) en lugar de los tarballs completos.
2. Incluye como "memoria" este documento + `00-AUDIT-REPORT.md` para no re-explicar el stack.
3. Pide *"profundiza en bloque X del audit report; no repitas estructura"*.

**Orden sugerido de próximo pase:**

1. Bloque 6 (UX/a11y) dedicado: abrir Chrome DevTools mobile, recorrer 3 flujos (login, crear proyecto, ver audit). Reportar por pantalla qué se rompe.
2. `lib/auth.ts` + setup de express-session: revisar cookie `sameSite`, `secure`, `maxAge`, y `requireAdmin` implementation.
3. Flujo PDF/ZIP (`ExportCenter.tsx` + `vault.ts`): auditoría completa de descarga, sanitización de nombres de archivo, streaming.
4. OpenAPI diff: que el agente next genere un diff response-schema vs handler real.
