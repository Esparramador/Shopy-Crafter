# Fusion Studio Pro — Suite completa de IA generativa

## Lo que incluye

**12 capacidades AI conectadas, todas accesibles desde una página unificada:**

| Capacidad | Modelos disponibles | Casos de uso |
|---|---|---|
| **Generar imagen** | Flux 1.1 Pro Ultra · Flux 1.1 Pro · Flux Schnell · Recraft V3 · Ideogram V3 Turbo · Imagen 4 Ultra · Nano Banana · Flux Kontext Pro | Hero shots, packaging, posters con texto, lifestyle |
| **Editar imagen** | Nano Banana (Gemini) · Flux Kontext Pro · Runway Aleph | Cambiar fondo conservando producto, modificar elementos, edits con prompt |
| **Eliminar fondo** | Bria RMBG (commercial-grade) | Producto recortado para e-commerce |
| **Reemplazar fondo** | Flux Inpainting | Producto en escena nueva |
| **Upscale general** | Real-ESRGAN x2/x4 | Aumentar resolución manteniendo fidelidad |
| **Upscale creativo** | Clarity Upscaler (estilo Magnific) | Añade detalle creativo al ampliar |
| **Mejorar caras** | GFPGAN | Retratos antiguos, fotos pixeladas |
| **Generar video** | Runway Gen-4 Turbo · Gen-3 Alpha · Kling 2.1 Master · Kling 2.1 · Seedance Pro · Seedance Fast · Hailuo 02 · Wan 2.5 Fast | Anuncios, reels, contenido para Ads |
| **Voiceover (TTS)** | ElevenLabs v3 / Multilingual v2 / Turbo / Flash | Narración multiidioma |
| **Voice cloning** | ElevenLabs Instant Voice Clone | Voz del CEO/fundador en todos los anuncios |
| **Sound effects** | ElevenLabs Sound Generation | Risers, impacts, ambientes para video |
| **Música original** | Stable Audio Open 1.0 | Bandas sonoras libres de derechos |
| **Composición final** | FFmpeg complex filter | Mux video + voz + música + texto overlay |
| **Descarga ZIP** | archiver | Exporta todos los assets seleccionados |

---

## Aplicación

### 1. Instalar dependencias backend

```bash
cd artifacts/api-server
pnpm add fluent-ffmpeg ffmpeg-static archiver
pnpm add -D @types/fluent-ffmpeg @types/archiver
```

### 2. Variables de entorno (Replit Secrets)

```
GEMINI_API_KEY=<existente>
ELEVENLABS_API_KEY=<nueva, revocada la antigua>
RUNWAY_API_KEY=<nueva, revocada la antigua>
REPLICATE_API_TOKEN=<existente o por proyecto>
```

### 3. Copiar ficheros

**Backend nuevos:**
```bash
cp shopycrafter-audit/files-to-create/fusion-studio-pro.ts  artifacts/api-server/src/lib/fusion-studio-pro.ts
cp shopycrafter-audit/files-to-create/fs-pro.ts             artifacts/api-server/src/routes/fs-pro.ts
cp shopycrafter-audit/files-to-create/adstudio.ts           artifacts/api-server/src/lib/adstudio.ts
cp shopycrafter-audit/files-to-create/ad-studio.ts          artifacts/api-server/src/routes/ad-studio.ts
```

**Backend actualizado (router mounts):**
```bash
cp shopycrafter-audit/files-to-replace/routes-index.ts      artifacts/api-server/src/routes/index.ts
```

**Frontend nuevo:**
```bash
cp shopycrafter-audit/files-to-create/FusionStudioPro.tsx   artifacts/shopify-optimizer/src/pages/projects/FusionStudioPro.tsx
cp shopycrafter-audit/files-to-create/AdStudio.tsx          artifacts/shopify-optimizer/src/pages/projects/AdStudio.tsx
```

**Frontend actualizado (route + sidebar):**
```bash
cp shopycrafter-audit/files-to-replace/App.tsx              artifacts/shopify-optimizer/src/App.tsx
cp shopycrafter-audit/files-to-replace/AppLayout.tsx        artifacts/shopify-optimizer/src/components/layout/AppLayout.tsx
```

### 4. Verificar

```bash
pnpm -F @workspace/api-server build
pnpm -F @workspace/shopify-optimizer typecheck
```

---

## Uso

Acceder a `/projects/<id>/fusion-studio-pro` (icono ✨ "Fusion Studio Pro" en sidebar de proyecto).

**8 pestañas:**

1. **Generar imagen** — selector de 8 modelos top-tier, prompt, aspect, negative prompt, imagen referencia
2. **Editar imagen** — 3 modelos de edit (Nano Banana / Flux Kontext / Runway Aleph), upload + URL
3. **Fondo** — quitar (Bria) o reemplazar (Flux Inpainting con prompt de escena)
4. **Mejorar** — Real-ESRGAN x2/x4, Clarity (creativo), GFPGAN (caras)
5. **Video** — 8 proveedores (Runway Gen-4, Kling Master/2.1, Seedance Pro/Fast, Hailuo, Wan), duración 3-10s, aspecto, prompt
6. **Voz & Música** — TTS con todos los parámetros ElevenLabs, voice clone (sube muestra), SFX, música original
7. **Componer** — selecciona video + voz + música de la sesión actual, ajusta volúmenes, añade overlay de texto, FFmpeg muxer
8. **Descargas** — selecciona checkboxes, descarga ZIP con todos los assets

**Galería de sesión** persistente arriba: ves todo lo generado en esta sesión con thumbnails y botón descargar individual.

---

## Coste por capacidad (estimado)

| Capacidad | Coste/uso | Créditos del plan |
|---|---|---|
| Generar imagen Flux 1.1 Pro Ultra | ~€0.06 | 1 |
| Generar imagen Flux Schnell | ~€0.003 | 1 |
| Generar imagen Recraft V3 | ~€0.04 | 1 |
| Generar imagen Nano Banana | ~€0.04 | 1 |
| Editar imagen | ~€0.04-0.08 | 1 |
| Eliminar fondo (Bria) | ~€0.02 | 1 |
| Reemplazar fondo (Flux Inpaint) | ~€0.04 | 1 |
| Upscale Real-ESRGAN | ~€0.005 | 1 |
| Upscale Clarity | ~€0.04 | 1 |
| Enhance faces (GFPGAN) | ~€0.005 | 1 |
| Video Seedance Fast 5s | ~€0.25 | 4 |
| Video Runway Gen-4 5s | ~€0.50 | 4 |
| Video Kling Master 5s | ~€0.90 | 4 |
| TTS por minuto | ~€0.10 | 0 (no descuenta) |
| Voice cloning | gratis (1ª vez) | 0 |
| SFX 5s | ~€0.02 | 0 |
| Música 30s | ~€0.04 | 2 |
| Composición FFmpeg | ~€0 (local) | 0 |

---

## Endpoints expuestos

```
GET    /api/fs-pro/capabilities            - Catálogo completo
POST   /api/fs-pro/generate-image          - Imagen text-to-image
POST   /api/fs-pro/edit-image              - Editar imagen
POST   /api/fs-pro/remove-bg               - Quitar fondo
POST   /api/fs-pro/replace-bg              - Reemplazar fondo
POST   /api/fs-pro/upscale                 - Upscale (modos: esrgan/clarity/faces)
POST   /api/fs-pro/generate-video          - Video desde imagen
POST   /api/fs-pro/voice/clone             - Clonar voz
DELETE /api/fs-pro/voice/:voiceId          - Eliminar voz clonada
POST   /api/fs-pro/tts                     - Text-to-speech
POST   /api/fs-pro/sfx                     - Sound effects
POST   /api/fs-pro/music                   - Música original
POST   /api/fs-pro/compose                 - Compose video+audio+overlay con FFmpeg
POST   /api/fs-pro/download-all            - ZIP con assets seleccionados
```

Todos requieren `requireAdmin`. Todos descuentan créditos del plan vía `checkProductionLimit` y registran usage. Todos guardan en Vault y alimentan el ShopyBrain con `learnFromOperation`.

---

## Lo que ahora puedes hacer en la práctica

**Caso 1: Hero shot premium para producto**
1. Pestaña "Generar imagen" → modelo Flux 1.1 Pro Ultra → prompt detallado → genera en 4MP
2. Pestaña "Mejorar" → modo Clarity con prompt → upscale a 8MP con detalle creativo
3. Descargar PNG de alta resolución

**Caso 2: Anuncio publicitario completo (manual, control total)**
1. "Generar imagen" → hero shot del producto con Recraft V3 (texto en imagen)
2. "Video" → Runway Gen-4 Turbo desde la imagen → 5s vertical
3. "Voz & Música" → TTS con voz de marca clonada
4. "Voz & Música" → SFX para impacto
5. "Voz & Música" → Música 30s de Stable Audio
6. "Componer" → mezclar todo + overlay "BLACK FRIDAY 50% OFF"
7. "Descargas" → ZIP con MP4 final + assets individuales

**Caso 3: Catálogo masivo de fotos producto**
1. "Editar imagen" con Nano Banana sobre cada producto → cambiar fondo a estudio profesional
2. "Mejorar" → faces enhance si hay modelos
3. "Descargas" → ZIP con todo el set listo para Shopify

**Caso 4: Voz de marca consistente**
1. "Voz & Música" → Clonar voz del CEO con muestra de 30s
2. La voz queda guardada en ElevenLabs y aparece en el selector de TTS
3. Todos los anuncios futuros usan esa voz automáticamente

---

## Notas técnicas importantes

### Compose y vault URLs

El endpoint `/api/fs-pro/compose` **necesita acceso a los buffers de los archivos** del Vault para mezclarlos con FFmpeg. El código actual hace fetch de `originalUrl` o `objectPath` cuando son URLs HTTP públicas. Si tu vault guarda solo en local (Replit Object Storage), hay que adaptar el helper `fetchVaultContent()` en `routes/fs-pro.ts:280` para leer del object storage interno usando la lib que ya tengas (probablemente `lib/objectStorage.ts`).

### FFmpeg en Replit

Si `ffmpeg-static` no funciona en runtime, añadir a `replit.nix`:
```nix
{ pkgs }: {
  deps = [
    pkgs.ffmpeg-full
    # ... resto
  ];
}
```

### ElevenLabs voice clone limits

El plan free de ElevenLabs no permite voice cloning. Plan Creator ($22/mes) permite **10 voces clonadas**. Plan Pro ($99/mes) permite **30**. Si usas voice cloning para múltiples clientes, ten esto en cuenta.

### Cuotas de Replicate

Cada generación consume cuota de tu cuenta Replicate (o del token del proyecto). Vigila el panel `replicate.com/account/billing`.

---

## Resumen final del paquete completo

Tras todas las sesiones de auditoría:

**33+ findings** documentados con archivo:línea
**6 bugs críticos arreglados** (C1 Revenue PATCH, C2 apk público, C3 reveal-token, C4 Billing huérfana, C5 ENCRYPTION_KEY, C6 push roto)
**14 problemas altos** con patches
**10 problemas medios** con patches
**Klaviyo redundante eliminado** (-200 líneas dead code)
**6 features nuevas conectadas** (impersonate, Plans modal, BrainSync admin, Audit Tienda Universal, FusionStudio create-product, AdStudio Pro)
**1 suite completa nueva** (Fusion Studio Pro con 12 capacidades AI)

Todo el código está listo para copiar+aplicar+typecheck.
