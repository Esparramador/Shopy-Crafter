# AdStudio Pro — guía de aplicación

Generador completo de anuncios publicitarios con IA end-to-end:
**Copy (Claude) → Hero image (Nano Banana / Gemini 2.5 Flash Image) → Video (Runway Gen-4 Turbo / Gen-3 / Seedance / Kling / Hailuo) → Voiceover (ElevenLabs) → Música/SFX (ElevenLabs) → Compose final MP4 (FFmpeg)**

---

## 1. Dependencias backend

```bash
cd artifacts/api-server
pnpm add fluent-ffmpeg ffmpeg-static
pnpm add -D @types/fluent-ffmpeg
# (Replicate, @google/genai, web-push ya estaban instaladas)
```

### Replit extras (si usas Replit)

Si FFmpeg no está disponible en runtime, añade a `replit.nix`:
```nix
{ pkgs }: {
  deps = [
    pkgs.ffmpeg-full
    pkgs.nodejs_20
    # ... resto de tus deps
  ];
}
```
(`ffmpeg-static` trae un binary portable, pero usar el del sistema es más robusto).

---

## 2. Variables de entorno (Replit Secrets o `.env`)

Añadir a los que ya tienes:

```
RUNWAY_API_KEY=<tu key NUEVA de Runway>
ELEVENLABS_API_KEY=<tu key NUEVA de ElevenLabs>
GEMINI_API_KEY=<ya existente>  # para Nano Banana
# Opcional
VAPID_SUBJECT=mailto:tu-email@ejemplo.com
```

⚠ **Recordatorio**: las keys van en Secrets del servidor, NUNCA en código, NUNCA en chats.

---

## 3. Copiar ficheros

### Backend nuevo

```bash
cp shopycrafter-audit/files-to-create/adstudio.ts        artifacts/api-server/src/lib/adstudio.ts
cp shopycrafter-audit/files-to-create/ad-studio.ts       artifacts/api-server/src/routes/ad-studio.ts
```

### Backend existente (actualizado con mount del nuevo router)

```bash
cp shopycrafter-audit/files-to-replace/routes-index.ts   artifacts/api-server/src/routes/index.ts
```

### Frontend nuevo

```bash
cp shopycrafter-audit/files-to-create/AdStudio.tsx       artifacts/shopify-optimizer/src/pages/projects/AdStudio.tsx
```

### Frontend existente (actualizado con route + sidebar)

```bash
cp shopycrafter-audit/files-to-replace/App.tsx           artifacts/shopify-optimizer/src/App.tsx
cp shopycrafter-audit/files-to-replace/AppLayout.tsx     artifacts/shopify-optimizer/src/components/layout/AppLayout.tsx
```

## 4. Verificar

```bash
pnpm -F @workspace/api-server build
pnpm -F @workspace/shopify-optimizer typecheck
```

---

## 5. Uso

Ir a `/projects/<id>/ad-studio` (también accesible desde el sidebar de cualquier proyecto con el icono 🎬 "Ad Studio Pro").

**Wizard de 4 pasos:**

1. **Producto** — título, categoría, marca, tono, público, contexto, URL imagen origen (opcional)
2. **Estilo** — objetivo (awareness/conversion/retargeting/ugc/story), formato (9:16/16:9/1:1/4:5), proveedor video, duración (3-10s), nº variantes A/B (1-5)
3. **Voz & Música** — voz ElevenLabs del catálogo (con preview), estabilidad, estilo, checkbox añadir música/SFX
4. **Generar** — resumen + botón "Generar ahora". La generación es **streaming (SSE)** — ves cada paso en tiempo real: copy → imagen → video → voz → compose

**Resultado:** N variantes de video MP4 embebidas en la página, descargables, guardadas automáticamente en el Vault del proyecto. El brain aprende de cada set generado.

---

## 6. Coste real por campaña

Desglose verificado por variante (5s de video):

| Paso | Proveedor | Coste |
|---|---|---:|
| Copy (hook + body + CTA) | Claude Sonnet | ~€0.02 |
| Hero image | Nano Banana | ~€0.04 |
| Voiceover 30 chars x ~10s | ElevenLabs TTS | ~€0.10 |
| SFX ambient 5-10s | ElevenLabs SFX | ~€0.02 |
| Video 5s | **Runway Gen-4 Turbo** | **€0.50** |
| Video 5s | Seedance Fast | €0.25 |
| Compose FFmpeg | Local | €0 |
| **Total Runway tier** | | **~€0.68** |
| **Total Seedance tier** | | **~€0.43** |

Una campaña de 5 variantes = ~€2.15–€3.40 según proveedor.

**Descuenta 6 créditos del plan del proyecto por variante** (24 créditos por campaña de 5 variantes). Ajusta `AD_CREDIT_COST` en `lib/adstudio.ts` si tu pricing de créditos cambia.

---

## 7. Verificación manual

### A. Catálogos
```bash
curl -b "session=..." https://tu-dominio/api/ad-studio/providers
curl -b "session=..." https://tu-dominio/api/ad-studio/voices
```
Ambos deben devolver JSON con listado.

### B. Pipeline completo (test con 1 variante económica)

En la UI:
1. Producto: "Collar de plata"
2. Categoría: "joyería"
3. Objetivo: conversion
4. Formato: 9:16
5. Proveedor: **Seedance Fast** (el más barato)
6. Duración: 5s
7. Variantes: **1** (para test)
8. Voz: primera disponible
9. Música: activada

**Click "Generar ahora"** → deberías ver los eventos SSE:
```
[copy]    Generando ángulos publicitarios con Claude...
[image]   [1/1] Generando imagen hero con Nano Banana...
[video]   [1/1] Generando video con replicate-seedance-fast... (1-3 min)
[voice]   [1/1] Generando voz con ElevenLabs...
[compose] [1/1] Componiendo video final con FFmpeg...
```

**Total esperado:** ~2-3 minutos. Al completar, ves la video card con hook + body + CTA + botón descargar MP4.

---

## 8. Lo que NO incluye (siguiente iteración)

- **Publicar automáticamente en Meta Ads / TikTok Ads** — requiere OAuth + Meta Marketing API + TikTok Business Center API. Los videos quedan en el vault, listos para descargar y subir manualmente a Ads Manager.
- **A/B test tracking real** — las variantes se generan pero no se mide qué funciona. Para eso hace falta webhook desde Meta/TikTok Ads con impressions/clicks/conversions.
- **Edición post-compose** — no se pueden modificar variantes generadas. Hay que regenerarlas con otro prompt.
- **Multi-shot / extensión de video** — cada variante es un clip único. Para videos de 30s+ hay que chain manual (exportar último frame + regenerar con ese como start).
- **Clonación de voz propia** — la UI lista voces stock de ElevenLabs. Para voice cloning (voz del CEO, presentador propio) hay que añadir flujo de consent + upload en Ajustes admin.

---

## 9. Troubleshooting común

### "ELEVENLABS_API_KEY not configured"
Verifica que la secret está en Replit y que el proceso se reinició después de añadirla.

### "RUNWAY_API_KEY not configured"
Igual. Además verifica que la key tiene cuota disponible en tu plan Runway.

### "Hero image generation failed"
Nano Banana tiene rate limit. Si generas muchas campañas seguidas, espera 60s. Si el error persiste, verifica `GEMINI_API_KEY`.

### "FFmpeg not installed"
```bash
pnpm add fluent-ffmpeg ffmpeg-static -F @workspace/api-server
```

### "Runway timed out after 5 minutes"
El modelo elegido puede estar saturado. Cambia a Gen-3 (más rápido) o a Seedance Fast.

### El video final no tiene audio
Verifica los logs de FFmpeg compose. Puede ser que el voiceover tenga 0 bytes (ElevenLabs falló) — en ese caso el MP4 sale mudo. Regenera la variante.

### La variante falla pero otras funcionan
Es normal: el pipeline es independiente por variante. La card de variante fallida muestra el error específico. Regenera solo esa variante con otra configuración.

---

## 10. Arquitectura técnica (para referencia futura)

```
Frontend (AdStudio.tsx)
  │
  ├─ GET /api/ad-studio/providers  → catálogo providers
  ├─ GET /api/ad-studio/voices     → catálogo ElevenLabs voices
  │
  └─ POST /api/ad-studio/generate-campaign (SSE)
        │
        └─ lib/adstudio.ts::runAdCampaign
              │
              ├─ Step 1: generateAdCopy (Claude, paralelo N variantes)
              ├─ Loop por variante:
              │   ├─ Step 2: generateHeroImage (Nano Banana)
              │   ├─ Step 3: generateVideo (Runway OR Replicate)
              │   ├─ Step 4: generateVoiceover (ElevenLabs, paralelo con SFX)
              │   ├─ Step 5: generateSfx (ElevenLabs, opcional)
              │   └─ Step 6: composeFinalAd (FFmpeg mux)
              │
              └─ Para cada variante completada:
                    ├─ saveToVault (hero + voice + final MP4)
                    ├─ recordUsage (plan-limits)
                    └─ learnFromOperation (ShopyBrain absorption)
```

Cada step es independiente. Si un step falla en una variante, la variante se marca con error pero el resto continúan. El SSE emite `progress` eventos en cada cambio de stage y un `complete` al final (o `error` si fallo global).
