# Quick wins aplicados — 3 features backend ahora conectadas en UI

## 1. `Billing` — enrutada + en el sidebar

**Ficheros tocados:**
- `src/App.tsx` — añadido `lazy import` y `<Route path="/admin/billing">`
- `src/components/layout/AppLayout.tsx` — añadida entrada `"Facturación & Plan" 💳` en `DEFAULT_ADMIN_NAV` justo después de `"Revenue & CRM"`

**Resultado:** la página `Billing.tsx` (que ya existía y ya llamaba correctamente a los 6 endpoints `/api/billing/*`) ahora es navegable desde el sidebar admin y responde en `/admin/billing`.

**Verificación manual recomendada:**
- Login como admin → click "Facturación & Plan" en el sidebar → ver plans, subscription, invoices, affiliate.

---

## 2. `AdminClients` — botón "Ver como" (impersonate START)

**Fichero tocado:** `src/pages/AdminClients.tsx`

**Cambios:**
- Añadido icono `Eye` al import de `lucide-react`.
- Añadida función `impersonate(u)` que:
  - Pide confirmación al admin.
  - Hace `POST /api/admin/impersonate/:userId` con `credentials: "include"`.
  - Al éxito hace `window.location.href = "/client"` (recarga completa para que `AuthContext` detecte el cambio de rol en sesión).
  - Muestra `alert` en caso de error de red o de permisos.
- Añadido botón "Ver como" (icono ojo) en la tabla de clientes, justo entre "Propuesta" y "Revocar/Activar". Solo activo si `u.isActive` (si no está activado, el botón queda deshabilitado con tooltip).

**Integración con el banner de impersonación existente:**
- `App.tsx:152-180` ya tiene `<ImpersonationBanner />` que muestra una barra arriba con botón "Salir" que llama a `/api/auth/stop-impersonate`. Ese flujo ya estaba; solo faltaba iniciar la impersonación.

**Verificación manual recomendada:**
1. Login admin, ir a `/admin/clients`.
2. Click "Ver como" en un usuario activo.
3. Confirmar el diálogo.
4. Te redirige a `/client` y arriba aparece el banner "Estás viendo como [nombre]".
5. Click "Salir" → vuelves a tu sesión de admin.

---

## 3. `FusionStudio` — botón "Crear producto en Shopify"

**Fichero tocado:** `src/pages/projects/FusionStudio.tsx`

**Cambios:**
- Añadidos tres state vars junto al resto: `creatingProduct`, `createdProductResult`.
- Añadida función `createProductInShopify` envuelta en `useCallback`:
  - Construye `FormData` con `projectId` + hasta 5 `images` (los `File` que el usuario ya subió a la fase "product").
  - Hace `POST /api/fusion-studio/create-product` multipart.
  - Muestra tarjeta verde con `platformId`, título y link a Shopify si el backend devuelve `createdProduct.url`.
  - Muestra tarjeta roja con el error si falla.
- Añadido botón dorado "🛍️ Crear producto en Shopify" en la fase `gallery`, al lado del botón "← Editar sesión" existente.
  - Deshabilitado si `productFiles.length === 0` con tooltip explicativo.
  - Texto cambia a "Creando…" mientras está en vuelo.

**Comportamiento del backend verificado** (`routes/fusion-studio.ts:226`):
- Acepta `upload.array("images", 5)` + `req.body.projectId`.
- Llama `analyzeImageForFusion()` (Claude vision).
- Usa `getProjectConnector(projectId)` — si la plataforma soporta `product_create`, invoca `connector.createProduct(...)` con título, descripción, tags, precio y variante default.
- Sube cada imagen al producto creado vía `connector.uploadImage(...)`.
- Guarda el resultado en el vault del proyecto.

**Verificación manual recomendada:**
1. Ir a `/projects/:id/fusion-studio`.
2. Completar fase `brand` → `product` (subir al menos 1 imagen).
3. Avanzar a `generate` → `gallery`.
4. Click "🛍️ Crear producto en Shopify".
5. Esperar 10-30s (llamada a Claude + Shopify API).
6. Ver tarjeta verde con "Abrir en Shopify →".

---

## Lo que NO hice en este turno (y por qué)

De los 10 clusters que mencionaste, solo los 3 anteriores son **mecánicos** (sin decisiones de producto).

Los otros 7 clusters requieren decisiones tuyas antes de poder escribir código sin inventar:

| Cluster | Rutas backend sin UI | Decisión bloqueante |
|---|---|---|
| Plans/créditos por proyecto | 6 | ¿Página nueva `/admin/projects/:id/credits` o modal dentro de `AdminClients.tsx`? ¿Qué ve el admin cuando abre los packs (solo lista o también la historia de consumo)? |
| Shopify OAuth nativo start | 3 | ¿Botón "Conectar con OAuth" dentro de `NewProject.tsx` como alternativa al form manual, o como botón adicional en `projects/:id/Settings.tsx`? |
| Brain sync admin tools | 11 | ¿Página nueva `/admin/brain-sync` con tabs (Export / Import / Stats)? ¿Qué rol tiene el NDJSON import — upload drag&drop o textarea paste? |
| Klaviyo REST directo | 10 | ¿Página nueva `/admin/klaviyo` con 6+ tabs, o integración dentro de `Emails.tsx` con subtabs? ¿La UI de "send-email" envía a destinatario único o a una lista? |
| ShopyBrain research extendido | 11 | ¿Se añaden como botones en `ShopyBrain.tsx` (página índice), o como tabs dentro de cada ShopyBrain{Memories,Insights,Study}? ¿`audit-entity` vs `research-entity POST` son flujos separados o dos botones del mismo panel? |
| Push notifications send/subscribe | 2 | ¿Push web (VAPID) o Android nativo (Firebase)? Son implementaciones completamente distintas. |
| Audit dedicados duplicados | 3 | ¿Borras los endpoints dedicados (más simple, queda todo vía dispatcher) o migras `Audit.tsx` a usarlos? (Mi recomendación: borrar los endpoints dedicados.) |

Si me das la decisión de cada uno, puedo ejecutarlos uno a uno sin inventarme UI.

---

## Coste real estimado

| Cluster | Tamaño si yo lo hago sin supervisión | Riesgo |
|---|---|---|
| Plans/créditos | ~400 líneas TSX + 1 endpoint hook | Medio (inventaría el diseño del modal) |
| Shopify OAuth start | ~50 líneas en NewProject.tsx | Bajo |
| Brain sync admin | ~500 líneas (upload + confirm + stats) | Alto (el NDJSON import es crítico; confirmar antes) |
| Klaviyo directo | ~1000 líneas (6 tabs) | Alto (schemas Klaviyo no auditados) |
| Research extendido | ~800 líneas (listados, modales, polling) | Medio-alto |
| Push | Depende: web 200 líneas / nativo 500 líneas + config Android | Alto si nativo |
| Audit dedup | 0 líneas frontend (borrar handlers backend) | Bajo pero decisión importante |

Con decisiones claras por cluster yo puedo hacerlos en sesiones enfocadas. Si me pides "todos a la vez" vuelvo a prometer cosas que no entrego.
