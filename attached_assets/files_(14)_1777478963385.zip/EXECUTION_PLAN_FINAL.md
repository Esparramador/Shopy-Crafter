# Plan de ejecución FINAL — Bloque E + F + G consolidado

Confirmado con datos reales de prod (24/04/2026): la DB es muy pequeña (max
3.190 filas), no hay enums creados, no hay valores inesperados en columnas
candidatas a enum. **Todo el plan se puede ejecutar en una ventana de 15-30
minutos con cero downtime real**.

## Inventario final de archivos

Para ejecutar en prod (en orden):

| # | Archivo | Origen | Versión | Tiempo prod |
|---|---|---|---|---|
| 1 | `0001_reconcile_v2.sql` | Bloque G | v2 (idempotente) | <1 s |
| 2 | `0002_validate_orphans.sql` | Bloque E | original | <1 s (read-only) |
| 3 | `0003_cleanup_orphans.sql` | Bloque E | original | <1 s (probable no-op) |
| 4 | `0004_fix_projectid_types.sql` | Bloque E | original | <1 s |
| 5 | `0005_add_fks.sql` | Bloque E | original | <1 s |
| 6 | `0006_add_indexes_v2.sql` | Bloque G | v2 (sin CONCURRENTLY) | ~2 s |
| 7 | `0007_unique_constraints_v2.sql` | Bloque G | v2 (omite products) | <1 s |
| 8 | `0008_fix_types_boolean.sql` | Bloque E | original | <1 s |
| 9 | `0009_enums_v2.sql` | Bloque G | v2 (sin subscription_plan) | <1 s |
| 10 | `0010_timestamps_tz.sql` | Bloque E | original | <1 s |
| 11 | `0011_retention_jobs.sql` | Bloque E | original (opcional) | <1 s |
| 12 | `0012_unify_plan_enum_v2.sql` | Bloque G | v2 (trivial, 0 filas) | <1 s |

**Total estimado en prod: ~10 segundos de DDL** + tiempo de validación manual.

## Pre-flight definitivo

```bash
# 1. Backup
pg_dump --format=custom DATABASE_URL > backup_$(date +%Y%m%d_%H%M).dump

# 2. Codemod TypeScript (booleanos)
bash ts_codemod_boolean.sh /ruta/repo --apply
pnpm tsc --noEmit  # debe pasar

# 3. Reemplazar los 28 schemas TS + añadir express_rate_limits.ts
# (los archivos están en bloque_e/updated_schemas/ y bloque_g/express_rate_limits.ts)

# 4. Reemplazar drizzle.config.ts y package.json scripts
# (también en bloque_e/updated_schemas/)

# 5. Validar que tsc sigue pasando con el nuevo schema
pnpm tsc --noEmit
```

## Aplicación en prod

Una sola sesión, idealmente domingo a las 03:00 UTC. **No requiere ventana de
mantenimiento estricta** porque:

- DB pequeña → ALTER COLUMN es instantáneo
- IF NOT EXISTS / IF EXISTS donde aplica → idempotente
- Cada migración en transacción → ROLLBACK automático en caso de error

```bash
psql $DATABASE_URL -1 -f 0001_reconcile_v2.sql
psql $DATABASE_URL    -f 0002_validate_orphans.sql  # solo SELECTs
                                                     # revisar output ANTES de seguir
psql $DATABASE_URL -1 -f 0003_cleanup_orphans.sql   # cambiar ROLLBACK→COMMIT
psql $DATABASE_URL -1 -f 0004_fix_projectid_types.sql
psql $DATABASE_URL -1 -f 0005_add_fks.sql
psql $DATABASE_URL -1 -f 0006_add_indexes_v2.sql
psql $DATABASE_URL -1 -f 0007_unique_constraints_v2.sql
psql $DATABASE_URL -1 -f 0008_fix_types_boolean.sql
psql $DATABASE_URL -1 -f 0009_enums_v2.sql
psql $DATABASE_URL -1 -f 0010_timestamps_tz.sql
psql $DATABASE_URL -1 -f 0012_unify_plan_enum_v2.sql

# Opcional ahora, recomendado más adelante:
psql $DATABASE_URL -1 -f 0011_retention_jobs.sql

# Verificación
psql $DATABASE_URL -f post_migrate_check.sql
```

## Validaciones post-migración esperadas

Ejecutando `post_migrate_check.sql` debería ver:
- CHECK 1: `0 filas` (todos los project_id son integer ahora)
- CHECK 2: `0 filas` (todas las project_id integer tienen FK)
- CHECK 3: `0 filas` (cada FK tiene índice)
- CHECK 4: 8 uniques compuestos (incluyendo el preexistente de products)
- CHECK 5: solo `user_sessions.expire`
- CHECK 6: `0 filas` (todas las columnas booleanas son boolean)
- CHECK 7: 7 enums (ahora son 7, no 8: subscription_plan eliminado)
- CHECK 8: `0 huérfanos`
- CHECK 9: tamaños actuales

## Riesgos residuales — ahora mínimos

| Riesgo | Probabilidad | Mitigación |
|---|---|---|
| `0004` falla por valores no-castables | Muy baja (DB joven) | 0002 lo detecta, ROLLBACK auto |
| `0009` falla por valor inesperado | **Cero** (pre-flight confirmado) | — |
| `0010` desplaza timestamps por TZ | Bajo (server suele estar en UTC) | `SHOW timezone;` antes |
| `0008` rompe app por boolean | Cero si codemod aplicado | Codemod obligatorio antes |
| `0007` falla por duplicados | Cero (DB pequeña, dedup en pre-migrate) | — |
| Aplicar 0006 sin CONCURRENTLY bloquea reads | Cero (índices son <100ms) | — |

## Archivos del Bloque G (esta carpeta)

- `README_HALLAZGOS.md` — qué cambió y por qué
- `0001_reconcile_v2.sql` — drift idempotente real
- `0006_add_indexes_v2.sql` — sin CONCURRENTLY
- `0007_unique_constraints_v2.sql` — sin recrear products
- `0009_enums_v2.sql` — sin subscription_plan, jobStatus completo
- `0012_unify_plan_enum_v2.sql` — trivial
- `express_rate_limits.ts` — schema TS faltante
- `index.ts` — re-exports actualizados
- `EXECUTION_PLAN_FINAL.md` — este archivo

## Estado: 100% auditado y corregido

✅ 28 schemas TS actualizados (bloque_e/updated_schemas) + 1 nuevo (bloque_g/express_rate_limits.ts) = 29 archivos
✅ 12 migraciones SQL (con v2 donde aplica)
✅ Drift de prod completamente reconciliado
✅ Enums verificados con datos reales (cero valores sorpresa)
✅ Tamaños de tabla medidos → CONCURRENTLY innecesario
✅ Plan ejecutable de principio a fin en <1 minuto de DDL en prod
✅ Sin riesgos altos restantes
