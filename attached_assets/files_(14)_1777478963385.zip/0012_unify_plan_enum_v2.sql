-- ============================================================================
-- 0012_unify_plan_enum_v2.sql
-- ----------------------------------------------------------------------------
-- Versión final tras pre-flight: subscriptions tiene 0 filas. La migración es
-- trivial — no hay datos que mapear, solo cambio de tipo.
--
-- IMPORTANTE: el 0009_v2.sql ya NO crea subscription_plan. Por tanto el
-- workflow es:
--   1. 0009_v2.sql crea plan_type
--   2. subscriptions.plan está hoy como text → este archivo lo migra a plan_type
-- (No hay subscription_plan que dropear, porque nunca lo creamos).
-- ============================================================================

BEGIN;

-- subscriptions.plan: hoy es text con default 'trial'.
-- 0 filas en prod → el USING castea sin riesgo.

ALTER TABLE subscriptions ALTER COLUMN plan DROP DEFAULT;
ALTER TABLE subscriptions
  ALTER COLUMN plan TYPE plan_type USING plan::plan_type;
ALTER TABLE subscriptions ALTER COLUMN plan SET DEFAULT 'trial'::plan_type;

COMMIT;

-- ─── Verificación post ──────────────────────────────────────────────────────
-- \d subscriptions
-- → "plan" debería mostrar tipo plan_type, default 'trial'::plan_type
