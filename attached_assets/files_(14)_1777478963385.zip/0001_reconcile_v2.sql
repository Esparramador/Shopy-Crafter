-- ============================================================================
-- 0001_reconcile_v2.sql
-- ----------------------------------------------------------------------------
-- Versión final tras cross-check con dump real de prod.
--
-- Cambios respecto al 0001_reconcile.sql del Bloque E:
--   - report_templates YA EXISTE en prod (mi audit inicial lo había marcado
--     como faltante por error). Mantengo el CREATE TABLE IF NOT EXISTS por si
--     se aplica a una DB nueva, pero en prod actual es no-op.
--   - Mantengo entity_name/entity_url y new_category/new_metafields porque sí
--     están en prod (confirmado en el dump) — los IF NOT EXISTS son no-op
--     pero se quedan para idempotencia.
--   - Añadido products.products_project_shopify_unique como reconocimiento
--     formal: ya existe en prod, NO crearlo en 0007.
--   - express_rate_limits documentada (no se crea aquí: la app la crea en
--     runtime; pero la añadimos al schema TS para que Drizzle la reconozca).
-- ============================================================================

BEGIN;

-- ─── 1. report_templates (idempotente) ──────────────────────────────────────
-- En prod ya existe con la estructura correcta. IF NOT EXISTS evita error.

CREATE TABLE IF NOT EXISTS "report_templates" (
  "id"                 serial PRIMARY KEY NOT NULL,
  "user_id"            integer,
  "name"               varchar(200) NOT NULL,
  "slug"               varchar(100) NOT NULL,
  "logo_base64"        text,
  "company_name"       varchar(200),
  "tagline"            varchar(300),
  "primary_color"      varchar(9) DEFAULT '#c8a84b',
  "secondary_color"    varchar(9) DEFAULT '#08080e',
  "accent_color"       varchar(9) DEFAULT '#44cc88',
  "text_color"         varchar(9) DEFAULT '#f0f0f5',
  "bg_color"           varchar(9) DEFAULT '#08080e',
  "card_bg"            varchar(9) DEFAULT '#12121a',
  "border_color"       varchar(9) DEFAULT '#1a1a22',
  "heading_font"       varchar(100) DEFAULT 'Helvetica Neue',
  "body_font"          varchar(100) DEFAULT 'Helvetica Neue',
  "heading_weight"     varchar(10)  DEFAULT '700',
  "cover_style"        varchar(20)  DEFAULT 'centered',
  "section_style"      varchar(20)  DEFAULT 'card',
  "footer_text"        varchar(300),
  "show_page_numbers"  boolean DEFAULT true,
  "is_public"          boolean DEFAULT false,
  "share_token"        varchar(64),
  "created_at"         timestamp with time zone DEFAULT now(),
  "updated_at"         timestamp with time zone DEFAULT now()
);

-- ─── 2. Columnas que ya existen en prod (idempotente) ───────────────────────

ALTER TABLE "project_files"
  ADD COLUMN IF NOT EXISTS "entity_name" text,
  ADD COLUMN IF NOT EXISTS "entity_url"  text;

ALTER TABLE "redesigns"
  ADD COLUMN IF NOT EXISTS "new_category"   text,
  ADD COLUMN IF NOT EXISTS "new_metafields" jsonb;

-- ─── 3. express_rate_limits — la crea pg-rate-limit-store.ts en runtime ─────
-- No se crea aquí; ya existe. Solo documentamos.

-- En prod existe con esta estructura:
--   CREATE TABLE express_rate_limits (
--     key TEXT PRIMARY KEY,
--     total_hits INTEGER NOT NULL DEFAULT 0,
--     reset_at TIMESTAMPTZ NOT NULL
--   );
-- El runtime hace INSERT con ON CONFLICT, así que key=PK es suficiente.

-- ─── 4. UNIQUE products(project_id, shopify_product_id) ya en prod ──────────
-- Ya existe como `products_project_shopify_unique`. NO se crea de nuevo en
-- 0007_v2. Solo documentamos.

COMMIT;
