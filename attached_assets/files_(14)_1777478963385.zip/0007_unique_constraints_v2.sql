-- ============================================================================
-- 0007_unique_constraints_v2.sql
-- ----------------------------------------------------------------------------
-- Versión final: omite products (ya tiene UNIQUE en prod como
-- `products_project_shopify_unique`). El resto se mantiene igual que el
-- Bloque E.
--
-- Nota sobre el constraint de products preexistente: mantiene el nombre
-- viejo `products_project_shopify_unique`. Si quieres uniformidad de naming,
-- añade al final un RENAME (ver al final del archivo).
-- ============================================================================

BEGIN;

-- products: YA EXISTE → no se hace nada.

-- cogs:
ALTER TABLE cogs
  ADD CONSTRAINT uq_cogs_project_shopify
  UNIQUE (project_id, shopify_product_id);

-- seo_data:
ALTER TABLE seo_data
  ADD CONSTRAINT uq_seo_data_project_shopify
  UNIQUE (project_id, shopify_product_id);

-- visual_dna: 1 por proyecto
ALTER TABLE visual_dna
  ADD CONSTRAINT uq_visual_dna_project
  UNIQUE (project_id);

-- brand_dna: 1 por proyecto
ALTER TABLE brand_dna
  ADD CONSTRAINT uq_brand_dna_project
  UNIQUE (project_id);

-- inventory_tracking: scheduler upsert por variant_id
ALTER TABLE inventory_tracking
  ADD CONSTRAINT uq_inventory_project_variant
  UNIQUE (project_id, variant_id);

-- revenue_snapshots: scheduler upsert por (project_id, date)
ALTER TABLE revenue_snapshots
  ADD CONSTRAINT uq_revenue_snapshots_project_date
  UNIQUE (project_id, date);

-- sales_analytics: 1 fila por orden de Shopify
ALTER TABLE sales_analytics
  ADD CONSTRAINT uq_sales_analytics_project_order
  UNIQUE (project_id, order_id);

COMMIT;

-- ─── Opcional: uniformar el naming del UNIQUE de products ───────────────────
-- Solo si quieres que todas sigan el patrón uq_*. NO es funcionalmente
-- relevante, solo cosmético. Ejecutar como migración separada después.
--
-- BEGIN;
--   ALTER TABLE products
--     RENAME CONSTRAINT products_project_shopify_unique TO uq_products_project_shopify;
-- COMMIT;
