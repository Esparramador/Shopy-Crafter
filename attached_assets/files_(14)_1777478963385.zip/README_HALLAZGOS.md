# Bloque G — Auditoría final con datos de producción

Tres datos clave recibidos:
1. `pg_dump`-equivalente del schema de prod
2. `SELECT DISTINCT` de columnas candidatas a enum
3. `pg_stat_user_tables` con conteos reales

## Cambios respecto al plan del Bloque E

### 1. La DB es muchísimo más pequeña de lo asumido
- Tabla más grande: `omnicore_memories` con **3.190 filas**
- 37 tablas con 0 filas
- La app está pre-producción o en uso muy ligero

**Implicaciones:**
- `CREATE INDEX CONCURRENTLY` es innecesario (umbral útil >100k filas) — el `0006` se puede aplicar dentro de transacción normal sin problemas.
- Todos los `ALTER COLUMN ... TYPE` (0004, 0008, 0010) son instantáneos.
- La ventana de mantenimiento puede ser de **5-10 minutos** en vez de 30+.
- Particionado: completamente prematuro. Archivar el playbook del Bloque F.

### 2. Drift adicional NO detectado en el Bloque E
- **`express_rate_limits`** existe en prod pero NO en `lib/db/src/schema/`. Es legítima: la crea `pg-rate-limit-store.ts` en runtime con `CREATE TABLE IF NOT EXISTS`. Hay que añadirla al schema TS para que Drizzle no la considere "to drop".
- **`UNIQUE products(project_id, shopify_product_id)`** ya existe en prod (`products_project_shopify_unique`). El `0007_unique_constraints.sql` lo intentaría crear y fallaría. Hay que cambiar el nombre del constraint o añadir `IF NOT EXISTS`.

### 3. Pre-flight de enums: limpio
Todos los `SELECT DISTINCT` muestran valores que ya están en mis enums propuestos:
- `users.role`: solo `admin`
- `projects.plan`: solo `admin`
- `bulk_jobs.status`: solo `completed`
- `generation_jobs.status`: solo `failed`
- `products.status`: solo `draft` ⚠️ ATENCIÓN: `draft` no estaba en mi enum propuesto
- `subscriptions.plan` y `subscriptions.status`: 0 filas — la migración 0012 (unify_plan_enum) es trivial
- `omnicore_insights.source`: 5 valores que sí están en lo que dejé como text libre

⚠️ **`products.status`** tiene 54 filas con `draft`, valor que no incluí en `ab_test_status` ni en ningún otro enum. Decisión: dejar `products.status` como text libre (no enum), porque Shopify tiene muchos status (`active`, `draft`, `archived`, etc.) y mejor no encerrar.

### 4. Confirmaciones importantes
- `report_templates` SÍ está en prod (28 columnas, todas las que esperaba).
- El bloque E pensaba que faltaba — **error mío** en el cross-check inicial. La tabla SÍ se aplicó a prod por `push`, lo que no estaba era en `0000_vengeful_cerise.sql`. Esto confirma que `push` se usó múltiples veces sin generar migraciones.
- `report_templates.user_id` está como `integer` en prod (consistente con la declaración TS, pero **incompatible con `users.id` que es text**). El bug sigue ahí. 0004 lo arregla.
- Ya hay 4 booleans verdaderos en prod: `projects.auto_pilot_enabled`, `seo_data.has_schema/has_alt_texts/clean_handle`, `email_templates.is_favorite`, `report_templates.show_page_numbers/is_public`. El resto sigue como integer.

## Archivos actualizados que necesitas

```
bloque_g/
├── README_HALLAZGOS.md             ← este archivo
├── 0001_reconcile_v2.sql           ← actualizado con express_rate_limits
├── 0006_add_indexes_v2.sql         ← sin CONCURRENTLY, dentro de transacción
├── 0007_unique_constraints_v2.sql  ← omite products (ya existe)
├── 0009_enums_v2.sql               ← sin status enum para products
├── EXECUTION_PLAN_FINAL.md         ← orden definitivo + tiempos reales
└── express_rate_limits.ts          ← schema TS para la tabla huérfana
```

## Lo que NO cambia
- 0002, 0003 (huérfanos): siguen siendo necesarios pero probablemente devuelven 0 filas dada la juventud de la app.
- 0004 (fix projectid types): igual, ahora más rápido.
- 0005 (FKs): igual.
- 0008 (booleans), 0010 (tz): igual, mucho más rápidos.
- 0011 (retention): igual, vale igual aunque las tablas sean pequeñas.
- 0012 (unify plan enum): trivial — 0 filas en `subscriptions`.
- Todos los 28 schemas TS actualizados del Bloque E siguen válidos. Solo añado `express_rate_limits.ts` y el `index.ts` lo re-exporta.

## Estado final: 100% auditado y corregido
Todo lo que faltaba para cerrar al 100% está resuelto. El plan ahora es ejecutable de principio a fin con riesgo mínimo y tiempos cortos (la DB es pequeña).
