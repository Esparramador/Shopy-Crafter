-- ============================================================================
-- 0006_add_indexes_v2.sql
-- ----------------------------------------------------------------------------
-- Versión final adaptada al tamaño REAL de prod (max 3.190 filas/tabla).
--
-- Cambios respecto al 0006_add_indexes.sql del Bloque E:
--   - CONCURRENTLY ELIMINADO: con 3k filas, un CREATE INDEX normal tarda <50ms.
--     CONCURRENTLY añade complejidad operativa (no se puede en transacción)
--     sin aportar nada. Se ejecuta normal, dentro de transacción.
--   - Todo va dentro de un único BEGIN/COMMIT.
--   - Si alguna tabla crece a >100k filas en el futuro, regenerar índices con
--     CONCURRENTLY no es necesario en este momento.
-- ============================================================================

BEGIN;

-- ─── FKs: índice sobre la columna hijo ───────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_audit_log_project_id           ON audit_log(project_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_user_id              ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_approvals_project_id           ON approvals(project_id);
CREATE INDEX IF NOT EXISTS idx_messages_project_id            ON messages(project_id);
CREATE INDEX IF NOT EXISTS idx_competitors_project_id         ON competitors(project_id);
CREATE INDEX IF NOT EXISTS idx_competitor_snapshots_competitor_id ON competitor_snapshots(competitor_id);
CREATE INDEX IF NOT EXISTS idx_competitor_alerts_project_id   ON competitor_alerts(project_id);
CREATE INDEX IF NOT EXISTS idx_competitor_alerts_competitor_id ON competitor_alerts(competitor_id);
CREATE INDEX IF NOT EXISTS idx_events_project_id              ON events(project_id);
CREATE INDEX IF NOT EXISTS idx_revenue_snapshots_project_id   ON revenue_snapshots(project_id);
CREATE INDEX IF NOT EXISTS idx_forecasts_project_id           ON forecasts(project_id);
CREATE INDEX IF NOT EXISTS idx_inventory_tracking_project_id  ON inventory_tracking(project_id);
CREATE INDEX IF NOT EXISTS idx_restock_orders_project_id      ON restock_orders(project_id);
CREATE INDEX IF NOT EXISTS idx_sales_analytics_project_id     ON sales_analytics(project_id);
CREATE INDEX IF NOT EXISTS idx_pricing_rules_project_id       ON pricing_rules(project_id);
CREATE INDEX IF NOT EXISTS idx_onboarding_progress_project_id ON onboarding_progress(project_id);
CREATE INDEX IF NOT EXISTS idx_project_files_project_id       ON project_files(project_id);
CREATE INDEX IF NOT EXISTS idx_email_flows_project_id         ON email_flows(project_id);
CREATE INDEX IF NOT EXISTS idx_email_templates_project_id     ON email_templates(project_id);
CREATE INDEX IF NOT EXISTS idx_track_events_test_id           ON track_events(test_id);
CREATE INDEX IF NOT EXISTS idx_affiliates_user_id             ON affiliates(user_id);
CREATE INDEX IF NOT EXISTS idx_referral_tracking_affiliate_id ON referral_tracking(affiliate_id);
CREATE INDEX IF NOT EXISTS idx_referral_tracking_referred_user_id ON referral_tracking(referred_user_id);
CREATE INDEX IF NOT EXISTS idx_achievements_user_id           ON achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_report_templates_user_id       ON report_templates(user_id);

-- Tablas Grupo A (FK ya existía, índice no):
CREATE INDEX IF NOT EXISTS idx_products_project_id            ON products(project_id);
CREATE INDEX IF NOT EXISTS idx_seo_data_project_id            ON seo_data(project_id);
CREATE INDEX IF NOT EXISTS idx_cogs_project_id                ON cogs(project_id);
CREATE INDEX IF NOT EXISTS idx_ab_tests_project_id            ON ab_tests(project_id);
CREATE INDEX IF NOT EXISTS idx_visual_dna_project_id          ON visual_dna(project_id);
CREATE INDEX IF NOT EXISTS idx_generation_jobs_project_id     ON generation_jobs(project_id);
CREATE INDEX IF NOT EXISTS idx_redesigns_project_id           ON redesigns(project_id);
CREATE INDEX IF NOT EXISTS idx_price_history_project_id       ON price_history(project_id);
CREATE INDEX IF NOT EXISTS idx_audit_results_project_id       ON audit_results(project_id);
CREATE INDEX IF NOT EXISTS idx_bulk_jobs_project_id           ON bulk_jobs(project_id);
CREATE INDEX IF NOT EXISTS idx_brand_dna_project_id           ON brand_dna(project_id);
CREATE INDEX IF NOT EXISTS idx_plan_credit_packs_project_id   ON plan_credit_packs(project_id);

-- ─── Compuestos por filtros y(eq, eq) observados ────────────────────────────
-- products(project_id, shopify_product_id) ya existe en prod como
-- `products_project_shopify_unique` — NO recrear.

CREATE INDEX IF NOT EXISTS idx_cogs_project_shopify           ON cogs(project_id, shopify_product_id);
CREATE INDEX IF NOT EXISTS idx_seo_data_project_shopify       ON seo_data(project_id, shopify_product_id);
CREATE INDEX IF NOT EXISTS idx_redesigns_project_shopify      ON redesigns(project_id, shopify_product_id);
CREATE INDEX IF NOT EXISTS idx_price_history_project_shopify  ON price_history(project_id, shopify_product_id);
CREATE INDEX IF NOT EXISTS idx_generation_jobs_project_shopify ON generation_jobs(project_id, shopify_product_id);
CREATE INDEX IF NOT EXISTS idx_ab_tests_project_shopify       ON ab_tests(project_id, shopify_product_id);

-- ─── orderBy DESC observados ────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_project_files_project_created
  ON project_files(project_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_revenue_snapshots_project_date
  ON revenue_snapshots(project_id, date DESC);

CREATE INDEX IF NOT EXISTS idx_sales_analytics_project_order_date
  ON sales_analytics(project_id, order_date DESC);

CREATE INDEX IF NOT EXISTS idx_products_project_audit_score
  ON products(project_id, audit_score DESC NULLS LAST);

CREATE INDEX IF NOT EXISTS idx_price_history_project_shopify_recorded
  ON price_history(project_id, shopify_product_id, recorded_at DESC);

CREATE INDEX IF NOT EXISTS idx_events_project_created
  ON events(project_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_audit_log_user_created
  ON audit_log(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_audit_log_project_created
  ON audit_log(project_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_restock_orders_project_created
  ON restock_orders(project_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_redesigns_project_created
  ON redesigns(project_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_competitor_snapshots_competitor_scanned
  ON competitor_snapshots(competitor_id, scanned_at DESC);

CREATE INDEX IF NOT EXISTS idx_inventory_project_days_remaining
  ON inventory_tracking(project_id, days_remaining ASC NULLS LAST);

CREATE INDEX IF NOT EXISTS idx_messages_project_created
  ON messages(project_id, created_at);

-- ─── Tokens de auth ──────────────────────────────────────────────────────────
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_invite_token ON users(invite_token)
  WHERE invite_token IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_reset_token  ON users(reset_token)
  WHERE reset_token IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_client_id           ON users(client_id)
  WHERE client_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_projects_client_id ON projects(client_id);

-- ─── rate_limits y express_rate_limits ──────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_rate_limits_blocked_until
  ON rate_limits(blocked_until) WHERE blocked_until IS NOT NULL;

-- express_rate_limits.reset_at se consulta en DELETE WHERE reset_at <= NOW()
CREATE INDEX IF NOT EXISTS idx_express_rate_limits_reset_at
  ON express_rate_limits(reset_at);

-- ─── project_files filtros frecuentes ───────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_project_files_project_file_type
  ON project_files(project_id, file_type);
CREATE INDEX IF NOT EXISTS idx_project_files_project_category
  ON project_files(project_id, category) WHERE category IS NOT NULL;

-- ─── Omnicore (la tabla más grande: 3190 filas) ─────────────────────────────
CREATE INDEX IF NOT EXISTS idx_omnicore_memories_niche_confidence
  ON omnicore_memories(niche, confidence DESC) WHERE niche IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_omnicore_memories_updated
  ON omnicore_memories(updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_omnicore_insights_domain_confidence
  ON omnicore_insights(domain, confidence DESC);

-- ─── Jobs por status (status,created_at) ────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_bulk_jobs_status_created
  ON bulk_jobs(status, created_at);
CREATE INDEX IF NOT EXISTS idx_generation_jobs_status_created
  ON generation_jobs(status, created_at);

-- ─── Stripe lookup ──────────────────────────────────────────────────────────
CREATE UNIQUE INDEX IF NOT EXISTS idx_subscriptions_stripe_sub
  ON subscriptions(stripe_subscription_id) WHERE stripe_subscription_id IS NOT NULL;

COMMIT;

-- VACUUM ANALYZE de tablas relevantes (ejecutar fuera del archivo, sin tx):
-- VACUUM ANALYZE omnicore_memories; VACUUM ANALYZE omnicore_insights;
-- VACUUM ANALYZE inventory_tracking; VACUUM ANALYZE seo_data;
-- VACUUM ANALYZE products; VACUUM ANALYZE project_files;
