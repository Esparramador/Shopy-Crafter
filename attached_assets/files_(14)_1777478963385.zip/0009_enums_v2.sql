-- ============================================================================
-- 0009_enums_v2.sql
-- ----------------------------------------------------------------------------
-- Versión final tras pre-flight de SELECT DISTINCT.
--
-- Cambios respecto al 0009_enums.sql del Bloque E:
--   - jobStatusEnum: añadidos los valores reales encontrados en prod
--     ('completed' en bulk_jobs, 'failed' en generation_jobs).
--   - products.status NO se migra a enum: prod tiene 'draft' (54 filas) que
--     no estaba en mi enum, y Shopify usa varios status. Se queda como text.
--   - subscription_plan se elimina aquí (ver 0012_unify_plan_enum_v2.sql).
--   - Pre-flight CONFIRMADO con datos reales de prod: solo aparecen valores
--     que ya están en los enums propuestos. Migración 100% segura.
-- ============================================================================

BEGIN;

-- ─── Crear enums ─────────────────────────────────────────────────────────────

CREATE TYPE user_role        AS ENUM ('admin', 'client');

CREATE TYPE platform_type    AS ENUM (
  'shopify', 'woocommerce', 'prestashop', 'wordpress', 'universal'
);

CREATE TYPE plan_type        AS ENUM (
  'admin', 'emprendedor', 'starter', 'agency_pro', 'enterprise', 'trial'
);

CREATE TYPE approval_status  AS ENUM ('pending', 'approved', 'rejected');

-- job_status: superset de los valores observados en prod
--   bulk_jobs: 'completed'
--   generation_jobs: 'failed'
-- Más los valores esperables del lifecycle típico
CREATE TYPE job_status       AS ENUM (
  'pending', 'running', 'completed', 'failed', 'cancelled', 'succeeded', 'generating'
);

CREATE TYPE ab_test_status   AS ENUM ('running', 'paused', 'completed', 'archived');

CREATE TYPE subscription_status AS ENUM (
  'active', 'past_due', 'canceled', 'unpaid', 'trialing', 'incomplete'
);

-- ─── Aplicar a columnas ──────────────────────────────────────────────────────

-- users.role (1 fila: 'admin')
ALTER TABLE users
  ALTER COLUMN role TYPE user_role USING role::user_role;

-- projects.platform_type (default 'shopify' confirmado)
ALTER TABLE projects ALTER COLUMN platform_type DROP DEFAULT;
ALTER TABLE projects
  ALTER COLUMN platform_type TYPE platform_type USING platform_type::platform_type;
ALTER TABLE projects ALTER COLUMN platform_type SET DEFAULT 'shopify'::platform_type;

-- projects.plan (1 fila: 'admin')
ALTER TABLE projects ALTER COLUMN plan DROP DEFAULT;
ALTER TABLE projects
  ALTER COLUMN plan TYPE plan_type USING plan::plan_type;
ALTER TABLE projects ALTER COLUMN plan SET DEFAULT 'starter'::plan_type;

-- approvals.status (0 filas)
ALTER TABLE approvals ALTER COLUMN status DROP DEFAULT;
ALTER TABLE approvals
  ALTER COLUMN status TYPE approval_status USING status::approval_status;
ALTER TABLE approvals ALTER COLUMN status SET DEFAULT 'pending'::approval_status;

-- bulk_jobs.status (6 filas: 'completed')
ALTER TABLE bulk_jobs ALTER COLUMN status DROP DEFAULT;
ALTER TABLE bulk_jobs
  ALTER COLUMN status TYPE job_status USING status::job_status;
ALTER TABLE bulk_jobs ALTER COLUMN status SET DEFAULT 'pending'::job_status;

-- generation_jobs.status (10 filas: 'failed')
ALTER TABLE generation_jobs ALTER COLUMN status DROP DEFAULT;
ALTER TABLE generation_jobs
  ALTER COLUMN status TYPE job_status USING status::job_status;
ALTER TABLE generation_jobs ALTER COLUMN status SET DEFAULT 'pending'::job_status;

-- ab_tests.status (0 filas)
ALTER TABLE ab_tests ALTER COLUMN status DROP DEFAULT;
ALTER TABLE ab_tests
  ALTER COLUMN status TYPE ab_test_status USING status::ab_test_status;
ALTER TABLE ab_tests ALTER COLUMN status SET DEFAULT 'running'::ab_test_status;

-- messages.from_role (0 filas)
ALTER TABLE messages
  ALTER COLUMN from_role TYPE user_role USING from_role::user_role;

-- subscriptions.status (0 filas)
ALTER TABLE subscriptions ALTER COLUMN status DROP DEFAULT;
ALTER TABLE subscriptions
  ALTER COLUMN status TYPE subscription_status USING status::subscription_status;
ALTER TABLE subscriptions ALTER COLUMN status SET DEFAULT 'active'::subscription_status;

-- subscriptions.plan se gestiona en 0012_unify_plan_enum (usa plan_type
-- directamente, no se crea subscription_plan).

COMMIT;

-- ─── NOT MIGRATED a enum (queda como text libre) ─────────────────────────────
-- - products.status: prod tiene 'draft', Shopify maneja muchos valores.
-- - inventory_tracking.status: prod tiene 'healthy' y NULL.
-- - competitor_alerts.severity, restock_orders.urgency: texto libre por diseño.
-- - referral_tracking.status: poco usado todavía, decidir luego.
-- - omnicore_insights.source: 5 valores observados, no crítico.
