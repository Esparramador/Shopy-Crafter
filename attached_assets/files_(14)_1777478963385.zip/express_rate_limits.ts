// express_rate_limits.ts — schema TS para la tabla huérfana detectada en prod
//
// Esta tabla la crea pg-rate-limit-store.ts en runtime con:
//   CREATE TABLE IF NOT EXISTS express_rate_limits (
//     key TEXT PRIMARY KEY,
//     total_hits INTEGER NOT NULL DEFAULT 0,
//     reset_at TIMESTAMPTZ NOT NULL
//   );
//
// La declaramos en Drizzle para:
//   1. Que `drizzle-kit generate` no la considere "to drop"
//   2. Que el ci_drift_guard.sh no aborte por drift
//   3. Que sea descubrible desde el código TS
//
// IMPORTANTE: NO toca la creación runtime — sigue siendo responsabilidad de
// pg-rate-limit-store.ts. Esto es solo declaración para Drizzle.

import { pgTable, text, integer, timestamp, index } from "drizzle-orm/pg-core";

export const expressRateLimitsTable = pgTable("express_rate_limits", {
  key:       text("key").primaryKey(),
  totalHits: integer("total_hits").notNull().default(0),
  resetAt:   timestamp("reset_at", { withTimezone: true }).notNull(),
}, (t) => [
  // Para el DELETE WHERE reset_at <= NOW() del cleanup periódico
  index("idx_express_rate_limits_reset_at").on(t.resetAt),
]);

export type ExpressRateLimit = typeof expressRateLimitsTable.$inferSelect;
