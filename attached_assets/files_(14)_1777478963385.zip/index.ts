// index.ts — POST Bloque G
// Añadido `./express_rate_limits` para reflejar la tabla huérfana detectada.

export * from "./projects";
export * from "./products";
export * from "./redesigns";
export * from "./generation_jobs";
export * from "./ab_tests";
export * from "./cogs";
export * from "./visual_dna";
export * from "./seo_data";
export * from "./bulk_jobs";
export * from "./users";
export * from "./cms";
export * from "./intelligence";
export * from "./inventory";
export * from "./onboarding";
export * from "./competitors";
export * from "./billing";
export * from "./shopybrain";
export * from "./project_files";
export * from "./conversations";
export * from "./messages";
export * from "./platform_settings";
export * from "./sessions";
export * from "./priceHistory";
export * from "./email_templates";
export * from "./email_flows";
export * from "./audit_results";
export * from "./report_templates";
export * from "./express_rate_limits";   // ← NUEVO en Bloque G
