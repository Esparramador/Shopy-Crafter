import { Router, type Request, type Response } from "express";
import multer from "multer";
import { db, projectsTable, projectFilesTable } from "@workspace/db";
import { eq, and, inArray } from "drizzle-orm";
import { requireAdmin } from "../lib/auth.js";
import { logger } from "../lib/logger.js";
import { enableLongRunning } from "../lib/long-running.js";
import { saveToVault } from "../lib/vault.js";
import { checkProductionLimit, recordUsage } from "../lib/plan-limits.js";
import { learnFromOperation } from "../lib/claude.js";
import { ObjectStorageService } from "../lib/objectStorage.js";
import {
  IMAGE_MODELS, VIDEO_MODELS,
  generateImage, editImage, removeBackground, replaceBackground,
  upscaleImage, clarityUpscale, enhanceFaces,
  cloneVoice, deleteCloneVoice, generateTTS, generateSFX, generateMusic,
  generateVideoFromImage, composeAd, packAssetsAsZip,
  fetchToBuffer,
  type ImageGenModel, type ImageEditModel, type VideoModel,
} from "../lib/fusion-studio-pro.js";

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 30 * 1024 * 1024 } });

// ─── HELPERS ───────────────────────────────────────────────────────────────

let _storage: ObjectStorageService | null = null;
function getStorage(): ObjectStorageService {
  if (!_storage) _storage = new ObjectStorageService();
  return _storage;
}

// Smart vault save: uploads large files to Object Storage instead of inline base64.
// Files >2MB (raw bytes, ~2.7MB base64) → Object Storage; smaller → content field.
// Keeps things efficient and avoids the 50MB Express body limit on subsequent reads.
// Throws on failure so caller's try/catch handles the response (no silent null).
async function saveToVaultSmart(params: {
  projectId: number;
  fileType: string;
  category: string;
  title: string;
  mimeType: string;
  generatedBy: string;
  buffer: Buffer;
}): Promise<number> {
  const RAW_THRESHOLD = 2 * 1024 * 1024; // 2MB raw

  if (params.buffer.length > RAW_THRESHOLD) {
    // Upload to Object Storage
    const safeTitle = params.title.replace(/[^a-z0-9-_]/gi, "_").slice(0, 50);
    const ext = params.mimeType.split("/")[1] || "bin";
    const objectPath = `projects/${params.projectId}/${params.fileType}/${safeTitle}_${Date.now()}.${ext}`;
    try {
      const gcsFile = await getStorage().getObjectEntityFile(objectPath);
      await getStorage().uploadObject(gcsFile, params.buffer, params.mimeType);
      const vaultId = await saveToVault({
        projectId: params.projectId,
        fileType: params.fileType,
        category: params.category,
        title: params.title,
        mimeType: params.mimeType,
        generatedBy: params.generatedBy,
        objectPath,
        fileSizeBytes: params.buffer.length,
      });
      if (vaultId === null) throw new Error("saveToVault returned null after objectStorage upload");
      return vaultId;
    } catch (err) {
      logger.warn({ err, fileType: params.fileType }, "fs-pro: object storage upload failed, falling back to base64 content");
      // Fall through to content base64
    }
  }
  const vaultId = await saveToVault({
    projectId: params.projectId,
    fileType: params.fileType,
    category: params.category,
    title: params.title,
    mimeType: params.mimeType,
    generatedBy: params.generatedBy,
    content: params.buffer.toString("base64"),
    fileSizeBytes: params.buffer.length,
  });
  if (vaultId === null) throw new Error("saveToVault returned null (DB insert failed)");
  return vaultId;
}

// ─── CAPABILITY CATALOG ───────────────────────────────────────────────────
router.get("/fs-pro/capabilities", requireAdmin, async (_req, res) => {
  res.json({
    imageGeneration: Object.entries(IMAGE_MODELS).map(([k, v]) => ({
      key: k, label: prettyLabel(k), ...v,
    })),
    videoGeneration: Object.entries(VIDEO_MODELS).map(([k, v]) => ({
      key: k, label: prettyLabel(k), ...v,
    })),
    imageEdit: [
      { key: "nano-banana", label: "Nano Banana (Gemini)", description: "Edición rápida con instrucciones de texto, mantiene la marca" },
      { key: "flux-kontext-pro", label: "Flux Kontext Pro", description: "Edición consistente, mantiene personajes/estilo" },
      { key: "gen4-image-edit", label: "Runway Gen-4 Image", description: "Image edit con referencias estilo Runway" },
    ],
    enhance: [
      { key: "real-esrgan", label: "Real-ESRGAN x2/x4", description: "Upscale general con preservación de detalle" },
      { key: "clarity-upscaler", label: "Clarity Upscaler", description: "Tipo Magnific, añade detalle creativo" },
      { key: "gfpgan-faces", label: "GFPGAN", description: "Mejora caras y retratos" },
    ],
    background: [
      { key: "remove-bg", label: "Eliminar fondo (Bria RMBG)", description: "Quita el fondo dejando producto recortado" },
      { key: "replace-bg", label: "Reemplazar fondo (Flux Inpaint)", description: "Coloca producto en escena nueva" },
    ],
    audio: [
      { key: "tts", label: "Text-to-Speech (ElevenLabs)", description: "Voz natural en 30+ idiomas" },
      { key: "voice-clone", label: "Voice Cloning", description: "Clona voz de marca con muestra de 30s" },
      { key: "sfx", label: "Sound Effects", description: "Efectos de sonido ambientales" },
      { key: "music", label: "Music Generation (Stable Audio)", description: "Música original libre de derechos" },
    ],
    composition: [
      { key: "compose", label: "Composición FFmpeg", description: "Mezcla video + voz + música + texto overlay en MP4 final" },
    ],
    voiceModels: [
      { key: "eleven_v3", label: "Eleven v3 (latest)", description: "Más expresivo y natural" },
      { key: "eleven_multilingual_v2", label: "Multilingual v2", description: "30+ idiomas, estable" },
      { key: "eleven_turbo_v2_5", label: "Turbo v2.5", description: "Más rápido, calidad alta" },
      { key: "eleven_flash_v2_5", label: "Flash v2.5", description: "El más rápido, baja latencia" },
    ],
  });
});

function prettyLabel(key: string): string {
  return key.split("-").map(s => s[0].toUpperCase() + s.slice(1)).join(" ");
}

// ─── IMAGE GENERATION ─────────────────────────────────────────────────────
router.post("/fs-pro/generate-image", requireAdmin, async (req: Request, res: Response) => {
  enableLongRunning(res);
  try {
    const { projectId, model, prompt, aspectRatio, seed, negativePrompt, referenceImageUrl } = req.body as {
      projectId: number; model: ImageGenModel; prompt: string; aspectRatio?: string;
      seed?: number; negativePrompt?: string; referenceImageUrl?: string;
    };
    if (!projectId || !model || !prompt) { res.status(400).json({ error: "projectId, model, prompt requeridos" }); return; }
    const limit = await checkProductionLimit(projectId, "image", 1);
    if (!limit.allowed) { res.status(402).json({ error: limit.reason }); return; }

    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
    if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

    let referenceImage: Buffer | undefined;
    let referenceMime: string | undefined;
    if (referenceImageUrl) {
      referenceImage = await fetchToBuffer(referenceImageUrl);
      referenceMime = "image/png";
    }

    const { buffer, mimeType } = await generateImage(model, prompt, {
      aspectRatio, seed, negativePrompt, referenceImage, referenceMime,
      replicateToken: (project as any).replicateApiKey || undefined,
    });

    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-image", category: "fusion-studio-pro",
      title: `FS Pro: ${prompt.slice(0, 60)}`,
      mimeType, generatedBy: `fs-pro:${model}`,
      buffer,
    });
    await recordUsage(projectId, "image", 1);
    learnFromOperation({
      operationType: "fs_pro_generate_image", niche: project.storeNiche ?? null,
      title: `FS Pro image: ${prompt.slice(0, 80)}`,
      content: `Generated image with ${model}. Prompt: ${prompt.slice(0, 200)}.`,
      confidence: 0.85, tags: ["fusion-studio-pro", "image", model],
    });

    res.json({ success: true, vaultId, model, dataUrl: `data:${mimeType};base64,${buffer.toString("base64")}` });
  } catch (err: any) {
    logger.error({ err }, "fs-pro generate-image failed");
    res.status(500).json({ error: err?.message || "Error generando imagen" });
  }
});

// ─── IMAGE EDIT ───────────────────────────────────────────────────────────
router.post("/fs-pro/edit-image", requireAdmin, upload.single("image"), async (req: Request, res: Response) => {
  enableLongRunning(res);
  try {
    const f = req.file;
    const { projectId: pidStr, model, prompt, aspectRatio, sourceImageUrl } = req.body;
    const projectId = parseInt(pidStr || "0", 10);
    if (!projectId || !model || !prompt) { res.status(400).json({ error: "projectId, model, prompt requeridos" }); return; }
    const limit = await checkProductionLimit(projectId, "image", 1);
    if (!limit.allowed) { res.status(402).json({ error: limit.reason }); return; }

    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
    if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

    let imgBuf: Buffer; let imgMime: string;
    if (f) { imgBuf = f.buffer; imgMime = f.mimetype; }
    else if (sourceImageUrl) { imgBuf = await fetchToBuffer(sourceImageUrl); imgMime = "image/png"; }
    else { res.status(400).json({ error: "Imagen requerida (file o sourceImageUrl)" }); return; }

    const { buffer, mimeType } = await editImage(model as ImageEditModel, imgBuf, imgMime, prompt, {
      aspectRatio, replicateToken: (project as any).replicateApiKey || undefined,
    });

    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-image-edit", category: "fusion-studio-pro",
      title: `FS Pro Edit: ${prompt.slice(0, 60)}`,
      mimeType, generatedBy: `fs-pro-edit:${model}`,
      buffer,
    });
    await recordUsage(projectId, "image", 1);

    res.json({ success: true, vaultId, model, dataUrl: `data:${mimeType};base64,${buffer.toString("base64")}` });
  } catch (err: any) {
    logger.error({ err }, "fs-pro edit-image failed");
    res.status(500).json({ error: err?.message || "Error editando imagen" });
  }
});

// ─── BACKGROUND REMOVE / REPLACE ──────────────────────────────────────────
router.post("/fs-pro/remove-bg", requireAdmin, upload.single("image"), async (req, res) => {
  enableLongRunning(res);
  try {
    const f = req.file;
    const { projectId: pidStr, sourceImageUrl } = req.body;
    const projectId = parseInt(pidStr || "0", 10);
    if (!projectId) { res.status(400).json({ error: "projectId requerido" }); return; }
    const limit = await checkProductionLimit(projectId, "image", 1);
    if (!limit.allowed) { res.status(402).json({ error: limit.reason }); return; }
    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
    if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

    let buf: Buffer; let mime: string;
    if (f) { buf = f.buffer; mime = f.mimetype; }
    else if (sourceImageUrl) { buf = await fetchToBuffer(sourceImageUrl); mime = "image/png"; }
    else { res.status(400).json({ error: "Imagen requerida" }); return; }

    const out = await removeBackground(buf, mime, (project as any).replicateApiKey || undefined);
    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-bg-removed", category: "fusion-studio-pro",
      title: `FS Pro: BG removido`, mimeType: "image/png", generatedBy: "fs-pro:bria-rmbg",
      buffer: out,
    });
    await recordUsage(projectId, "image", 1);
    res.json({ success: true, vaultId, dataUrl: `data:image/png;base64,${out.toString("base64")}` });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Error eliminando fondo" });
  }
});

router.post("/fs-pro/replace-bg", requireAdmin, upload.single("image"), async (req, res) => {
  enableLongRunning(res);
  try {
    const f = req.file;
    const { projectId: pidStr, sourceImageUrl, scenePrompt } = req.body;
    const projectId = parseInt(pidStr || "0", 10);
    if (!projectId || !scenePrompt) { res.status(400).json({ error: "projectId + scenePrompt requeridos" }); return; }
    const limit = await checkProductionLimit(projectId, "image", 1);
    if (!limit.allowed) { res.status(402).json({ error: limit.reason }); return; }
    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
    if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

    let buf: Buffer; let mime: string;
    if (f) { buf = f.buffer; mime = f.mimetype; }
    else if (sourceImageUrl) { buf = await fetchToBuffer(sourceImageUrl); mime = "image/png"; }
    else { res.status(400).json({ error: "Imagen requerida" }); return; }

    const out = await replaceBackground(buf, mime, scenePrompt, (project as any).replicateApiKey || undefined);
    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-bg-replaced", category: "fusion-studio-pro",
      title: `FS Pro: BG reemplazado - ${scenePrompt.slice(0, 50)}`,
      mimeType: "image/png", generatedBy: "fs-pro:bria-bg-gen",
      buffer: out,
    });
    await recordUsage(projectId, "image", 1);
    res.json({ success: true, vaultId, dataUrl: `data:image/png;base64,${out.toString("base64")}` });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Error reemplazando fondo" });
  }
});

// ─── UPSCALE / ENHANCE ────────────────────────────────────────────────────
router.post("/fs-pro/upscale", requireAdmin, upload.single("image"), async (req, res) => {
  enableLongRunning(res);
  try {
    const f = req.file;
    const { projectId: pidStr, sourceImageUrl, scale, mode, prompt } = req.body;
    const projectId = parseInt(pidStr || "0", 10);
    if (!projectId) { res.status(400).json({ error: "projectId requerido" }); return; }
    const limit = await checkProductionLimit(projectId, "image", 1);
    if (!limit.allowed) { res.status(402).json({ error: limit.reason }); return; }
    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
    if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

    let buf: Buffer; let mime: string;
    if (f) { buf = f.buffer; mime = f.mimetype; }
    else if (sourceImageUrl) { buf = await fetchToBuffer(sourceImageUrl); mime = "image/png"; }
    else { res.status(400).json({ error: "Imagen requerida" }); return; }

    const sc = parseInt(scale || "2") as 2 | 4;
    let out: Buffer;
    if (mode === "clarity") out = await clarityUpscale(buf, mime, prompt || "high detail photograph", sc, (project as any).replicateApiKey || undefined);
    else if (mode === "faces") out = await enhanceFaces(buf, mime, (project as any).replicateApiKey || undefined);
    else out = await upscaleImage(buf, mime, sc, (project as any).replicateApiKey || undefined);

    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-upscaled", category: "fusion-studio-pro",
      title: `FS Pro: Upscaled x${sc} (${mode || "esrgan"})`,
      mimeType: "image/png", generatedBy: `fs-pro:upscale-${mode || "esrgan"}`,
      buffer: out,
    });
    await recordUsage(projectId, "image", 1);
    res.json({ success: true, vaultId, dataUrl: `data:image/png;base64,${out.toString("base64")}` });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Error en upscale" });
  }
});

// ─── VIDEO GENERATION ─────────────────────────────────────────────────────
router.post("/fs-pro/generate-video", requireAdmin, upload.single("image"), async (req, res) => {
  enableLongRunning(res);
  try {
    const f = req.file;
    const { projectId: pidStr, model, prompt, duration, aspect, sourceImageUrl } = req.body;
    const projectId = parseInt(pidStr || "0", 10);
    if (!projectId || !model || !prompt) { res.status(400).json({ error: "projectId, model, prompt requeridos" }); return; }

    const VIDEO_CREDITS = 4;
    const limit = await checkProductionLimit(projectId, "image", VIDEO_CREDITS);
    if (!limit.allowed) { res.status(402).json({ error: limit.reason }); return; }

    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
    if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

    let buf: Buffer; let mime: string;
    if (f) { buf = f.buffer; mime = f.mimetype; }
    else if (sourceImageUrl) { buf = await fetchToBuffer(sourceImageUrl); mime = "image/png"; }
    else { res.status(400).json({ error: "Imagen origen requerida" }); return; }

    const out = await generateVideoFromImage(model as VideoModel, buf, mime, prompt, {
      duration: parseInt(duration || "5"),
      aspect: aspect || "9:16",
      replicateToken: (project as any).replicateApiKey || undefined,
    });

    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-video", category: "fusion-studio-pro",
      title: `FS Pro Video: ${prompt.slice(0, 60)}`,
      mimeType: "video/mp4", generatedBy: `fs-pro:${model}`,
      buffer: out,
    });
    await recordUsage(projectId, "image", VIDEO_CREDITS);

    res.json({ success: true, vaultId, model, sizeBytes: out.length });
  } catch (err: any) {
    logger.error({ err }, "fs-pro generate-video failed");
    res.status(500).json({ error: err?.message || "Error generando video" });
  }
});

// ─── VOICE CLONING ────────────────────────────────────────────────────────
router.post("/fs-pro/voice/clone", requireAdmin, upload.single("audio"), async (req, res) => {
  enableLongRunning(res);
  try {
    const f = req.file;
    const { name, description } = req.body;
    if (!f || !name) { res.status(400).json({ error: "audio file + name requeridos" }); return; }

    const result = await cloneVoice(name, f.buffer, f.mimetype, description);
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Error clonando voz" });
  }
});

router.delete("/fs-pro/voice/:voiceId", requireAdmin, async (req, res) => {
  try {
    await deleteCloneVoice(req.params.voiceId);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Error eliminando voz" });
  }
});

// ─── TTS ──────────────────────────────────────────────────────────────────
router.post("/fs-pro/tts", requireAdmin, async (req, res) => {
  enableLongRunning(res);
  try {
    const { projectId, voiceId, text, modelId, stability, similarity, style, speed } = req.body;
    if (!projectId || !voiceId || !text) { res.status(400).json({ error: "projectId, voiceId, text requeridos" }); return; }

    const buf = await generateTTS(text, { voiceId, modelId, stability, similarity, style, speed });
    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-tts", category: "fusion-studio-pro",
      title: `FS Pro TTS: ${text.slice(0, 60)}`,
      mimeType: "audio/mpeg", generatedBy: `fs-pro:elevenlabs-tts`,
      buffer: buf,
    });
    res.json({ success: true, vaultId, dataUrl: `data:audio/mpeg;base64,${buf.toString("base64")}` });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Error en TTS" });
  }
});

// ─── SFX & MUSIC ──────────────────────────────────────────────────────────
router.post("/fs-pro/sfx", requireAdmin, async (req, res) => {
  enableLongRunning(res);
  try {
    const { projectId, prompt, duration, promptInfluence } = req.body;
    if (!projectId || !prompt) { res.status(400).json({ error: "projectId, prompt requeridos" }); return; }
    const buf = await generateSFX(prompt, parseInt(duration || "5"), parseFloat(promptInfluence || "0.5"));
    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-sfx", category: "fusion-studio-pro",
      title: `FS Pro SFX: ${prompt.slice(0, 60)}`,
      mimeType: "audio/mpeg", generatedBy: "fs-pro:elevenlabs-sfx",
      buffer: buf,
    });
    res.json({ success: true, vaultId, dataUrl: `data:audio/mpeg;base64,${buf.toString("base64")}` });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Error en SFX" });
  }
});

router.post("/fs-pro/music", requireAdmin, async (req, res) => {
  enableLongRunning(res);
  try {
    const { projectId, prompt, duration } = req.body;
    if (!projectId || !prompt) { res.status(400).json({ error: "projectId, prompt requeridos" }); return; }
    const limit = await checkProductionLimit(projectId, "image", 2);
    if (!limit.allowed) { res.status(402).json({ error: limit.reason }); return; }
    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
    if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

    const buf = await generateMusic(prompt, parseInt(duration || "30"), (project as any).replicateApiKey || undefined);
    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-music", category: "fusion-studio-pro",
      title: `FS Pro Music: ${prompt.slice(0, 60)}`,
      mimeType: "audio/wav", generatedBy: "fs-pro:stable-audio",
      buffer: buf,
    });
    await recordUsage(projectId, "image", 2);
    res.json({ success: true, vaultId, dataUrl: `data:audio/wav;base64,${buf.toString("base64")}` });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Error generando música" });
  }
});

// ─── COMPOSE ──────────────────────────────────────────────────────────────
router.post("/fs-pro/compose", requireAdmin, async (req, res) => {
  enableLongRunning(res);
  try {
    const { projectId, videoVaultId, voiceVaultId, musicVaultId, voiceVolume, musicVolume, overlayText } = req.body;
    if (!projectId || !videoVaultId) { res.status(400).json({ error: "projectId, videoVaultId requeridos" }); return; }

    // Fetch vault file rows for IDs needed
    const ids = [videoVaultId, voiceVaultId, musicVaultId].filter(Boolean) as number[];
    const files = await db.select().from(projectFilesTable).where(
      and(eq(projectFilesTable.projectId, projectId), inArray(projectFilesTable.id, ids)),
    );
    const map = new Map(files.map(f => [f.id, f]));
    const vidFile = map.get(videoVaultId);
    if (!vidFile) { res.status(404).json({ error: "Video vault file no encontrado" }); return; }

    // Helper that reads vault content from any of: HTTP URL, objectStorage, base64 content field
    const fetchVaultContent = async (file: any): Promise<Buffer | undefined> => {
      if (!file) return undefined;
      // 1. Try HTTP URL first (cheapest)
      if (file.originalUrl?.startsWith("http")) {
        try { return await fetchToBuffer(file.originalUrl); } catch {}
      }
      // 2. Try Replit Object Storage via objectPath
      if (file.objectPath) {
        try {
          const { ObjectStorageService } = await import("../lib/objectStorage.js");
          const svc = new ObjectStorageService();
          const gcsFile = await svc.getObjectEntityFile(file.objectPath);
          const resp = await svc.downloadObject(gcsFile);
          return Buffer.from(await resp.arrayBuffer());
        } catch (err) {
          logger.warn({ err, fileId: file.id }, "fs-pro compose: objectStorage read failed");
        }
      }
      // 3. Fallback: content field with base64 (small files only)
      if (file.content) {
        try { return Buffer.from(file.content, "base64"); } catch {}
      }
      return undefined;
    };

    const videoBuf = await fetchVaultContent(vidFile);
    const voiceBuf = voiceVaultId ? await fetchVaultContent(map.get(voiceVaultId)) : undefined;
    const musicBuf = musicVaultId ? await fetchVaultContent(map.get(musicVaultId)) : undefined;

    if (!videoBuf) { res.status(500).json({ error: "No se pudo leer el video del vault (sin URL pública, objectPath ni content)" }); return; }

    const finalBuf = await composeAd({
      videoBuffer: videoBuf,
      voiceBuffer: voiceBuf,
      musicBuffer: musicBuf,
      voiceVolume: voiceVolume ? parseFloat(voiceVolume) : undefined,
      musicVolume: musicVolume ? parseFloat(musicVolume) : undefined,
      overlayText,
    });

    const vaultId = await saveToVaultSmart({
      projectId, fileType: "fs-pro-composed", category: "fusion-studio-pro",
      title: `FS Pro Compose: final MP4`,
      mimeType: "video/mp4", generatedBy: "fs-pro:ffmpeg",
      buffer: finalBuf,
    });
    res.json({ success: true, vaultId, sizeBytes: finalBuf.length });
  } catch (err: any) {
    logger.error({ err }, "fs-pro compose failed");
    res.status(500).json({ error: err?.message || "Error componiendo" });
  }
});

// ─── DOWNLOAD ALL ASSETS AS ZIP ───────────────────────────────────────────
router.post("/fs-pro/download-all", requireAdmin, async (req, res) => {
  enableLongRunning(res);
  try {
    const { projectId, vaultIds } = req.body as { projectId: number; vaultIds: number[] };
    if (!projectId || !Array.isArray(vaultIds) || vaultIds.length === 0) {
      res.status(400).json({ error: "projectId + vaultIds[] requeridos" }); return;
    }
    const files = await db.select().from(projectFilesTable).where(
      and(eq(projectFilesTable.projectId, projectId), inArray(projectFilesTable.id, vaultIds)),
    );
    if (files.length === 0) { res.status(404).json({ error: "No se encontraron archivos" }); return; }

    // Helper that reads vault content from URL, objectStorage, or content base64
    const readVaultBuf = async (file: any): Promise<Buffer | undefined> => {
      if (file.originalUrl?.startsWith("http")) {
        try { return await fetchToBuffer(file.originalUrl); } catch {}
      }
      if (file.objectPath) {
        try {
          const { ObjectStorageService } = await import("../lib/objectStorage.js");
          const svc = new ObjectStorageService();
          const gcsFile = await svc.getObjectEntityFile(file.objectPath);
          const resp = await svc.downloadObject(gcsFile);
          return Buffer.from(await resp.arrayBuffer());
        } catch (err) {
          logger.warn({ err, fileId: file.id }, "fs-pro download-all: objectStorage read failed");
        }
      }
      if (file.content) {
        try { return Buffer.from(file.content, "base64"); } catch {}
      }
      return undefined;
    };

    const buffers: Array<{ name: string; buffer: Buffer }> = [];
    for (const f of files) {
      const buf = await readVaultBuf(f);
      if (!buf) {
        logger.warn({ fileId: f.id }, "fs-pro: skipping file in zip — could not read content");
        continue;
      }
      const ext = (f.mimeType || "").split("/")[1] || "bin";
      const safeTitle = (f.title || `file-${f.id}`).replace(/[^a-z0-9-_]/gi, "_").slice(0, 50);
      buffers.push({ name: `${safeTitle}.${ext}`, buffer: buf });
    }
    if (buffers.length === 0) { res.status(500).json({ error: "No se pudo descargar ningún archivo" }); return; }

    const zipBuf = await packAssetsAsZip(buffers);
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="fusion-studio-assets-${Date.now()}.zip"`);
    res.send(zipBuf);
  } catch (err: any) {
    logger.error({ err }, "fs-pro download-all failed");
    res.status(500).json({ error: err?.message || "Error preparando ZIP" });
  }
});

export default router;
