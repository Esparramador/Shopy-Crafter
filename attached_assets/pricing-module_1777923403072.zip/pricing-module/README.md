# Módulo Pricing — Shopy Crafter

Sistema completo de cálculo COGS y optimización de precios con IA.
Reemplaza el `/pricing` actual con todos los botones funcionales.

---

## 📦 Qué incluye

```
pricing-module/
├── Pricing.tsx                       # Página principal (la que importas)
├── components/
│   ├── ActionButton.tsx              # Botón unificado con estados
│   ├── COGSStructureModal.tsx        # Modal "Estructura de costes real"
│   ├── SimulatorDrawer.tsx           # Drawer simulador con sliders
│   └── OptimizationModal.tsx         # Modal optimización con IA
├── hooks/
│   └── useAIAction.ts                # Hook para batch con polling
└── lib/
    ├── api.ts                        # Cliente API
    └── types.ts                      # Tipos TypeScript
```

---

## 🚀 Integración en 4 pasos

### Paso 1 — Copiar archivos

Copia toda la carpeta `pricing-module/` dentro de `client/src/pages/`
en tu repo de Replit. La estructura queda:

```
client/src/pages/pricing/
├── Pricing.tsx
├── components/
├── hooks/
└── lib/
```

### Paso 2 — Conectar la ruta

En tu router (probablemente `App.tsx` o `Router.tsx`), reemplaza el componente actual:

```tsx
import Pricing from './pages/pricing/Pricing';

// Reemplaza el componente antiguo:
<Route path="/pricing" element={<Pricing />} />
```

### Paso 3 — Verificar dependencias instaladas

```bash
npm install lucide-react
```

Si NO usas Tailwind CSS, lo necesitas. Si lo usas (lo más probable),
asegúrate de que `slate`, `teal`, `cyan`, `violet`, `amber` están en tu config.
Estos colores son los que vienen por defecto en Tailwind, no necesitas hacer nada.

### Paso 4 — Backend: implementar los endpoints

El frontend espera estos endpoints en `/api/pricing/*`. Los firmas exactas
están en `lib/api.ts` con tipos. Implementa cada uno en tu backend:

| Método | Ruta | Función |
|--------|------|---------|
| GET | `/api/pricing/products` | Lista productos con COGS |
| GET | `/api/pricing/kpis` | KPIs agregados |
| POST | `/api/pricing/classify-product` | Clasifica tipo (digital/físico/servicio) |
| POST | `/api/pricing/estimate-cogs` | Estima COGS de UN producto con Claude |
| POST | `/api/pricing/estimate-cogs/batch` | Inicia batch, devuelve `jobId` |
| GET | `/api/pricing/batch-progress/:jobId` | Polling de progreso |
| POST | `/api/pricing/batch-cancel/:jobId` | Cancela batch |
| PATCH | `/api/pricing/cogs/:productId` | Guarda COGS editado manualmente |
| POST | `/api/pricing/simulate` | Simulación matemática (sin IA) |
| POST | `/api/pricing/optimize` | Optimiza precio con Claude |
| PATCH | `/api/pricing/apply` | Aplica precio nuevo a Shopify |
| POST | `/api/pricing/ab-test` | Crea test A/B |

---

## 🧠 Lógica del backend (resumen)

### `/api/pricing/estimate-cogs` — el más importante

**Pseudo-código del flujo:**

```typescript
1. Obtén el producto de Shopify (title, body_html, weight, tags, requires_shipping)

2. Si no tiene categoría guardada, llama a Claude para clasificarlo:
   - Prompt: "Clasifica este producto en: digital_puro | fisico | servicio | hibrido | digital_hibrido"
   - Guarda category en la tabla products

3. Según la categoría, prepara el prompt específico para Claude:

   - DIGITAL_PURO (NFT, packs digitales, audiobooks):
     COGS típico 5-15%. Componentes: créditos IA, storage,
     bandwidth, payment fees, royalties, mint NFT (€0.50-2.00)

   - FISICO (pósters, lienzos):
     COGS típico 35-65%. Componentes: impresión papel/lienzo,
     materiales, marco, embalaje, envío (€4.50-7.50 ES),
     rotura 5-8%, mano de obra

   - SERVICIO (sesiones consultoría):
     COGS típico 25-50%. Componentes: horas consultor (€25-120/h),
     tools prorrateados, overhead

4. Llama a Claude Opus 4.7 con el prompt + tabla de referencia 2026
   pidiendo JSON con TODOS los campos del COGSData (ver types.ts)

5. Guarda en tabla cogs_calculations y retorna el JSON al frontend
```

### Schema mínimo que necesita el backend

```sql
ALTER TABLE products ADD COLUMN cogs_category TEXT;
ALTER TABLE products ADD COLUMN cogs_data JSONB;
ALTER TABLE products ADD COLUMN last_estimated_at TIMESTAMP;

CREATE TABLE batch_jobs (
  id TEXT PRIMARY KEY,
  shop_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  status TEXT NOT NULL,
  current_count INTEGER DEFAULT 0,
  total_count INTEGER NOT NULL,
  errors_count INTEGER DEFAULT 0,
  message TEXT,
  started_at TIMESTAMP DEFAULT NOW(),
  completed_at TIMESTAMP,
  metadata JSONB
);
```

---

## ✅ Qué obtienes con esto

### Botones que SÍ funcionan

- **"Auto-estimar todos"** → batch real con IA, barra de progreso, cancelable
- **"Estructura"** → abre modal con 19 campos, todos editables
- **"Auto-estimar con IA"** (dentro del modal) → rellena los 19 campos con stagger animation
- **"Simular"** → drawer lateral con 4 sliders, math en tiempo real, gráfico sensibilidad
- **"Optimizar"** → modal con 3 niveles de precio (conservador/óptimo/agresivo), justificación de Claude, riesgos, oportunidades, opción de crear A/B test

### Estados UI manejados

Cada botón maneja: `idle` → `confirming` (si requiere) → `loading` → `success` (1.5s) → `idle`. Los errores muestran toast con mensaje real del backend.

### Coste IA visible

Antes de cada batch grande, el usuario ve el coste estimado en € de créditos IA y debe confirmar.

---

## 🔧 Personalización rápida

### Cambiar colores principales

En cada componente, busca y reemplaza `teal-500`, `teal-400` por tu color de marca.
Variables principales: `teal` (acción), `cyan` (info), `violet` (IA), `amber` (warning), `red` (crítico).

### Adaptar el endpoint base

En `lib/api.ts`, primera línea:
```typescript
const API_BASE = '/api/pricing'; // Cámbialo si tu backend usa otra ruta
```

### Añadir más campos al COGS

1. Añade el campo en `types.ts` → `COGSData`
2. Añade el `<Field>` en `COGSStructureModal.tsx`
3. Añádelo a `calculateTotal()` y al prompt de Claude en backend

---

## 🧪 Cómo probar localmente

1. Sin backend funcionando, los botones mostrarán errores de fetch — eso es esperado
2. Para probar UI sin backend, comenta las llamadas reales en `Pricing.tsx` y rellena con datos mock:

```typescript
// Mock temporal para ver el UI
useEffect(() => {
  setProducts([
    { id: '1', title: 'NFT Arte IA 4K', currentPrice: 39.99, /* ... */ },
    { id: '2', title: 'Póster Personalizado', currentPrice: 19.99, /* ... */ },
  ]);
  setKPIs({ totalProducts: 2, /* ... */ });
  setLoading(false);
}, []);
```

3. Una vez veas que la UI carga bien, conecta el backend real

---

## 🐛 Errores comunes

**"Cannot find module 'lucide-react'"**
→ `npm install lucide-react`

**"Property 'X' does not exist on type"**
→ Verifica que copiaste `types.ts` completo. Los tipos son estrictos.

**Botones no responden visualmente**
→ Verifica que Tailwind compila bien las clases. Si usas Tailwind v4, `accent-teal-500` debería funcionar; en v3 también.

**"Invalid hook call"**
→ React 18+ requerido. Verifica versión.

---

## 📝 Siguiente paso recomendado

Una vez funcione Pricing:

1. **Aplicar el mismo patrón a Auditoría** — usa `<ActionButton>` en todos los botones
2. **Aplicar a SEO Engine** — los botones "Generar meta tags", "Optimizar URLs"
3. **Aplicar a A/B Testing** — los botones "Crear test", "Generar variantes IA"

Patrón siempre igual: cualquier `<button>` se reemplaza por `<ActionButton>` con su `onAction`.

---

## 💡 Tip final

Si Replit Agent te pregunta dudas implementando los endpoints, dile:

> "Lee `client/src/pages/pricing/lib/api.ts` y `client/src/pages/pricing/lib/types.ts` para conocer las firmas exactas de los endpoints que necesito. Implementa cada uno en `server/routes/pricing.ts` siguiendo el patrón que ya uses en otras rutas del proyecto."

Eso le da contexto suficiente para no inventar firmas distintas.
