// ============================================================
// TIPOS PRINCIPALES DEL MÓDULO PRICING
// ============================================================

export type ProductCategory =
  | 'digital_puro'
  | 'fisico'
  | 'servicio'
  | 'hibrido'
  | 'digital_hibrido'
  | 'unknown';

export type ProductGrade = 'A' | 'B' | 'C' | 'D' | 'F';

export interface ShopifyProduct {
  id: string;
  shopifyId: number;
  title: string;
  imageUrl?: string;
  currentPrice: number;
  compareAtPrice?: number;
  currency: string;
  imageScore?: number; // 0-100
  grade?: ProductGrade;
  category?: ProductCategory;
  cogsData?: COGSData;
  lastEstimatedAt?: string;
  hasOptimizedPrice?: boolean;
}

export interface COGSData {
  // Producción / Fabricación
  costeUnitario: number;
  materiales: number;
  tejidos: number;
  impresionDigital: number;
  serigrafia: number;
  amortizacionMoldes: number;
  montaje: number;
  manoObra: number;
  controlCalidad: number;

  // Embalaje y Etiquetado
  embalaje: number;
  etiquetado: number;

  // Logística y Envío
  envioNacional: number;
  envioInternacional: number;
  fulfillment: number;
  almacenamiento: number;

  // Digital / IA
  creditosIA: number;
  storageBandwidth: number;
  paymentFees: number;

  // Otros costes
  rotura: number;
  marketing: number;

  // Resultados
  cogsTotal: number;
  cogsLow: number;
  cogsHigh: number;
  margenBruto: number;
  margenPct: number;

  // Metadata IA
  confidence: number; // 0-1
  warnings: string[];
  assumptions: string[];
  estimatedAt: string;
}

export interface SimulationParams {
  priceVariation: number; // -50 a +50 (%)
  monthlyVolume: number;
  conversionRate: number; // 0-15 (%)
  customerAcquisitionCost: number;
}

export interface SimulationResult {
  projectedRevenue: number;
  projectedCOGS: number;
  grossProfit: number;
  netProfit: number;
  breakEvenUnits: number;
  marginPct: number;
  sensitivityCurve: { priceChange: number; netProfit: number }[];
}

export interface OptimizationResult {
  precioOptimo: number;
  precioConservador: number;
  precioAgresivo: number;
  margenObjetivo: number;
  justificacion: string;
  riesgos: string[];
  abTestSugerido: {
    variantA: number;
    variantB: number;
    duracionDias: number;
    traficoMinimo: number;
  };
  upsellOportunidades: string[];
}

export interface BatchProgress {
  status: 'idle' | 'running' | 'completed' | 'error' | 'cancelled';
  current: number;
  total: number;
  message: string;
  errors: number;
  startedAt?: string;
  completedAt?: string;
}

export interface PricingKPIs {
  totalProducts: number;
  productsWithCOGS: number;
  avgMarginPct: number;
  productsLowMargin: number; // margen < 20%
  productsCriticalMargin: number; // margen < 15%
  totalEstimatedRevenue: number;
  potentialSavings: number;
}
