// ============================================================
// useAIAction - Hook para acciones IA con polling de progreso
// ============================================================

import { useState, useEffect, useRef, useCallback } from 'react';
import { pricingAPI } from '../lib/api';
import type { BatchProgress } from '../lib/types';

interface UseBatchOptions {
  pollIntervalMs?: number;
  onComplete?: (progress: BatchProgress) => void;
  onError?: (error: Error) => void;
}

export function useBatchProgress(options: UseBatchOptions = {}) {
  const { pollIntervalMs = 1000, onComplete, onError } = options;

  const [jobId, setJobId] = useState<string | null>(null);
  const [progress, setProgress] = useState<BatchProgress>({
    status: 'idle',
    current: 0,
    total: 0,
    message: '',
    errors: 0,
  });

  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stopPolling = useCallback(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  }, []);

  // Polling effect
  useEffect(() => {
    if (!jobId) return;

    const poll = async () => {
      try {
        const data = await pricingAPI.getBatchProgress(jobId);
        setProgress(data);

        if (data.status === 'completed') {
          stopPolling();
          onComplete?.(data);
        } else if (data.status === 'error') {
          stopPolling();
          onError?.(new Error(data.message || 'Batch falló'));
        } else if (data.status === 'cancelled') {
          stopPolling();
        }
      } catch (err) {
        stopPolling();
        onError?.(err instanceof Error ? err : new Error('Error en polling'));
      }
    };

    poll(); // primera llamada inmediata
    pollRef.current = setInterval(poll, pollIntervalMs);

    return () => stopPolling();
  }, [jobId, pollIntervalMs, onComplete, onError, stopPolling]);

  const startBatch = useCallback(async (productIds?: string[]) => {
    try {
      const { jobId: newJobId, total } = await pricingAPI.estimateCOGSBatch(productIds);
      setProgress({
        status: 'running',
        current: 0,
        total,
        message: 'Iniciando análisis...',
        errors: 0,
        startedAt: new Date().toISOString(),
      });
      setJobId(newJobId);
      return newJobId;
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Error al iniciar batch');
      setProgress((p) => ({ ...p, status: 'error', message: error.message }));
      onError?.(error);
      throw error;
    }
  }, [onError]);

  const cancelBatch = useCallback(async () => {
    if (!jobId) return;
    try {
      await pricingAPI.cancelBatch(jobId);
      stopPolling();
      setProgress((p) => ({ ...p, status: 'cancelled' }));
    } catch (err) {
      console.error('Error cancelando batch:', err);
    }
  }, [jobId, stopPolling]);

  return {
    progress,
    startBatch,
    cancelBatch,
    isRunning: progress.status === 'running',
  };
}
