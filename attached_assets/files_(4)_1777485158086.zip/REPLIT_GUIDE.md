# Shopy Crafter — Guía completa de aplicación de fixes (v2)

**Contenido del paquete:** 20 de 20 hallazgos del Bloque B con fix listo para aplicar.

## Paso rápido (si solo quieres terminar)

```bash
# Desde la raíz del paquete descomprimido:
bash apply-fixes.sh /ruta/a/tu/repo-shopy-crafter
```

Esto:
1. Hace backup de los archivos originales.
2. Copia 13 archivos nuevos/actualizados automáticamente.
3. Instala DOMPurify.
4. Valida con `pnpm typecheck`.
5. Te lista qué 12 patches manuales quedan.

Los patches manuales son cambios puntuales (3-10 líneas cada uno) en archivos que no se pueden sobrescribir enteros — están documentados paso a paso en `patches/PATCHES.md` y `patches/PATCHES_PART2.md`.

---

## Mapa completo de fixes

| # | Severidad | Hallazgo | Archivo | Status |
|---|---|---|---|---|
| FE-1 | 🔴 | postMessage con wildcard | Landing.tsx | Patch manual #1 |
| FE-2 | 🔴 | CMSEditor sin origin check | CMSEditor.tsx | ✅ YA arreglado (falso positivo) |
| FE-3 | 🔴 | XSS dangerouslySetInnerHTML | Redesign.tsx | Patch manual #2 + lib/sanitize.ts |
| FE-4 | 🟡 | SVG sin sanitizar | Images.tsx | Patch manual #3 + lib/sanitize.ts |
| FE-5 | 🟡 | BASE_URL mal usado | 9 archivos | ✅ lib/api.ts + patch #6 (opcional) |
| FE-6 | 🟡 | RequireClient redirect | App.tsx | Patch manual #4 |
| FE-7 | 🟡 | Capacitor sin offline | capacitor.config.ts | ✅ reemplazado |
| FE-8 | 🟡 | Timeout fijo OmniChatbot | OmniChatbot.tsx | ✅ omnichatbot/action-constants.ts + patch #10 |
| FE-9 | 🟡 | Billing sin loading/error | Billing.tsx | ✅ reemplazado completo |
| FE-10 | ⚠️ | NewProject drafts credenciales | NewProject.tsx | ✅ verificado safe, patch #9 preventivo |
| FE-11 | 🟡 | AndroidManifest minimal | AndroidManifest.xml | ✅ reemplazado |
| FE-12 | ⚠️ | use-draft-persistence sin omitFields | use-draft-persistence.ts | ✅ reemplazado |
| FE-13 | ⚠️ | react-query inconsistente | Billing + 3 páginas | ✅ Billing, ShopyBrainInsights, UniversalSearch + patch #8 |
| FE-14 | ⚠️ | OmniChatbot monolítico | OmniChatbot.tsx | ✅ 4 módulos + patch #10 |
| FE-15 | 🟢 | Endpoints huérfanos | - | ✅ 0 huérfanos verificados |
| FE-16 | 🟡 | Multi-action sin límite | OmniChatbot.tsx | ✅ action-constants + useShopyChat + patch #10 |
| FE-17 | 🟡 | Mobile responsive | 4 páginas | ✅ styles/responsive.css + patches #11, #12 |
| FE-18 | ⚠️ | ErrorBoundary sin reporting | ErrorBoundary.tsx | ✅ reemplazado + endpoint backend |
| FE-19 | ⚠️ | 93 cases formatActionResult | OmniChatbot.tsx | ✅ formatters.ts (30 cases + default) |
| FE-20 | 🟢 | Acciones invisibles | OmniChatbot.tsx | ✅ integrado en patch #10 |

**Estado final:**
- 🔴 Críticos: 3/3 cubiertos (1 falso positivo + 2 con fix)
- 🟡 Altos: 9/9 cubiertos
- ⚠️ Medios: 6/6 cubiertos
- 🟢 Info: 2/2 cubiertos

---

## Archivos generados

### Nuevos (no existían)
```
lib/api.ts                                # helper apiFetch/apiJson
lib/sanitize.ts                           # cleanHtml/cleanSvg con DOMPurify
lib/queries.ts                            # query keys + fetchers centralizados
styles/responsive.css                     # utilidades responsive mobile-first
components/omnichatbot/types.ts           # tipos + helpers del chatbot
components/omnichatbot/action-constants.ts # LONG_RUNNING + DESTRUCTIVE sets
components/omnichatbot/useShopyChat.ts    # hook con lógica de chat
components/omnichatbot/formatters.ts      # formatActionResult (30 cases)
api-server/error-report.ts                # endpoint /api/error-report
```

### Reemplazados (se sobreescriben enteros)
```
hooks/use-draft-persistence.ts            # añade omitFields
components/ErrorBoundary.tsx              # añade reporting
pages/Billing.tsx                         # react-query + skeleton + responsive
pages/ShopyBrainInsights.tsx              # react-query + skeleton
pages/UniversalSearch.tsx                 # react-query + mutation
android/capacitor.config.ts               # deep links + plugins
android/AndroidManifest.xml               # permisos + deep links
```

### Patches manuales (patches/PATCHES*.md)
- `src/pages/Landing.tsx` — postMessage allowlist
- `src/pages/projects/Redesign.tsx` — cleanHtml
- `src/pages/projects/Images.tsx` — cleanSvg
- `src/App.tsx` — RequireClient
- `src/contexts/AuthContext.tsx` — timeout
- `src/components/OmniChatbot.tsx` — integración módulos
- `src/pages/AdminClients.tsx` — react-query parcial
- `src/pages/NewProject.tsx` — clases responsive
- `src/pages/admin/CMSEditor.tsx` — sidebar layout
- `artifacts/api-server/src/routes/index.ts` — registrar router
- `src/main.tsx` — import CSS responsive

---

## Orden de aplicación recomendado

### Opción A — automático

```bash
bash apply-fixes.sh /ruta/a/repo
```

Tarda 1-2 minutos. Instala todo lo automatizable. Luego aplicas los 12 patches manuales siguiendo la lista que te imprime.

### Opción B — paso a paso

Si prefieres controlar cada cambio:

**Día 1 (2-3 horas): seguridad crítica**
1. Copiar `lib/sanitize.ts` y `lib/api.ts`.
2. Instalar DOMPurify.
3. Aplicar patches manuales #1, #2, #3 (postMessage + XSS).
4. `pnpm typecheck && pnpm dev`.
5. Test manual: abre /admin/redesign, verifica que el HTML se sigue mostrando.

**Día 2 (2-3 horas): infraestructura**
6. Copiar `lib/queries.ts`.
7. Copiar `components/ErrorBoundary.tsx`.
8. Copiar `api-server/error-report.ts`, registrar en `routes/index.ts`.
9. Copiar `pages/Billing.tsx` (reemplazo completo).
10. Copiar `hooks/use-draft-persistence.ts`.
11. `pnpm typecheck && pnpm dev`.
12. Test manual: /admin/billing (skeleton + datos), forzar un error.

**Día 3 (2-3 horas): OmniChatbot**
13. Copiar carpeta `components/omnichatbot/` entera.
14. Aplicar patch manual #10 (integración).
15. `pnpm typecheck && pnpm dev`.
16. Test manual:
    - "lista mis productos" → OK
    - "borra el producto X" → debe decir "Confirmación requerida"
    - "optimiza todos los productos" → timeout de 15 min

**Día 4 (2-3 horas): páginas + capacitor**
17. Copiar `pages/ShopyBrainInsights.tsx`, `pages/UniversalSearch.tsx`.
18. Aplicar patch #8 (AdminClients).
19. Copiar config Capacitor + AndroidManifest.
20. Crear los dos XML referenced: `network_security_config.xml`, `data_extraction_rules.xml` (ver comentario en AndroidManifest.xml).
21. `pnpm build && npx cap sync android`.

**Día 5 (2 horas): responsive**
22. Copiar `styles/responsive.css`.
23. Importar en `main.tsx`.
24. Aplicar patches #11 (NewProject) y #12 (CMSEditor).
25. Test en Chrome DevTools modo iPhone 12 — las 5 páginas críticas deben verse OK.

---

## Checklist final antes de merge

**Seguridad**
- [ ] DOMPurify aplicado en Redesign.tsx y Images.tsx
- [ ] Landing postMessage con allowlist (no "*")
- [ ] /api/error-report responde 200

**Flujo**
- [ ] Login → dashboard admin
- [ ] Crear proyecto Shopify funciona
- [ ] OmniChatbot: "lista productos" → OK
- [ ] OmniChatbot: "borra producto X" → "Confirmación requerida"
- [ ] Billing: skeleton en carga, error si falla API

**Mobile**
- [ ] Billing se ve OK en iPhone 12
- [ ] NewProject se ve OK en iPhone 12
- [ ] CMSEditor en móvil: sidebar se puede cerrar

**Producción**
- [ ] `pnpm typecheck` pasa
- [ ] `pnpm build` genera bundle sin warnings nuevos
- [ ] APK build: `cd android && ./gradlew assembleDebug`

---

## Troubleshooting

**"Cannot find module 'dompurify'"**
```bash
pnpm add dompurify --filter @workspace/shopify-optimizer
pnpm add -D @types/dompurify --filter @workspace/shopify-optimizer
```

**El HTML de Redesign aparece en blanco tras aplicar cleanHtml**
DOMPurify está quitando atributos que el CSS necesita. En `lib/sanitize.ts` añadir a `ALLOWED_ATTR`:
```typescript
ALLOWED_ATTR: [..., "style"],  // con moderación
```

**"TypeError: Cannot read properties of undefined (reading 'subscription')"**
El nuevo Billing.tsx usa react-query estricto con tipos. Si el backend devuelve un shape diferente, ajusta `SubscriptionResponse`, `Plan` al principio del archivo.

**El typecheck falla con "Property 'json' does not exist on type 'RequestInit'"**
Verifica que `lib/api.ts` está en `src/lib/` y que `tsconfig.json` resuelve `@/*` a `src/*`.

**El OmniChatbot refactorizado no encuentra los módulos**
La carpeta `omnichatbot/` debe ir dentro de `src/components/`, no en la raíz de `src/`.

---

## Qué NO he cubierto (Bloque C pendiente)

1. **Auditoría del backend completo** — los otros 47 archivos de `routes/` (solo `shopybrain.ts` cubierto en Bloque A).
2. **Auditoría de lib/auth.ts, lib/claude.ts, lib/gemini.ts, lib/vault.ts** — capa compartida.
3. **Auditoría del schema Drizzle** — índices faltantes, cascades, tipos de columna.
4. **Test E2E** con Playwright.
5. **CI/CD** — workflow de GitHub Actions.
6. **Monitoring** — integración real con Sentry/Datadog (el endpoint /api/error-report es solo el hook).

---

**Total fixes generados: 20/20. Archivos: 13 nuevos/reemplazados + 12 patches manuales.**
