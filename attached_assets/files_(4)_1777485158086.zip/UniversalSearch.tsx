/**
 * FIX FE-13: UniversalSearch con react-query para recent searches + mutation.
 * FIX FE-5: usa apiJson via queryFns.
 * FIX FE-17: responsive mobile-first con clamp y minmax.
 */
import { useState, useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Search, Globe, Instagram, Store, ExternalLink, Loader2,
  Clock, ChevronRight, Sparkles, Building2, ArrowRight, AlertTriangle,
} from "lucide-react";
import { useListProjects } from "@workspace/api-client-react";
import { apiJson, ApiError } from "@/lib/api";
import { queryKeys } from "@/lib/queries";

const RECENT_SEARCHES_KEY = "sc_recent_searches";

interface ResearchResult {
  entity: { name: string; type: string; url?: string; instagramHandle?: string };
  sections: { title: string; content: string }[];
  savedFileId?: number;
  duration?: number;
}

interface RecentSearch {
  input: string;
  entityName: string;
  date: string;
  fileId?: number;
}

interface ResearchInput {
  input: string;
  niche?: string;
  projectId?: number;
}

// ─── localStorage helpers ────────────────────────────────────────────────────
function loadRecentSearches(): RecentSearch[] {
  try {
    const raw = localStorage.getItem(RECENT_SEARCHES_KEY);
    return raw ? JSON.parse(raw) as RecentSearch[] : [];
  } catch { return []; }
}

function saveRecentSearches(searches: RecentSearch[]) {
  try { localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(searches.slice(0, 20))); } catch {}
}

// ─── Component ───────────────────────────────────────────────────────────────
export default function UniversalSearch() {
  const { data: projects } = useListProjects();
  const activeProjectId = projects?.[0]?.id ?? 0;
  const qc = useQueryClient();

  const [input, setInput] = useState("");
  const [niche, setNiche] = useState("");
  const [result, setResult] = useState<ResearchResult | null>(null);

  // react-query para cache de recents (así otras páginas pueden invalidar)
  const recentQuery = useQuery({
    queryKey: ["universalSearch", "recent"] as const,
    queryFn: (): RecentSearch[] => loadRecentSearches(),
    staleTime: Infinity,
  });
  const recentSearches = recentQuery.data ?? [];

  const saveRecent = useCallback((search: RecentSearch) => {
    const current = loadRecentSearches();
    const updated = [search, ...current.filter(s => s.input !== search.input)].slice(0, 20);
    saveRecentSearches(updated);
    qc.setQueryData(["universalSearch", "recent"], updated);
  }, [qc]);

  // Mutation para la búsqueda
  const search = useMutation({
    mutationFn: async (payload: ResearchInput) =>
      apiJson<ResearchResult>("/api/shopybrain/research-entity-sync", {
        method: "POST",
        json: { ...payload, market: "es" },
        timeoutMs: 180_000,
      }),
    onSuccess: (data, payload) => {
      setResult(data);
      saveRecent({
        input: payload.input,
        entityName: data.entity?.name || payload.input,
        date: new Date().toISOString(),
        fileId: data.savedFileId,
      });
      qc.invalidateQueries({ queryKey: queryKeys.vault.entities });
    },
  });

  const detectInputType = (val: string) => {
    const v = val.trim().toLowerCase();
    if (v.startsWith("@") || v.includes("instagram.com")) return { icon: Instagram, label: "Instagram", color: "#e040fb" };
    if (v.includes(".myshopify.com") || v.includes("shopify")) return { icon: Store, label: "Shopify", color: "#95bf47" };
    if (v.includes("http") || v.includes(".com") || v.includes(".es") || v.includes(".")) return { icon: Globe, label: "URL / Web", color: "#3b82f6" };
    return { icon: Building2, label: "Marca / Empresa", color: "#c8a84b" };
  };

  const handleSearch = () => {
    if (!input.trim()) return;
    setResult(null);
    search.mutate({
      input: input.trim(),
      niche: niche.trim() || undefined,
      projectId: activeProjectId || undefined,
    });
  };

  const errorMsg = search.error instanceof ApiError ? search.error.message
                 : search.error instanceof Error ? search.error.message
                 : null;

  const Type = detectInputType(input);

  return (
    <div style={{ maxWidth: 1000, margin: "0 auto", padding: "16px" }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: "clamp(18px, 4vw, 24px)", fontWeight: 800, display: "flex", alignItems: "center", gap: 8 }}>
          <Sparkles size={22} style={{ color: "var(--gold)" }} /> Universal Search
        </h1>
        <p style={{ fontSize: 13, color: "var(--t2)", marginTop: 3 }}>
          Investiga cualquier marca, web, o Instagram con IA en profundidad.
        </p>
      </div>

      {/* Input principal */}
      <div className="glass-card" style={{ padding: "14px 16px", marginBottom: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
          <Type.icon size={16} style={{ color: Type.color }} />
          <span style={{ fontSize: 11, fontWeight: 700, color: Type.color, textTransform: "uppercase", letterSpacing: 1 }}>
            {Type.label}
          </span>
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSearch()}
            placeholder="URL, @instagram, o nombre de marca…"
            style={{
              flex: 1, minWidth: 220, padding: "10px 14px",
              background: "var(--ink2)", border: "1px solid var(--bdr)",
              borderRadius: 8, color: "var(--t)", fontSize: 14,
            }}
          />
          <input
            value={niche}
            onChange={e => setNiche(e.target.value)}
            placeholder="Nicho (opcional)"
            style={{
              width: 180, padding: "10px 14px",
              background: "var(--ink2)", border: "1px solid var(--bdr)",
              borderRadius: 8, color: "var(--t)", fontSize: 14,
            }}
          />
          <button
            className="btn-primary"
            onClick={handleSearch}
            disabled={search.isPending || !input.trim()}
            style={{ display: "inline-flex", alignItems: "center", gap: 6, minWidth: 120, justifyContent: "center" }}
          >
            {search.isPending ? <><Loader2 size={14} className="spin" /> Buscando…</> : <><Search size={14} /> Buscar</>}
          </button>
        </div>
      </div>

      {/* Error */}
      {errorMsg && (
        <div className="glass-card" style={{ padding: 14, marginBottom: 16, borderColor: "var(--crim)", background: "rgba(220,53,69,0.08)" }}>
          <p style={{ fontSize: 13, color: "var(--crim)", display: "flex", alignItems: "center", gap: 8 }}>
            <AlertTriangle size={14} /> {errorMsg}
          </p>
        </div>
      )}

      {/* Resultado */}
      {result && (
        <div className="glass-card" style={{ padding: 20, marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 8, marginBottom: 16 }}>
            <div>
              <h2 style={{ fontSize: 18, fontWeight: 700, color: "var(--t)" }}>
                {result.entity.name}
              </h2>
              {result.entity.url && (
                <a href={result.entity.url} target="_blank" rel="noopener noreferrer"
                   style={{ fontSize: 12, color: "var(--gold)", display: "inline-flex", alignItems: "center", gap: 4 }}>
                  {result.entity.url} <ExternalLink size={10} />
                </a>
              )}
            </div>
            {result.duration && (
              <span style={{ fontSize: 11, color: "var(--t3)", display: "flex", alignItems: "center", gap: 4 }}>
                <Clock size={11} /> {Math.round(result.duration / 1000)}s
              </span>
            )}
          </div>

          {/* Sections */}
          <div style={{ display: "grid", gap: 12 }}>
            {result.sections.map((s, i) => (
              <details key={i} style={{ background: "var(--ink2)", padding: 12, borderRadius: 8 }}>
                <summary style={{ cursor: "pointer", fontWeight: 600, color: "var(--t)" }}>
                  {s.title}
                </summary>
                <div style={{ marginTop: 10, fontSize: 13, color: "var(--t2)", whiteSpace: "pre-wrap", lineHeight: 1.6 }}>
                  {/* Plain text — NO HTML para evitar XSS */}
                  {s.content}
                </div>
              </details>
            ))}
          </div>
        </div>
      )}

      {/* Recents */}
      {recentSearches.length > 0 && (
        <div>
          <h2 style={{ fontSize: 14, fontWeight: 700, color: "var(--t2)", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
            <Clock size={13} /> Búsquedas recientes
          </h2>
          <div style={{ display: "grid", gap: 6 }}>
            {recentSearches.map((s, i) => (
              <button
                key={i}
                onClick={() => { setInput(s.input); setTimeout(handleSearch, 50); }}
                style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "10px 12px", background: "var(--ink2)",
                  border: "1px solid var(--bdr)", borderRadius: 8,
                  cursor: "pointer", textAlign: "left", width: "100%",
                }}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, color: "var(--t)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {s.entityName}
                  </div>
                  <div style={{ fontSize: 11, color: "var(--t3)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {s.input} · {new Date(s.date).toLocaleDateString("es-ES")}
                  </div>
                </div>
                <ChevronRight size={14} style={{ color: "var(--t4)" }} />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
