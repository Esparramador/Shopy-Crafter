/**
 * Hook que encapsula la comunicación con Claude vía /api/shopybrain/search + execute-action.
 *
 * Extraído de OmniChatbot.tsx (líneas 1004-1033 y 1541-1890).
 * Parte del refactor FE-14: aislar toda la lógica de red en un hook testeable.
 *
 * FIXES integrados:
 * - FE-5: usa apiFetch del helper centralizado.
 * - FE-8: timeouts categorizados.
 * - FE-16: límite MAX_ACTIONS_PER_TURN + confirmación destructiva.
 * - FE-18: errores reportables via ErrorBoundary si falla el render.
 */
import { useCallback, useRef } from "react";
import { apiFetch, friendlyErrorMessage } from "@/lib/api";
import {
  LONG_RUNNING_ACTIONS,
  needsConfirmation,
  MAX_ACTIONS_PER_TURN,
  getActionTimeout,
} from "./action-constants";
import type {
  DetectedAction,
  SearchResponse,
} from "./types";

export interface UseShopyChatOpts {
  systemPrompt: string;
}

export interface ExecuteActionResult {
  ok: boolean;
  action: string;
  params: Record<string, unknown>;
  data?: Record<string, unknown>;
  error?: string;
  blockedForConfirmation?: boolean;
}

export function useShopyChat(_opts: UseShopyChatOpts) {
  const abortRef = useRef<AbortController | null>(null);

  /** Cancela cualquier llamada de chat en vuelo. */
  const cancel = useCallback(() => {
    if (abortRef.current) {
      try { abortRef.current.abort(); } catch {}
    }
    abortRef.current = null;
  }, []);

  /**
   * Ejecuta una única acción Shopify via /api/shopybrain/execute-action.
   * Maneja timeouts categorizados + confirmación destructiva.
   */
  const executeShopifyAction = useCallback(
    async (action: string, params: Record<string, unknown>): Promise<ExecuteActionResult> => {
      // FIX FE-16: bloquear destructivas sin confirmed
      if (needsConfirmation(action, params)) {
        return {
          ok: false,
          action,
          params,
          blockedForConfirmation: true,
          error: `Confirmación requerida para ${action}`,
        };
      }

      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), getActionTimeout(action));

      try {
        const res = await apiFetch("/api/shopybrain/execute-action", {
          method: "POST",
          json: { action, params },
          signal: ctrl.signal,
          timeoutMs: 0, // desactivamos el default del helper — ya lo gestionamos aquí
        });
        clearTimeout(timer);

        if (!res.ok) {
          const errText = await res.text().catch(() => "");
          return {
            ok: false,
            action,
            params,
            error: parseActionError(errText, res.status, action),
          };
        }
        const data = (await res.json()) as Record<string, unknown>;
        return { ok: true, action, params, data };
      } catch (e) {
        clearTimeout(timer);
        return {
          ok: false,
          action,
          params,
          error: friendlyErrorMessage(e, action),
        };
      }
    },
    [],
  );

  /**
   * Envía un mensaje de texto a /api/shopybrain/search con returnRaw=true.
   * Devuelve la respuesta de Claude (texto + detectedActions).
   */
  const sendTextMessage = useCallback(
    async (input: {
      query: string;
      systemPrompt: string;
      conversationHistory?: string;
      currentRoute?: string;
      activeProjectId?: string;
    }): Promise<SearchResponse> => {
      cancel();
      const ctrl = new AbortController();
      abortRef.current = ctrl;

      try {
        const res = await apiFetch("/api/shopybrain/search", {
          method: "POST",
          json: {
            query: input.query,
            returnRaw: true,
            systemPrompt: input.systemPrompt,
            conversationHistory: input.conversationHistory,
            currentRoute: input.currentRoute,
            activeProjectId: input.activeProjectId,
          },
          signal: ctrl.signal,
          timeoutMs: 180_000,
        });
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        return (await res.json()) as SearchResponse;
      } finally {
        if (abortRef.current === ctrl) abortRef.current = null;
      }
    },
    [cancel],
  );

  /**
   * Ejecuta una lista de detectedActions en serie respetando:
   * - límite MAX_ACTIONS_PER_TURN (FE-16)
   * - confirmación destructiva (FE-16)
   * - timeouts categorizados (FE-8)
   */
  const runDetectedActions = useCallback(
    async (actions: DetectedAction[]): Promise<{
      results: ExecuteActionResult[];
      truncatedCount: number;
      stoppedForConfirmation: boolean;
    }> => {
      const toRun = actions.slice(0, MAX_ACTIONS_PER_TURN);
      const truncatedCount = actions.length - toRun.length;
      const results: ExecuteActionResult[] = [];
      let stoppedForConfirmation = false;

      for (const act of toRun) {
        const r = await executeShopifyAction(act.action, act.params ?? {});
        results.push(r);
        if (r.blockedForConfirmation) {
          stoppedForConfirmation = true;
          break;
        }
      }

      return { results, truncatedCount, stoppedForConfirmation };
    },
    [executeShopifyAction],
  );

  return { sendTextMessage, executeShopifyAction, runDetectedActions, cancel };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function parseActionError(errText: string, status: number, action: string): string {
  if (errText.includes("credit balance is too low") || errText.includes("insufficient_quota")) {
    return `⚠️ **Créditos de IA agotados** — Recarga en anthropic.com.`;
  }
  if (errText.includes("rate_limit") || errText.includes("429")) {
    return `⏳ **Límite de velocidad** — Espera unos segundos.`;
  }
  if (errText.includes("authentication") || errText.includes("401") || errText.includes("api_key")) {
    return `🔑 **Error de autenticación** — Contacta al administrador.`;
  }
  if (status === 400) {
    try {
      const d = JSON.parse(errText) as { error?: string };
      return d.error ?? errText.slice(0, 200);
    } catch {
      return errText.slice(0, 200);
    }
  }
  return errText.slice(0, 200) || `Error ${status} ejecutando ${action}`;
}
