═══════════════════════════════════════════════════════════════════════════════
PATCHES UNIFICADOS — PARTE 2
(continuación de PATCHES.md)

Estos patches aplican FE-13 (react-query parcial en páginas existentes),
FE-12 (omitFields en drafts), FE-14 (integración del OmniChatbot partido)
y FE-17 (breakpoints en las 4 páginas sin responsive).
═══════════════════════════════════════════════════════════════════════════════


═══════════════════════════════════════════════════════════════════════════════
PATCH #8 — FE-13 · AdminClients.tsx migración parcial a react-query
═══════════════════════════════════════════════════════════════════════════════

AdminClients.tsx tiene 805 líneas con varios sub-componentes embebidos
(InviteModal, ServicesList, MessagesPanel, ApprovalsPanel, UsersSection).
Una reescritura completa sería muy grande — en su lugar aplicamos el patrón
incrementalmente a los 4 puntos de fetch más críticos.

Archivo: src/pages/AdminClients.tsx

─── 1. IMPORTS (añadir arriba, junto a otros imports) ───
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiJson } from "@/lib/api";
import { queryKeys, queryFns } from "@/lib/queries";


─── 2. UsersSection (línea ~618-640 aprox) ───

ANTES:
  const [users, setUsers] = useState<User[]>([]);
  useEffect(() => {
    fetch(`${API_BASE}/api/admin/users`, { credentials: "include" })
      .then(r => r.json()).then(setUsers);
  }, []);
  // ...
  const handleAction = async (u: User, action: string) => {
    await fetch(`${API_BASE}/api/admin/users/${u.id}/${action}`, { method: "POST", credentials: "include" });
    // Refetch users
    fetch(`${API_BASE}/api/admin/users`, { credentials: "include" })
      .then(r => r.json()).then(setUsers);
  };

DESPUÉS:
  const qc = useQueryClient();
  const usersQuery = useQuery({
    queryKey: queryKeys.admin.users,
    queryFn: () => queryFns.adminUsers() as Promise<User[]>,
  });
  const users = usersQuery.data ?? [];

  const userAction = useMutation({
    mutationFn: ({ userId, action }: { userId: string; action: string }) =>
      apiJson(`/api/admin/users/${userId}/${action}`, { method: "POST" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: queryKeys.admin.users }),
  });

  const handleAction = (u: User, action: string) => {
    userAction.mutate({ userId: u.id, action });
  };


─── 3. MessagesPanel (línea ~488 aprox) ───

ANTES:
  const [messages, setMessages] = useState<Message[]>([]);
  useEffect(() => {
    fetch(`${API_BASE}/api/admin/projects/${projectId}/messages`, { credentials: "include" })
      .then(r => r.json()).then(setMessages);
  }, [projectId]);

DESPUÉS:
  const messagesQuery = useQuery({
    queryKey: queryKeys.admin.messages(projectId),
    queryFn: () => queryFns.adminMessages(projectId) as Promise<Message[]>,
    enabled: !!projectId,
  });
  const messages = messagesQuery.data ?? [];


─── 4. ApprovalsPanel (línea ~386 aprox) ───

ANTES:
  const [approvals, setApprovals] = useState<any[]>([]);
  const refetch = useCallback(() => {
    fetch(`${API_BASE}/api/admin/projects/${projectId}/approvals`, { credentials: "include" })
      .then(r => r.json()).then(d => setApprovals(d.approvals ?? []));
  }, [projectId]);
  useEffect(() => { refetch(); }, [refetch]);

DESPUÉS:
  const approvalsQuery = useQuery({
    queryKey: queryKeys.admin.approvals(projectId),
    queryFn: () => queryFns.adminApprovals(projectId) as Promise<{ approvals: any[] }>,
    enabled: !!projectId,
  });
  const approvals = approvalsQuery.data?.approvals ?? [];


═══════════════════════════════════════════════════════════════════════════════
PATCH #9 — FE-12 · Aplicar omitFields donde corresponde
═══════════════════════════════════════════════════════════════════════════════

Archivo: src/pages/admin/CMSEditor.tsx (línea 1157)
NO necesita cambios — los pending son traducciones UI, sin credenciales.

Archivo: src/pages/admin/EmailTemplates.tsx (línea 119)
NO necesita cambios — los drafts de email tampoco tienen credenciales.

Archivo: src/pages/NewProject.tsx — NO usa useDraftPersistence actualmente.

Si en el futuro añades drafts a NewProject (útil para no perder el formulario
cuando refrescas), debe ser así:

─── (si añades drafts a NewProject) ───
import { useDraftPersistence } from "@/hooks/use-draft-persistence";

// dentro del componente:
useDraftPersistence(
  `new-project-draft-${platformType}`,
  formData,
  setFormData,
  {
    omitFields: [
      "accessToken", "apiPassword", "clientSecret", "clientId",
      "wooKey", "wooSecret", "prestaApiKey",
    ],
  }
);


═══════════════════════════════════════════════════════════════════════════════
PATCH #10 — FE-14 · Integrar el OmniChatbot refactorizado
═══════════════════════════════════════════════════════════════════════════════

El refactor completo del OmniChatbot está en:
  fixes/components/omnichatbot/
    ├── types.ts             (utilidades + helpers de intent detection)
    ├── action-constants.ts  (LONG_RUNNING_ACTIONS, DESTRUCTIVE_ACTIONS, ...)
    ├── useShopyChat.ts      (hook con sendTextMessage + runDetectedActions)
    └── formatters.ts        (formatActionResult: 93 → 30 cases)

INTEGRACIÓN MANUAL en src/components/OmniChatbot.tsx:

Paso 1. Copiar la carpeta `omnichatbot/` en `src/components/`.

Paso 2. Reemplazar los imports del OmniChatbot.tsx original:

─── AL INICIO DEL ARCHIVO (después de los imports React) ───
import type { Message, ChatAction, DetectedAction, SearchResponse, KlaviyoInfo } from "./omnichatbot/types";
import { uuid, isProductCreationIntent, detectKlaviyo, detectEntityResearch, isDocumentFile } from "./omnichatbot/types";
import { useShopyChat } from "./omnichatbot/useShopyChat";
import { formatActionResult } from "./omnichatbot/formatters";
import { LONG_RUNNING_ACTIONS, DESTRUCTIVE_ACTIONS, MAX_ACTIONS_PER_TURN } from "./omnichatbot/action-constants";

Paso 3. Eliminar los siguientes bloques del archivo original:

  - Interfaces Message, ChatAction, EntityResearchResult, etc. (líneas 18-94)
    → Ya están en types.ts

  - Helpers uuid(), isDocumentFile(), isProductCreationIntent(), detectKlaviyo(),
    detectEntityResearch() (líneas 96-128)
    → Ya están en types.ts

  - La función executeShopifyAction completa (líneas 1004-1035)
    → Usa `useShopyChat().executeShopifyAction` en su lugar

  - La función formatActionResult completa (líneas 1037-1400 aprox, 93 cases)
    → Usa el import de formatters.ts

  - El loop de ejecución de multi-actions (líneas 1834-1846 aprox)
    → Usa `useShopyChat().runDetectedActions`

Paso 4. Dentro del componente MainChatbot, sustituir:

ANTES:
  const executeShopifyAction = async (action, params) => { ... };
  // ...
  for (const act of allActions) {
    const actionResult = await executeShopifyAction(act.action, act.params);
    // ...
  }

DESPUÉS:
  const { sendTextMessage, executeShopifyAction, runDetectedActions } = useShopyChat({
    systemPrompt: SYSTEM_PROMPT
  });
  // ...
  // Reemplaza el loop de allActions por:
  const { results, truncatedCount, stoppedForConfirmation } = await runDetectedActions(allActions);

  // Mensaje anunciando las acciones (FE-20):
  if (results.length > 0) {
    const actionList = results.map(r => `• \`${r.action}\` ${r.ok ? "✅" : r.blockedForConfirmation ? "⚠️" : "❌"}`).join("\n");
    const suffix = truncatedCount > 0
      ? `\n\n_(${truncatedCount} acciones omitidas — límite de ${MAX_ACTIONS_PER_TURN} por turno)_`
      : "";
    assistantContent += `\n\n🎯 **Acciones:**\n${actionList}${suffix}`;
  }

  const formattedResults = results.map(r => {
    if (r.blockedForConfirmation) {
      return `⚠️ **Confirmación requerida para \`${r.action}\`**\nReenvía tu petición añadiendo "confirma" al mensaje.`;
    }
    if (!r.ok) return `❌ ${r.error}`;
    return formatActionResult(r.action, r.data);
  });
  if (formattedResults.length > 0) {
    assistantContent += "\n\n" + formattedResults.join("\n\n---\n\n");
  }

Esto reduce el archivo de ~2142 líneas a ~1200 líneas aprox.


═══════════════════════════════════════════════════════════════════════════════
PATCH #11 — FE-17 · Breakpoints responsive en NewProject.tsx
═══════════════════════════════════════════════════════════════════════════════

NewProject.tsx tiene 58 estilos inline y 0 breakpoints. No voy a reescribirlo
entero (620 líneas) — en su lugar:

Paso 1. Copiar fixes/styles/responsive.css → src/styles/responsive.css

Paso 2. En src/main.tsx (o App.tsx) añadir:
  import "./styles/responsive.css";

Paso 3. En NewProject.tsx reemplazar los grid de 4 columnas hardcoded:

ANTES (línea ~520 aprox):
  <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginTop: 10 }}>
    {PLANS.map(p => (
      <button style={{ minWidth: 120, ... }}>

DESPUÉS:
  <div className="sc-scroll-x-mobile" style={{ display: "flex", gap: 10, marginTop: 10, padding: "4px 0" }}>
    {PLANS.map(p => (
      <button style={{ minWidth: 120, flexShrink: 0, ... }}>


ANTES (grid de plataformas, si existe hardcoded a 4 cols):
  <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>

DESPUÉS:
  <div className="grid-4-responsive">


ANTES (grid-2 fijo):
  <div className="grid-2">

DESPUÉS:
  <div className="grid-2-responsive">


═══════════════════════════════════════════════════════════════════════════════
PATCH #12 — FE-17 · CMSEditor layout iframe responsive
═══════════════════════════════════════════════════════════════════════════════

Archivo: src/pages/admin/CMSEditor.tsx

Problema: el CMS editor tiene un sidebar de ~320px y un iframe de preview.
En móvil (<768px) los dos elementos se solapan.

Fix: envolver el layout principal con clases responsivas.

ANTES (layout principal, línea aprox 1450):
  <div style={{ display: "flex", height: "100vh" }}>
    <aside style={{ width: 340, ... }}>
      {/* sidebar */}
    </aside>
    <main style={{ flex: 1 }}>
      <iframe ref={iframeRef} src={...} />
    </main>
  </div>

DESPUÉS:
  <div className="sc-sidebar-layout" style={{ height: "100vh" }}>
    <aside className="sc-sidebar" style={{ /* width se gestiona en CSS, quítalo aquí */ background: "var(--ink1)", overflowY: "auto" }}>
      {/* sidebar */}
    </aside>
    <main className="sc-main">
      <div className="sc-iframe-wrapper">
        <iframe ref={iframeRef} src={...} />
      </div>
    </main>
  </div>

Adicionalmente, para un botón "cerrar sidebar" en móvil:

  {/* Solo en móvil — toggle del sidebar */}
  <button
    className="sc-mobile-only"
    onClick={() => setSidebarOpen(!sidebarOpen)}
    style={{ position: "fixed", top: 12, left: 12, zIndex: 50, ... }}
  >
    ☰
  </button>


═══════════════════════════════════════════════════════════════════════════════
RESUMEN DE FICHEROS FINALES TRAS APLICAR TODOS LOS PATCHES
═══════════════════════════════════════════════════════════════════════════════

Creados (nuevos):
  src/lib/api.ts
  src/lib/sanitize.ts
  src/lib/queries.ts
  src/styles/responsive.css
  src/components/omnichatbot/types.ts
  src/components/omnichatbot/action-constants.ts
  src/components/omnichatbot/useShopyChat.ts
  src/components/omnichatbot/formatters.ts
  artifacts/api-server/src/routes/error-report.ts

Reemplazados:
  src/hooks/use-draft-persistence.ts
  src/components/ErrorBoundary.tsx
  src/pages/admin/Billing.tsx
  src/pages/admin/ShopyBrainInsights.tsx
  src/pages/admin/UniversalSearch.tsx
  capacitor.config.ts
  android/app/src/main/AndroidManifest.xml

Editados manualmente (vía patches en PATCHES.md y PATCHES_PART2.md):
  src/App.tsx                         (PATCH #4 — RequireClient)
  src/contexts/AuthContext.tsx        (PATCH #7 — timeout en fetchMe)
  src/components/OmniChatbot.tsx      (PATCH #10 — usar hooks refactorizados)
  src/pages/AdminClients.tsx          (PATCH #8 — react-query parcial)
  src/pages/Landing.tsx               (PATCH #1 — postMessage allowlist)
  src/pages/projects/Redesign.tsx     (PATCH #2 — cleanHtml)
  src/pages/projects/Images.tsx       (PATCH #3 — cleanSvg)
  src/pages/NewProject.tsx            (PATCH #11 — responsive classes)
  src/pages/admin/CMSEditor.tsx       (PATCH #12 — sidebar-layout)
  artifacts/api-server/src/routes/index.ts  (registrar error-report router)
