/**
 * Formatters de resultados de acciones Shopify.
 *
 * FIX FE-19: el OmniChatbot original tenía 93 cases en formatActionResult.
 * De ellos, 60+ solo devolvían variaciones de `result.message`.
 * Este módulo conserva SOLO los cases que aportan formato significativo
 * (tablas de productos, resúmenes de auditoría, etc.) y delega el resto
 * al default, que usa `result.message` con un emoji según la categoría.
 *
 * Resultado: ~250 líneas vs ~900 del archivo original.
 */

// ─── Tipos helper para evitar any's ──────────────────────────────────────────
interface ProductItem {
  title: string;
  id?: number;
  status?: string;
  price: string;
  compareAtPrice?: string;
  published?: boolean;
  auditScore?: number;
  auditGrade?: string;
  imageCount?: number;
  imageUrl?: string;
  descriptionLength?: number;
  descLength?: number;
  tagsCount?: number;
  variantCount?: number;
  hasComparePrice?: boolean;
  issues?: string[];
  grade?: string;
  score?: number;
}

interface ActionResult {
  error?: boolean;
  message?: string;
  [key: string]: unknown;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
const gradeIcon = (g: string): string =>
  g === "A" ? "🟢" : g === "B" ? "🟡" : g === "C" ? "🟠" : "🔴";

function formatProductLine(p: ProductItem): string {
  const grade = p.auditGrade ?? p.grade ?? "D";
  let line = `${gradeIcon(grade)} **${p.title}** — ${p.price}€`;
  if (p.compareAtPrice) line += ` ~~${p.compareAtPrice}€~~`;
  line += ` | **${grade}** (${p.auditScore ?? p.score ?? 0}/100)`;
  if (p.published === false) line += ` | 🔇 NO PUBLICADO`;

  const details: string[] = [];
  if (p.imageCount !== undefined) details.push(`${p.imageCount >= 3 ? "✅" : "⚠️"} ${p.imageCount} imgs`);
  if (p.variantCount !== undefined) details.push(`${p.variantCount} variants`);
  const descLen = p.descriptionLength ?? p.descLength;
  if (descLen !== undefined) details.push(`${descLen >= 500 ? "✅" : "⚠️"} ${descLen}ch desc`);
  if (p.tagsCount !== undefined) details.push(`${p.tagsCount >= 10 ? "✅" : "⚠️"} ${p.tagsCount} tags`);
  if (p.hasComparePrice !== undefined) details.push(p.hasComparePrice ? "✅ compare" : "⚠️ sin compare");

  if (details.length) line += `\n   ${details.join(" | ")}`;
  if (p.issues?.length) line += `\n   ⚠️ ${p.issues.join(" | ")}`;
  return line;
}

// ─── Iconos por categoría de acción ──────────────────────────────────────────
const ACTION_CATEGORY_ICONS: Record<string, string> = {
  audit: "🔍", analyze: "🔍", scan: "📊", diagnose: "🔬",
  generate: "🎨", create: "✨", design: "📄",
  optimize: "🧠", redesign: "✨", fix: "🔧",
  edit: "✏️", update: "📝", change: "🔄",
  delete: "🗑️", remove: "🗑️", deactivate: "⛔",
  list: "📋", get: "📋", read: "📖",
  publish: "📢", sync: "🔁", setup: "🏗️",
  seo: "🔎", email: "📧", inventory: "📦",
  price: "💰", pricing: "💰", financial: "📊",
  brain: "🧠", learn: "🧠", recall: "🔍",
  agency: "💼", approve: "✅",
};

function pickIcon(action: string): string {
  for (const [keyword, icon] of Object.entries(ACTION_CATEGORY_ICONS)) {
    if (action.toLowerCase().includes(keyword)) return icon;
  }
  return "✅";
}

// ─── Formatter principal ─────────────────────────────────────────────────────

/**
 * Formatea el resultado de una acción para mostrarse en el chat.
 * Los 30 cases específicos formatean con diseño custom.
 * Cualquier acción no listada cae al default con `result.message` + emoji.
 */
export function formatActionResult(action: string, result: unknown): string {
  const r = result as ActionResult;
  if (r.error) return `❌ ${r.message ?? "Error en la acción"}`;

  switch (action) {
    // ─── Acciones con formato rico (30 cases) ────────────────────────────────

    case "store_status":
      return `✅ **Estado de la tienda:**\n` +
        `🏪 ${r.storeName} (${r.domain})\n` +
        `📦 ${r.productsCount} productos (✅ ${r.activeProducts ?? "?"} activos | 📝 ${r.draftProducts ?? "?"} borradores | 📁 ${r.archivedProducts ?? "?"} archivados)\n` +
        `📢 Publicados: ${r.publishedProducts ?? "?"} | 🔇 No publicados: ${r.unpublishedProducts ?? "0"}${(r.unpublishedProducts as number) > 0 ? " ⚠️" : ""}\n` +
        `🛒 ${r.ordersCount} pedidos\n` +
        `🔑 Token: ${r.tokenStatus === "valid" ? `✅ válido (${r.tokenHoursLeft}h)` : "❌ EXPIRADO"}`;

    case "list_products": {
      const prods = (r.products as ProductItem[]) ?? [];
      if (!prods.length) return "📦 No se encontraron productos.";
      return `📦 **${r.total} productos:**\n\n${prods.map(formatProductLine).join("\n\n")}`;
    }

    case "search_product": {
      const prods = (r.products as ProductItem[]) ?? [];
      if (!prods.length) return "🔍 No se encontraron productos.";
      return `🔍 **${r.total} resultados:**\n\n${prods.map(formatProductLine).join("\n\n")}`;
    }

    case "audit_store": {
      let msg = `🔍 **AUDITORÍA PROFUNDA**\n\n`;
      msg += `📊 Puntuación media: ${r.averageScore}/100 (${r.overallGrade})\n`;
      msg += `📦 Total: ${r.totalProducts} productos\n`;
      msg += `📢 Publicados: ${r.publishedCount} | 🔇 No publicados: ${r.unpublishedCount}\n`;
      const critical = (r.criticalIssues as string[]) ?? [];
      const warnings = (r.warnings as string[]) ?? [];
      if (critical.length) msg += `\n🚨 **PROBLEMAS CRÍTICOS:**\n${critical.join("\n")}`;
      if (warnings.length) msg += `\n\n⚠️ **ADVERTENCIAS:**\n${warnings.join("\n")}`;
      if (!critical.length && !warnings.length) msg += `\n✅ ¡Todos los productos en perfecto estado!`;
      const prods = (r.products as ProductItem[]) ?? [];
      if (prods.length) msg += `\n\n📋 **Detalle por producto:**\n\n${prods.map(formatProductLine).join("\n\n")}`;
      return msg;
    }

    case "publish_product": {
      const issues = (r.auditIssues as string[]) ?? [];
      let msg = `✅ Producto "${r.title}" publicado correctamente\n📢 Estado: active | Publicado: SÍ`;
      if (r.previousStatus) msg += `\n📋 Antes: ${r.previousStatus}, publicado=${r.wasPublished ? "sí" : "no"}`;
      msg += issues.length > 0
        ? `\n\n🔍 Auditoría post-publicación:\n${issues.join("\n")}`
        : `\n\n✅ Auditoría OK — producto completo`;
      return msg;
    }

    case "fix_unpublished":
      return (r.fixed as number) > 0
        ? `✅ **${r.fixed} producto(s) publicados correctamente**${(r.errors as number) > 0 ? `\n⚠️ ${r.errors} error(es)` : ""}`
        : `✅ No hay productos sin publicar — todos están visibles`;

    case "fix_missing_compare_prices":
      return `💰 **Precios tachados añadidos:** ${r.fixed ?? 0}/${r.total ?? 0}${(r.errors as number) > 0 ? `\n⚠️ ${r.errors} errores` : ""}`;

    case "delete_product":
      if (r.requiresConfirmation) return `⚠️ ${r.message ?? "Confirma la eliminación reenviando la orden."}`;
      return `🗑️ **Producto eliminado** — ${r.message ?? "Borrado correctamente"}`;

    case "create_product":
      return `✨ **Producto creado:**\n📦 ${r.title}\n💰 ${r.price}€${r.compareAtPrice ? ` ~~${r.compareAtPrice}€~~` : ""}\n🏷️ ID: ${r.id}`;

    case "change_price":
      return `💰 **Precio actualizado:** ${r.oldPrice}€ → **${r.newPrice}€** en "${r.title}"`;

    case "list_collections": {
      const cols = r.collections as Array<{ title: string; productsCount: number }> ?? [];
      if (!cols.length) return "📂 No hay colecciones.";
      return `📂 **${cols.length} colecciones:**\n${cols.map(c => `• ${c.title} (${c.productsCount} productos)`).join("\n")}`;
    }

    case "list_variants": {
      const vars = r.variants as Array<{ title: string; price: string; sku?: string; inventory?: number }> ?? [];
      if (!vars.length) return "📋 Sin variantes.";
      return `📋 **${vars.length} variantes:**\n${vars.map(v => `• ${v.title} — ${v.price}€${v.sku ? ` [${v.sku}]` : ""}${v.inventory !== undefined ? ` | 📦 ${v.inventory}` : ""}`).join("\n")}`;
    }

    case "update_stock":
    case "bulk_update_stock":
      return `📦 **Stock actualizado:** ${r.updated ?? 0} variantes${(r.errors as number) > 0 ? `\n⚠️ ${r.errors} errores` : ""}`;

    case "generate_product_images":
    case "generate_images_from_reference":
    case "bulk_generate_images": {
      const success = r.success ?? r.succeeded ?? 0;
      const total = r.total ?? success;
      return `🎨 **Imágenes generadas:** ${success}/${total}${r.creditsUsed ? ` | Créditos: ${r.creditsUsed}` : ""}`;
    }

    case "virtual_tryon":
      return `👗 **Try-on generado** — ${r.message ?? "Completado"}`;

    case "redesign_product":
      return `✨ **Rediseño listo** — ${r.title ?? "producto"}\n${r.message ?? "Previsualización generada."}`;

    case "apply_redesign":
      return `✅ **Rediseño aplicado** — ${r.message ?? "Producto actualizado."}`;

    case "bulk_redesign":
      return `🚀 **Rediseño masivo:** ${r.updated ?? 0}/${r.total ?? 0} productos${(r.errors as number) > 0 ? `\n⚠️ ${r.errors} errores` : ""}`;

    case "create_ab_test":
      return `🧪 **A/B test creado:** ${r.testName ?? "Test"}`;

    case "declare_winner":
      return `🏆 **Ganador declarado:** ${r.winner ?? "variante"}\n${r.message ?? ""}`;

    case "seo_full_audit":
      return `🔍 **Auditoría SEO completa:**\n📊 Score medio: ${r.averageScore ?? "?"}/100\n${r.summary ?? ""}\n\n${r.message ?? ""}`;

    case "fix_all_alt_texts":
      return `🏷️ **Alt texts arreglados:** ${r.fixed ?? 0} imágenes`;

    case "generate_all_metas":
      return `📝 **Meta tags generados:** ${r.updated ?? 0}/${r.total ?? 0} productos`;

    case "audit_page_speed":
      return `⚡ **Page Speed:**\n🖥️ Desktop: ${r.desktopScore ?? "?"}/100\n📱 Mobile: ${r.mobileScore ?? "?"}/100`;

    case "list_source_files":
      return r.message as string ?? `📂 ${r.totalFrontend ?? 0} archivos frontend, ${r.totalBackend ?? 0} archivos backend`;

    case "fix_code":
      if (r.requiresConfirmation) return `⚠️ ${r.message ?? "Confirmación requerida"}`;
      return r.success
        ? `✅ **Fix aplicado en ${r.filePath}**\n${r.description ?? ""}\n💾 Backup: ${r.backupCreated ?? "?"}`
        : `❌ ${r.message ?? "No se pudo aplicar el fix"}`;

    case "modify_ui":
      if (r.requiresConfirmation) return `⚠️ ${r.message ?? "Preview — confirma para aplicar"}`;
      return r.message as string ?? "✅ UI modificada.";

    case "audit_app_offerings":
      return r.audit
        ? `🔍 **Auditoría de oferta:**\n\n${r.audit}`
        : (r.message as string) ?? "Auditoría completada.";

    case "financial_dashboard":
    case "financial_forecast":
      return `📊 **Dashboard financiero:**\n${r.message ?? "Análisis generado."}`;

    case "generate_budget":
    case "generate_platform_report":
    case "agency_quote":
    case "agency_proposal":
      return `💼 **${action.replace(/_/g, " ")}:** ${r.message ?? "Documento generado — descárgalo desde el panel."}`;

    case "brain_status":
      return `🧠 **Estado del cerebro:**\n${r.message ?? `${r.totalMemories ?? "?"} memorias totales.`}`;

    // ─── Default: usa message con emoji de categoría ─────────────────────────
    default:
      return `${pickIcon(action)} ${r.message ?? `Acción ${action} completada.`}`;
  }
}
