/**
 * Constantes compartidas de acciones del OmniChatbot.
 *
 * FIXES aplicados:
 * - FE-8: categorización de timeouts (LONG_RUNNING_ACTIONS = 15 min)
 * - FE-16: acciones destructivas que requieren confirmación (DESTRUCTIVE_ACTIONS)
 * - FE-16: límite de acciones por turno (MAX_ACTIONS_PER_TURN)
 */

/**
 * Acciones que tardan significativamente más que el default (3 min).
 * Requieren timeout de 15 minutos porque operan sobre todo el catálogo
 * o hacen varias llamadas a IA en serie.
 */
export const LONG_RUNNING_ACTIONS = new Set<string>([
  "optimize_all_products",
  "bulk_redesign",
  "bulk_generate_images",
  "setup_full_store",
  "design_all_pages",
  "auto_collections",
  "fix_unpublished",
  "fix_missing_compare_prices",
  "sync_catalog_prices",
  "run_full_audit_report",
  "generate_ai_report",
  "audit_store",
  "scan_store",
  "generate_competitive_pricing",
  "copyright_audit",
  "auto_estimate_all_cogs",
  "analyze_external_store",
  "external_pre_report",
]);

/**
 * Acciones destructivas o de alto impacto. Requieren `params.confirmed === true`
 * antes de ejecutarse desde el chatbot. Evita que Claude, por error o por
 * prompt injection, dispare operaciones irrevocables sin que el usuario
 * haya tenido oportunidad de pararlas.
 */
export const DESTRUCTIVE_ACTIONS = new Set<string>([
  // Eliminaciones directas
  "delete_product",
  "delete_collection",
  "delete_variant",
  "delete_email_flow",
  "deactivate_user",
  "reset_user_password",
  "reset_cms",
  // Bulk writes masivos en Shopify
  "fix_unpublished",
  "fix_missing_compare_prices",
  "sync_catalog_prices",
  "optimize_all_products",
  "bulk_redesign",
  "bulk_update_prices",
  "bulk_update_stock",
  "auto_collections",
  "design_all_pages",
  "setup_full_store",
  // Edición de código / UI (reescriben archivos del workspace)
  "fix_code",
  "modify_ui",
  // Edición de themes Shopify
  "edit_theme_file",
  "edit_theme_css",
  "edit_theme_settings",
  "create_theme_section",
  "sync_store_theme",
]);

/**
 * Límite de acciones que se ejecutan en un turno de chat. Si Claude detecta
 * más, las extra se ignoran y se informa al usuario.
 */
export const MAX_ACTIONS_PER_TURN = 3;

/**
 * Timeout por defecto para acciones (3 min) y para bulk (15 min).
 */
export const ACTION_TIMEOUT_DEFAULT_MS = 180_000;
export const ACTION_TIMEOUT_LONG_MS = 900_000;

/**
 * Calcula el timeout apropiado para una acción.
 */
export function getActionTimeout(action: string): number {
  return LONG_RUNNING_ACTIONS.has(action) ? ACTION_TIMEOUT_LONG_MS : ACTION_TIMEOUT_DEFAULT_MS;
}

/**
 * Comprueba si una acción requiere confirmación antes de ejecutar.
 * Una acción se considera "confirmada" si `params.confirmed === true|"true"`.
 */
export function needsConfirmation(action: string, params: Record<string, unknown> | undefined): boolean {
  if (!DESTRUCTIVE_ACTIONS.has(action)) return false;
  const c = params?.confirmed;
  return !(c === true || c === "true");
}
