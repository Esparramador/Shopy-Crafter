/**
 * Types compartidos del sistema OmniChatbot.
 *
 * Extraído de OmniChatbot.tsx original (líneas 18-96).
 * Parte del refactor FE-14: partir el archivo monolítico en módulos.
 */

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  model?: string;
  attachmentType?: "image" | "video" | "url" | "document";
  attachmentName?: string;
  action?: ChatAction;
}

export interface ChatAction {
  type:
    | "klaviyo-workflow"
    | "absorb-result"
    | "entity-research"
    | "shopify-action"
    | "supplier-research"
    | "pending-confirmation";
  label: string;
  data: unknown;
  actionName?: string;
  formattedContent?: string;
}

export interface EntityResearchResult {
  success: boolean;
  researchId: string;
  entity: string;
  queriesExecuted: number;
  sourcesFound: number;
  memoriesSaved: number;
  elapsed: string;
  profile: EntityProfile;
}

export interface EntityProfile {
  description?: string;
  ecommerceStack?: {
    platform?: string;
    emailTool?: string;
    [key: string]: unknown;
  };
  shopifyOpportunities?: string[];
  [key: string]: unknown;
}

export interface ProductFromImageResult {
  product: {
    id: number | string;
    title: string;
    status: string;
  };
  pricing: {
    recommendedPrice: number;
    compareAtPrice?: number;
    sourcesResearched: number;
    sources?: Array<{ source: string; product: string; price: number }>;
  };
  analysis: Record<string, unknown>;
}

export interface DetectedAction {
  action: string;
  params: Record<string, unknown>;
}

export interface SearchResponse {
  answer?: string;
  result?: string;
  detectedActions?: DetectedAction[];
  detectedAction?: DetectedAction;
}

export interface KlaviyoInfo {
  shopDomain: string;
  storeName: string;
  niche: string;
}

export interface KlaviyoWorkflowResponse {
  plan?: {
    flows?: Array<{
      name: string;
      emails?: Array<unknown>;
    }>;
    expected_revenue_impact?: string;
  };
}

/** Intent helper — detectar si el usuario quiere crear un producto */
export function isProductCreationIntent(text: string): boolean {
  const lower = text.toLowerCase();
  const createWords = [
    "crea", "crear", "créame", "creame", "publica", "sube", "subir",
    "añade", "añadir", "pon", "poner", "haz", "hacer", "genera", "generar",
    "create", "make", "add", "upload",
  ];
  const productWords = ["producto", "product", "artículo", "articulo", "item", "listing"];
  const shopifyWords = ["shopify", "tienda", "store", "shop"];
  const hasCreate = createWords.some(w => lower.includes(w));
  const hasProduct = productWords.some(w => lower.includes(w)) || shopifyWords.some(w => lower.includes(w));
  return hasCreate && hasProduct;
}

/** Detectar intent de Klaviyo */
export function detectKlaviyo(text: string): KlaviyoInfo | null {
  const lower = text.toLowerCase();
  if (!lower.includes("klaviyo") && !lower.includes("email marketing") && !lower.includes("flujo de email")) return null;
  const domainMatch = text.match(/(\S+\.myshopify\.com|\S+\.com)/i);
  const shopDomain = domainMatch?.[0] ?? "";
  const storeNameMatch = text.match(/(?:para|de)\s+"?([A-ZÁ-Úa-zá-ú][\w\s]+)"?/);
  const storeName = storeNameMatch?.[1]?.trim() ?? shopDomain.split(".")[0] ?? "mi tienda";
  const nicheMatch = text.match(/(?:nicho|sector|vertical|industria)\s+(?:de\s+)?([\w\s]+)/i);
  const niche = nicheMatch?.[1]?.trim() ?? "generic";
  return { shopDomain, storeName, niche };
}

/** Detectar intent de investigación de entidad (URL, @handle, "investiga X") */
export function detectEntityResearch(text: string): string | null {
  const handleMatch = text.match(/@([a-zA-Z0-9_.]{2,})/);
  if (handleMatch) return handleMatch[0];
  const researchMatch = text.match(/(?:investigar?|analiza(?:r)?|sobre|qu[eé] sabes (?:de|sobre))\s+([^\?\.]+)/i);
  if (researchMatch && researchMatch[1].trim().length > 2) return researchMatch[1].trim();
  return null;
}

/** Detectar si un archivo es documento (no imagen ni vídeo) */
export function isDocumentFile(file: File): boolean {
  const docExts = [".pdf", ".doc", ".docx", ".txt", ".md", ".rtf", ".csv", ".xlsx", ".xls", ".json"];
  const lower = file.name.toLowerCase();
  return docExts.some(ext => lower.endsWith(ext)) ||
    file.type.includes("pdf") ||
    file.type.includes("document") ||
    file.type.includes("text/");
}

/** Generar UUID v4 simple para IDs de mensajes */
export function uuid(): string {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}
