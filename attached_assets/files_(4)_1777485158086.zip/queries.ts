/**
 * FIX FE-13: migrar fetchers manuales a react-query.
 *
 * Este archivo centraliza las query keys + fetchers de las páginas admin que
 * originalmente hacían `useEffect + fetch + setState`. Así toda la app puede
 * reutilizar los mismos y se benefician de:
 *  - Cache compartida
 *  - Invalidation automática tras mutations
 *  - Retry exponential con backoff
 *  - Dedup de peticiones simultáneas
 *  - Loading/error state consistente
 *
 * UBICACIÓN: artifacts/shopify-optimizer/src/lib/queries.ts
 */

import type { QueryClient } from "@tanstack/react-query";
import { apiJson } from "./api";

// ─── Query keys ──────────────────────────────────────────────────────────────
export const queryKeys = {
  auth: {
    me: ["auth", "me"] as const,
  },

  admin: {
    all: ["admin"] as const,
    users: ["admin", "users"] as const,
    projects: ["admin", "projects"] as const,
    messages: (projectId: string | number) => ["admin", "projects", projectId, "messages"] as const,
    approvals: (projectId: string | number) => ["admin", "projects", projectId, "approvals"] as const,
    unreadMessages: ["admin", "unreadMessages"] as const,
  },

  billing: {
    all: ["billing"] as const,
    subscription: ["billing", "subscription"] as const,
    plans: ["billing", "plans"] as const,
    affiliate: ["billing", "affiliate"] as const,
    invoices: ["billing", "invoices"] as const,
  },

  shopyBrain: {
    all: ["shopyBrain"] as const,
    status: ["shopyBrain", "status"] as const,
    insights: (domain?: string) => ["shopyBrain", "insights", domain ?? "all"] as const,
    memories: ["shopyBrain", "memories"] as const,
    sessions: ["shopyBrain", "sessions"] as const,
    niches: ["shopyBrain", "niches"] as const,
    prompts: ["shopyBrain", "prompts"] as const,
  },

  project: {
    all: ["project"] as const,
    detail: (projectId: number | string) => ["project", projectId] as const,
    products: (projectId: number | string) => ["project", projectId, "products"] as const,
    audit: (projectId: number | string) => ["project", projectId, "audit"] as const,
    vault: (projectId: number | string) => ["project", projectId, "vault"] as const,
    vaultStats: (projectId: number | string) => ["project", projectId, "vault", "stats"] as const,
  },

  agency: {
    all: ["agency"] as const,
    services: ["agency", "services"] as const,
    costStructure: ["agency", "costStructure"] as const,
    shopifyProducts: ["agency", "shopifyProducts"] as const,
  },

  automations: {
    all: ["automations"] as const,
    jobs: ["automations", "jobs"] as const,
  },

  vault: {
    global: ["vault", "global"] as const,
    entities: ["vault", "global", "entities"] as const,
  },
} as const;

// ─── Fetchers típicos ────────────────────────────────────────────────────────
export const queryFns = {
  // Billing
  billingSubscription: () => apiJson("/api/billing/subscription"),
  billingPlans: () => apiJson("/api/billing/plans"),
  billingAffiliate: () => apiJson("/api/billing/affiliate"),
  billingInvoices: () => apiJson("/api/billing/invoices"),

  // Admin
  adminUsers: () => apiJson("/api/admin/users"),
  adminProjects: () => apiJson("/api/admin/projects-list"),
  adminUnreadMessages: () => apiJson("/api/admin/unread-messages"),
  adminMessages: (projectId: string | number) =>
    apiJson(`/api/admin/projects/${projectId}/messages`),
  adminApprovals: (projectId: string | number) =>
    apiJson(`/api/admin/projects/${projectId}/approvals`),

  // Shopybrain
  shopyBrainStatus: () => apiJson("/api/shopybrain/status"),
  shopyBrainInsights: (domain?: string) => {
    const suffix = domain ? `?domain=${encodeURIComponent(domain)}` : "";
    return apiJson(`/api/shopybrain/insights${suffix}`);
  },
  shopyBrainMemories: () => apiJson("/api/shopybrain/memories"),
  shopyBrainSessions: () => apiJson("/api/shopybrain/sessions"),

  // Agency
  agencyServices: () => apiJson("/api/agency/services"),
  agencyShopifyProducts: () => apiJson("/api/agency/shopify-products"),

  // Automations
  automationsJobs: () => apiJson("/api/automations/jobs"),

  // Vault
  vaultGlobal: () => apiJson("/api/vault/global"),
  vaultGlobalEntities: () => apiJson("/api/vault/global/entities"),
};

// ─── Invalidación masiva tras mutations ──────────────────────────────────────
export const invalidate = {
  /** Invalida tras crear/editar/eliminar un proyecto */
  projects: (qc: QueryClient) => {
    qc.invalidateQueries({ queryKey: queryKeys.admin.projects });
    qc.invalidateQueries({ queryKey: queryKeys.project.all });
  },

  /** Invalida tras acciones en un proyecto concreto */
  project: (qc: QueryClient, projectId: number | string) => {
    qc.invalidateQueries({ queryKey: queryKeys.project.detail(projectId) });
    qc.invalidateQueries({ queryKey: queryKeys.project.products(projectId) });
    qc.invalidateQueries({ queryKey: queryKeys.project.audit(projectId) });
  },

  /** Invalida tras upgrade/downgrade de plan */
  billing: (qc: QueryClient) => {
    qc.invalidateQueries({ queryKey: queryKeys.billing.all });
  },

  /** Invalida tras invitar cliente o cambiar usuarios */
  users: (qc: QueryClient) => {
    qc.invalidateQueries({ queryKey: queryKeys.admin.users });
  },

  /** Invalida tras enviar/leer mensaje */
  messages: (qc: QueryClient, projectId?: number | string) => {
    qc.invalidateQueries({ queryKey: queryKeys.admin.unreadMessages });
    if (projectId !== undefined) {
      qc.invalidateQueries({ queryKey: queryKeys.admin.messages(projectId) });
    }
  },

  /** Invalida cache de ShopyBrain */
  shopyBrain: (qc: QueryClient) => {
    qc.invalidateQueries({ queryKey: queryKeys.shopyBrain.all });
  },
};
