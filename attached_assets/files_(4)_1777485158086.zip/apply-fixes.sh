#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════════════
# apply-fixes.sh — Script de aplicación automática de fixes Shopy Crafter
# ════════════════════════════════════════════════════════════════════════════
#
# Uso:
#   1. Descomprimir shopy-crafter-fixes-v2.zip en cualquier directorio
#   2. cd al directorio descomprimido
#   3. bash apply-fixes.sh /ruta/a/repo-shopy-crafter
#
# El script:
#   - Hace backup antes de tocar nada (.shopy-fixes-backup/)
#   - Copia archivos nuevos (create)
#   - Reemplaza archivos existentes (overwrite)
#   - Valida con pnpm typecheck al final
#   - Los patches manuales (modificaciones puntuales) los deja en patches/ para aplicar a mano
#
# Fases:
#   FASE 1 — Seguridad crítica (FE-1, FE-3, FE-4, manual)
#   FASE 2 — Helper networking (FE-5) + sanitize
#   FASE 3 — ErrorBoundary + backend report (FE-18)
#   FASE 4 — Billing completa (FE-9, FE-13, FE-17)
#   FASE 5 — Drafts seguros (FE-12)
#   FASE 6 — OmniChatbot modules (FE-8, FE-14, FE-16, FE-19, FE-20, manual)
#   FASE 7 — Páginas migradas (FE-13: ShopyBrainInsights, UniversalSearch)
#   FASE 8 — Capacitor/Android (FE-7, FE-11)
#   FASE 9 — Responsive CSS global (FE-17)

set -euo pipefail

REPO="${1:-}"
if [ -z "$REPO" ]; then
  echo "Uso: bash apply-fixes.sh /ruta/a/repo"
  exit 1
fi
if [ ! -d "$REPO/artifacts/shopify-optimizer" ]; then
  echo "❌ No se encuentra artifacts/shopify-optimizer en $REPO"
  exit 1
fi

FE="$REPO/artifacts/shopify-optimizer"
BE="$REPO/artifacts/api-server"
BACKUP="$REPO/.shopy-fixes-backup-$(date +%Y%m%d_%H%M%S)"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "📦 Aplicando fixes a: $REPO"
echo "📁 Backup en: $BACKUP"
mkdir -p "$BACKUP"

backup() {
  local src="$1"
  if [ -f "$src" ]; then
    local rel="${src#$REPO/}"
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp "$src" "$BACKUP/$rel"
  fi
}

install() {
  local src_rel="$1"
  local dst="$2"
  mkdir -p "$(dirname "$dst")"
  backup "$dst"
  cp "$SCRIPT_DIR/$src_rel" "$dst"
  echo "  ✓ $dst"
}

echo ""
echo "═══ FASE 2 — helpers (api, sanitize, queries) ═══"
install "lib/api.ts"                         "$FE/src/lib/api.ts"
install "lib/sanitize.ts"                    "$FE/src/lib/sanitize.ts"
install "lib/queries.ts"                     "$FE/src/lib/queries.ts"

echo ""
echo "═══ FASE 3 — ErrorBoundary + endpoint backend ═══"
install "components/ErrorBoundary.tsx"       "$FE/src/components/ErrorBoundary.tsx"
install "api-server/error-report.ts"         "$BE/src/routes/error-report.ts"

echo ""
echo "═══ FASE 4 — Billing ═══"
install "pages/Billing.tsx"                  "$FE/src/pages/admin/Billing.tsx"

echo ""
echo "═══ FASE 5 — Drafts seguros ═══"
install "hooks/use-draft-persistence.ts"     "$FE/src/hooks/use-draft-persistence.ts"

echo ""
echo "═══ FASE 6 — OmniChatbot modules ═══"
install "components/omnichatbot/types.ts"             "$FE/src/components/omnichatbot/types.ts"
install "components/omnichatbot/action-constants.ts"  "$FE/src/components/omnichatbot/action-constants.ts"
install "components/omnichatbot/useShopyChat.ts"      "$FE/src/components/omnichatbot/useShopyChat.ts"
install "components/omnichatbot/formatters.ts"        "$FE/src/components/omnichatbot/formatters.ts"

echo ""
echo "═══ FASE 7 — Páginas migradas react-query ═══"
install "pages/ShopyBrainInsights.tsx"       "$FE/src/pages/admin/ShopyBrainInsights.tsx"
install "pages/UniversalSearch.tsx"          "$FE/src/pages/admin/UniversalSearch.tsx"

echo ""
echo "═══ FASE 8 — Capacitor / Android ═══"
install "android/capacitor.config.ts"        "$FE/capacitor.config.ts"
install "android/AndroidManifest.xml"        "$FE/android/app/src/main/AndroidManifest.xml"

echo ""
echo "═══ FASE 9 — Responsive CSS ═══"
install "styles/responsive.css"              "$FE/src/styles/responsive.css"

echo ""
echo "═══ Crear .env files si no existen ═══"
if [ ! -f "$FE/.env.production" ]; then
  echo "VITE_API_URL=" > "$FE/.env.production"
  echo "  ✓ .env.production"
fi
if [ ! -f "$FE/.env.development" ]; then
  echo "VITE_API_URL=" > "$FE/.env.development"
  echo "  ✓ .env.development"
fi

echo ""
echo "═══ Instalando DOMPurify ═══"
cd "$REPO"
pnpm add dompurify --filter @workspace/shopify-optimizer 2>/dev/null || {
  echo "⚠️  Instala manualmente: pnpm add dompurify --filter @workspace/shopify-optimizer"
  echo "⚠️  Y: pnpm add -D @types/dompurify --filter @workspace/shopify-optimizer"
}
pnpm add -D @types/dompurify --filter @workspace/shopify-optimizer 2>/dev/null || true

echo ""
echo "═══ Validación con typecheck ═══"
cd "$FE"
if pnpm typecheck 2>&1 | head -30; then
  echo "✅ typecheck OK"
else
  echo "⚠️  typecheck con warnings — revisa los imports manuales en los patches"
fi

echo ""
echo "════════════════════════════════════════════════════════════════════════"
echo "✅ FASES AUTOMATIZABLES COMPLETAS"
echo "════════════════════════════════════════════════════════════════════════"
echo ""
echo "🔴 PENDIENTE MANUAL (aplicar los 12 patches de patches/PATCHES*.md):"
echo ""
echo "  Patches en patches/PATCHES.md:"
echo "    #1  src/pages/Landing.tsx           (FE-1  postMessage allowlist)"
echo "    #2  src/pages/projects/Redesign.tsx (FE-3  cleanHtml)"
echo "    #3  src/pages/projects/Images.tsx   (FE-4  cleanSvg)"
echo "    #4  src/App.tsx                     (FE-6  RequireClient redirect)"
echo "    #5  src/components/OmniChatbot.tsx  (FE-8, FE-16, FE-20: timeout + confirm)"
echo "    #6  Migrar BASE_URL en 9 archivos   (FE-5, opcional — funcionando como está)"
echo "    #7  src/contexts/AuthContext.tsx    (FE-1  timeout fetchMe)"
echo ""
echo "  Patches en patches/PATCHES_PART2.md:"
echo "    #8  src/pages/AdminClients.tsx      (FE-13 react-query parcial)"
echo "    #9  No requiere cambios             (FE-12 ya safe)"
echo "    #10 src/components/OmniChatbot.tsx  (FE-14 usar hooks refactorizados)"
echo "    #11 src/pages/NewProject.tsx        (FE-17 clases responsive)"
echo "    #12 src/pages/admin/CMSEditor.tsx   (FE-17 sc-sidebar-layout)"
echo ""
echo "  En artifacts/api-server/src/routes/index.ts añadir:"
echo "    import errorReportRouter from \"./error-report.js\";"
echo "    router.use(errorReportRouter);  // ANTES de requireAdmin"
echo ""
echo "  En artifacts/shopify-optimizer/src/main.tsx añadir:"
echo "    import \"./styles/responsive.css\";"
echo ""
echo "📁 Backup de archivos originales en: $BACKUP"
echo ""
