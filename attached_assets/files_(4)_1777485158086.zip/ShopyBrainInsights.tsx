/**
 * FIX FE-13: migrado de useEffect+fetch+setState a react-query.
 * FIX FE-17: responsive mobile-first (ya lo era — confirmado).
 * FIX FE-5: usa apiJson via queryFns.
 */
import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Brain, Zap, TrendingUp, AlertTriangle, Lightbulb, Link as LinkIcon, RefreshCcw } from "lucide-react";
import { queryKeys, queryFns } from "@/lib/queries";
import { ApiError } from "@/lib/api";

const DOMAIN_ICONS: Record<string, string> = {
  ecommerce: "🛒", shopify_technical: "⚙️", financial_analysis: "💰",
  trading_markets: "📈", investment: "💎", marketing: "📣",
  sales: "🎯", design_ux: "🎨", merchandising: "🏪",
  seo_content: "🔍", logistics: "📦", paid_media: "💸",
  consumer_psychology: "🧠", pricing_science: "💱",
};

const INSIGHT_TYPE_CONFIG: Record<string, { color: string; icon: typeof Lightbulb; label: string }> = {
  principle: { color: "#c8a84b", icon: Lightbulb, label: "Principio" },
  pattern: { color: "#5b4eff", icon: TrendingUp, label: "Patrón" },
  correlation: { color: "#06b6d4", icon: LinkIcon, label: "Correlación" },
  prediction: { color: "#2dd49f", icon: Zap, label: "Predicción" },
  opportunity: { color: "#f97316", icon: TrendingUp, label: "Oportunidad" },
  warning: { color: "#e84558", icon: AlertTriangle, label: "Alerta" },
  contradiction: { color: "#8b5cf6", icon: Brain, label: "Contradicción" },
};

interface Domain {
  id: string; domain: string; label: string;
  knowledgeDepth: number;
  totalInsights: number; verifiedInsights: number;
}
interface Insight {
  id: string; domain: string; insightType: string; title: string;
  insight: string; evidence?: string; confidence: number; impactScore: number;
  timesApplied: number; successRate: number;
}
interface InsightsResponse {
  domains?: Domain[];
  insights?: Insight[];
}

export default function ShopyBrainInsights() {
  const [selectedDomain, setSelectedDomain] = useState<string>("");

  const q = useQuery({
    queryKey: queryKeys.shopyBrain.insights(selectedDomain || undefined),
    queryFn: () => queryFns.shopyBrainInsights(selectedDomain || undefined) as Promise<InsightsResponse>,
  });

  const domains = q.data?.domains ?? [];
  const insights = q.data?.insights ?? [];

  const handleDomainSelect = (domain: string) => {
    setSelectedDomain(prev => prev === domain ? "" : domain);
  };

  const sortedInsights = useMemo(() =>
    [...insights].sort((a, b) => (b.impactScore ?? 0) - (a.impactScore ?? 0))
  , [insights]);

  return (
    <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 16px" }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: "clamp(18px, 4vw, 22px)", fontWeight: 800 }}>⚡ Knowledge Domains</h1>
        <p style={{ fontSize: 13, color: "var(--t2)", marginTop: 3 }}>
          14 áreas de expertise donde Shopy Crafter acumula conocimiento profundo
        </p>
      </div>

      {q.isError && (
        <div className="glass-card" style={{ padding: 16, marginBottom: 16, borderColor: "var(--crim)" }}>
          <p style={{ fontSize: 13, color: "var(--crim)", display: "flex", alignItems: "center", gap: 8 }}>
            <AlertTriangle size={14} />
            {q.error instanceof ApiError ? q.error.message : "Error cargando insights"}
            <button
              onClick={() => q.refetch()}
              className="btn-secondary"
              style={{ marginLeft: "auto", display: "inline-flex", alignItems: "center", gap: 4 }}
            >
              <RefreshCcw size={12} /> Reintentar
            </button>
          </p>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(min(160px, 100%), 1fr))", gap: 10, marginBottom: 24 }}>
        {q.isLoading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="skeleton" style={{ height: 72, borderRadius: 10 }} />
          ))
        ) : domains.map(d => (
          <button
            key={d.domain}
            onClick={() => handleDomainSelect(d.domain)}
            style={{
              background: selectedDomain === d.domain ? "rgba(200,168,75,0.12)" : "var(--ink2)",
              border: `1px solid ${selectedDomain === d.domain ? "var(--gold)" : "var(--bdr)"}`,
              borderRadius: 10, padding: "12px 14px", cursor: "pointer", textAlign: "left",
              transition: "all 0.15s",
            }}
          >
            <div style={{ fontSize: 20, marginBottom: 4 }}>{DOMAIN_ICONS[d.domain] ?? "📚"}</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "var(--t)" }}>{d.label}</div>
            <div style={{ fontSize: 10, color: "var(--t3)", marginTop: 2 }}>
              {d.totalInsights} insights · depth {d.knowledgeDepth}
            </div>
          </button>
        ))}
      </div>

      <div>
        <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>
          {selectedDomain ? `Insights de ${selectedDomain}` : "Todos los insights"}
          {!q.isLoading && ` (${sortedInsights.length})`}
        </h2>
        {q.isLoading ? (
          <div style={{ display: "grid", gap: 10 }}>
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="skeleton" style={{ height: 100, borderRadius: 10 }} />
            ))}
          </div>
        ) : sortedInsights.length === 0 ? (
          <div className="glass-card" style={{ padding: 32, textAlign: "center", color: "var(--t3)" }}>
            <p>No hay insights {selectedDomain ? "en este dominio" : "todavía"}.</p>
          </div>
        ) : (
          <div style={{ display: "grid", gap: 10 }}>
            {sortedInsights.map(ins => {
              const cfg = INSIGHT_TYPE_CONFIG[ins.insightType] ?? INSIGHT_TYPE_CONFIG.principle;
              const Icon = cfg.icon;
              return (
                <div key={ins.id} className="glass-card" style={{ padding: 14, borderLeft: `3px solid ${cfg.color}` }}>
                  <div style={{ display: "flex", alignItems: "flex-start", gap: 10, flexWrap: "wrap" }}>
                    <Icon size={16} style={{ color: cfg.color, flexShrink: 0, marginTop: 2 }} />
                    <div style={{ flex: 1, minWidth: 220 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4, flexWrap: "wrap" }}>
                        <span style={{ fontSize: 10, fontWeight: 700, color: cfg.color, textTransform: "uppercase", letterSpacing: 1 }}>
                          {cfg.label}
                        </span>
                        <span style={{ fontSize: 10, color: "var(--t3)" }}>{ins.domain}</span>
                        <span style={{ fontSize: 10, color: "var(--gold)", marginLeft: "auto" }}>
                          💪 {Math.round(ins.confidence * 100)}% · 🎯 {ins.impactScore}/10
                        </span>
                      </div>
                      <h3 style={{ fontSize: 14, fontWeight: 700, color: "var(--t)", marginBottom: 6 }}>
                        {ins.title}
                      </h3>
                      <p style={{ fontSize: 12, color: "var(--t2)", lineHeight: 1.5 }}>
                        {ins.insight}
                      </p>
                      {ins.evidence && (
                        <p style={{ fontSize: 11, color: "var(--t3)", marginTop: 6, fontStyle: "italic" }}>
                          💡 {ins.evidence}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
