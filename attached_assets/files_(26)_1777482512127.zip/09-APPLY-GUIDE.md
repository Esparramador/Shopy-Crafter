# Aplicación final — paquete completo de auditoría Shopy Crafter

## ⚠ Antes de empezar

Si pegaste API keys de Runway o ElevenLabs en algún chat, **revócalas YA** antes de aplicar nada:
- ElevenLabs: https://elevenlabs.io/app/settings/api-keys
- Runway: https://app.runwayml.com/account?tab=api

Genera nuevas y guárdalas como Replit Secrets, **nunca en código ni en chats**.

---

## Lo que incluye este paquete

**12 ficheros backend + frontend** que cierran 5 clusters críticos + 5 quick-wins anteriores:

### Backend (5 ficheros to replace + 1 to delete)

| Fichero | Cambio |
|---|---|
| `routes/index.ts` | Borrado import + mount de `klaviyoRouter` (verificado: solo este fichero lo importaba) |
| `routes/push.ts` | Reescrito completo: persistencia en PG + `webpush.sendNotification()` real (antes era stub que no enviaba nada) |
| `routes/fusion-studio.ts` | `/create-product` ahora acepta `generatedPhotoUrls[]` y los sube a Shopify junto con las de referencia. Nuevos endpoints `/generate-video` (6 modelos Replicate) y `/video-models` |
| `lib/auth.ts` | Eliminado `requireClientAccess` (dead code, nadie lo importaba) |
| `lib/crypto.ts` | `validateEncryptionKey` ahora falla duro en producción si no está seteada (antes generaba key temporal en RAM → silent corruption tras restart) |
| ~~`routes/klaviyo.ts`~~ | **BORRAR** — wrappers REST redundantes con `klaviyo-ai.ts` |

### Frontend (6 ficheros to replace + 4 to create)

| Fichero | Cambio |
|---|---|
| `App.tsx` | + `lazy import Billing` + `lazy import BrainSync` + `<Route /admin/billing>` + `<Route /admin/brain-sync>` |
| `components/layout/AppLayout.tsx` | + sidebar item "Facturación & Plan 💳" + "Brain Sync 🔄" |
| `pages/AdminClients.tsx` | + función `impersonate()` + botón "Ver como" + función `PlansModal` completa con cambio de plan, asignar packs, ver usage, reset + botón "💳 Plan" en cada row |
| `pages/projects/Audit.tsx` | + handler `runStoreAudit()` + botón "🔍 Auditoría Tienda" + modal con scores/recommendations/issues/historial usando endpoint `/audit/run` (huérfano rescatado) |
| `pages/projects/FusionStudio.tsx` | + envío de fotos generadas al crear producto + panel "🎬 Generar video publicitario IA" (selector modelo/duración/aspecto/prompt + picker imagen origen + video player + descarga MP4) |
| `pages/admin/Revenue.tsx` | PATCH→PUT (fix C1 original) |
| `pages/admin/BrainSync.tsx` | **NUEVO** — página admin con 4 tabs: Vista General (métricas + salud + categorías + recientes), Exportar (3 cards JSON), Importar (JSON/NDJSON dual paste/upload), Herramientas (4 acciones admin) |
| `hooks/use-push-subscription.tsx` | **NUEVO** — hook React + componente `<PushNotificationsButton />` listo para embeber |
| `public/service-worker.js` | **NUEVO** — recibe push notifications + click handler |
| `lib/api.ts` | **NUEVO** — wrapper centralizado fetchApi (fix A1) |

### Android (2 ficheros — turnos previos)

| Fichero | Cambio |
|---|---|
| `android/app/src/main/AndroidManifest.xml` | `allowBackup=false` + `usesCleartextTraffic=false` + permisos de cámara/audio + deep links `shopycrafter://` |
| `android/app/src/main/res/xml/data_extraction_rules.xml` | **NUEVO** — complemento del Manifest |

---

## Aplicación rápida

### 1. Backend dependency

```bash
cd artifacts/api-server
pnpm add web-push @types/web-push
```

### 2. Copiar todo

```bash
AUDIT=./shopycrafter-audit

# Backend replace
cp $AUDIT/files-to-replace/routes-index.ts        artifacts/api-server/src/routes/index.ts
cp $AUDIT/files-to-replace/push.ts                artifacts/api-server/src/routes/push.ts
cp $AUDIT/files-to-replace/fusion-studio.ts       artifacts/api-server/src/routes/fusion-studio.ts
cp $AUDIT/files-to-replace/auth.ts                artifacts/api-server/src/lib/auth.ts
cp $AUDIT/files-to-replace/crypto.ts              artifacts/api-server/src/lib/crypto.ts

# Backend delete
rm artifacts/api-server/src/routes/klaviyo.ts

# Frontend replace
cp $AUDIT/files-to-replace/App.tsx                artifacts/shopify-optimizer/src/App.tsx
cp $AUDIT/files-to-replace/AppLayout.tsx          artifacts/shopify-optimizer/src/components/layout/AppLayout.tsx
cp $AUDIT/files-to-replace/AdminClients.tsx       artifacts/shopify-optimizer/src/pages/AdminClients.tsx
cp $AUDIT/files-to-replace/Audit.tsx              artifacts/shopify-optimizer/src/pages/projects/Audit.tsx
cp $AUDIT/files-to-replace/FusionStudio.tsx       artifacts/shopify-optimizer/src/pages/projects/FusionStudio.tsx
cp $AUDIT/files-to-replace/Revenue.tsx            artifacts/shopify-optimizer/src/pages/admin/Revenue.tsx

# Frontend new
cp $AUDIT/files-to-create/BrainSync.tsx              artifacts/shopify-optimizer/src/pages/admin/BrainSync.tsx
cp $AUDIT/files-to-create/use-push-subscription.tsx  artifacts/shopify-optimizer/src/hooks/use-push-subscription.tsx
cp $AUDIT/files-to-create/service-worker.js          artifacts/shopify-optimizer/public/service-worker.js
cp $AUDIT/files-to-create/lib-api.ts                 artifacts/shopify-optimizer/src/lib/api.ts

# Android
cp $AUDIT/files-to-replace/AndroidManifest.xml       artifacts/shopify-optimizer/android/app/src/main/AndroidManifest.xml
mkdir -p artifacts/shopify-optimizer/android/app/src/main/res/xml
cp $AUDIT/files-to-create/data_extraction_rules.xml  artifacts/shopify-optimizer/android/app/src/main/res/xml/data_extraction_rules.xml
```

### 3. Variables de entorno (Replit Secrets o `.env`)

```
ENCRYPTION_KEY=<64-char hex string>          # OBLIGATORIO (ver abajo)
VAPID_SUBJECT=mailto:tu-email@ejemplo.com    # opcional, default OK
```

Generar `ENCRYPTION_KEY`:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

⚠ **Si ya tenías datos cifrados en producción** (tokens Shopify), coordina el cambio. El fix C5 evita que el servidor arranque sin la key. Si pones una NUEVA, los datos cifrados con la key temporal previa quedan inutilizables. Recomendación: hacer una migración que des-cifre con la key antigua + re-cifre con la nueva, o reseteo manual de los `accessToken` por proyecto.

### 4. Verificar

```bash
pnpm -F @workspace/api-server build
pnpm -F @workspace/shopify-optimizer typecheck
```

---

## Tests manuales sugeridos

### A. Push notifications end-to-end
1. Login admin → `/admin/settings` → si no había VAPID, click "Generar claves VAPID"
2. Embebir `<PushNotificationsButton />` en cualquier página de cliente (ej: client/Settings.tsx)
3. Click "🔔 Activar notificaciones push" → aceptar permiso del navegador
4. Backend curl test:
   ```bash
   curl -X POST -b "session=<tu-cookie>" \
     -H "Content-Type: application/json" \
     -d '{"userId":"<user-id>","title":"Hola","body":"Funciona"}' \
     https://tu-dominio/api/push/send
   ```
5. Debe llegar notificación al navegador del usuario

### B. Auditoría Tienda Universal
1. `/projects/<id>/audit` (proyecto con `shopDomain` válido)
2. Click "🔍 Auditoría Tienda" (botón morado)
3. Modal abre con loader. El backend ejecuta `UniversalAuditConnector` (PageSpeed + scraping + Claude analysis)
4. Polling cada 15s hasta máximo 4 minutos
5. Resultados: scores SEO/Performance/Mobile/Accessibility + recomendaciones priorizadas + issues + historial

### C. Plans/Créditos
1. `/admin/clients` → click "💳 Plan" en cualquier cliente
2. Modal muestra dropdown de proyectos del cliente (si >1) o auto-selecciona
3. Tarjeta dorada: plan actual + usage del mes (productos / imágenes) + packs activos
4. Botón ↻ Reset: resetea contador mensual
5. Cards de planes: click para cambiar (pide confirmación)
6. Cards de packs: click para asignar (suma créditos al proyecto)

### D. Brain Sync
1. Sidebar admin → "🔄 Brain Sync"
2. **Tab Vista General**: barra de salud del cerebro (0-100), 6 métricas con iconos coloreados, gráfico de barras por categoría, tarjetas de aprendizajes recientes con tags
3. **Tab Exportar**: 3 cards (Knowledge / Domains / Prompts) → click descarga `.json` con timestamp
4. **Tab Importar**: toggle JSON ↔ NDJSON, área pegar + área subir archivo, botón importar pide confirmación
5. **Tab Herramientas**: 4 cards (Sync, Self-knowledge, Shopify services, Shopify prices) cada una con confirm

### E. FusionStudio: crear producto + video publicitario
1. `/projects/<id>/fusion-studio`
2. Completar fases brand → product → generate → gallery
3. Cuando hay fotos generadas: tarjeta de éxito muestra "📸 X de referencia · ✨ Y generadas IA"
4. Click "🛍️ Crear producto en Shopify" → producto se crea con TODAS las imágenes (subidas + IA)
5. Debajo de la galería: panel "🎬 Generar video publicitario IA"
6. Selector de modelo (default Seedance Fast = $0.05/seg) + duración + aspecto + prompt + picker imagen origen
7. Click generar → 1-3 minutos → video aparece embebido + descarga MP4

---

## Lo que NO está en este paquete

### AdStudio Pro (Runway + ElevenLabs + Nano Banana)
Pendiente del próximo turno. No lo construí porque pegaste API keys vivas en el chat anterior y no habías confirmado revocación. Cuando confirmes "keys revocadas y nuevas en Replit Secrets", arranco con:
- Backend: `/api/ad-studio/generate-campaign` con stages copy → voice → video → compose
- Frontend: wizard `/projects/:id/ad-studio` con 5 steps + galería A/B
- Pipeline: Claude (copy 3 variantes) → ElevenLabs (TTS + SFX) → Runway Gen-4 Turbo (video) → Nano Banana (Gemini Image 3 para hero shots) → FFmpeg server-side (compose final MP4) → vault + brain learn
- Coste estimado: $0.50-$1.50 por anuncio único, $2.50-$7.50 por set de 5 variantes

### Decisiones de producto pendientes
- Webhook Shopify `orders/paid` para cerrar loop de créditos cuando un pack se compra (A11)
- Mensajería tiempo real cliente↔admin (SSE vs WebSocket vs polling) (A12)
- DOMPurify en `Redesign.tsx`/`Images.tsx` para HTML que viene del LLM (A7)
- iOS Safari clipboard fallback (M10)

### Trabajo que sigue siendo deuda técnica (para otra sesión)
- Adoptar `lib-api.ts` wrapper en las 197 llamadas `fetch()` directas (1-2 días iterativo)
- Agregar 55 formatters faltantes en `OmniChatbot.tsx formatActionResult()`
- Auditar a fondo `shopybrain.ts` (11000 líneas) y `exports.ts` (5115 líneas) handler por handler
