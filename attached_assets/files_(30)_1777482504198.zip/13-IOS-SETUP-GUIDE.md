# 13 — iOS Setup Guide

Estado actual y pasos necesarios para que la app de Shopy Crafter funcione en iOS.

---

## Estado actual auditado

| Componente | Estado |
|---|---|
| `capacitor.config.ts` con bloque `ios:` | 🟡 **Faltaba** → ✅ corregido (`/files-to-replace/capacitor.config.ts`) |
| Carpeta `artifacts/shopify-optimizer/ios/` | ❌ No existe (debe generarse con `npx cap add ios` en Mac) |
| Paquete `@capacitor/ios` | ❌ No instalado (solo está `@capacitor/android`) |
| Safe-area CSS para iPhone con notch | ❌ No implementado |
| Push notifications iOS | ❌ Web Push VAPID NO funciona en Capacitor iOS — requiere `@capacitor/push-notifications` + APNs setup |
| App Store assets (icons, splash) | ❌ Solo hay assets Android |

---

## Lo que ya he aplicado al paquete

### `capacitor.config.ts` actualizado

He añadido el bloque `ios:` con la configuración correcta:

```ts
ios: {
  contentInset: "always",
  backgroundColor: "#080810",
  scrollEnabled: true,
  limitsNavigationsToAppBoundDomains: false,
  preferredContentMode: "mobile",
},
```

Y a `SplashScreen` plugin se añadió:
```ts
iosSplashResourceName: "Default",
splashFullScreen: true,
splashImmersive: true,
```

Y al `server`:
```ts
iosScheme: "https",
```

---

## Pasos pendientes para activar iOS (requiere Mac)

### 1. Instalar @capacitor/ios

```bash
cd artifacts/shopify-optimizer
pnpm add @capacitor/ios@^8.2.0
```

### 2. Generar la carpeta ios/

```bash
pnpm build  # genera dist/public/
npx cap add ios
npx cap sync ios
```

Esto crea `artifacts/shopify-optimizer/ios/` con el proyecto Xcode (`App.xcworkspace`).

### 3. Configurar Bundle Identifier y certificados en Xcode

```bash
npx cap open ios  # abre Xcode
```

En Xcode:
- General → Identity → Bundle Identifier: `es.shopybrain.app`
- Signing & Capabilities → Team: tu Apple Developer account
- Activar capability "Push Notifications" (si vas a usar push)
- Activar capability "Background Modes" → Remote notifications (si push)

### 4. Añadir App Icons y Launch Screen

Necesitas:
- App icons en distintas resoluciones (`@1x`, `@2x`, `@3x`) en `ios/App/App/Assets.xcassets/AppIcon.appiconset/`
- Launch Screen storyboard en `ios/App/App/Base.lproj/LaunchScreen.storyboard`

Capacitor genera placeholders pero conviene reemplazarlos con el branding de Shopy Crafter.

### 5. Añadir Safe-area CSS (CRÍTICO para iPhones con notch)

Añadir al `index.css` o equivalente:

```css
/* Soporte para iPhones X+ con notch */
.app-header {
  padding-top: env(safe-area-inset-top);
}
.app-bottom-nav {
  padding-bottom: env(safe-area-inset-bottom);
}

/* Scroll sin cortar contenido por el notch */
body {
  padding-top: env(safe-area-inset-top);
  padding-bottom: env(safe-area-inset-bottom);
  padding-left: env(safe-area-inset-left);
  padding-right: env(safe-area-inset-right);
}

/* Para áreas full-bleed que sí deben llegar al borde (hero images, etc) */
.full-bleed {
  margin-top: calc(-1 * env(safe-area-inset-top));
  padding-top: env(safe-area-inset-top);
}
```

Y en `<head>` del HTML:
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
```

El `viewport-fit=cover` es **imprescindible** para que `env(safe-area-inset-*)` funcione en iOS.

### 6. Push Notifications iOS (si las quieres en iOS)

⚠️ **VAPID Web Push NO funciona en Capacitor iOS** (al menos a 25 abril 2026). Solo funciona en Safari como PWA pura.

Para Capacitor iOS, necesitas APNs:

```bash
pnpm add @capacitor/push-notifications
```

En Xcode:
- Activar "Push Notifications" capability
- Generar APNs Authentication Key en developer.apple.com → Keys
- Subir el .p8 al backend para enviar pushes via APNs

Y modificar el `push.ts` del backend para usar `node-apn` (`apn` package) en paralelo a `web-push`. Esto es trabajo adicional.

**Recomendación para MVP iOS**: NO incluir push notifications en la primera versión iOS. Mantener web-push solo para Android + web. Añadir APNs en v2.

### 7. Build & Deploy

```bash
npx cap copy ios
npx cap sync ios
npx cap run ios  # corre en simulador
```

Para distribución App Store:
- Xcode → Product → Archive
- Distribute App → App Store Connect
- Subir el archivo .xcarchive

---

## Lo que hay que tener listo antes de subir a App Store

1. **Apple Developer account**: $99/año
2. **Privacy Policy URL** pública (App Store la requiere)
3. **Privacy info plist entries** si usas:
   - Camera (`NSCameraUsageDescription`)
   - Photo Library (`NSPhotoLibraryUsageDescription`)
   - Microphone (`NSMicrophoneUsageDescription`)

Como **Shopy Crafter no usa APIs nativas** (solo es WebView con `server.url`), probablemente no necesitas ninguna de estas. Verificar antes de submission.

4. **App Store screenshots** en distintas resoluciones (iPhone 6.7", 6.5", 5.5", iPad Pro 12.9", iPad 11")
5. **App Description, keywords, category**
6. **Age rating**: probablemente 4+ (no hay contenido explícito)
7. **App Tracking Transparency** si usas analytics: declarar tracking en plist

---

## Riesgos conocidos para review de App Store

1. **WebView wrappers** (lo que es Shopy Crafter ahora) tienen riesgo de rechazo por la regla 4.2 ("Minimum Functionality"). Apple requiere que la app **no sea solo un wrapper de la web**. Sugerencias para mitigar:
   - Añadir features nativas de valor: notificaciones push, offline mode con cache, deep linking
   - Asegurar que la primera experiencia (sin login) muestra contenido útil, no solo el form de login
   - Personalizar el design para verse "nativo" (animaciones, bottom tabs nativos, etc.)

2. **Login web sin Sign in with Apple** = rechazo automático. Si tienes login con Google/Facebook/Email, **DEBES añadir** [Sign in with Apple](https://developer.apple.com/sign-in-with-apple/). Es regla 4.8 de App Store.

3. **In-app purchases**: si vendes algo dentro de la app, debes usar StoreKit (no Stripe ni nada externo). Apple cobra 30%. **Workaround**: vender solo en la web, y en la app mostrar contenido pero NO permitir comprar nada nuevo. Mostrar mensaje: "Para suscribirte, visita shopycrafter.com" — esto es legal según el reciente cambio post-Epic vs Apple.

---

## Resumen ejecutivo

| Tarea | Tiempo estimado | Bloqueante para release |
|---|---|---|
| Instalar `@capacitor/ios` + `npx cap add ios` | 30min | Sí |
| Configurar Bundle ID + signing en Xcode | 1h | Sí |
| Safe-area CSS + viewport-fit=cover | 2h | Sí (UX terrible sin esto) |
| App icons + Launch Screen | 4h (diseño + integración) | Sí |
| Apple Developer account ($99/año) | 1 día waiting period | Sí |
| Sign in with Apple | 1 día (backend + frontend) | Sí (sin esto, rechazo automático) |
| Privacy policy URL | 2h | Sí |
| App Store screenshots | 4h | Sí |
| App Store metadata + submit | 4h | Sí |
| **TOTAL para tener iOS en App Store** | **~5-7 días** + 1-3 días review | |
| Push notifications iOS (APNs) | +3 días | NO (puede ser v2) |

**Si solo quieres iOS para uso interno (TestFlight)**, puedes saltarte App Store metadata y "Sign in with Apple", lo cual reduce a ~3 días.
