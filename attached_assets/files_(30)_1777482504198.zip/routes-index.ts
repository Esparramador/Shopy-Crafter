import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import projectsRouter from "./projects.js";
import productsRouter from "./products.js";
import redesignRouter from "./redesign.js";
import imagesRouter from "./images.js";
import pricingRouter from "./pricing.js";
import seoRouter from "./seo.js";
import abTestingRouter from "./ab-testing.js";
import jobsRouter from "./jobs.js";
import consistencyRouter from "./consistency.js";
import authRouter from "./auth.js";
import adminRouter from "./admin.js";
import clientRouter from "./client.js";
import cmsRouter from "./cms.js";
import intelligenceRouter from "./intelligence.js";
import inventoryRouter from "./inventory.js";
import onboardingRouter from "./onboarding.js";
import competitorsRouter from "./competitors.js";
import emailsRouter from "./emails.js";
import emailTemplatesRouter from "./email-templates.js";
import storeRouter from "./store.js";
import voiceRouter from "./voice.js";
import pushRouter from "./push.js";
import shopybrainRouter from "./shopybrain.js";
import agencyRouter from "./agency.js";
import klaviyoAiRouter from "./klaviyo-ai.js";
import vaultRouter from "./vault.js";
import referenceRouter from "./reference.js";
import geminiResearchRouter from "./gemini-research.js";
import absorberRouter from "./absorber.js";
import entityResearchRouter from "./entity-research.js";
import contactRouter from "./contact.js";
import apkRouter from "./apk.js";
import plansRouter from "./plans.js";
import exportsRouter from "./exports.js";
import scripttagRouter from "./scripttag.js";
import automationsRouter from "./automations.js";
import brainSyncRouter from "./brain-sync.js";
import referenceImagesRouter from "./reference-images.js";
import actionButtonsRouter from "./action-buttons.js";
import auditRouter from "./audit.js";
import enrichmentRouter from "./enrichment.js";
import generatorRouter from "./generator.js";
import webLabRouter from "./web-lab.js";
import fusionStudioRouter from "./fusion-studio.js";
import adStudioRouter from "./ad-studio.js";
import fsProRouter from "./fs-pro.js";
import reportTemplatesRouter from "./report-templates.js";
import billingRouter from "./billing.js";
import { requireAuth, requireAdmin, requireProjectAccess } from "../lib/auth.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/admin", adminRouter);
router.use("/client", clientRouter);
router.use("/cms", (req, res, next) => {
  if (req.method === "GET" && req.path === "/content") return next();
  return requireAdmin(req, res, next);
}, cmsRouter);
router.use(storeRouter);
router.use(contactRouter);
router.use(apkRouter);

router.get("/report-templates/:token", (req, res, next) => {
  if (/^[a-f0-9]{64}$/.test(req.params.token)) return next();
  return requireAdmin(req, res, next);
}, async (req, res) => {
  const { db } = await import("@workspace/db");
  const schemaModule = await import("@workspace/db/schema");
  const reportTemplatesTable = (schemaModule as Record<string, unknown>).reportTemplatesTable as typeof import("@workspace/db/schema").reportTemplatesTable;
  if (!reportTemplatesTable) { res.status(500).json({ error: "Schema not available" }); return; }
  const { eq } = await import("drizzle-orm");
  const [tpl] = await db.select().from(reportTemplatesTable).where(eq(reportTemplatesTable.shareToken, req.params.token));
  if (!tpl || !tpl.isPublic) { res.status(404).json({ error: "Plantilla no encontrada" }); return; }
  res.json(tpl);
});

router.use(requireAdmin);
router.use(projectsRouter);
router.use(productsRouter);
router.use(redesignRouter);
router.use(imagesRouter);
router.use(pricingRouter);
router.use(seoRouter);
router.use(abTestingRouter);
router.use(jobsRouter);
router.use(consistencyRouter);
router.use(intelligenceRouter);
router.use(inventoryRouter);
router.use(onboardingRouter);
router.use(competitorsRouter);
router.use(emailsRouter);
router.use(emailTemplatesRouter);
router.use(voiceRouter);
router.use(pushRouter);
router.use(shopybrainRouter);
router.use(agencyRouter);
router.use(klaviyoAiRouter);
router.use(vaultRouter);
router.use(referenceRouter);
router.use("/gemini", geminiResearchRouter);
router.use(absorberRouter);
router.use(entityResearchRouter);
router.use(plansRouter);
// ─── exports router: protect project-scoped endpoints ─────────────────────
// /api/projects/:projectId/exports/* → requires login + project ownership
// /api/exports/brand-css/:projectId, brand-kit, etc. → intentionally public
// (loaded by Shopify storefronts), so they remain unprotected.
router.use("/projects/:projectId/exports", requireAuth, requireProjectAccess);
router.use(exportsRouter);
router.use(scripttagRouter);
router.use(automationsRouter);
router.use(brainSyncRouter);
router.use(referenceImagesRouter);
router.use(actionButtonsRouter);
router.use(auditRouter);
router.use("/enrichment", enrichmentRouter);
router.use(generatorRouter);
router.use(webLabRouter);
router.use(fusionStudioRouter);
router.use(adStudioRouter);
router.use(fsProRouter);
router.use(reportTemplatesRouter);
router.use(billingRouter);

export default router;
