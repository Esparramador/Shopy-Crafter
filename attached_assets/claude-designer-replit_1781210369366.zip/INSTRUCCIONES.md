# Claude Designer + Design Lab — Guía de implantación en Replit

## Qué contiene este paquete

| Archivo / Carpeta | Descripción |
|---|---|
| `backend/_claude_designer.py` | Motor completo: 3 modelos AI, streaming, sesiones, 30+ templates |
| `backend/_visme_effects_engine.py` | 30 snippets CSS/JS + 594 Visme + generación con Claude |
| `admin/web-lab.html` | Design Command Center: iframe designer + skills sidebar + effects |
| `admin/effects-studio.html` | Effects Studio: explorar/componer/generar efectos |
| `backend/data/prompt_vault/templates/visme_templates.json` | 594 templates Visme (809 KB) |
| `backend/data/prompt_vault/templates/effects_prompts.json` | 24 templates FX para Claude |
| `admin/demos/` | 26 páginas de referencia generadas por el Designer |
| `main_patch.txt` | Bloques exactos para pegar en `main.py` |

---

## Paso 1 — Copiar archivos en Replit

En el árbol de archivos de tu Replit, copia cada archivo en su ruta exacta:

```
crafter_agency_ai/
├── backend/
│   ├── _claude_designer.py          ← reemplazar
│   ├── _visme_effects_engine.py     ← nuevo
│   └── data/
│       └── prompt_vault/
│           └── templates/
│               ├── visme_templates.json    ← nuevo
│               └── effects_prompts.json   ← nuevo (si no existe)
└── admin/
    ├── web-lab.html                 ← reemplazar
    ├── effects-studio.html          ← nuevo
    └── demos/
        ├── 01-particle-saas.html
        ├── 02-cinematic-agency.html
        ... (26 archivos)
```

---

## Paso 2 — Parchear main.py

Abre `backend/main.py` y añade los dos bloques de `main_patch.txt`:

**Bloque A — Visme Effects Engine** (pega ANTES del bloque Claude Designer):
```python
# ═══ VISME EFFECTS ENGINE ═══
try:
    from _visme_effects_engine import register_visme_engine
    _ve_result = register_visme_engine(app)
    _module_status["loaded"].append("visme_effects_engine")
    print(f"[CRAFTER] [OK] Visme Effects Engine → {_ve_result.get('builtin_snippets',0)} snippets + {_ve_result.get('visme_templates',0)} Visme")
except Exception as _e:
    _module_status["failed"].append("visme_effects_engine")
    _module_status["errors"]["visme_effects_engine"] = str(_e)
    print(f"[CRAFTER] [FAIL] visme_effects_engine - {_e}")
```

**Bloque B — Ruta web-lab** (ya existe si tienes `/web-lab` registrado; si no, añade):
```python
@app.get("/web-lab")
async def serve_web_lab():
    from fastapi.responses import FileResponse
    import os
    p = os.path.join(os.path.dirname(__file__), "..", "admin", "web-lab.html")
    return FileResponse(os.path.abspath(p))
```

---

## Paso 3 — Variables de entorno en Replit

En **Secrets** de tu Replit (`🔒 Secrets` en el panel izquierdo), asegúrate de tener:

```
ANTHROPIC_API_KEY=sk-ant-...       ← para Claude Designer + generación de efectos
GEMINI_API_KEY=AIza...             ← para Gemini Flash/Pro en el Designer
OPENAI_API_KEY=sk-...              ← para GPT-4.1 en el Designer (opcional)
```

**No hardcodees NUNCA estas claves en código Python.**

---

## Paso 4 — Verificar rutas activas

Después de (re)iniciar el servidor, estas rutas deben responder:

| URL | Qué sirve |
|---|---|
| `/web-lab` | Design Command Center (iframe + skills sidebar) |
| `/api/designer/studio` | Claude Designer 3-panel (chat \| preview \| code) |
| `/effects-studio` | Effects Studio (explorar + componer) |
| `/api/visme/stats` | JSON con conteos del motor Visme |
| `/api/designer/status` | JSON con estado del motor Designer |

Prueba en el navegador Replit:
```
https://tu-repl.replit.app/web-lab
https://tu-repl.replit.app/api/visme/stats
```

---

## Paso 5 — Solución al problema de redirección

Si `/api/designer/studio` redirige a claude.ai en lugar de servir el panel local:

1. Verifica que `_claude_designer.py` esté en `backend/` y no haya error de importación
2. Revisa los logs del servidor — busca `[CRAFTER] [FAIL] claude_designer`
3. Si hay error, cópialo aquí para resolverlo
4. La línea clave en `main.py` debe ser:
   ```python
   from _claude_designer import register_claude_designer
   register_claude_designer(app)
   ```
5. El endpoint que sirve el HTML es `GET /api/designer/studio` — **no** hace redirect externo

---

## Cómo funciona el Design Lab (web-lab.html)

```
┌─────────────────────────────────────────────────────────────┐
│  TOPBAR: Designer AI │ Effects Studio │ Demos Gallery        │
├──────────────────┬──────────────────────────────────────────┤
│  SIDEBAR         │  MAIN (iframe)                           │
│  ─ Skills (12)   │                                          │
│  ─ Efectos (30)  │  Tab 1: /api/designer/studio             │
│  ─ Visme (20)    │  Tab 2: /effects-studio                  │
│  ─ Prompts (12)  │  Tab 3: Demo Gallery grid (26)           │
│  ─ Demos (26)    │                                          │
└──────────────────┴──────────────────────────────────────────┘
```

- **Skill chip** → abre panel inject con prompt pre-rellenado → lo envía al Designer via postMessage (o clipboard)
- **Effect chip** → cambia a Effects Studio tab y selecciona categoría
- **Demo btn** → genera prompt para recrear el demo en el Designer
- **Inject button** → abre textarea libre para prompt custom

---

## Flujo de generación de efectos

```
Usuario describe efecto
        ↓
POST /api/visme/generate
        ↓
Claude (claude-sonnet-4-6) con sistema prompt:
  - 30 snippets pre-built listados
  - 65 categorías Visme
  - Reglas de implementación CSS/JS
        ↓
HTML ejecutable con DNA variables aplicadas
        ↓
Preview en iframe (srcdoc sandbox)
```

---

## DNA Variables disponibles

El motor sustituye estas variables en todo HTML generado:

| Variable | Default | Descripción |
|---|---|---|
| `__PRIMARY__` | `#6366f1` | Color primario de marca |
| `__SECONDARY__` | `#ec4899` | Color secundario / accent |
| `__BG__` | `#0d0d1a` | Fondo principal |
| `__SURFACE__` | `#1a1a2e` | Superficies / cards |
| `__TEXT__` | `#f1f5f9` | Texto principal |
| `__FONT__` | `Inter` | Familia tipográfica |
| `__NAME__` | `Brand` | Nombre de la marca |
| `__HEADLINE__` | `Construye algo extraordinario` | Titular principal |
| `__CTA__` | `Empezar ahora` | Texto del botón CTA |

---

## Soporte

Si algo no funciona, revisa los logs del servidor Replit:
- `[OK]` = módulo cargado correctamente
- `[FAIL]` = módulo falló — el error aparece en la misma línea
- El sistema falla graciosamente — el resto de la plataforma sigue funcionando aunque un módulo falle
