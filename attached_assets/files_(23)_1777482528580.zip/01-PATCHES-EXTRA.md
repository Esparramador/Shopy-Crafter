# Parches extra — findings nuevos de la pasada final

Complementa `01-PATCHES.md`. Aquí están los fixes para los findings **C5, A13, A14, M9, M10** descubiertos al auditar el backend `lib/` y las páginas cliente/proyectos pendientes.

---

## § C5 — `ENCRYPTION_KEY` en producción: fallar duro

**File:** `artifacts/api-server/src/lib/crypto.ts`

**Reemplazar la función `validateEncryptionKey`:**

```ts
export function validateEncryptionKey(): void {
  const keyHex = process.env.ENCRYPTION_KEY;
  if (!keyHex) {
    // SECURITY FIX C5: En producción, fallar duro en vez de generar una key
    // temporal que se perdería al reiniciar → silent corruption de tokens
    // Shopify y todo lo cifrado en la BD.
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "ENCRYPTION_KEY is required in production. Generate a persistent key with:\n" +
        "  node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\"\n" +
        "then set it as an environment variable.",
      );
    }
    const generated = randomBytes(32).toString("hex");
    process.env.ENCRYPTION_KEY = generated;
    tempKeyGenerated = true;
    console.warn("⚠️ ENCRYPTION_KEY not set — using temporary key (dev only, data lost on restart)");
  } else if (keyHex.length !== 64 || !/^[0-9a-fA-F]+$/.test(keyHex)) {
    throw new Error("ENCRYPTION_KEY must be a 64-character hex string (32 bytes)");
  }
}
```

Fichero completo: `files-to-replace/crypto.ts`.

**Además, en el startup** (wherever `validateEncryptionKey()` is called, probably `index.ts` or `app.ts` entry):

Asegúrate de que está **al principio** del arranque, antes de `app.listen()`. Si ya está así, perfecto.

---

## § A13 — Borrar `requireClientAccess` (dead code)

**File:** `artifacts/api-server/src/lib/auth.ts`

**Eliminar** la función `requireClientAccess` (líneas 19-39). Fichero resultante:

```ts
import type { Request, Response, NextFunction } from "express";

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  if (!req.session.userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

export function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  if (!req.session.userId || req.session.role !== "admin") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  next();
}

declare module "express-session" {
  interface SessionData {
    userId: string;
    role: "admin" | "client";
    clientId: string | null;
    name: string;
    email: string;
    impersonating?: string;
  }
}
```

Fichero completo: `files-to-replace/auth.ts`.

**Por qué se puede borrar sin riesgo:** ningún archivo del backend importa `requireClientAccess`. `grep -r "requireClientAccess" api-server/` → 0 resultados en `routes/`.

---

## § A14 — Adoptar wrapper centralizado `fetchApi`

El fichero `files-to-create/lib-api.ts` ya está listo. Pasos:

```bash
# 1. Copiar
cp shopycrafter-audit/files-to-create/lib-api.ts \
   artifacts/shopify-optimizer/src/lib/api.ts

# 2. Typecheck
pnpm -F @workspace/shopify-optimizer typecheck
```

**Plan de migración por prioridad** (1 página / día):

### Semana 1 — páginas admin con mutaciones
1. `pages/admin/Revenue.tsx` (ya fixed, incorporar wrapper)
2. `pages/admin/Emails.tsx` (8 fetches)
3. `pages/admin/AdminClients.tsx` (9 fetches)
4. `pages/admin/MyPricing.tsx` (11 fetches)
5. `pages/admin/Competitors.tsx`, `AdminAutomations.tsx`, `AdminSettings.tsx`

### Semana 2 — páginas client (menos riesgo)
6. `pages/client/ClientDashboard.tsx`
7. `pages/client/ClientMessages.tsx`
8. `pages/client/ClientProducts.tsx`
9. `pages/client/ClientReports.tsx` (verificar iOS download — M10)
10. `pages/client/ClientApprovals.tsx` (ya parchado en M2, integrar wrapper)

### Semana 3 — componentes y hooks
11. `components/OmniChatbot.tsx` (~20 fetches — importante, muchas callbacks)
12. `components/VoiceButton.tsx`, `ReferenceMediaPanel.tsx`, `BrainExtractor.tsx`
13. `hooks/useSaveReport.ts`, `hooks/use-draft-persistence.ts` (el `useRetryFetch` se puede deprecar)

### Semana 4 — deprecar lo redundante
14. Eliminar `const api = ...` en `UniversalGenerator.tsx:50`
15. Marcar `useRetryFetch` como `@deprecated` en `use-draft-persistence.ts:132`

---

## § M9 — Validar `data.redirect` del backend en UniversalGenerator

**File:** `src/pages/projects/UniversalGenerator.tsx`

**Antes (líneas 145-155, aprox):**

```tsx
if (data.redirect) {
  const redirectUrl = data.redirect.startsWith("/api")
    ? api(data.redirect.replace("/api", ""))
    : api(data.redirect);
  window.open(redirectUrl, "_blank");
}
```

**Después:**

```tsx
if (data.redirect) {
  // Seguridad: solo permitir redirects dentro de /generator/* o /vault/*
  const raw = String(data.redirect);
  const safe = /^\/(api\/)?(generator|vault)\/[a-zA-Z0-9/_.\-]+$/.test(raw);
  if (!safe) {
    console.warn("[UniversalGenerator] rejected unsafe redirect:", raw);
    return;
  }
  const redirectUrl = raw.startsWith("/api")
    ? api(raw.replace("/api", ""))
    : api(raw);
  window.open(redirectUrl, "_blank");
}
```

---

## § M10 — `ClientReports.tsx` — patrón de download compatible iOS Safari

**File:** `src/pages/client/ClientReports.tsx:53`

**Antes:**

```tsx
const exportReport = async (format: string) => {
  const res = await fetch(`${API_BASE}/api/client/reports/export?format=${format}`, {
    credentials: "include",
  });
  // ...posiblemente: window.open(URL.createObjectURL(await res.blob()))
};
```

**Después** (patrón compatible iOS):

```tsx
const exportReport = async (format: string) => {
  try {
    const res = await fetch(`${API_BASE}/api/client/reports/export?format=${format}`, {
      credentials: "include",
    });
    if (!res.ok) throw new Error(`Error ${res.status}`);
    const blob = await res.blob();

    // Extract filename from Content-Disposition (server-controlled)
    const disposition = res.headers.get("Content-Disposition");
    const filenameMatch = disposition?.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
    const filename = filenameMatch?.[1] ?? `report.${format}`;

    // Anchor + programmatic click — funciona en Safari iOS, Chrome Android, etc.
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (e: any) {
    toast({ title: e?.message || "Error al exportar", variant: "destructive" });
  }
};
```

(Añadir `import { useToast } from "@/hooks/use-toast"` y `const { toast } = useToast();` si no están).

---

## Resumen de patches totales

| Finding | Tipo | Archivo entregable |
|---|---|---|
| **C1** Revenue PATCH→PUT | Reemplazar | `files-to-replace/Revenue.tsx` |
| **C2** apkRouter detrás de requireAdmin | Reemplazar | `files-to-replace/routes-index.ts` |
| **C3** reveal-token scoping | Manual | Ver `01-PATCHES.md § C3` |
| **C4** montar /admin/billing | Manual | Ver `01-PATCHES.md § C4` |
| **C5** ENCRYPTION_KEY hard-fail | Reemplazar | `files-to-replace/crypto.ts` |
| **A1** wrapper fetchApi | Crear | `files-to-create/lib-api.ts` |
| **A2** 3 credentials faltantes | Manual | Ver `01-PATCHES.md § A2` |
| **A3** formatters OmniChatbot | Manual | Ver `01-PATCHES.md § A3` + `02-OMNI-ACTIONS-DIFF.md` |
| **A4** guard re-check | Manual | Ver `01-PATCHES.md § A4` |
| **A5** AndroidManifest | Reemplazar | `files-to-replace/AndroidManifest.xml` + `files-to-create/data_extraction_rules.xml` |
| **A6** postMessage no-`*` | Manual | Ver `01-PATCHES.md § A6` |
| **A7** DOMPurify | Manual | Ver `01-PATCHES.md § A7` |
| **A8** invalidations react-query | Manual | Ver `01-PATCHES.md § A8` |
| **A9** useRetryFetch (consolidar) | Recomendación | Se resuelve al adoptar A1 |
| **A10** execute-action directo | Recomendación | Tipado compartido del dispatcher (enum) |
| **A11** webhook Shopify orders/paid | Manual | Backend change, ver `04-APPENDIX § A11` |
| **A12** mensajería tiempo real | Decisión | Polling/SSE/WS |
| **A13** borrar requireClientAccess | Reemplazar | `files-to-replace/auth.ts` |
| **A14** adoptar wrapper | Manual iterativo | Ver § A14 arriba |
| **M2** ClientApprovals feedback | Manual | Ver `01-PATCHES.md § M2` |
| **M3** CoachMarks versión | Manual | Ver `01-PATCHES.md § M3` |
| **M4** ErrorBoundary → backend | Manual | Ver `01-PATCHES.md § M4` |
| **M5** initGlobalErrorHandlers | Manual (menor) | Mover a useEffect en App |
| **M6** NewProject test obligatorio | Manual | Ver `04-APPENDIX § M6` |
| **M7** MyPricing trust | No-op | Marcar deuda si se abre multi-agencia |
| **M8** CMS iframe verify origin | Manual | Ver `04-APPENDIX § M8` |
| **M9** UniversalGenerator redirect | Manual | Ver § M9 arriba |
| **M10** iOS download pattern | Manual | Ver § M10 arriba |
