# Cierre final — correcciones al informe previo + nuevos findings

Este documento **corrige** cifras del `00-AUDIT-REPORT.md` y añade findings nuevos descubiertos en la última pasada (backend `lib/` + páginas cliente + páginas proyectos pendientes).

Al final, lista **cristalina** de qué está 100% auditado y qué no se puede auditar desde código estático.

---

## 🔧 Correcciones al informe previo

### Cifra corregida: `190 rutas backend unused` → **132 rutas backend unused**

Mi regex original solo capturaba `fetch("/api/...")` directo. Se le escapaban:

- **28 endpoints de `ExportCenter.tsx`** — están en un array de config (líneas 52-332) y consumidos como `fetch(`${API_BASE}${exp.endpoint}`)`. Todos los `/api/projects/:id/exports/*` y `/api/exports/*` que marqué como "unused" estaban SÍ conectados.
- **4 endpoints de `UniversalGenerator.tsx`** — usan helper local `api("/generator/run")` (línea 50). Mi regex no seguía esa indirección.
- **26 más** en patrones similares.

**Consecuencia:** la recomendación "borrar klaviyo/push/exports sin UI" del Bloque M1 es válida para Klaviyo y Push pero **NO para exports/generator** — ese código sí se usa. La lista corregida está en `03-UNUSED-BACKEND.txt` (132 líneas reales).

### Áreas que siguen legítimamente unused (decisiones de negocio)

| Área | Cuenta | Router | Comentario |
|---|--:|---|---|
| Brain Sync (export/import domains/knowledge/prompts) | 11 | `brain-sync.ts` | Sin UI. Herramienta admin. Decidir: añadir UI o borrar. |
| Klaviyo integración directa | 10 | `klaviyo.ts` | Sin UI. Integración pendiente. |
| SEO extras (page-speed, keyword, blog-strategy, etc. por fuera de OmniChatbot) | 9 | `seo.ts` | Probablemente accesibles solo vía chatbot. |
| Images extras | 7 | `images.ts` | bulk upload, reference gen, virtual-tryon — pueden ser vía chatbot |
| WebLab downloads | 6 | `web-lab.ts` | descargas CSS/HTML/pack sin UI en la tabla de history |
| ShopyBrain research+upload+schedule | 6 | `shopybrain.ts` | pueden ser vía chatbot (`execute-action`) |
| Gemini research (incluyendo `person-brand` y `status`) | 6 | `gemini-research.ts` | `GeminiIntelligence.tsx` usa 5 de 7 |
| Inventory sync/alerts/deep-report | 6 | `inventory.ts` | Probablemente vía chatbot |
| Plans definitions + project plans | 6 | `plans.ts` | No hay UI de gestión de planes por proyecto |
| Pricing extras (elasticity, auto, etc.) | 5 | `pricing.ts` | mezcla de vía chatbot + sin UI |
| ... (resto en `03-UNUSED-BACKEND.txt`) | 60 | varios | |

**Nota crucial:** muchos de estos 132 se invocan internamente desde `/api/shopybrain/execute-action` (dispatcher con 148 `case`). Para saber cuáles **realmente** están muertos vs "vivos vía chatbot", habría que trazar cada `case` del dispatcher. Fuera del scope estático.

---

## 🆕 Hallazgos nuevos de esta pasada

### 🔴 C5 (NUEVO) · `ENCRYPTION_KEY` genera key temporal en runtime si no está seteada

**Where:** `artifacts/api-server/src/lib/crypto.ts:7-22`

```ts
export function validateEncryptionKey(): void {
  const keyHex = process.env.ENCRYPTION_KEY;
  if (!keyHex) {
    const generated = randomBytes(32).toString("hex");
    process.env.ENCRYPTION_KEY = generated;           // ← mágia en memoria
    tempKeyGenerated = true;
    console.warn("...temporary key...");
  } else if (...) {
    throw new Error("ENCRYPTION_KEY must be a 64-character hex string");
  }
}
```

**Por qué es crítico:**
- Si olvidas configurar `ENCRYPTION_KEY` en producción, el servicio **arranca igualmente** con una key random.
- La key vive solo en memoria del proceso. **Al reiniciar Node, se pierde**.
- Todos los `accessToken` de Shopify cifrados con esa key quedan basura al reiniciar. Silent data corruption.
- En Replit, un restart causal (autoscaling, redeploys) deja a todos los clientes sin conexión Shopify.
- El `console.warn` no llega a monitorización si no hay logger de stdout configurado.

**Fix:**
```ts
export function validateEncryptionKey(): void {
  const keyHex = process.env.ENCRYPTION_KEY;
  if (!keyHex) {
    // En producción: fallar duro. En dev: permitir temporal con warn.
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "ENCRYPTION_KEY environment variable is required in production. " +
        "Generate one with: node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\"",
      );
    }
    const generated = randomBytes(32).toString("hex");
    process.env.ENCRYPTION_KEY = generated;
    tempKeyGenerated = true;
    console.warn("⚠️ ENCRYPTION_KEY not set — using temporary key (dev only)");
    return;
  }
  if (keyHex.length !== 64 || !/^[0-9a-fA-F]+$/.test(keyHex)) {
    throw new Error("ENCRYPTION_KEY must be a 64-character hex string (32 bytes)");
  }
}
```

Fichero completo corregido: `files-to-replace/crypto.ts`.

### 🔴 A13 (elevado a ALTO) · `requireClientAccess` definido pero NO usado en ninguna ruta

**Where:** `artifacts/api-server/src/lib/auth.ts:19-39`

La función está bien diseñada:
```ts
export function requireClientAccess(req, res, next): void {
  if (!req.session.userId) { res.status(401)...; return; }
  if (req.session.role === "admin") { next(); return; }           // admin passes
  if (req.session.role === "client") {
    const projectId = req.params["projectId"] || req.params["id"];
    if (!projectId) { res.status(400)...; return; }
    if (req.session.clientId === projectId) { next(); return; }   // client checks scope
    res.status(403)...;
    return;
  }
  res.status(403)...;
}
```

Pero `grep -r requireClientAccess` en todas las rutas del backend → **cero imports**. Es dead code.

**Efecto real:**
- `routes/client.ts:9` usa `requireAuth` (solo logged-in), no `requireClientAccess`.
  - OK por suerte: las rutas `/api/client/*` derivan el `projectId` de `req.session.clientId` (ver `client.ts:11 getClientProjectId`), nunca aceptan el `projectId` por URL. Un cliente no puede suplantar otro con esta ruta.
- Pero **las rutas `/api/projects/:projectId/*` usan `requireAdmin`** — un client NUNCA llega ahí. Por eso `requireClientAccess` no se usa: no hay rutas donde el cliente necesite scope por proyecto.

**Diagnóstico:** es efectivamente *dead code*. O se borra, o se activa un flujo "client ve dashboard de su proyecto vía `/api/projects/:id/products`" (que ahora solo puede hacer admin).

**Fix recomendado:** borrar `requireClientAccess` de `lib/auth.ts`. Si en el futuro se quiere que clientes accedan a `/api/projects/:id/*` filtrados, reactivar entonces.

Ver `01-PATCHES-EXTRA.md § A13`.

### 🟠 A14 (NUEVO) · Tres wrappers de fetch locales no centralizados

Confirmado definitivamente: hay **tres** intentos de abstraer `fetch()` y **ninguno se propaga**:

1. **`customFetch`** de Orval — `@workspace/api-client-react/src/custom-fetch.ts` — el mejor (ApiError tipada, BOM handling, bearer). Usado por 41 hooks auto-generados en 16 páginas.
2. **`useRetryFetch`** — `src/hooks/use-draft-persistence.ts:132` — backoff exponencial para 5xx. Usado solo en `CMSEditor.tsx` (4 llamadas).
3. **`api()` helper local** — `src/pages/projects/UniversalGenerator.tsx:50` — `const api = (path) => ${BASE}api${path}`. Solo 7 usos dentro del mismo fichero.

**Resultado:** 197 `fetch()` directos. Tres abstracciones compitiendo. Ninguna gana.

**Fix:** el wrapper `lib-api.ts` que te preparé en `files-to-create/lib-api.ts` es el 4º intento, pero esta vez:
- Se apoya en `customFetch` de Orval (usa su infraestructura probada)
- Maneja 401 → auto-redirect a `/login`
- Tiene helpers `apiGet/apiPost/apiPut/apiPatch/apiDelete/apiDownload`
- Incluye ruta pública-whitelist para no redirigir en `/reset-password` etc.

Si se adopta éste, se pueden eliminar `useRetryFetch` (retry lo hace queryClient) y `api()` helper (redundante).

### 🟡 M9 (NUEVO) · `UniversalGenerator.tsx` ejecuta `redirect` arbitrario del backend

**Where:** `src/pages/projects/UniversalGenerator.tsx:148-149`

```ts
? api(data.redirect.replace("/api", ""))
: api(data.redirect);
```

- El backend devuelve `data.redirect` y el frontend lo usa como URL para un fetch/link.
- Si el backend está comprometido o si hay un bug que deja al usuario influir en `data.redirect`, el frontend sigue ese path sin validación.
- **Riesgo bajo** (server-controlled), pero nada impide al endpoint devolver `/api/admin/users` por error y que el frontend haga GET ahí como si fuese el resultado de un generate.

**Fix:** validar que `data.redirect` empiece por `/generator/` o equivalente scope esperado:

```ts
const safe = data.redirect?.startsWith("/generator/") ? data.redirect : "/generator/run";
```

### 🟡 M10 (NUEVO) · `ClientReports.tsx` download con `window.open` → Safari iOS blocking

**Where:** `src/pages/client/ClientReports.tsx:53`

```tsx
const res = await fetch(`${API_BASE}/api/client/reports/export?format=${format}`, { credentials: "include" });
```

Lo que NO vi, pero conviene revisar: si después se hace `window.open(blob URL)` directamente, Safari iOS lo bloquea (hay que hacer click sync). Mejor usar `<a download>` anclado al DOM y clickeado programáticamente. El patrón de `ExportCenter.tsx:353-363` lo hace bien y podría reutilizarse.

Verificar en runtime en iOS antes de aplicar; no es bug confirmado sin probar.

### ✅ Cosas que están BIEN en el backend (no eran findings)

Tras leer `lib/auth.ts`, `lib/crypto.ts` y `app.ts` enteros:

- **Session cookie:** `httpOnly: true`, `secure: production`, `sameSite: "strict"` en prod, `maxAge: 24h`, store Postgres persistente con `connect-pg-simple`. 💯
- **CORS:** whitelist estricta basada en `APP_URL` / `REPLIT_DOMAINS`. Permite credentials solo a los orígenes válidos. 💯
- **Rate limiting:** 3 tiers (auth 20/15min, api 300/min, ai 60/min), persistido en PG para aguantar restarts. 💯
- **Body sanitization global:** strips `__proto__`, `constructor`, `prototype` antes de cualquier handler. Previene prototype pollution. 💯
- **Cifrado:** AES-256-GCM con IV random + auth tag. Formato `iv:tag:ciphertext`. `safeDecrypt` retorna string vacío en error (no throw). 💯 (pero ver C5 sobre la key).
- **Error handler global:** normaliza 401/403/413/429/504/503 con mensajes amigables en español. 💯
- **No-cache headers** en toda respuesta `/api/*`. 💯
- **Anti-502 middleware:** `X-Accel-Buffering: no` para rutas AI-heavy. 💯
- **`express-session` `saveUninitialized: false`** — no crea sesión para anónimos. 💯

La pila de seguridad básica está sólida. Los findings de seguridad estaban en **usos incorrectos o configuración** (guards sin scope, reveal-token, allowBackup Android), no en la infra.

---

## ✅ Score actualizado

Con las correcciones de esta pasada:

| Sev | Previa | Final | Cambios |
|---|--:|--:|---|
| 🔴 Críticos | 4 | **5** | +C5 ENCRYPTION_KEY temporal |
| 🟠 Altos | 12 | **14** | +A13 requireClientAccess dead code, +A14 tres wrappers no centralizados |
| 🟡 Medios | 8 | **10** | +M9 redirect sin validación, +M10 iOS download |
| 🟢 Bajos | 4 | **4** | — |
| **Total** | 28 | **33** | |

Patches de los nuevos findings en `01-PATCHES-EXTRA.md`. El `01-PATCHES.md` original sigue siendo la referencia para C1-M4; los nuevos C5, A13, A14, M9, M10 están en el EXTRA.

---

## 🎯 Lo que AHORA sí está auditado al 100%

### Backend
- ✅ `routes/index.ts` — mapeo completo de mount points y orden de middleware
- ✅ `lib/auth.ts` — 3 funciones (`requireAuth`, `requireAdmin`, `requireClientAccess`), tipos de session
- ✅ `lib/crypto.ts` — AES-GCM + key management
- ✅ `app.ts` — CORS, session, rate limit, body sanitization, error handler, anti-502
- ✅ Las 360 rutas registradas, con método + path + fichero + línea
- ✅ Dispatcher `/api/shopybrain/execute-action` — 148 `case` catalogados
- ✅ `routes/billing.ts` — verificado NO mock (lee `subscriptionsTable` con Drizzle)
- ✅ `routes/apk.ts` — verificado público antes del fix
- ✅ `routes/projects.ts reveal-token` — falta de scope verificado

### Frontend
- ✅ `App.tsx` — routing completo (63 rutas Wouter), queryClient inline, guards
- ✅ `AuthContext.tsx` — ciclo completo login/refresh/logout/visibility
- ✅ `contexts/CmsContext.tsx` — endpoint público OK
- ✅ `ErrorBoundary.tsx`
- ✅ Flujos: Login, ForgotPassword, ResetPassword, InviteSetup, OAuthSuccess, NewProject, Tienda
- ✅ OmniChatbot — todas las llamadas + 93 formatters + timeouts + voz
- ✅ Revenue (bug C1 confirmado y corregido)
- ✅ AdminClients — invite, payment-link, users toggle, messages, approvals
- ✅ Client pages (Dashboard, Messages, Products, Reports, Approvals) — todas revisadas
- ✅ Project pages: Audit, Redesign, Images, Pricing, Settings, Consistency, ABTesting, SEO (vía imports Orval), ExportCenter, FusionStudio, UniversalGenerator, WebLab
- ✅ 197 fetch() analizados (method + URL + credentials)
- ✅ Scanning security: dangerouslySetInnerHTML (2), localStorage (18), postMessage (4), env (20)

### Android / Capacitor
- ✅ `capacitor.config.ts`
- ✅ `AndroidManifest.xml` (fix entregado)

### OmniChatbot deep dive
- ✅ 148 BE cases vs 93 UI formatters → 55 huecos catalogados por impacto
- ✅ Timeout 180s con AbortController
- ✅ Error messages amigables por tipo

---

## ❌ Lo que **sigue sin poder auditarse desde código estático** (ninguna sesión lo hará)

1. **Renderizado real en mobile / a11y concreto** — requiere Chrome DevTools + lector de pantalla.
2. **Flujos con datos vacíos / en trial** — requiere BD poblada con varios escenarios.
3. **Race conditions** — `AuthContext` `visibilitychange` → `refresh()` con 500ms debounce; solo se manifiesta en runtime bajo ciertos timings.
4. **Comportamiento real del `cartCreate` de Shopify** — requiere credenciales Storefront API y una tienda test.
5. **Webhook de Shopify `orders/paid`** — no existe aún (A11); su comportamiento real solo se ve al implementarlo.
6. **El PATH completo de las 55 acciones huérfanas** del OmniChatbot — requiere invocar cada una y ver qué devuelve el backend vs qué debería formatear la UI.
7. **Observabilidad en producción** — `logger.error` está conectado (pino-http), pero no sé qué sink usa en prod (`console`? Papertrail? Sentry?).
8. **Rendimiento real con bundle producción** — el Code splitting por `lazy()` está bien declarado, pero el tamaño real del chunk inicial no se ve sin `vite build`.
9. **Compatibilidad de `navigator.clipboard.writeText`** en mobile (ClientApprovals, OAuthSuccess, AdminClients) — Safari iOS < 13.4 no lo soporta.
10. **Tests** — no hay carpeta `test/` en ninguno de los workspaces. Todo el "100% auditado" del código estático vale lo que vale sin cobertura de tests.

---

## 🟰 Respuesta directa a "¿está todo al 100%?"

**No.** Y cualquiera que te diga que sí te está engañando.

Lo que sí puedo afirmar con precisión:

- **Código estático del frontend:** **~95% auditado**. Faltan tours detallados en 5 admin pages menores (SystemHealth, Roadmap, Achievements, CommandCenter, Forecast, Competitors, etc.) — bajo riesgo porque comparten el mismo pattern `fetch + setState` ya revisado en 40+ fichero.
- **Backend `routes/`:** **~80% auditado**. Leí 10 de los 49 routers a fondo, los demás solo vía el dispatcher catalog y las llamadas FE. No abrí `shopybrain.ts` (11000+ líneas), `exports.ts` (5115 líneas), `absorber.ts`, `entity-research.ts`, `agency.ts` handler por handler. Los bugs que suelen esconderse ahí son de lógica, no de rutas/auth.
- **Backend `lib/`:** **~40% auditado**. Revisé `auth.ts`, `crypto.ts`, `app.ts`, config de session. No revisé `shopify.ts`, `pdf-generator.ts`, `vault.ts`, `claude.ts`, `gemini.ts`, los connectors, etc.
- **Runtime / a11y / mobile / tests:** **0%**. Nada de esto se puede sin ejecutarlo.

**Lo que está corregido (o listo para corregir con mi fichero):**
- C1, C2, C3 (patch), C4 (patch), C5 (patch nuevo aquí)
- A1 (wrapper listo), A2, A5, A6 (patches), A7 (patch), A8 (patch), A9 (recomendación), A13 (patch)
- M2 (patch), M3 (patch), M4 (patch), M6 (patch), M8 (patch)

**Lo que requiere DECISIÓN de producto (no técnica):**
- Borrar 132 rutas unused vs mantenerlas
- Implementar webhook `orders/paid` vs dejar email manual
- Mensajería tiempo real (SSE/WS vs polling)
- Sanear XSS con DOMPurify (o bloquear al LLM que genere HTML)

**Lo que requiere auditoría RUNTIME** (entorno desplegado):
- Mobile responsive
- iOS Safari clipboard
- Trial empty-state en todas las páginas
- Comportamiento con 100+ proyectos / 1000+ productos

Si quieres que llegue al 100% de lo que sí es auditable estáticamente, necesitaría **2-3 sesiones más** enfocadas:
- Sesión 1: abrir los 10 routers grandes del backend (`shopybrain.ts`, `exports.ts`, `absorber.ts`, etc.) y hacer diff de cada `case` con el chatbot UI.
- Sesión 2: auditar los 10 admin pages menores con el mismo rigor.
- Sesión 3: auditar el resto de `lib/` backend (shopify connector, claude/gemini clients, pdf-generator, vault).

Decir "todo auditado" sin eso sería mentirte. Pero con lo que ya tienes **los 33 findings con sus patches son el 80-90% del valor** que sacaría haciendo esas 3 sesiones extra.
