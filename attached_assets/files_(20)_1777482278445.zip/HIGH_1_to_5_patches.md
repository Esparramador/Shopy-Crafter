═══════════════════════════════════════════════════════════════════════════════
BLOQUE A — PATCHES PARA LOS 5 HALLAZGOS ALTOS

Los 6 críticos ya están cubiertos en CRIT_1_to_6_patches.md. Estos 5 altos
son problemas serios pero no catastróficos.
═══════════════════════════════════════════════════════════════════════════════


═══════════════════════════════════════════════════════════════════════════════
HIGH-1 · JSON.parse(uiText.match()) sin try-catch robusto
Ubicación: línea 6658 aprox, dentro de modify_ui
═══════════════════════════════════════════════════════════════════════════════

ANTES:
            let uiJson: any = {};
            try { uiJson = JSON.parse(uiText.match(/\{[\s\S]*\}/)?.[0] || "{}"); } catch { uiJson = {}; }

DESPUÉS:
            // HIGH-1: parsing robusto de JSON con fallback + log
            let uiJson: { files?: Array<{ filePath: string; changes: Array<{ oldCode: string; newCode: string; description?: string }> }>; summary?: string } = {};
            try {
              // Intento 1: el texto directo es JSON
              uiJson = JSON.parse(uiText);
            } catch {
              // Intento 2: extraer primer bloque {...}
              const match = uiText.match(/\{[\s\S]*\}/);
              if (match) {
                try {
                  uiJson = JSON.parse(match[0]);
                } catch {
                  // Intento 3: quitar code fences ```json ... ```
                  const cleaned = uiText.replace(/```(?:json)?\s*/g, "").replace(/```/g, "").trim();
                  try {
                    uiJson = JSON.parse(cleaned);
                  } catch {
                    result = {
                      error: true,
                      message: `❌ Claude devolvió JSON inválido. Respuesta (primeros 300 chars): ${uiText.slice(0, 300)}`,
                    };
                    break;
                  }
                }
              } else {
                result = {
                  error: true,
                  message: `❌ Claude no devolvió JSON. Respuesta (primeros 300 chars): ${uiText.slice(0, 300)}`,
                };
                break;
              }
            }


═══════════════════════════════════════════════════════════════════════════════
HIGH-2 · Error handling con `any` en lugar de tipado
Ubicación: transversal — muchos `} catch (e) { result = { error: true, message: ... } }`

El patrón original es correcto funcionalmente, pero no tipado. TypeScript
no puede ayudar a detectar errores. Mejorar al modelo típico de la app.
═══════════════════════════════════════════════════════════════════════════════

ANTES (patrón repetido ~50 veces en el archivo):

          } catch (e) {
            result = { error: true, message: `Error analizando: ${e instanceof Error ? e.message : String(e)}` };
          }

DESPUÉS (añadir helper al inicio del archivo):

// Helper para formatear errores de forma consistente
function errorResult(action: string, err: unknown): { error: true; message: string; action: string } {
  const msg = err instanceof Error ? err.message : String(err);
  return {
    error: true,
    action,
    message: `❌ Error en ${action}: ${msg}`,
  };
}

Y en cada catch reemplazar:

          } catch (e) {
            result = errorResult("nombre_de_la_accion", e);
          }

Esto te da:
  - Tipado correcto de la respuesta
  - Mensajes de error homogéneos para el frontend (el formatter ya los entiende)
  - Logs más fáciles de grepear


═══════════════════════════════════════════════════════════════════════════════
HIGH-3 · Missing timeout en Shopify requests dentro de bulk operations
Ubicación: acciones `bulk_redesign`, `optimize_all_products`, `bulk_generate_images`

Problema: dentro de un loop `for (const product of products)` hay calls a
Shopify sin timeout individual. Si Shopify responde lento, el bulk se eterniza
y acumula promises.
═══════════════════════════════════════════════════════════════════════════════

PATRÓN GENERAL — buscar todos los loops que hacen shopifyRequest dentro:

  for (const p of products) {
    await shopifyRequest(...);
    await askClaude(...);
    // ... procesamiento ...
  }

Y reemplazar por:

  // HIGH-3: procesamiento en chunks con timeout individual + reporte de progreso
  const BATCH_SIZE = 5;
  const PER_ITEM_TIMEOUT_MS = 120_000;  // 2 min por producto

  const results: Array<{ id: string; ok: boolean; error?: string }> = [];

  for (let i = 0; i < products.length; i += BATCH_SIZE) {
    const batch = products.slice(i, i + BATCH_SIZE);

    const batchResults = await Promise.allSettled(
      batch.map(async (p) => {
        const timeoutPromise = new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`Timeout procesando producto ${p.id}`)), PER_ITEM_TIMEOUT_MS)
        );

        try {
          const work = (async () => {
            // ... código original del loop por producto ...
            return { id: p.id, ok: true };
          })();
          return await Promise.race([work, timeoutPromise]);
        } catch (err) {
          return { id: p.id, ok: false, error: err instanceof Error ? err.message : String(err) };
        }
      })
    );

    for (const r of batchResults) {
      if (r.status === "fulfilled") results.push(r.value);
      else results.push({ id: "unknown", ok: false, error: r.reason?.message ?? "batch failure" });
    }
  }

  const successful = results.filter(r => r.ok).length;
  const failed = results.filter(r => !r.ok).length;

  result = {
    message: `✅ Procesados ${successful}/${products.length}${failed > 0 ? ` (${failed} fallos)` : ""}`,
    processed: successful,
    failed,
    details: results,
  };


═══════════════════════════════════════════════════════════════════════════════
HIGH-4 · Detección de acciones con `:::ACTION:::{...}:::END_ACTION:::` frágil
Ubicación: handler de /search — parseo de las respuestas de Claude

El regex actual puede matchear mal si Claude devuelve JSON con `:::` dentro
de un string. Hacerlo más robusto con validación de estructura.
═══════════════════════════════════════════════════════════════════════════════

ANTES (aproximado, buscar la zona de parseo):

  const actionMatches = [...text.matchAll(/:::ACTION:::([\s\S]*?):::END_ACTION:::/g)];
  const detectedActions = actionMatches.map(m => {
    try {
      return JSON.parse(m[1]);
    } catch {
      return null;
    }
  }).filter(Boolean);

DESPUÉS:

  // HIGH-4: parseo robusto con validación de estructura
  function parseDetectedActions(text: string): Array<{ action: string; params: Record<string, unknown> }> {
    const actions: Array<{ action: string; params: Record<string, unknown> }> = [];

    // Usar regex no-greedy que acepta :::ACTION::: y :::END_ACTION:::
    const pattern = /:::ACTION:::\s*([\s\S]*?)\s*:::END_ACTION:::/g;
    const matches = [...text.matchAll(pattern)];

    for (const match of matches) {
      const raw = match[1].trim();
      if (!raw) continue;

      let parsed: unknown;
      try {
        parsed = JSON.parse(raw);
      } catch (err) {
        logger.warn({ raw: raw.slice(0, 200), err: err instanceof Error ? err.message : String(err) },
          "Failed to parse detected action JSON");
        continue;
      }

      // Validar estructura esperada
      if (typeof parsed !== "object" || parsed === null) continue;
      const obj = parsed as Record<string, unknown>;
      if (typeof obj.action !== "string" || !obj.action) continue;
      if (obj.params !== undefined && (typeof obj.params !== "object" || obj.params === null)) {
        logger.warn({ action: obj.action }, "Detected action has invalid params");
        continue;
      }

      actions.push({
        action: obj.action,
        params: (obj.params as Record<string, unknown>) ?? {},
      });
    }

    return actions;
  }

  // Usar:
  const detectedActions = parseDetectedActions(text);


═══════════════════════════════════════════════════════════════════════════════
HIGH-5 · resolveFilePath no valida que el resultado sigue en el workspace
Ubicación: helper `resolveFilePath()` al inicio del archivo

El helper resuelve paths pero no verifica que el path resuelto sigue siendo
subdirectorio de FRONTEND_ROOT o BACKEND_ROOT. Complementa CRIT-5 pero desde
otro ángulo.
═══════════════════════════════════════════════════════════════════════════════

ANTES (aproximado):

  function resolveFilePath(filePath: string): string | null {
    const candidates = [
      path.resolve(FRONTEND_SRC, filePath),
      path.resolve(FRONTEND_ROOT, filePath),
      path.resolve(BACKEND_SRC, filePath),
      path.resolve(BACKEND_ROOT, filePath),
    ];
    for (const p of candidates) {
      if (fs.existsSync(p)) return p;
    }
    return null;
  }

DESPUÉS:

  // HIGH-5: resolveFilePath con verificación defensiva de scope
  function resolveFilePath(filePath: string): string | null {
    if (!filePath || filePath.includes("..") || filePath.includes("\0")) return null;
    if (path.isAbsolute(filePath)) return null;

    const candidates = [
      { root: FRONTEND_SRC, prefix: "frontend/src" },
      { root: FRONTEND_ROOT, prefix: "frontend" },
      { root: BACKEND_SRC, prefix: "backend/src" },
      { root: BACKEND_ROOT, prefix: "backend" },
    ];

    for (const { root } of candidates) {
      const resolved = path.resolve(root, filePath);
      // Verificar que el path resuelto sigue siendo subdirectorio del root esperado
      if (!resolved.startsWith(root + path.sep) && resolved !== root) continue;
      try {
        if (fs.existsSync(resolved) && fs.statSync(resolved).isFile()) {
          return resolved;
        }
      } catch { /* skip */ }
    }
    return null;
  }


═══════════════════════════════════════════════════════════════════════════════
FIN DE LOS 5 FIXES ALTOS.

Verificación post-aplicación:
  1. modify_ui con Claude devolviendo JSON malformado → mensaje claro, no crash
  2. bulk_redesign con 50 productos → procesados en chunks de 5, reporte final
  3. /search con mensaje que contenga ':::' dentro de strings → no rompe parsing
  4. resolveFilePath("../etc/passwd") → null
═══════════════════════════════════════════════════════════════════════════════
