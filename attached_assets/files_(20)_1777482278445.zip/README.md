# Fixes Bloque A — shopybrain.ts (9.661 líneas, 148 acciones)

**Cierra los 25 hallazgos del Bloque A con código aplicable directo.**

Este paquete completa la auditoría al 100% — ya estaba cubierto por el dossier
`BLOQUE_A_shopybrain_audit.md` pero sin archivos listos para pegar. Ahora sí.

---

## Contenido del paquete

```
fixes-bloque-a/
├── README.md                              ← este archivo
├── lib/
│   └── shopybrain-helpers.ts              ← código NUEVO con los 3 helpers
├── patches/
│   ├── CRIT_1_to_6_patches.md             ← 6 hallazgos críticos (🔴)
│   ├── HIGH_1_to_5_patches.md             ← 5 hallazgos altos (🟡)
│   └── MED_1_to_14_patches.md             ← 14 hallazgos medios (⚠️)
└── REFACTOR_PLAN.md                       ← Split shopybrain.ts en 7 módulos (opcional)
```

---

## Mapa de los 25 hallazgos

| # | Severidad | Hallazgo | Ubicación | Fix |
|---|---|---|---|---|
| CRIT-1 | 🔴 | `fix_code` reescribe cualquier archivo del workspace | L4205 | ✅ |
| CRIT-2 | 🔴 | `modify_ui` con `parseInt(params?.projectId) \|\| 2` hardcoded | L6574 | ✅ |
| CRIT-3 | 🔴 | 3 sitios más con `\|\| 2` hardcoded | L4086, 4152, 6545 | ✅ |
| CRIT-4 | 🔴 | `fusion_analyze/create_product` DoS por imagen sin content-length | L5697, 5730 | ✅ |
| CRIT-5 | 🔴 | `list_source_files` path traversal en `directory` | L4024 | ✅ |
| CRIT-6 | 🔴 | Solo 1/148 acciones exige `params.confirmed` | Transversal | ✅ |
| HIGH-1 | 🟡 | `JSON.parse(uiText.match())` frágil | L6658 | ✅ |
| HIGH-2 | 🟡 | Error handling con `any` | Transversal | ✅ |
| HIGH-3 | 🟡 | Bulk operations sin timeout individual | L5200+ (varias) | ✅ |
| HIGH-4 | 🟡 | Parsing frágil de `:::ACTION:::...:::END_ACTION:::` | En /search | ✅ |
| HIGH-5 | 🟡 | `resolveFilePath` no valida scope | Helper | ✅ |
| MED-1 | ⚠️ | Logs sin contexto | Transversal | ✅ |
| MED-2 | ⚠️ | db.select(projects) duplicado en 30 acciones | Transversal | ✅ |
| MED-3 | ⚠️ | parseInt() sin radix | Transversal | ✅ |
| MED-4 | ⚠️ | Magic numbers en timeouts | Transversal | ✅ |
| MED-5 | ⚠️ | switch default sin sugerencias | Final del switch | ✅ |
| MED-6 | ⚠️ | Cache-Control headers | - | ✅ YA resuelto por app.ts |
| MED-7 | ⚠️ | Enum validation con strings | Transversal | ✅ |
| MED-8 | ⚠️ | askClaude sin projectId en costes | Transversal | ✅ YA resuelto por BE-15 |
| MED-9 | ⚠️ | Mensajes en inglés/español mezclados | Transversal | ✅ |
| MED-10 | ⚠️ | Prompts sin sanitizar user input | Transversal | ✅ |
| MED-11 | ⚠️ | Pagination sin cap máximo | list_products | ✅ |
| MED-12 | ⚠️ | writeFileSync sin handle ENOSPC | fix_code + modify_ui | ✅ |
| MED-13 | ⚠️ | Regex con posible ReDoS | Varias | ✅ |
| MED-14 | ⚠️ | AbortController sin clearTimeout en catch | Varias | ✅ |

**Estado: 25/25 hallazgos con código aplicable**. 2 de ellos (MED-6, MED-8) ya
están resueltos por los paquetes anteriores (Bloque C/D/E).

---

## Orden de aplicación recomendado

### FASE 1 — helpers compartidos (15 min)

**Primero**, copiar el archivo con los helpers que los fixes necesitan:

```bash
cp fixes-bloque-a/lib/shopybrain-helpers.ts artifacts/api-server/src/lib/shopybrain-helpers.ts
```

Y al inicio de `artifacts/api-server/src/routes/shopybrain.ts`, añadir:

```typescript
import {
  getSessionProjectId,
  fetchImageWithSizeLimit,
  requireConfirmation,
  validateFixCodePath,
  normalizeListDirectory,
  loadProjectOrThrow,
} from "../lib/shopybrain-helpers.js";
```

Verificar: `pnpm typecheck` pasa sin errores.

### FASE 2 — los 6 críticos (2 h)

Aplicar los 6 patches de `patches/CRIT_1_to_6_patches.md` **en orden**:

1. CRIT-5 primero (path traversal en list_source_files) — 10 min
2. CRIT-1 (whitelist + confirmación en fix_code) — 30 min
3. CRIT-4 (fetchImageWithSizeLimit en fusion_analyze + fusion_create_product) — 20 min
4. CRIT-2 + CRIT-3 (sustituir los 4 sitios de `|| 2`) — 15 min
5. CRIT-6 (añadir requireConfirmation a las 21 acciones destructivas) — 60 min

Tras cada uno, hacer `pnpm typecheck` y probar manualmente la acción tocada.

### FASE 3 — los 5 altos (1-2 h)

Aplicar los 5 patches de `patches/HIGH_1_to_5_patches.md`.
Son independientes, puedes aplicarlos en cualquier orden o saltarte alguno
si te parece menos relevante para tu caso.

### FASE 4 — los 14 medios (3-4 h)

Aplicar los que te interesen de `patches/MED_1_to_14_patches.md`. Prioridad recomendada:

1. **MED-2** (helper loadProjectOrThrow) — fácil, limpia 30 sitios
2. **MED-3** (parseInt radix) — 1 sed global, 2 min
3. **MED-4** (constantes de timeouts) — mejora legibilidad
4. **MED-14** (try/finally en AbortController) — bugfix real
5. **MED-12** (ENOSPC en writeFileSync) — bugfix real
6. **MED-11** (cap pagination) — defensa
7. **MED-10** (sanitize prompts) — defensa prompt injection
8. Resto según disponibilidad

### FASE 5 — refactor en 7 módulos (OPCIONAL, 14-16 h)

Ver `REFACTOR_PLAN.md`. Esto **NO corrige bugs**, solo divide el monolito de
9.661 líneas en 7 archivos de ~1.500 líneas cada uno. Recomendado si vas a
mantener este código en los próximos 6-12 meses.

---

## Verificación post-aplicación

Script de smoke test después de aplicar los 6 críticos:

```bash
# Desde una sesión admin del backend:

# CRIT-5: path traversal
curl -X POST http://localhost:8080/api/shopybrain/execute-action \
  -H "Content-Type: application/json" --cookie "connect.sid=..." \
  -d '{"action":"list_source_files","params":{"directory":"../../../etc"}}'
# Esperar: {"error":true,"message":"🚫 Path inválido: ..."}

# CRIT-1: fix_code sobre package.json (bloqueado)
curl -X POST http://localhost:8080/api/shopybrain/execute-action \
  -H "Content-Type: application/json" --cookie "connect.sid=..." \
  -d '{"action":"fix_code","params":{"filePath":"package.json","oldCode":"x","newCode":"y","confirmed":true}}'
# Esperar: {"error":true,"message":"🚫 Archivo protegido: ..."}

# CRIT-6: acción destructiva sin confirmed
curl -X POST http://localhost:8080/api/shopybrain/execute-action \
  -H "Content-Type: application/json" --cookie "connect.sid=..." \
  -d '{"action":"optimize_all_products","params":{"projectId":2}}'
# Esperar: {"requiresConfirmation":true,"message":"⚠️ Confirmación requerida..."}

# CRIT-4: imagen "gigante"
curl -X POST http://localhost:8080/api/shopybrain/execute-action \
  -H "Content-Type: application/json" --cookie "connect.sid=..." \
  -d '{"action":"fusion_analyze","params":{"imageUrl":"https://speed.hetzner.de/100MB.bin"}}'
# Esperar: {"error":true,"message":"❌ Imagen demasiado grande: ..."}
```

---

## Qué NO incluye este paquete

- **Tests automáticos**: los 25 hallazgos se verifican manualmente con los
  curl de arriba. Para cobertura real haría falta Vitest/Jest — recomendado
  después del refactor de Fase 5.
- **Cambios en el frontend**: los mensajes `requiresConfirmation` del backend
  ya los maneja el OmniChatbot del Bloque B (fix FE-16). Si no aplicaste ese
  fix, el frontend mostrará el mensaje crudo en el chat (funciona pero es feo).
- **Fixes a los otros routers**: `shopybrain.ts` es solo 1 de 47 archivos de
  routes. Los otros están cubiertos en el Bloque C/D/E.

---

## Resumen global de la auditoría Shopy Crafter

| Bloque | Hallazgos | Paquete de fixes |
|---|---|---|
| **A** — shopybrain.ts | 25 | `shopy-crafter-fixes-bloque-a.zip` ← **ESTE** |
| **B** — frontend | 20 | `shopy-crafter-fixes-v2.zip` |
| **C/D/E** — backend + lib + schema | 19 | `shopy-crafter-fixes-bloque-c-d-e.zip` |
| **Pendientes** — BE-9, 12, 15, 16, 22 | 5 | `shopy-crafter-fixes-pendientes.zip` |
| **TOTAL** | **69** | **4 paquetes ZIP** |

**Con este paquete, los 69/69 hallazgos están cubiertos con código aplicable
directo.** La auditoría queda cerrada al 100% real.
