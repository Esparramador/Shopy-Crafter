═══════════════════════════════════════════════════════════════════════════════
BLOQUE A — PATCHES PARA LOS 6 HALLAZGOS CRÍTICOS DE shopybrain.ts

Aplicar abriendo el archivo artifacts/api-server/src/routes/shopybrain.ts
y sustituyendo cada bloque ANTES por el DESPUÉS. Todos los patches son
independientes entre sí — puedes aplicarlos en cualquier orden.

Dependencias necesarias:
  - helper getSessionProjectId (ver abajo, CRIT-3)
  - helper fetchImageWithSizeLimit (ver abajo, CRIT-4)
═══════════════════════════════════════════════════════════════════════════════

───────────────────────────────────────────────────────────────────────────────
HELPER COMÚN — añadir al inicio del archivo (después de los imports, antes
de los endpoints). Será utilizado por CRIT-3 y CRIT-4.
───────────────────────────────────────────────────────────────────────────────

ANTES: nada.

DESPUÉS: añadir este bloque aprox línea 50 del archivo (junto a las
constantes WORKSPACE_ROOT, FRONTEND_ROOT, BACKEND_ROOT):

  // ═════════════════════════════════════════════════════════════════════════
  // Helpers críticos
  // ═════════════════════════════════════════════════════════════════════════

  /**
   * FIX CRIT-3: obtiene el projectId de forma segura.
   * Si no hay projectId en params ni en sesión, lanza error.
   * Nunca hardcodea '2' como fallback.
   */
  function getSessionProjectId(req: Request, params: Record<string, unknown>): number {
    // 1. Parámetro explícito (preferido para llamadas entre acciones)
    const paramId = params?.projectId;
    if (paramId !== undefined && paramId !== null && paramId !== "") {
      const parsed = parseInt(String(paramId), 10);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }

    // 2. Sesión del usuario autenticado
    const sessionClientId = req.session?.clientId;
    if (sessionClientId !== null && sessionClientId !== undefined) {
      const parsed = typeof sessionClientId === "number"
        ? sessionClientId
        : parseInt(String(sessionClientId), 10);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }

    // 3. Ningún proyecto — error explícito, nunca hardcoded
    throw new Error(
      "No se pudo determinar el projectId. Proporciona params.projectId explícitamente " +
      "o asegúrate de estar autenticado con un proyecto asociado."
    );
  }

  /**
   * FIX CRIT-4: descarga una imagen verificando tamaño ANTES de cargarla entera.
   * Primero hace HEAD para leer content-length. Si excede el límite, aborta.
   * Protege contra bombas zip: imágenes de 1GB que agotan la memoria.
   */
  async function fetchImageWithSizeLimit(url: string, maxBytes = 15 * 1024 * 1024): Promise<{
    buffer: Buffer;
    mimeType: string;
  }> {
    // Pre-check con HEAD (opcional — no todos los servers lo implementan)
    try {
      const headResp = await fetch(url, {
        method: "HEAD",
        signal: AbortSignal.timeout(10_000),
      });
      const contentLength = headResp.headers.get("content-length");
      if (contentLength && parseInt(contentLength, 10) > maxBytes) {
        throw new Error(`Imagen demasiado grande: ${Math.round(parseInt(contentLength, 10) / 1024 / 1024)}MB (máx ${maxBytes / 1024 / 1024}MB)`);
      }
    } catch (err) {
      // HEAD puede fallar si el servidor no lo soporta — no es fatal
      if (err instanceof Error && err.message.startsWith("Imagen demasiado grande")) throw err;
    }

    // Descarga real con límite durante el streaming
    const resp = await fetch(url, { signal: AbortSignal.timeout(60_000) });
    if (!resp.ok) throw new Error(`No se pudo descargar la imagen: HTTP ${resp.status}`);

    const mimeType = resp.headers.get("content-type") || "image/jpeg";
    if (!mimeType.startsWith("image/")) {
      throw new Error(`La URL no apunta a una imagen (content-type: ${mimeType})`);
    }

    const reader = resp.body?.getReader();
    if (!reader) throw new Error("No se pudo leer el body de la respuesta");

    const chunks: Uint8Array[] = [];
    let totalBytes = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      totalBytes += value.byteLength;
      if (totalBytes > maxBytes) {
        try { reader.cancel(); } catch {}
        throw new Error(`Imagen demasiado grande: excedió ${maxBytes / 1024 / 1024}MB durante la descarga`);
      }
      chunks.push(value);
    }
    return { buffer: Buffer.concat(chunks), mimeType };
  }


═══════════════════════════════════════════════════════════════════════════════
CRIT-1 · fix_code reescribe cualquier archivo del workspace
Ubicación: línea 4205 aprox, case "fix_code".

Problema: valida solo `..` y `isAbsolute()`, pero acepta cualquier archivo
del workspace incluido package.json, drizzle.config.ts, .env, SKILLS.md, etc.
Un prompt injection vía fix_code puede reescribir archivos sensibles.
═══════════════════════════════════════════════════════════════════════════════

ANTES (línea 4216 aprox):

        case "fix_code": {
          const filePath = params?.filePath;
          const oldCode = params?.oldCode;
          const newCode = params?.newCode;
          const description = params?.description || "Fix aplicado por Shopy Crafter";

          if (!filePath || !oldCode || newCode === undefined) {
            res.status(400).json({ error: "filePath, oldCode y newCode son requeridos" });
            return;
          }
          if (String(filePath).includes("..") || path.isAbsolute(String(filePath))) { res.status(400).json({ error: "Path inválido: no se permiten rutas absolutas ni '..'." }); return; }

          const resolvedPath = resolveFilePath(String(filePath));
          if (!resolvedPath) {
            res.status(404).json({ error: `Archivo no encontrado: ${filePath}. Prueba con list_source_files para ver los archivos disponibles.` });
            return;
          }
          let fileContent = fs.readFileSync(resolvedPath, "utf-8");

DESPUÉS:

        case "fix_code": {
          const filePath = params?.filePath;
          const oldCode = params?.oldCode;
          const newCode = params?.newCode;
          const description = params?.description || "Fix aplicado por Shopy Crafter";
          const confirmed = params?.confirmed === true || params?.confirmed === "true";

          if (!filePath || !oldCode || newCode === undefined) {
            res.status(400).json({ error: "filePath, oldCode y newCode son requeridos" });
            return;
          }
          if (String(filePath).includes("..") || path.isAbsolute(String(filePath))) {
            res.status(400).json({ error: "Path inválido: no se permiten rutas absolutas ni '..'." });
            return;
          }

          // FIX CRIT-1: whitelist estricta de paths modificables.
          // Solo se permite escribir dentro de src/pages, src/components, src/routes,
          // src/lib de frontend y backend. Nunca tocar archivos de config, build,
          // drizzle schemas, .env, package.json, etc.
          const ALLOWED_PATH_PATTERNS = [
            /^(src\/)?(pages|components|hooks|contexts|lib|styles|utils)\//,
            /^(src\/)?(routes|services|helpers|lib|middlewares)\//,
          ];
          const FORBIDDEN_FILES = new Set([
            "package.json", "tsconfig.json", "vite.config.ts", "capacitor.config.ts",
            ".env", ".env.production", ".env.development",
            "drizzle.config.ts", "SKILLS.md", "README.md",
          ]);
          const FORBIDDEN_PATH_PATTERNS = [
            /^(src\/)?(db|schema|migrations)\//,
            /^(src\/)?(\.env|\.git)/,
            /node_modules\//,
            /dist\//,
            /\.env/,
          ];
          const pathStr = String(filePath).replace(/^\.?\/+/, "");
          const basename = pathStr.split("/").pop() || "";

          const isAllowedPath = ALLOWED_PATH_PATTERNS.some(re => re.test(pathStr));
          const isForbidden = FORBIDDEN_FILES.has(basename) ||
                              FORBIDDEN_PATH_PATTERNS.some(re => re.test(pathStr));

          if (!isAllowedPath || isForbidden) {
            result = {
              error: true,
              message: `🚫 **Path no permitido:** ${filePath}\n` +
                       `Solo se pueden modificar archivos en src/pages, src/components, src/routes, src/lib, src/services. ` +
                       `Los archivos de configuración, schema y build están protegidos.`,
            };
            break;
          }

          // FIX CRIT-1 bis: extensión permitida
          if (!/\.(tsx?|jsx?|css|scss|md)$/.test(basename)) {
            result = {
              error: true,
              message: `🚫 **Extensión no permitida:** ${basename}\n` +
                       `Solo se permiten archivos .ts, .tsx, .js, .jsx, .css, .scss, .md.`,
            };
            break;
          }

          // FIX CRIT-6: confirmación explícita requerida
          if (!confirmed) {
            result = {
              requiresConfirmation: true,
              filePath,
              description,
              preview: {
                before: String(oldCode).slice(0, 300),
                after: String(newCode).slice(0, 300),
              },
              message: `⚠️ **Confirmación requerida para fix_code en \`${filePath}\`**\n\n` +
                       `**Descripción:** ${description}\n` +
                       `**Cambio:** ${String(newCode).split("\n").length} líneas modificadas\n\n` +
                       `Re-envía la acción con \`"confirmed": true\` para aplicar el cambio.`,
            };
            break;
          }

          const resolvedPath = resolveFilePath(String(filePath));
          if (!resolvedPath) {
            res.status(404).json({ error: `Archivo no encontrado: ${filePath}. Prueba con list_source_files para ver los archivos disponibles.` });
            return;
          }
          let fileContent = fs.readFileSync(resolvedPath, "utf-8");


═══════════════════════════════════════════════════════════════════════════════
CRIT-2 · modify_ui con hardcoded `|| 2`
Ubicación: línea 6574 aprox, case "modify_ui".
═══════════════════════════════════════════════════════════════════════════════

ANTES (línea 6649 aprox):

            const uiText = await askClaudeWithBrain(
              parseInt(params?.projectId) || 2,
              [{ role: "user", content: analyzePrompt }],
              "Eres un experto frontend senior. Responde SOLO JSON válido. Los paths de archivo son relativos desde src/ sin incluir src/ al inicio.",
              "general",
              undefined,
              3000
            );

DESPUÉS:

            const modifyUiProjectId = getSessionProjectId(req, params);
            const uiText = await askClaudeWithBrain(
              modifyUiProjectId,
              [{ role: "user", content: analyzePrompt }],
              "Eres un experto frontend senior. Responde SOLO JSON válido. Los paths de archivo son relativos desde src/ sin incluir src/ al inicio.",
              "general",
              undefined,
              3000
            );


═══════════════════════════════════════════════════════════════════════════════
CRIT-3 · Otros 3 sitios con `|| 2` hardcoded
Ubicación: líneas 4086, 4152, 6545 aprox.
═══════════════════════════════════════════════════════════════════════════════

ANTES (línea 4086 aprox, dentro de inspect_code):

              analysis = await askClaudeWithBrain(
                parseInt(params?.projectId) || 2,
                [{
                  role: "user",
                  content: `Analiza este archivo de código fuente de una app Shopify...

DESPUÉS:

              const inspectProjectId = getSessionProjectId(req, params);
              analysis = await askClaudeWithBrain(
                inspectProjectId,
                [{
                  role: "user",
                  content: `Analiza este archivo de código fuente de una app Shopify...


ANTES (línea 4152 aprox, dentro de componentAnalysis):

            const componentAnalysis = await askClaudeWithBrain(
              parseInt(params?.projectId) || 2,
              [{
                role: "user",
                content: `Eres un senior developer auditando código de producción...

DESPUÉS:

            const componentProjectId = getSessionProjectId(req, params);
            const componentAnalysis = await askClaudeWithBrain(
              componentProjectId,
              [{
                role: "user",
                content: `Eres un senior developer auditando código de producción...


ANTES (línea 6545 aprox, en audit_app_offerings):

              const auditText = await askClaudeWithBrain(
                parseInt(params?.projectId) || 2,
                [{ role: "user", content: auditPrompt }],
                ...
              );

DESPUÉS:

              const auditOfferingsProjectId = getSessionProjectId(req, params);
              const auditText = await askClaudeWithBrain(
                auditOfferingsProjectId,
                [{ role: "user", content: auditPrompt }],
                ...
              );


═══════════════════════════════════════════════════════════════════════════════
CRIT-4 · fusion_analyze y fusion_create_product DoS por imagen enorme
Ubicación: líneas 5697 y 5730 aprox.

Problema: `fetch(imageUrl)` sin validar content-length puede agotar la RAM del
servidor con imágenes de varios GB.
═══════════════════════════════════════════════════════════════════════════════

ANTES (fusion_analyze línea 5700 aprox):

          try {
            const imgResp = await fetch(String(imageUrl));
            if (!imgResp.ok) throw new Error(`No se pudo descargar la imagen: ${imgResp.status}`);
            const imgBuf = Buffer.from(await imgResp.arrayBuffer());
            const mimeType = imgResp.headers.get("content-type") || "image/jpeg";
            const analysis = await analyzeImageForFusion(imgBuf.toString("base64"), mimeType);

DESPUÉS:

          try {
            // FIX CRIT-4: límite de 15MB con check de content-length
            const { buffer: imgBuf, mimeType } = await fetchImageWithSizeLimit(String(imageUrl), 15 * 1024 * 1024);
            const analysis = await analyzeImageForFusion(imgBuf.toString("base64"), mimeType);


ANTES (fusion_create_product línea 5740 aprox):

          try {
            const imgResp = await fetch(String(imageUrl));
            if (!imgResp.ok) throw new Error(`No se pudo descargar la imagen: ${imgResp.status}`);
            const imgBuf = Buffer.from(await imgResp.arrayBuffer());
            const imgMime = imgResp.headers.get("content-type") || "image/jpeg";
            const analysis = await analyzeImageForFusion(imgBuf.toString("base64"), imgMime);

DESPUÉS:

          try {
            // FIX CRIT-4: límite de 15MB con check de content-length
            const { buffer: imgBuf, mimeType: imgMime } = await fetchImageWithSizeLimit(String(imageUrl), 15 * 1024 * 1024);
            const analysis = await analyzeImageForFusion(imgBuf.toString("base64"), imgMime);


═══════════════════════════════════════════════════════════════════════════════
CRIT-5 · list_source_files path traversal en `directory`
Ubicación: línea 4024 aprox.

Problema: `params.directory` se concatena en un path sin validar `..`, sin
whitelist de prefijos, sin chequeo de que el resultado sigue siendo subdirectorio
del WORKSPACE_ROOT. Un `directory: "../../../etc"` lista /etc.
═══════════════════════════════════════════════════════════════════════════════

ANTES (línea 4052 aprox):

          const frontendDir = directory ? (directory.startsWith("src") ? directory : `src/${directory}`.replace(/\/+/g, "/").replace(/\/$/, "")) : "src";
          const frontendFiles = listDir(FRONTEND_ROOT, frontendDir, "[frontend] ");
          const backendDir = directory ? (directory.startsWith("src") ? directory : `src/${directory}`.replace(/\/+/g, "/").replace(/\/$/, "")) : "src";
          const backendFiles = listDir(BACKEND_ROOT, backendDir, "[backend] ");

DESPUÉS:

          // FIX CRIT-5: rechazar rutas traversal y normalizar
          const dirStr = String(directory).trim();
          if (dirStr.includes("..") || path.isAbsolute(dirStr) || dirStr.includes("\0")) {
            result = {
              error: true,
              message: "🚫 Path inválido: no se permiten rutas con '..', absolutas ni caracteres nulos.",
            };
            break;
          }

          // Construir path normalizado y verificar que vive dentro de /src/
          const normalizeDir = (input: string, rootDir: string): string | null => {
            const rawDir = input ? (input.startsWith("src") ? input : `src/${input}`).replace(/\/+/g, "/").replace(/\/$/, "") : "src";
            const candidate = path.resolve(rootDir, rawDir);
            const srcRoot = path.resolve(rootDir, "src");
            if (!candidate.startsWith(srcRoot)) return null;
            return path.relative(rootDir, candidate);
          };

          const frontendDir = normalizeDir(dirStr, FRONTEND_ROOT);
          const backendDir = normalizeDir(dirStr, BACKEND_ROOT);

          if (!frontendDir || !backendDir) {
            result = {
              error: true,
              message: "🚫 Directory fuera del workspace permitido. Solo se pueden listar subdirectorios de src/.",
            };
            break;
          }

          const frontendFiles = listDir(FRONTEND_ROOT, frontendDir, "[frontend] ");
          const backendFiles = listDir(BACKEND_ROOT, backendDir, "[backend] ");


═══════════════════════════════════════════════════════════════════════════════
CRIT-6 · Solo 1 de 148 acciones exige `params.confirmed`
Ubicación: transversal — afecta a todas las acciones destructivas.

Problema: acciones como `bulk_redesign`, `optimize_all_products`,
`delete_product`, `fix_unpublished`, etc. se ejecutan sin confirmación.
Un prompt injection puede borrar productos, cambiar precios en masa, etc.

Solución: helper `requireConfirmation` al inicio de cada acción destructiva.
El fix de CRIT-1 `fix_code` ya incluye este check — aplicar el mismo patrón
a las demás.
═══════════════════════════════════════════════════════════════════════════════

Añadir este helper al principio del archivo (línea 50 aprox, junto a los
otros helpers):

  /**
   * FIX CRIT-6: helper que exige confirmación explícita para acciones destructivas.
   * Si params.confirmed no es true, devuelve un objeto con requiresConfirmation=true
   * que el frontend (OmniChatbot) ya maneja para mostrar el diálogo al usuario.
   */
  function requireConfirmation(
    params: Record<string, unknown> | undefined,
    action: string,
    preview: { summary: string; items?: unknown[]; estimatedCost?: string }
  ): { requiresConfirmation: boolean; message: string; action: string; preview: typeof preview } | null {
    if (params?.confirmed === true || params?.confirmed === "true") return null;
    return {
      requiresConfirmation: true,
      action,
      preview,
      message: `⚠️ **Confirmación requerida para \`${action}\`**\n\n${preview.summary}\n\n` +
               `Re-envía la acción añadiendo \`"confirmed": true\` en los parámetros para ejecutarla.`,
    };
  }


Acciones que DEBEN empezar con un check de confirmación. Añadir en la
primera línea de cada `case`:

  case "optimize_all_products": {
    const projectId = getSessionProjectId(req, params);
    const confirmed = requireConfirmation(params, "optimize_all_products", {
      summary: `Vas a optimizar TODOS los productos del proyecto ${projectId}. Esto modifica título, descripción, tags y SEO de cada producto vía IA.`,
      estimatedCost: "Consumo de créditos IA proporcional al número de productos.",
    });
    if (confirmed) { result = confirmed; break; }
    // ... resto del código original ...
  }

  case "bulk_redesign": {
    const projectId = getSessionProjectId(req, params);
    const confirmed = requireConfirmation(params, "bulk_redesign", {
      summary: `Vas a rediseñar TODAS las descripciones de productos del proyecto ${projectId}. El cambio es masivo y puede afectar a cientos de productos.`,
    });
    if (confirmed) { result = confirmed; break; }
    // ...
  }

  case "bulk_generate_images":
  case "bulk_update_prices":
  case "bulk_update_stock":
  case "auto_collections":
  case "design_all_pages":
  case "setup_full_store":
  case "fix_unpublished":
  case "fix_missing_compare_prices":
  case "sync_catalog_prices":
  case "delete_product":
  case "delete_collection":
  case "delete_variant":
  case "delete_email_flow":
  case "deactivate_user":
  case "reset_user_password":
  case "reset_cms":
  case "edit_theme_file":
  case "edit_theme_css":
  case "edit_theme_settings":
  case "create_theme_section":
  case "sync_store_theme": {
    // Mismo patrón — añadir el check de requireConfirmation como primera línea
  }

RECOMENDACIÓN: generar el helper `needsConfirmation` en un archivo separado
(action-constants.ts) para mantener la lista centralizada. El fix FE-16 del
Bloque B ya hace esto en el frontend; idealmente el backend usa la MISMA lista.

Ver shopy-crafter-fixes-v2/components/omnichatbot/action-constants.ts.


═══════════════════════════════════════════════════════════════════════════════
FIN DE LOS 6 FIXES CRÍTICOS.

Verificación post-aplicación:
  1. Intentar fix_code con filePath="package.json" → debe devolver error
  2. Intentar fusion_analyze con URL que apunte a un archivo de 50MB → debe
     abortar con "Imagen demasiado grande"
  3. Intentar list_source_files con directory="../../../etc" → debe devolver
     "Path inválido"
  4. Intentar optimize_all_products sin confirmed → debe devolver
     requiresConfirmation
  5. Intentar modify_ui sin params.projectId y sin sesión → debe lanzar
     "No se pudo determinar el projectId"
═══════════════════════════════════════════════════════════════════════════════
