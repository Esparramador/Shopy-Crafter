═══════════════════════════════════════════════════════════════════════════════
BLOQUE A — PATCHES PARA LOS 14 HALLAZGOS MEDIOS

Estos son mejoras incrementales. Aplicables en cualquier orden. Ninguno
representa un riesgo de seguridad serio; son deuda técnica + UX + observabilidad.
═══════════════════════════════════════════════════════════════════════════════


───────────────────────────────────────────────────────────────────────────────
MED-1 · Logs sin contexto de acción/proyecto
───────────────────────────────────────────────────────────────────────────────

Los `console.log(...)` y `logger.info(...)` dispersos en el archivo no
incluyen el contexto (action + projectId + userId). Añadir logger estructurado.

En cada action, al empezar:
  logger.info({ action, projectId: ctx.projectId, userId: req.session.userId },
    `[shopybrain] Start ${action}`);

Al terminar con éxito:
  logger.info({ action, projectId, durationMs: Date.now() - startTime },
    `[shopybrain] Done ${action}`);


───────────────────────────────────────────────────────────────────────────────
MED-2 · Múltiples calls a db.select().from(projectsTable) en la misma request
───────────────────────────────────────────────────────────────────────────────

Patrón repetido al principio de ~30 acciones:
  const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, parseInt(projectId)));
  if (!project) { res.status(404).json({ error: "Proyecto no encontrado" }); return; }

ANTES — se ejecuta idéntico en 30 lugares.

DESPUÉS — helper reutilizable en lib/shopybrain-helpers.ts:

  export async function loadProjectOrThrow(projectId: number): Promise<Project> {
    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
    if (!project) throw new Error(`Proyecto ${projectId} no encontrado`);
    return project;
  }

Y en cada case:
  const projectId = getSessionProjectId(req, params);
  const project = await loadProjectOrThrow(projectId);


───────────────────────────────────────────────────────────────────────────────
MED-3 · parseInt(...) sin radix
───────────────────────────────────────────────────────────────────────────────

Todos los `parseInt(params?.projectId)` sin el segundo argumento (radix).
Aunque en la práctica funciona (siempre es decimal), JS mejor con radix
explícito.

Buscar en el archivo: `parseInt(` sin segundo argumento.
Reemplazar por: `parseInt(valor, 10)`.

Búsqueda rápida:
  grep -n 'parseInt([^,)]*)' artifacts/api-server/src/routes/shopybrain.ts | head -30

Hay aprox 40-50 sitios. Script de sed:
  sed -i -E 's/parseInt\(([^,)]+)\)/parseInt(\1, 10)/g' shopybrain.ts


───────────────────────────────────────────────────────────────────────────────
MED-4 · Magic numbers en timeouts
───────────────────────────────────────────────────────────────────────────────

Los `180_000`, `30_000`, `15_000`, `120_000` están esparcidos sin explicación.
Extraer a constantes al principio del archivo:

  const CLAUDE_CALL_TIMEOUT_MS = 180_000;          // Llamadas normales a Claude
  const CLAUDE_BULK_TIMEOUT_MS = 900_000;          // Bulk operations
  const SHOPIFY_REQUEST_TIMEOUT_MS = 45_000;       // Ya está en lib/shopify.ts
  const IMAGE_DOWNLOAD_TIMEOUT_MS = 60_000;
  const MAX_IMAGE_SIZE_BYTES = 15 * 1024 * 1024;   // 15MB
  const MAX_VIDEO_SIZE_BYTES = 50 * 1024 * 1024;


───────────────────────────────────────────────────────────────────────────────
MED-5 · switch(action) gigante sin default claro
───────────────────────────────────────────────────────────────────────────────

Al final del switch de 148 cases:

ANTES:
  default:
    res.status(400).json({ error: `Acción desconocida: ${action}` });
    return;

DESPUÉS (más informativo):
  default:
    // MED-5: sugerir acciones similares si el usuario escribe mal el nombre
    const similar = findSimilarActions(action, ALL_ACTIONS);  // levenshtein distance
    res.status(400).json({
      error: `Acción desconocida: "${action}".`,
      suggestion: similar.length > 0 ? `¿Quisiste decir: ${similar.join(", ")}?` : undefined,
      availableActionCount: ALL_ACTIONS.size,
    });
    return;

Con el helper:
  function findSimilarActions(query: string, all: Set<string>, maxResults = 3): string[] {
    const results: Array<{ name: string; distance: number }> = [];
    for (const action of all) {
      const d = levenshtein(query, action);
      if (d < Math.max(3, query.length / 3)) results.push({ name: action, distance: d });
    }
    return results.sort((a, b) => a.distance - b.distance).slice(0, maxResults).map(r => r.name);
  }

  function levenshtein(a: string, b: string): number {
    const matrix = Array.from({ length: a.length + 1 }, (_, i) =>
      Array.from({ length: b.length + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
    );
    for (let i = 1; i <= a.length; i++) {
      for (let j = 1; j <= b.length; j++) {
        matrix[i][j] = a[i - 1] === b[j - 1]
          ? matrix[i - 1][j - 1]
          : Math.min(matrix[i - 1][j] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j - 1] + 1);
      }
    }
    return matrix[a.length][b.length];
  }


───────────────────────────────────────────────────────────────────────────────
MED-6 · Respuestas sin Cache-Control cuando deberían tenerlo
───────────────────────────────────────────────────────────────────────────────

Ya está cubierto por el middleware global en app.ts que añade
`Cache-Control: no-store` a todo `/api`. No hay acción pendiente.
**Marcado como RESUELTO por app.ts.**


───────────────────────────────────────────────────────────────────────────────
MED-7 · Validación de enum values con strings mágicos
───────────────────────────────────────────────────────────────────────────────

ANTES (ej en audit_product):
  const focusOn = params?.focusOn || "all";
  const focusPrompts: Record<string, string> = {
    all: "...", security: "...", performance: "...", ux: "...",
  };
  const prompt = focusPrompts[focusOn] || focusPrompts.all;

DESPUÉS (con validación explícita):
  const ALLOWED_FOCUS = ["all", "security", "performance", "ux", "bugs"] as const;
  type FocusArea = typeof ALLOWED_FOCUS[number];

  const focusOnRaw = String(params?.focusOn || "all");
  const focusOn: FocusArea = (ALLOWED_FOCUS as readonly string[]).includes(focusOnRaw)
    ? (focusOnRaw as FocusArea)
    : "all";


───────────────────────────────────────────────────────────────────────────────
MED-8 · askClaude sin projectId en contexto de costes
───────────────────────────────────────────────────────────────────────────────

Ya cubierto por fix BE-15 (telemetría) del Bloque C/D/E.
**Marcado como RESUELTO tras aplicar BE-15_claude-telemetry.ts.**


───────────────────────────────────────────────────────────────────────────────
MED-9 · Mensajes de error al usuario en inglés mezclado con español
───────────────────────────────────────────────────────────────────────────────

Muchos mensajes son híbridos:
  "Error: invalid token" (EN)
  "❌ Proyecto no encontrado" (ES)
  "Shopify request failed: ..." (EN)

Estandarizar todos a español. Grep para encontrar:
  grep -nE 'Error:|failed:|not found|invalid' artifacts/api-server/src/routes/shopybrain.ts | head -40

Reemplazar caso por caso. Prioridad: mensajes que el usuario ve en el chat.


───────────────────────────────────────────────────────────────────────────────
MED-10 · Prompts de Claude con template strings no escapados
───────────────────────────────────────────────────────────────────────────────

ANTES:
  const prompt = `Analiza esto: ${userInput}`;

Si `userInput` contiene backticks o `${...}`, puede romper el prompt o
inyectar texto. Mitigación:

DESPUÉS:
  function sanitizeForPrompt(text: string): string {
    return String(text)
      .replace(/```/g, "'''")       // escapar code fences
      .replace(/\$\{/g, "\\${")     // escapar template interpolation
      .slice(0, 50_000);             // limitar longitud
  }

  const prompt = `Analiza esto: ${sanitizeForPrompt(userInput)}`;


───────────────────────────────────────────────────────────────────────────────
MED-11 · Shopify pagination sin límite máximo
───────────────────────────────────────────────────────────────────────────────

En acciones como list_products, si el usuario pasa limit=10000, hacemos
muchas llamadas paginadas. Añadir cap:

ANTES:
  const limit = parseInt(params?.limit || "250");
  // ... loop de paginación ...

DESPUÉS:
  const requested = parseInt(String(params?.limit || "250"), 10);
  const limit = Math.min(Math.max(1, requested), 500);  // hard cap a 500
  // ... resto ...


───────────────────────────────────────────────────────────────────────────────
MED-12 · File writes sin confirmar que el disco tiene espacio
───────────────────────────────────────────────────────────────────────────────

`fs.writeFileSync(backupPath, ...)` puede fallar con ENOSPC. El error no
está capturado en todos los sitios.

ANTES:
  const backupPath = `${resolvedPath}.bak.${Date.now()}`;
  fs.writeFileSync(backupPath, fileContent, "utf-8");

DESPUÉS:
  const backupPath = `${resolvedPath}.bak.${Date.now()}`;
  try {
    fs.writeFileSync(backupPath, fileContent, "utf-8");
  } catch (err) {
    if (err instanceof Error && (err as NodeJS.ErrnoException).code === "ENOSPC") {
      result = { error: true, message: "No hay espacio en disco para crear el backup. Aborto." };
      break;
    }
    throw err;
  }


───────────────────────────────────────────────────────────────────────────────
MED-13 · Regex de tags con posible ReDoS
───────────────────────────────────────────────────────────────────────────────

Revisar todos los regex en shopybrain.ts. Algunos patrones con cuantificadores
anidados como `(.*)+` o `(.+)*` pueden ser vulnerables a Catastrophic Backtracking.

Búsqueda:
  grep -nE '\(.*\+\)\*|\(.+\)\+\*|\(\..*\)\*' shopybrain.ts

Reemplazar cuantificadores greedy por lazy (?):
  /<script[\s\S]*?<\/script>/  ← OK (lazy con ?)
  /<script(.*?)<\/script>/g    ← OK
  /(.+)+/                       ← mal (catastrophic)


───────────────────────────────────────────────────────────────────────────────
MED-14 · AbortController no limpiado en algunas paths
───────────────────────────────────────────────────────────────────────────────

El patrón actual:
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 180_000);
  try {
    const result = await fetch(url, { signal: ctrl.signal });
    clearTimeout(timer);
    return result;
  } catch (err) {
    // ← falta clearTimeout aquí. El timer sigue vivo hasta que llegue.
  }

Fix — usar try/finally:
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 180_000);
  try {
    return await fetch(url, { signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }


═══════════════════════════════════════════════════════════════════════════════
FIN DE LOS 14 FIXES MEDIOS.

Prioridad recomendada de aplicación:
  1. MED-2 (helper loadProjectOrThrow) — reduce duplicación, fácil
  2. MED-3 (parseInt radix) — sed global, 2 minutos
  3. MED-4 (constantes timeouts) — orden del día, 15 min
  4. MED-14 (AbortController try/finally) — bugfix real
  5. MED-12 (ENOSPC en backups) — bugfix real
  6. MED-11 (cap de paginación) — seguridad defensiva
  7. MED-10 (sanitize prompts) — defensa prompt injection
  8. MED-7 (enum validation) — mejora tipado
  9. MED-1 (logs estructurados) — observabilidad
  10. MED-5 (sugerencias de acciones similares) — UX
  11. MED-9 (i18n español consistente) — UX
  12. MED-13 (ReDoS review) — seguridad
  13. MED-6, MED-8 — ya resueltos

Tiempo total estimado: 4-6 horas
═══════════════════════════════════════════════════════════════════════════════
