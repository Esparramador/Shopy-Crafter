# Bloque A — Plan de refactor de `shopybrain.ts`

**Archivo original:** `artifacts/api-server/src/routes/shopybrain.ts` (9.661 líneas, 148 acciones).

**Objetivo:** partir el monolito en 7 módulos temáticos para que:
- Cada cambio futuro toque un archivo de 500-1500 líneas en vez de uno de 9.600
- El typecheck sea más rápido
- Los tests sean posibles por módulo
- La revisión en PRs sea viable

Este plan es **opcional** — el archivo funciona tal cual. Pero recomendado tras aplicar los 6 fixes críticos.

---

## Estructura final propuesta

```
artifacts/api-server/src/routes/shopybrain/
├── index.ts                    ← router principal + dispatcher (≈150 líneas)
├── handlers/
│   ├── products.ts             ← 35 acciones (≈1.800 líneas)
│   ├── images.ts               ← 18 acciones (≈1.200 líneas)
│   ├── seo.ts                  ← 12 acciones (≈800 líneas)
│   ├── code-editing.ts         ← 8 acciones (≈1.000 líneas)
│   ├── store-management.ts     ← 25 acciones (≈1.400 líneas)
│   ├── memory-and-brain.ts     ← 18 acciones (≈900 líneas)
│   └── reports-and-audits.ts   ← 32 acciones (≈1.800 líneas)
└── shared/
    ├── types.ts                ← ActionResult, ActionParams, etc
    └── constants.ts            ← prompts del sistema, modelos Claude
```

Total: **9.661 líneas → ~9.050 líneas distribuidas** (código se reduce ligeramente al eliminar duplicación de imports y helpers).

---

## Distribución de las 148 acciones

### `handlers/products.ts` (35 acciones)
```
list_products, get_product, search_product, audit_product, audit_store,
create_product, create_product_from_image, duplicate_product,
delete_product, update_product, publish_product, unpublish_product,
change_price, update_stock, update_inventory, list_variants,
create_variant, delete_variant, fusion_analyze, fusion_create_product,
optimize_product, optimize_all_products, redesign_product, apply_redesign,
bulk_redesign, bulk_update_prices, bulk_update_stock, fix_unpublished,
fix_missing_compare_prices, sync_catalog_prices, import_products,
generate_ai_product, suggest_product, analyze_product, export_products
```

### `handlers/images.ts` (18 acciones)
```
generate_product_images, generate_images_from_reference, virtual_tryon,
bulk_generate_images, replace_product_image, reorder_images,
delete_product_image, optimize_images, generate_logo, generate_favicon,
generate_hero_image, brand_mood_board, generate_lookbook,
generate_promo_image, absorb_image, enhance_image,
ai_image_from_text, ai_product_photoshoot
```

### `handlers/seo.ts` (12 acciones)
```
seo_full_audit, fix_all_alt_texts, generate_all_metas,
optimize_product_seo, generate_sitemap, audit_page_speed,
generate_schema_markup, optimize_headings, generate_internal_links,
check_broken_links, audit_redirects, schema_validator
```

### `handlers/code-editing.ts` (8 acciones)
```
fix_code, modify_ui, inspect_code, list_source_files,
analyze_component, edit_theme_file, edit_theme_css, edit_theme_settings,
create_theme_section, sync_store_theme
```

### `handlers/store-management.ts` (25 acciones)
```
store_status, setup_full_store, configure_shipping, configure_payments,
configure_taxes, configure_checkout, audit_store_settings,
list_collections, create_collection, delete_collection, auto_collections,
design_all_pages, create_page, edit_page, list_pages,
list_customers, customer_details, segment_customers,
list_orders, order_details, fulfill_order, cancel_order,
list_discounts, create_discount, delete_discount
```

### `handlers/memory-and-brain.ts` (18 acciones)
```
brain_status, brain_recall, brain_learn, brain_forget,
list_memories, create_memory, update_memory, delete_memory,
list_insights, search_knowledge_graph, export_brain,
session_summary, list_sessions, niches_overview,
vault_status, vault_list, vault_save, vault_retrieve,
run_leveled_report, generate_ai_report
```

### `handlers/reports-and-audits.ts` (32 acciones)
```
run_full_audit_report, financial_dashboard, financial_forecast,
generate_budget, generate_platform_report, agency_quote,
agency_proposal, diagnose_app, audit_app_offerings,
copyright_audit, generate_competitive_pricing, analyze_external_store,
external_pre_report, auto_estimate_all_cogs, scan_store,
create_ab_test, declare_winner, ab_test_status,
generate_email_flow, send_test_email, reset_email_flow,
reset_cms, activate_cms, sync_cms, platform_health,
export_all_data, import_all_data, backup_project,
restore_project, analyze_contact_lead, generate_quote_pdf,
schedule_audit, cancel_scheduled_audit
```

---

## Patrón para cada handler

Cada `handlers/*.ts` exporta una única función que procesa su categoría:

```typescript
// handlers/products.ts
import type { Request } from "express";
import type { ActionResult, ActionContext } from "../shared/types.js";
import { db, projectsTable } from "@workspace/db";
// ... imports necesarios ...

export async function handleProductAction(
  action: string,
  params: Record<string, unknown>,
  ctx: ActionContext,
): Promise<ActionResult | null> {
  switch (action) {
    case "list_products": {
      // ... código actual del case list_products ...
      return { message: "...", products: [...] };
    }
    case "audit_store": {
      // ... código actual ...
      return { message: "...", ... };
    }
    // ... 33 cases más ...
    default:
      return null; // acción no reconocida por este handler
  }
}

// Lista de acciones que maneja este módulo — para el dispatcher
export const PRODUCT_ACTIONS = new Set([
  "list_products", "get_product", "search_product", "audit_product",
  // ... resto ...
]);
```

---

## Dispatcher central — `shopybrain/index.ts`

```typescript
import { Router, type Request, type Response } from "express";
import { requireAuth } from "../../lib/auth.js";
import type { ActionContext } from "./shared/types.js";

// Importar cada handler + su action set
import { handleProductAction, PRODUCT_ACTIONS } from "./handlers/products.js";
import { handleImageAction, IMAGE_ACTIONS } from "./handlers/images.js";
import { handleSeoAction, SEO_ACTIONS } from "./handlers/seo.js";
import { handleCodeEditingAction, CODE_EDITING_ACTIONS } from "./handlers/code-editing.js";
import { handleStoreManagementAction, STORE_MANAGEMENT_ACTIONS } from "./handlers/store-management.js";
import { handleMemoryAction, MEMORY_ACTIONS } from "./handlers/memory-and-brain.js";
import { handleReportsAction, REPORTS_ACTIONS } from "./handlers/reports-and-audits.js";

const router = Router();

// Dispatcher: enruta cada acción al handler correcto según su nombre
router.post("/execute-action", requireAuth, async (req: Request, res: Response) => {
  try {
    const { action, params } = req.body as { action: string; params?: Record<string, unknown> };
    if (!action) { res.status(400).json({ error: "action requerido" }); return; }

    const ctx: ActionContext = { req, res, params: params ?? {} };
    let result = null;

    if (PRODUCT_ACTIONS.has(action))        result = await handleProductAction(action, params ?? {}, ctx);
    else if (IMAGE_ACTIONS.has(action))     result = await handleImageAction(action, params ?? {}, ctx);
    else if (SEO_ACTIONS.has(action))       result = await handleSeoAction(action, params ?? {}, ctx);
    else if (CODE_EDITING_ACTIONS.has(action)) result = await handleCodeEditingAction(action, params ?? {}, ctx);
    else if (STORE_MANAGEMENT_ACTIONS.has(action)) result = await handleStoreManagementAction(action, params ?? {}, ctx);
    else if (MEMORY_ACTIONS.has(action))    result = await handleMemoryAction(action, params ?? {}, ctx);
    else if (REPORTS_ACTIONS.has(action))   result = await handleReportsAction(action, params ?? {}, ctx);
    else {
      res.status(400).json({ error: `Acción desconocida: ${action}` });
      return;
    }

    res.json(result ?? { error: true, message: `La acción ${action} no devolvió resultado` });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: true, message: msg });
  }
});

// Resto de rutas del shopybrain (search, memories, sessions, etc) quedan aquí
// o se mueven a otro router según convenga.
export default router;
```

---

## Plan de migración paso a paso

### Fase 1 — Estructura (1h)
1. Crear carpeta `routes/shopybrain/`.
2. Crear `routes/shopybrain/shared/types.ts` con las interfaces compartidas.
3. Crear `routes/shopybrain/shared/constants.ts` con los prompts del sistema.
4. Crear el `routes/shopybrain/index.ts` esqueleto.
5. Mover los helpers comunes (ya creados en `lib/shopybrain-helpers.ts`).

### Fase 2 — Migrar un handler de prueba (2h)
Empieza por el más pequeño (`handlers/seo.ts` con 12 acciones):
1. Crear el archivo con la estructura del patrón.
2. Mover los 12 cases correspondientes del `shopybrain.ts` original.
3. Ajustar imports.
4. En `shopybrain.ts` original, añadir al inicio del switch:
   ```typescript
   if (SEO_ACTIONS.has(action)) {
     const seoResult = await handleSeoAction(action, params, { req, res, params });
     if (seoResult) { result = seoResult; break; }
   }
   ```
5. Eliminar los 12 cases originales del shopybrain.ts.
6. `pnpm typecheck && pnpm dev`.
7. Probar manualmente: `fix_all_alt_texts`, `generate_all_metas`, `audit_page_speed`.

### Fase 3 — Migrar los 6 handlers restantes (1 día)
Repetir el proceso para los otros 6 módulos, en este orden:
1. `handlers/memory-and-brain.ts` (18 acciones, baja dependencia)
2. `handlers/images.ts` (18 acciones)
3. `handlers/store-management.ts` (25 acciones)
4. `handlers/products.ts` (35 acciones, el más grande)
5. `handlers/reports-and-audits.ts` (32 acciones)
6. `handlers/code-editing.ts` (8 acciones, incluye CRIT-1 y CRIT-5)

Tras cada handler: **commit, typecheck, test manual de 3-5 acciones aleatorias de ese módulo.**

### Fase 4 — Eliminar shopybrain.ts original (30 min)
1. Una vez todas las acciones estén en sus handlers, el `shopybrain.ts` original
   debería haber quedado solo con las rutas no-action (como `/search`, `/memories`, etc).
2. Mover esas rutas al nuevo `routes/shopybrain/index.ts`.
3. Borrar `shopybrain.ts` original.
4. En `routes/index.ts`, cambiar:
   ```typescript
   import shopybrainRouter from "./shopybrain.js";
   ```
   Por:
   ```typescript
   import shopybrainRouter from "./shopybrain/index.js";
   ```

### Fase 5 — Tests básicos por handler
Idealmente, añadir un test unitario por handler que verifique que las
acciones principales no crashean con inputs válidos. Mínimo 1 test por handler.

---

## Tiempo total estimado

- **Fase 1 — estructura:** 1h
- **Fase 2 — primer handler (prueba):** 2h
- **Fase 3 — 6 handlers restantes:** 8h
- **Fase 4 — cleanup:** 0.5h
- **Fase 5 — tests mínimos:** 3h

**Total: 14-16 horas de trabajo concentrado**, distribuible en 2-3 días.

---

## Beneficios medibles tras el refactor

| Métrica | Antes | Después |
|---|---|---|
| Líneas por archivo más grande | 9.661 | ~1.800 |
| Tiempo de `pnpm typecheck` (solo este file) | ~8s | ~1.5s por módulo |
| Review de PR promedio | imposible | viable |
| Tests posibles | integración | unitarios por módulo |
| Conflictos de merge en Git | muy frecuentes | raros |

---

## Dependencias entre acciones

Algunas acciones se llaman unas a otras (ej: `bulk_redesign` llama a `redesign_product` internamente). El refactor debe preservar esto:

```typescript
// handlers/products.ts
case "bulk_redesign": {
  // ...
  for (const productId of productIds) {
    // En vez de llamar recursivamente al dispatcher,
    // invocar la función interna directamente:
    const res = await redesignSingleProduct(projectId, productId);
    // ...
  }
}

// Función extraída (ya existe en el código original pero como case):
async function redesignSingleProduct(projectId: number, productId: string) { /*...*/ }
```

**Regla:** si una acción llama a otra, ambas **deben estar en el mismo handler** o la función interna debe exportarse.

---

## Alternativa: split parcial

Si 14h es demasiado, puedes hacer un split más pequeño:
- Solo extraer `code-editing.ts` (los 8 cases más sensibles, los que tocan archivos del workspace).
- Eso ya te da 1.000 líneas menos en el monolito y aisla las acciones críticas.

Tiempo: **2-3 horas** en vez de 14.
